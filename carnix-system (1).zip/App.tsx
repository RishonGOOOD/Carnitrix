
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AppProvider, useAppContext } from './context';
import { Mode, Profile, Message, SystemState } from './types';

// UI Components
import Sidebar from './components/Sidebar';
import SystemStatusBar from './components/SystemStatusBar';
import Dashboard from './components/Dashboard';
import ChatPanel from './components/ChatPanel';
import VisionHubPanel from './components/VisionHubPanel';
import GeoIntelPanel from './components/GeoIntelPanel';
import LocalDatabanksPanel from './components/LocalDatabanksPanel';
import SettingsPanel from './components/SettingsPanel';
import ErrorBoundary from './components/ErrorBoundary';
import TopBar from './components/TopBar';
import FloatingExit from './components/FloatingExit';
import DriverPanel from './components/DriverPanel';
import PanelsHubPanel from './components/PanelsHubPanel';
import AppMatrixPanel from './components/AppMatrixPanel';
import DiagnosticsPanel from './components/DiagnosticsPanel';
import AppLauncherPanel from './components/AppLauncherPanel';
import CameraView from './components/CameraView';
import NewsPanel from './components/NewsPanel';
import TaskSchedulerPanel from './components/TaskSchedulerPanel';
import NotesPanel from './components/NotesPanel';
import WebBrowserPanel from './components/WebBrowserPanel';
import AIModelRegistryPanel from './components/AIModelRegistryPanel';
import GlobalSearchPanel from './components/GlobalSearchPanel';
import EthicalHackingPanel from './components/EthicalHackingPanel';
import TacticalDeploymentPanel from './components/TacticalDeploymentPanel';
import HealthPanel from './components/HealthPanel';
import StellarCartographyPanel from './components/StellarCartographyPanel';
import SecureCommsPanel from './components/SecureCommsPanel';
import SubspaceCommsPanel from './components/SubspaceCommsPanel';
import DevConsolePanel from './components/DevConsolePanel';
import AudioLabPanel from './components/AudioLabPanel';
import WeatherRadarPanel from './components/WeatherRadarPanel';
import FlightTrackerPanel from './components/FlightTrackerPanel';
import DroneControlPanel from './components/DroneControlPanel';
import SystemCorePanel from './components/SystemCorePanel';
import CyberneticsPanel from './components/CyberneticsPanel';
import ProfileManagerPanel from './components/ProfileManagerPanel';
import WebIntelligencePanel from './components/WebIntelligencePanel';
import CryptoPanel from './components/CryptoPanel';
import DeviceScanPanel from './components/DeviceScanPanel';
import WorldStatusPanel from './components/WorldStatusPanel';
import GroupChatPanel from './components/GroupChatPanel';
import RecoveryBackupPanel from './components/RecoveryBackupPanel';
import GenericUtilityPanel from './components/GenericUtilityPanel';
import MicrocontrollerPanel from './components/MicrocontrollerPanel';
import AudioVoicePanel from './components/AudioVoicePanel';
import HFModelHubPanel from './components/HFModelHubPanel';
import HuggingFaceHubPanel from './components/HuggingFaceHubPanel';
import SubstrateCPanel from './components/SubstrateCPanel';

import HighSpeedObjectRecognitionPanel from './components/HighSpeedObjectRecognitionPanel';
import DeepOsintAiPanel from './components/DeepOsintAiPanel';
import FreeAiGithubHubPanel from './components/FreeAiGithubHubPanel';

// Production Modular CARNIX Panels
import ToolDiscoveryPanel from './components/ToolDiscoveryPanel';
import SecurityEnginePanel from './components/SecurityEnginePanel';
import EvidenceEnginePanel from './components/EvidenceEnginePanel';
import InvestigationWorkspacePanel from './components/InvestigationWorkspacePanel';
import ReportEnginePanel from './components/ReportEnginePanel';
import SecureTerminalPanel from './components/SecureTerminalPanel';
import NetworkAnalyzerPanel from './components/NetworkAnalyzerPanel';
import UnifiedOsintAggregatorPanel from './components/UnifiedOsintAggregatorPanel';
import TacticalDiagnosticsPanel from './components/TacticalDiagnosticsPanel';
import CarnixPlatformHub from './components/CarnixPlatformHub';
import AiToolsSuitePanel from './components/AiToolsSuitePanel';
import JarvisSensorsHub from './components/JarvisSensorsHub';

// Extended Legacy & Tactical Panels
import AIWorkspacePanel from './components/AIWorkspacePanel';
import CodeAssistantPanel from './components/CodeAssistantPanel';
import BallisticsCalculatorPanel from './components/BallisticsCalculatorPanel';
import DreamInterpreterPanel from './components/DreamInterpreterPanel';
import ForensicAnalysisPanel from './components/ForensicAnalysisPanel';
import ExoplanetDBPanel from './components/ExoplanetDBPanel';
import RoboticsControlPanel from './components/RoboticsControlPanel';
import SocialEngineeringToolkitPanel from './components/SocialEngineeringToolkitPanel';
import EmergencyServicesMonitorPanel from './components/EmergencyServicesMonitorPanel';
import GeothermalAnalysisPanel from './components/GeothermalAnalysisPanel';
import ChemicalAnalysisPanel from './components/ChemicalAnalysisPanel';
import LinguisticsTranslatorPanel from './components/LinguisticsTranslatorPanel';
import EconomicForecasterPanel from './components/EconomicForecasterPanel';
import QuantumSearchPanel from './components/QuantumSearchPanel';
import ThreatIntelPanel from './components/ThreatIntelPanel';
import MemoryVaultPanel from './components/MemoryVaultPanel';
import PsionicInterfacePanel from './components/PsionicInterfacePanel';
import StealthSystemsPanel from './components/StealthSystemsPanel';
import SignalInterceptPanel from './components/SignalInterceptPanel';
import RadioPanel from './components/RadioPanel';
import CalendarPanel from './components/CalendarPanel';
import ClimatePanel from './components/ClimatePanel';
import AccessControlPanel from './components/AccessControlPanel';
import MediaPanel from './components/MediaPanel';
import JournalPanel from './components/JournalPanel';
import LocationPanel from './components/LocationPanel';
import SatellitePanel from './components/SatellitePanel';
import PluginForgePanel from './components/PluginForgePanel';
import PluginHubPanel from './components/PluginHubPanel';
import HardwarePanel from './components/HardwarePanel';
import SystemLogPanel from './components/SystemLogPanel';
import { StorageSyncModal } from './components/StorageSyncModal';

import { getAIResponse } from './services/geminiService';
import { playSound } from './utils/soundEffects';
import { launchAndroidApp } from './utils/nativeBridge';
import { startAIDaemon, updateDaemonPulse } from './daemon/AIDaemon';
import { Zap } from 'lucide-react';

const MainApplication: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { mode, activeProfile, isStealthMode, isOnline } = state;
    const [isLoadingAI, setIsLoadingAI] = useState(false);
    const [isStorageModalOpen, setIsStorageModalOpen] = useState(false);
    const [isAndroidMode, setIsAndroidMode] = useState(false);
    const stateRef = useRef(state);

    useEffect(() => {
        stateRef.current = state;
        updateDaemonPulse();
    }, [state]);

    // AI Daemon Lifecycle
    useEffect(() => {
        if (activeProfile) {
            const getSysState = (): SystemState => ({
                isStealthMode: stateRef.current.isStealthMode,
                isOnline: stateRef.current.isOnline,
                performance: stateRef.current.performance
            });
            startAIDaemon(getSysState, dispatch, stateRef.current);
        }
    }, [activeProfile, dispatch]);

    // Global Key Hooks
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            updateDaemonPulse();
            if (e.altKey && e.key.toLowerCase() === 's') {
                e.preventDefault();
                dispatch({ type: 'TOGGLE_STEALTH' });
                playSound(isStealthMode ? 'access' : 'alert');
                dispatch({ type: 'ADD_LOG', payload: { source: 'GHOST', message: isStealthMode ? 'Stealth Protocol Terminated' : 'Stealth Protocol Engaged', level: 'warn' }});
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [dispatch, isStealthMode]);

    const handleNavigation = useCallback((m: Mode) => {
        if (m === mode) return;
        dispatch({ type: 'SET_MODE', payload: m });
        playSound('access');
        updateDaemonPulse();
    }, [dispatch, mode]);

    const handleCommand = async (text: string) => {
        if (!activeProfile) return;
        
        let chats = [...(activeProfile.chats || [])];
        let chatId = activeProfile.activeChatId;
        
        if (!chatId || !chats.find(c => c.id === chatId)) {
            chatId = `log-${Date.now()}`;
            const initialChat: ChatSession = {
                id: chatId,
                title: 'TACTICAL_OPERATIONS',
                createdAt: Date.now(),
                messages: [
                    {
                        id: Date.now() - 1000,
                        sender: 'carnix',
                        text: 'CARNIX_SYSTEM_ONLINE // VAMPIRE CORE v7.4\nMaster Operative, neural link synchronized. All 42 tactical subsystems armed and ready.'
                    }
                ]
            };
            chats = [initialChat, ...chats];
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats, activeChatId: chatId } });
        }

        const userMsg: Message = { id: Date.now(), sender: 'user', text };
        const updatedWithUser = chats.map(c => 
            c.id === chatId ? { ...c, messages: [...c.messages, userMsg] } : c
        );
        dispatch({ type: 'UPDATE_PROFILE', payload: { chats: updatedWithUser } });

        setIsLoadingAI(true);
        updateDaemonPulse();
        playSound('typing');

        const trimmed = text.trim();
        const upper = trimmed.toUpperCase();

        // Local Instant Commands
        if (upper === 'CLEAR') {
            const clearedChats = chats.map(c => c.id === chatId ? { ...c, messages: [] } : c);
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats: clearedChats } });
            setIsLoadingAI(false);
            playSound('success');
            return;
        }

        if (upper === 'STEALTH' || upper === 'GHOST') {
            dispatch({ type: 'TOGGLE_STEALTH' });
            const botMsg: Message = { id: Date.now() + 1, sender: 'carnix', text: `[GHOST PROTOCOL] Stealth state toggled. Invisibility filter: ${!isStealthMode ? 'ENGAGED' : 'DISENGAGED'}` };
            const nextChats = chats.map(c => c.id === chatId ? { ...c, messages: [...c.messages, userMsg, botMsg] } : c);
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats: nextChats } });
            setIsLoadingAI(false);
            playSound('access');
            return;
        }

        if (upper.startsWith('DEFCON')) {
            const level = upper.split(' ')[1] || '1';
            const botMsg: Message = { id: Date.now() + 1, sender: 'carnix', text: `[THREAT ALERT] Defense Condition set to DEFCON ${level}. Security perimeter hardened.` };
            const nextChats = chats.map(c => c.id === chatId ? { ...c, messages: [...c.messages, userMsg, botMsg] } : c);
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats: nextChats } });
            setIsLoadingAI(false);
            playSound('alert');
            return;
        }

        if (upper === 'HELP') {
            const helpText = `CARNIX TACTICAL HUD // COMMAND MATRIX:\n` +
                `• HELP - Display operational command directives\n` +
                `• CLEAR - Purge active buffer logs\n` +
                `• STEALTH - Toggle Ghost Protocol optical cloak\n` +
                `• DEFCON <1-5> - Escalate defense condition matrix\n` +
                `• START_EXCHANGE:<topic> - Initiate Substrate Tri-Engine Debate\n` +
                `• Natural Language Queries - Dispatched directly to Gemini 2.5 Tactical Core with real-time web search grounding`;
            const botMsg: Message = { id: Date.now() + 1, sender: 'carnix', text: helpText };
            const nextChats = chats.map(c => c.id === chatId ? { ...c, messages: [...c.messages, userMsg, botMsg] } : c);
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats: nextChats } });
            setIsLoadingAI(false);
            playSound('success');
            return;
        }
        
        try {
            if (text.startsWith('START_EXCHANGE:')) {
                const topic = text.replace('START_EXCHANGE:', '').trim();
                dispatch({ type: 'QUEUE_INTENT', payload: { type: 'START_AI_DEBATE', topic, rounds: 6 } });
                const msg: Message = { id: Date.now() + 1, sender: 'carnix', text: `PROTOCOL_INITIALIZED: Brokering tri-engine exchange for "${topic}"...` };
                const finalChats = chats.map(c => 
                    c.id === chatId ? { ...c, messages: [...c.messages, userMsg, msg] } : c
                );
                dispatch({ type: 'UPDATE_PROFILE', payload: { chats: finalChats } });
            } else {
                const currentChat = chats.find(c => c.id === chatId);
                const history = currentChat ? [...currentChat.messages, userMsg] : [userMsg];
                const response = await getAIResponse(text, mode, activeProfile.aiSettings, undefined, history);
                
                if (response.text.includes('OPEN_APP:')) {
                    const pkg = response.text.split('OPEN_APP:')[1].trim().split('\n')[0];
                    const msg: Message = { id: Date.now() + 1, sender: 'carnix', text: `PROTOCOL_INITIATED: Tunneling to ${pkg}...` };
                    const finalChats = chats.map(c => 
                        c.id === chatId ? { ...c, messages: [...c.messages, userMsg, msg] } : c
                    );
                    dispatch({ type: 'UPDATE_PROFILE', payload: { chats: finalChats } });
                    launchAndroidApp(pkg);
                } else {
                    const msg: Message = { id: Date.now() + 1, sender: 'carnix', text: response.text, urls: response.urls };
                    const finalChats = chats.map(c => 
                        c.id === chatId ? { ...c, messages: [...c.messages, userMsg, msg] } : c
                    );
                    dispatch({ type: 'UPDATE_PROFILE', payload: { chats: finalChats } });
                }
            }
            playSound('success');
        } catch {
            const errorMsg: Message = { id: Date.now() + 1, sender: 'carnix', text: `[COMM_RELAY_TIMEOUT] Master, localized defensive backup mode sustained.` };
            const finalChats = chats.map(c => 
                c.id === chatId ? { ...c, messages: [...c.messages, userMsg, errorMsg] } : c
            );
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats: finalChats } });
            playSound('error');
        } finally {
            setIsLoadingAI(false);
        }
    };

    const renderPanelContent = (m: Mode) => {
        const currentChat = activeProfile?.chats?.find(c => c.id === activeProfile?.activeChatId);
        const activeMessages = currentChat?.messages || [];

        switch (m) {
            case Mode.Home: return <Dashboard />;
            case Mode.Chat: return <div className="h-full max-w-5xl mx-auto"><ChatPanel messages={activeMessages} onChatSubmit={handleCommand} isLoading={isLoadingAI} /></div>;
            case Mode.DriverPanel: return <DriverPanel />;
            case Mode.PanelsHub: return <PanelsHubPanel />;
            case Mode.AppMatrix: return <AppMatrixPanel />;
            case Mode.Settings: return <SettingsPanel />;
            case Mode.Vision: return <HighSpeedObjectRecognitionPanel />;
            case Mode.AppLauncher: return <AppLauncherPanel />;
            case Mode.Browser: return <WebBrowserPanel />;
            case Mode.News: return <NewsPanel aiSettings={activeProfile!.aiSettings} address={state.address} />;
            case Mode.Tasks: return <TaskSchedulerPanel />;
            case Mode.Notes: return <NotesPanel />;
            case Mode.Geo: return <GeoIntelPanel />;
            case Mode.Diagnostics: return <DiagnosticsPanel />;
            case Mode.Files: return <LocalDatabanksPanel />;
            case Mode.AIModelRegistry: return <AIModelRegistryPanel />;
            case Mode.GlobalSearch: return <GlobalSearchPanel />;
            case Mode.EthicalHacking: return <NetworkAnalyzerPanel />;
            case Mode.Tactical: return <TacticalDeploymentPanel />;
            case Mode.Health: return <HealthPanel />;
            case Mode.StellarCartography: return <StellarCartographyPanel />;
            case Mode.SecureComms: return <SecureCommsPanel />;
            case Mode.SubspaceComms: return <SubspaceCommsPanel />;
            case Mode.Terminal: return <SecureTerminalPanel />;
            case Mode.AudioLab: return <AudioLabPanel />;
            case Mode.WeatherRadar: return <WeatherRadarPanel />;
            case Mode.FlightTracker: return <FlightTrackerPanel />;
            case Mode.DriveControl: return <DroneControlPanel />;
            case Mode.SystemCore: return <SystemCorePanel profile={activeProfile!} onUpdateProfile={(u) => dispatch({type:'UPDATE_PROFILE', payload:u})} addMessage={()=>{}} isConnected={state.isOnline} />;
            case Mode.Cybernetics: return <CyberneticsPanel />;
            case Mode.ProfileManager: return <ProfileManagerPanel />;
            case Mode.WebIntelligence: return <WebIntelligencePanel />;
            case Mode.Crypto: return <CryptoPanel />;
            case Mode.Sensors: return <DeviceScanPanel />;
            case Mode.WorldStatus: return <WorldStatusPanel />;
            case Mode.GroupChat: return <GroupChatPanel />;
            case Mode.RecoveryBackup: return <RecoveryBackupPanel />;
            case Mode.Microcontroller: return <MicrocontrollerPanel />;
            case Mode.GPTLogic: return <FreeAiGithubHubPanel />;
            case Mode.HFModelHub: return <HuggingFaceHubPanel />;
            case Mode.AudioVoice: return <AudioVoicePanel addMessage={()=>{}} startSession={()=>{}} stopSession={()=>{}} isSessionActive={false} currentProfile={activeProfile!} outputAudioContext={null} outputAudioSources={{current: new Set()}} nextStartTimeRef={{current:0}} registerCallbacks={()=>{}} />;
            
            // Real GitHub Open-Source AI Engines
            case Mode.ObjectRecognition: return <HighSpeedObjectRecognitionPanel />;
            case Mode.DeepOsintAI: return <DeepOsintAiPanel />;
            case Mode.FreeAiGithubHub: return <FreeAiGithubHubPanel />;

            // Production Modular CARNIX Panels
            case Mode.UnifiedOsintAggregator: return <UnifiedOsintAggregatorPanel />;
            case Mode.TacticalDiagnostics: return <TacticalDiagnosticsPanel />;
            case Mode.CarnixPlatformHub: return <CarnixPlatformHub />;
            case Mode.AiToolsSuite: return <AiToolsSuitePanel />;
            case Mode.JarvisSensors: return <JarvisSensorsHub />;
            case Mode.ToolDiscovery: return <ToolDiscoveryPanel />;
            case Mode.McpHub: return <ToolDiscoveryPanel defaultTab="mcp" />;
            case Mode.SecurityEngine: return <SecurityEnginePanel />;
            case Mode.EvidenceEngine: return <EvidenceEnginePanel />;
            case Mode.InvestigationWorkspace: return <InvestigationWorkspacePanel />;
            case Mode.ReportEngine: return <ReportEnginePanel />;

            // Restored Specialized & Real Panels
            case Mode.Workspace: return <AIWorkspacePanel />;
            case Mode.CodeAssistant: return <CodeAssistantPanel addMessage={() => {}} />;
            case Mode.BallisticsCalculator: return <BallisticsCalculatorPanel />;
            case Mode.DreamInterpreter: return <FreeAiGithubHubPanel />;
            case Mode.ForensicAnalysis: return <ForensicAnalysisPanel />;
            case Mode.ExoplanetDB: return <FreeAiGithubHubPanel />;
            case Mode.RoboticsControl: return <RoboticsControlPanel />;
            case Mode.SocialEngineeringToolkit: return <DeepOsintAiPanel />;
            case Mode.EmergencyServicesMonitor: return <EmergencyServicesMonitorPanel />;
            case Mode.GeothermalAnalysis: return <GeothermalAnalysisPanel />;
            case Mode.ChemicalAnalysis: return <DeepOsintAiPanel />;
            case Mode.LinguisticsTranslator: return <LinguisticsTranslatorPanel />;
            case Mode.EconomicForecaster: return <EconomicForecasterPanel />;
            case Mode.QuantumSearch: return <QuantumSearchPanel />;
            case Mode.ThreatIntel: return <ThreatIntelPanel />;
            case Mode.MemoryVault: return <MemoryVaultPanel />;
            case Mode.PsionicInterface: return <FreeAiGithubHubPanel />;
            case Mode.StealthSystems: return <StealthSystemsPanel />;
            case Mode.SignalIntercept: return <SignalInterceptPanel />;
            case Mode.Radio: return <RadioPanel />;
            case Mode.Calendar: return <CalendarPanel />;
            case Mode.Climate: return <ClimatePanel />;
            case Mode.AccessControl: return <AccessControlPanel />;
            case Mode.Media: return <MediaPanel />;
            case Mode.Journal: return <JournalPanel />;
            case Mode.Location: return <LocationPanel />;
            case Mode.Satellite: return <SatellitePanel />;
            case Mode.PluginForge: return <PluginForgePanel />;
            case Mode.PluginHub: return <PluginHubPanel />;
            case Mode.Hardware: return <HardwarePanel />;
            case Mode.Logs: return <SystemLogPanel logs={state.systemLog} onClearLogs={() => {}} />;

            default: return <GenericUtilityPanel mode={m} />;
        }
    };

    return (
        <div className={`bg-[#040002] h-screen w-screen flex flex-col overflow-hidden text-white font-[Rajdhani] select-none ${isStealthMode ? 'grayscale brightness-[0.4] contrast-125' : ''}`}>
            {/* 1. Header Bar: Full width, zero overlap */}
            <TopBar 
                onOpenSettings={() => handleNavigation(Mode.Settings)} 
                onOpenMatrix={() => handleNavigation(Mode.PanelsHub)}
                onOpenStorage={() => setIsStorageModalOpen(true)}
                isAndroidMode={isAndroidMode}
                onToggleAndroidMode={() => setIsAndroidMode(!isAndroidMode)}
            />

            {/* Android Phone View Wrapper or Fullscreen Workstation */}
            {isAndroidMode ? (
                <div className="flex-1 flex items-center justify-center p-2 sm:p-6 bg-gradient-to-b from-[#110206] to-[#020001] overflow-hidden">
                    <div className="w-full max-w-sm h-[92vh] max-h-[880px] bg-black border-[6px] border-[#222] rounded-[42px] shadow-[0_0_50px_rgba(255,0,0,0.2)] flex flex-col overflow-hidden relative ring-1 ring-red-500/30">
                        {/* Android Status Bar */}
                        <div className="bg-black text-gray-400 px-6 py-1.5 flex items-center justify-between text-[11px] font-mono select-none shrink-0 z-50 border-b border-white/5">
                            <span className="text-white font-bold">02:14</span>
                            {/* Camera Punch-hole */}
                            <div className="w-3 h-3 bg-[#111] rounded-full border border-[#333] absolute left-1/2 -translate-x-1/2 top-1.5"></div>
                            <div className="flex items-center gap-2 text-[10px]">
                                <span className="text-red-400 font-bold">5G</span>
                                <span>98%</span>
                            </div>
                        </div>

                        {/* Inner Android App Container */}
                        <div className="flex-1 flex flex-row overflow-hidden relative">
                            <Sidebar onNavigate={handleNavigation} />
                            <main className="flex-1 flex flex-col overflow-y-auto bg-black/50 relative p-1">
                                {renderPanelContent(mode)}
                            </main>
                        </div>

                        {/* Android Bottom Navigation Gesture Bar */}
                        <div className="h-6 bg-black flex items-center justify-center shrink-0 z-50 border-t border-white/5">
                            <div className="w-32 h-1 bg-gray-600 rounded-full"></div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="flex-1 flex flex-row overflow-hidden relative">
                    <Sidebar onNavigate={handleNavigation} />
                    <main className="flex-1 flex flex-col overflow-y-auto bg-black/40 relative p-1 sm:p-2">
                        {renderPanelContent(mode)}
                    </main>
                </div>
            )}

            {/* 3. Pinned Bottom Telemetry Bar */}
            <SystemStatusBar />
            <StorageSyncModal isOpen={isStorageModalOpen} onClose={() => setIsStorageModalOpen(false)} />
        </div>
    );
};

const BootSequence: React.FC = () => {
    const { dispatch } = useAppContext();
    const [progress, setProgress] = useState(0);

    const finishBoot = useCallback(() => {
        playSound('access');
        const saved = localStorage.getItem('carnix_master_profile');
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                if (!parsed.chats || parsed.chats.length === 0) {
                    parsed.chats = [{
                        id: 'log-main',
                        title: 'TACTICAL_OPERATIONS',
                        createdAt: Date.now(),
                        messages: [{
                            id: Date.now(),
                            sender: 'carnix',
                            text: 'CARNIX_SYSTEM_ONLINE // VAMPIRE CORE v7.4\nMaster Operative recognized. Neural telemetry synchronized. All 42 tactical subsystems armed and ready.'
                        }]
                    }];
                    parsed.activeChatId = 'log-main';
                }
                if (parsed.aiSettings) {
                    parsed.aiSettings.engine = 'GEMINI_CLOUD';
                    parsed.aiSettings.model = 'gemini-2.5-flash';
                }
                dispatch({ type: 'SET_PROFILE', payload: parsed });
                return;
            } catch {
                // fall through
            }
        }
        const master: Profile = {
            id: 'carnix-node-main',
            name: 'MASTER_OPERATIVE',
            speciality: 'Tactical Overlord',
            nodeCreatedAt: Date.now(),
            aiEvolutionLevel: 1,
            chats: [{
                id: 'log-main',
                title: 'TACTICAL_OPERATIONS',
                createdAt: Date.now(),
                messages: [{
                    id: Date.now(),
                    sender: 'carnix',
                    text: 'CARNIX_SYSTEM_ONLINE // VAMPIRE CORE v7.4\nMaster Operative recognized. Neural telemetry synchronized. All 42 tactical subsystems armed and ready.'
                }]
            }],
            activeChatId: 'log-main',
            nexusLinks: [],
            aiSettings: { 
                engine: 'GEMINI_CLOUD',
                model: 'gemini-2.5-flash', 
                personality: 'CARNIX Tactical OS (Vampire Core)', 
                useSearchGrounding: true, 
                useThinking: false, 
                textToSpeechEnabled: true, 
                speechSpeed: 1.1, 
                voiceName: 'Zephyr', 
                temperature: 0.6,
                useLocalModel: false,
                isLocalModelLoaded: false,
                localEndpoint: 'http://localhost:8080',
                contextWindow: 8192,
                gpuLayers: 32
            },
            uiSettings: { primaryColor: '#FF0000', accentColor: '#00F0FF', glowIntensity: 100, showScanlines: true, hudPosition: 'standard', codeRainDensity: 50, uiScale: 100, soundVolume: 80, hapticEnabled: true },
            notes: [], 
            tasks: [], 
            systemLog: [], 
            features: [], 
            contacts: [], 
            events: [], 
            journal: [], 
            usageMetrics: {},
            launcherApps: [], 
            registeredModels: [],
            automations: [],
            plugins: [],
            nanobotSwarm: { status: 'STANDBY', activeCount: 12400, efficiency: 98, currentTask: 'Perimeter Recon' },
            activeTheme: 'crimson_eclipse',
            customThemes: {}
        };
        dispatch({ type: 'SET_PROFILE', payload: master });
    }, [dispatch]);

    useEffect(() => {
        playSound('scan');
        const timer = setInterval(() => {
            setProgress(old => {
                const next = Math.min(100, old + 2.5);
                if (next === 100) {
                    clearInterval(timer);
                    setTimeout(finishBoot, 150);
                }
                return next;
            });
        }, 30);
        return () => clearInterval(timer);
    }, [finishBoot]);

    return (
        <div className="fixed inset-0 bg-black z-[9999] flex flex-col items-center justify-center font-orbitron overflow-hidden select-none">
            <div className="relative z-20 w-full max-w-sm p-8 flex flex-col gap-8 items-center">
                <div className="p-6 bg-red-600/90 rounded-3xl shadow-[0_0_80px_rgba(255,0,0,0.8)] border border-red-400 animate-pulse cursor-pointer" onClick={finishBoot} title="Click to Fast Boot">
                    <Zap size={64} className="text-black fill-black" />
                </div>
                <div className="w-full space-y-4">
                    <div className="flex justify-between text-[11px] font-black text-red-500 uppercase tracking-[0.4em]">
                        <span>CARNIX_BOOT_SEQUENCE</span>
                        <span>{Math.floor(progress)}%</span>
                    </div>
                    <div className="w-full h-2 bg-red-950/80 rounded-full overflow-hidden border border-red-600/40 p-0.5">
                        <div className="h-full bg-gradient-to-r from-red-700 via-red-500 to-cyan-400 shadow-[0_0_25px_red] transition-all duration-150 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
                <div className="flex flex-col items-center gap-2">
                    <div className="text-[9px] font-mono text-red-400 uppercase tracking-widest animate-pulse text-center">SYNCHRONIZING TACTICAL NEURAL SUBSTRATE...</div>
                    <button 
                        onClick={finishBoot}
                        className="text-[10px] text-gray-500 hover:text-red-400 font-mono tracking-widest uppercase underline underline-offset-4 transition-colors pt-2"
                    >
                        [BYPASS_INITIALIZATION // FAST_LAUNCH]
                    </button>
                </div>
            </div>
        </div>
    );
};

export const App: React.FC = () => (
    <ErrorBoundary>
        <AppProvider>
            <RegistryGate />
        </AppProvider>
    </ErrorBoundary>
);

const RegistryGate: React.FC = () => {
    const { state } = useAppContext();
    return !state.activeProfile ? <BootSequence /> : <MainApplication />;
};
