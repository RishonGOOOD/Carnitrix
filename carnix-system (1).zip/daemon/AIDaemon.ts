import { Dispatch } from 'react';
import { Action, AppState } from '../context';
import { IntentEngine } from '../ai/IntentEngine';
import { StealthFilter } from '../ai/StealthFilter';
import { startAIExchange, stopAIExchange } from '../ai/AIExchangeLoop';
import { launchAndroidApp } from '../utils/nativeBridge';
import { SystemState, Intent } from '../types';

/**
 * CARNIX AI DAEMON (Headless Heartbeat) v1.4
 * Autonomous intent broker and idle optimization manager.
 * Phase 7.1.C: Includes stagnation detection.
 */

let running = false;
let lastUserActivity = Date.now();

export const startAIDaemon = (getState: () => SystemState, dispatch: Dispatch<Action>, fullState: AppState) => {
    if (running) return;
    running = true;
    console.log("[DAEMON] Headless substrate heartbeat active.");

    const loop = async () => {
        const state = getState();
        const currentTime = Date.now();
        
        // 1. Idle Detection: detect stagnation > 5 minutes (300,000 ms)
        if (currentTime - lastUserActivity > 300000 && !fullState.daemonState.isExchanging) {
            console.log("[DAEMON] Stagnation detected. Triggering optimization debate.");
            dispatch({ 
                type: 'QUEUE_INTENT', 
                payload: { 
                    type: 'START_AI_DEBATE', 
                    topic: 'Analyze current OS resource allocation and suggest neural path optimizations based on Master activity patterns.', 
                    rounds: 2 
                } 
            });
            // Prevent immediate re-trigger by updating pulse
            updateDaemonPulse();
        }

        // 2. Fetch system signals
        const intents = IntentEngine.fromSystemEvent("IDLE_PULSE");
        
        // 3. Pass through Stealth Policy (MANDATORY)
        const filtered = StealthFilter.process(intents, state);

        // 4. Execute Autonomous Intents
        for (const intent of filtered) {
            await executeIntent(intent, dispatch, fullState, state);
        }

        // 5. Handle Context-level Intent Queue (Manual triggers like START_EXCHANGE)
        // Note: The loop needs to check the live state from context, so we might need a more reactive way,
        // but for now, we process queue on heartbeat.
        if (fullState.intentQueue.length > 0) {
            const nextIntent = fullState.intentQueue[0];
            dispatch({ type: 'CLEAR_INTENT_QUEUE' });
            await executeIntent(nextIntent, dispatch, fullState, state);
        }

        // Heartbeat pulse: 30 seconds
        setTimeout(loop, fullState.daemonState.heartbeatInterval);
    };

    loop();
};

const executeIntent = async (intent: Intent, dispatch: Dispatch<Action>, appState: AppState, sysState: SystemState) => {
    switch (intent.type) {
        case 'LAUNCH_APP':
            await launchAndroidApp(intent.package);
            break;
        case 'SPEAK':
            dispatch({ type: 'ADD_MESSAGE', payload: { id: Date.now(), sender: 'carnix', text: intent.text } });
            break;
        case 'START_AI_DEBATE':
            await startAIExchange(intent.topic, intent.rounds, appState, dispatch);
            break;
        case 'NOTIFY':
            if ("Notification" in window && Notification.permission === "granted") {
                new Notification(intent.title, { body: intent.body });
            }
            dispatch({ type: 'ADD_LOG', payload: { source: 'DAEMON', message: `[${intent.title}] ${intent.body}`, level: 'info' } });
            break;
        case 'SILENT_LOG':
            dispatch({ type: 'ADD_LOG', payload: { source: intent.source, message: `Substrate Sync: ${JSON.stringify(intent.data)}`, level: 'info' } });
            break;
    }
};

export const updateDaemonPulse = () => {
    lastUserActivity = Date.now();
};
