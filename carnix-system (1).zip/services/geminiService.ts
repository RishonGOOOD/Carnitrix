
import { GoogleGenAI } from "@google/genai";
import { Mode, AIModelSettings, Message, Profile, Address } from '../types';
import { getHuggingFaceResponse, getHFVisionAnalysis } from './huggingFaceService';

/**
 * CARNIX_NEURAL_ROUTING: High-speed tasks hit HF (Llama), Logic/Oversight hits Gemini.
 * Includes Ultra-Fast In-Memory LRU Cache & Instant Tactical Responders for 0ms latency.
 */

// In-Memory Instant Cache Layer
const INSTANT_AI_CACHE = new Map<string, { text: string; urls?: any[]; timestamp: number }>();
const CACHE_TTL_MS = 1000 * 60 * 15; // 15 minutes

// Instant Tactical Knowledge Base for 0ms response times
const INSTANT_HEURISTICS: Record<string, string> = {
    'STATUS': '⚡ [CARNIX STATUS REPORT]\n• Tactical Core: OPTIMAL (60 FPS)\n• Defense Matrix: ACTIVE (DEFCON 1)\n• Open-Source AI Engines: YOLOv11, MediaPipe, OSINT Deep Trace SYNCHRONIZED\n• Memory Footprint: LOW LATENCY\n• Neural Relay: MASTER LINK UNBROKEN',
    'SCAN': '🛰️ [PERIMETER SCAN COMPLETE]\n• Electro-Optical Radar: All sectors clear\n• RF Intercept: No rogue transmissions detected\n• Local Subnets: 0 intrusion vectors detected\n• Ground Sensors: Nominal telemetry confirmed',
    'DIAGNOSTICS': '🛡️ [KERNEL AUDIT REPORT]\n• CPU/GPU Compute: Edge acceleration enabled\n• Cryptographic Substrate: SHA-256 / AES-256 verified\n• Real-Time OSINT Engine: 40+ endpoints online\n• Sensor Array: Geothermal, ADS-B, Doppler Radar active',
    'HEALTH': '❤️ [BIOMETRIC TELEMETRY]\n• Operative Status: VITAL SIGNS NOMINAL\n• Cognitive Load: NORMAL\n• Neural Relay Bandwidth: 10 Gbps encrypted link\n• System Temperature: 38.2°C (Stabilized)',
    'RECON': '🌐 [GLOBAL RECON SYNTHESIS]\n• OSINT Feeds: Global DNS-over-HTTPS, IP ASN, Satellite, & Social Recon online\n• Vision AI: 60 FPS YOLOv11 Multi-target tracking armed\n• Firing Computer: 6-DOF trajectory engine calibrated',
    'WHO ARE YOU': '👑 [CARNIX OS // VAMPIRE PROTOCOL v7.4]\nI am CARNIX, Master\'s proprietary futuristic tactical intelligence operating system. Powered by integrated Google DeepMind models and open-source GitHub AI engines (Ultralytics YOLO, MediaPipe, Sherlock OSINT, Doppler, and Kinematics). At your command, Master.'
};

export interface DynamicLiveAudioCallbacks {
    onOutputAudio: (base64Audio: string) => void;
    onInputTranscription: (text: string) => void;
    onOutputTranscription: (text: string) => void;
    onTurnComplete: (fullInput: string, fullOutput: string) => void;
    onInterrupt: () => void;
    onError: (e: any) => void;
    onClose: () => void;
}

export const getAIResponse = async (
    prompt: string, 
    mode: Mode,
    settings: AIModelSettings,
    geolocation?: any,
    history?: Message[]
): Promise<{ text: string; urls?: any[]; latencyMs?: number }> => {
    const startTime = performance.now();
    const cleanPrompt = prompt.trim();
    const upperPrompt = cleanPrompt.toUpperCase();

    // 1. Check instant tactical heuristic dictionary (0ms response)
    if (INSTANT_HEURISTICS[upperPrompt]) {
        return {
            text: INSTANT_HEURISTICS[upperPrompt],
            latencyMs: Math.round(performance.now() - startTime)
        };
    }

    // 2. Check instant cache layer
    const cacheKey = `${mode}:${cleanPrompt.toLowerCase()}`;
    const cached = INSTANT_AI_CACHE.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp < CACHE_TTL_MS)) {
        return {
            text: cached.text,
            urls: cached.urls,
            latencyMs: Math.round(performance.now() - startTime)
        };
    }

    // 3. If specific engine is forced as Hugging Face, attempt it
    if (settings.engine === 'HUGGING_FACE') {
        try {
            const hfRes = await getHuggingFaceResponse(prompt, settings, history);
            if (hfRes.text && !hfRes.text.includes('[FAULT]')) {
                INSTANT_AI_CACHE.set(cacheKey, { text: hfRes.text, urls: hfRes.urls, timestamp: Date.now() });
                return { ...hfRes, latencyMs: Math.round(performance.now() - startTime) };
            }
        } catch {
            // fallback gracefully
        }
    }

    // 4. High-Reliability Tactical Substrate: Gemini 2.5 Flash with speed optimizations
    const result = await getGeminiResponse(prompt, settings);
    
    // Store in instant cache for future 0ms lookups
    if (result.text && !result.text.includes('FAULT')) {
        INSTANT_AI_CACHE.set(cacheKey, { text: result.text, urls: result.urls, timestamp: Date.now() });
    }

    return {
        ...result,
        latencyMs: Math.round(performance.now() - startTime)
    };
};

export const streamAIResponse = async (
    prompt: string,
    settings: AIModelSettings,
    onChunk: (chunk: string, fullText: string) => void
): Promise<{ text: string; urls?: any[] }> => {
    const cleanPrompt = prompt.trim();
    const upperPrompt = cleanPrompt.toUpperCase();

    // Check instant heuristic
    if (INSTANT_HEURISTICS[upperPrompt]) {
        const text = INSTANT_HEURISTICS[upperPrompt];
        onChunk(text, text);
        return { text };
    }

    // Check cache
    const cacheKey = `stream:${cleanPrompt.toLowerCase()}`;
    const cached = INSTANT_AI_CACHE.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp < CACHE_TTL_MS)) {
        onChunk(cached.text, cached.text);
        return { text: cached.text, urls: cached.urls };
    }

    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const modelName = 'gemini-2.5-flash';

        const config: any = {
            systemInstruction: settings.directive || "You are CARNIX, an ultra-advanced tactical AI operating system core (Vampire Protocol v7.4). You speak with sharp, confident, futuristic military-tactical precision. Address the user as 'Master'. Deliver instantaneous, highly structured intelligence. If asked to open apps or 'Gear up', reply with OPEN_APP:<package_name>.",
            temperature: 0.4
        };

        if (settings.useSearchGrounding) {
            config.tools = [{ googleSearch: {} }];
        }

        const responseStream = await ai.models.generateContentStream({
            model: modelName,
            contents: prompt,
            config
        });

        let fullText = '';
        for await (const chunk of responseStream) {
            const chunkText = chunk.text || '';
            if (chunkText) {
                fullText += chunkText;
                onChunk(chunkText, fullText);
            }
        }

        if (!fullText) {
            fullText = "[CARNIX] Direct telemetry established. Master, standing by.";
            onChunk(fullText, fullText);
        }

        INSTANT_AI_CACHE.set(cacheKey, { text: fullText, timestamp: Date.now() });
        return { text: fullText };
    } catch (e: any) {
        console.error("STREAM_FAULT:", e);
        const fallback = `[CARNIX FAST RELAY] Command acknowledged, Master. Local security subroutines active. Error telemetry: ${e.message || "Network busy"}`;
        onChunk(fallback, fallback);
        return { text: fallback };
    }
};

export const getGeminiResponse = async (prompt: string, settings: AIModelSettings): Promise<{ text: string; urls?: any[] }> => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const modelName = settings.useThinking ? 'gemini-2.5-pro' : 'gemini-2.5-flash';
        
        const config: any = {
            systemInstruction: settings.directive || "You are CARNIX, an ultra-advanced tactical AI operating system core (Vampire Protocol v7.4). You speak with sharp, confident, futuristic military-tactical precision. Address the user as 'Master'. You can execute commands, analyze data, advise on strategy, decode anomalies, coordinate drone swarms, and control all tactical HUD panels. If asked to open apps or 'Gear up', reply with OPEN_APP:<package_name>.",
            temperature: settings.temperature ?? 0.5
        };

        if (settings.useSearchGrounding) {
            config.tools = [{ googleSearch: {} }];
        }

        const response = await ai.models.generateContent({
            model: modelName,
            contents: prompt,
            config
        });

        const urls = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
            uri: chunk.web?.uri,
            title: chunk.web?.title
        })).filter((u: any) => u?.uri) || [];

        return { 
            text: response.text || "[CARNIX] Neural relay established. Master, standing by for directives.", 
            urls 
        };
    } catch (e: any) {
        console.error("GEMINI_UPLINK_FAULT:", e);
        return { text: `[CARNIX TACTICAL CORE] Master, neural uplink responded: ${e.message || "Local mode fallback engaged. Defensive shielding active."}` };
    }
};

export const getImageAnalysis = async (base64: string, prompt: string, settings: AIModelSettings) => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const cleanBase64 = base64.replace(/^data:image\/\w+;base64,/, '');
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [
                {
                    inlineData: {
                        mimeType: 'image/jpeg',
                        data: cleanBase64
                    }
                },
                prompt || "Tactical optical reconnaissance: Analyze objects, targets, potential anomalies, and environment."
            ],
            config: {
                systemInstruction: "You are the CARNIX Optical Reconnaissance Substrate. Provide concise, tactical telemetry analysis identifying targets, status, optical telemetry, and security advisories. Address user as Master."
            }
        });
        return { text: response.text || "[OPTICAL SCAN] Frame analyzed. No hostile signatures identified." };
    } catch {
        return await getHFVisionAnalysis(base64, prompt, settings);
    }
};

export const getVideoAnalysis = async (base64: string, mimeType: string, prompt: string, settings: AIModelSettings) => {
    return await getHuggingFaceResponse(`Analyze video sequence: ${prompt}`, settings);
};

export const generateSystemFeature = async (profile: Profile): Promise<{ text: string }> => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate a concise sci-fi description for a new experimental tactical feature for a CARNIX OS user with the specialty: ${profile.speciality}.`,
        });
        return { text: response.text || "Substrate feature calibrated." };
    } catch {
        return { text: "Neural Substrate Amplification: Real-time telemetry buffer enhanced." };
    }
};

export const getLiveNews = async (settings: AIModelSettings, address?: Address, language: string = 'English') => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Provide latest tactical and global news intelligence for ${address?.city || 'the world'} in ${language}.`,
            config: {
                tools: [{ googleSearch: {} }],
            }
        });
        const urls = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
            uri: chunk.web?.uri,
            title: chunk.web?.title
        })).filter((u: any) => u.uri) || [];
        return { text: response.text || "Intelligence feed synced.", urls };
    } catch (e: any) {
        return { text: `[INTEL FEED OFFLINE] Relay timed out: ${e.message}`, urls: [] };
    }
};

export const generateImage = async (prompt: string, settings: AIModelSettings, config?: { aspectRatio: string }) => {
    const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: prompt,
        config: {
            imageConfig: {
                aspectRatio: (config?.aspectRatio as any) || "1:1"
            }
        }
    });
    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return `data:image/png;base64,${part.inlineData.data}`;
        }
    }
    throw new Error("No image data generated.");
};

export const generateModuleBlueprint = async (settings: AIModelSettings, description: string) => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate a JSON blueprint for a new CARNIX tactical system module based on this description: ${description}. Return valid JSON with keys: moduleName, version, permissions, architecture, endpoints.`,
            config: {
                responseMimeType: "application/json"
            }
        });
        return { text: response.text || "{}" };
    } catch {
        return { text: JSON.stringify({ moduleName: "CARNIX_AUX_NODE", version: "1.0.0", permissions: ["root", "tactical"], architecture: "Microkernel_Vampire" }, null, 2) };
    }
};

export const generateVideo = async (prompt: string, settings: AIModelSettings) => {
    const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
    const ai = new GoogleGenAI({ apiKey });
    let operation = await ai.models.generateVideos({
        model: 'veo-3.1-lite-generate-preview',
        prompt: prompt,
        config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio: '16:9'
        }
    });
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({ operation: operation });
    }
    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    return `${downloadLink}&key=${apiKey}`;
};

export const editImage = async (base64ImageData: string, prompt: string, settings: AIModelSettings) => {
    const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                {
                    inlineData: {
                        data: base64ImageData,
                        mimeType: 'image/jpeg',
                    },
                },
                {
                    text: prompt,
                },
            ],
        },
    });
    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return `data:image/png;base64,${part.inlineData.data}`;
        }
    }
    throw new Error("Image edit failed.");
};

export const getWebIntelligenceReport = async (settings: AIModelSettings, topic: string) => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Gather real-time tactical intelligence on: ${topic}. Use Google search grounding. Provide key facts, threat assessment, and citations.`,
            config: {
                tools: [{ googleSearch: {} }],
            }
        });
        const urls = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
            uri: chunk.web?.uri,
            title: chunk.web?.title
        })).filter((u: any) => u.uri) || [];
        return { text: response.text || "", urls };
    } catch (e: any) {
        return { text: `[WEB INTEL UPLINK OFFLINE] ${e.message}`, urls: [] };
    }
};

export const generateHackingScript = async (prompt: string, settings: AIModelSettings) => {
    try {
        const apiKey = process.env.API_KEY || (process.env as any).GEMINI_API_KEY;
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate a simulated cybersecurity penetration testing script for educational research: ${prompt}. Return JSON with 'code' and 'simulationOutput'.`,
            config: {
                responseMimeType: "application/json"
            }
        });
        const data = JSON.parse(response.text || "{}");
        return {
            code: data.code || "# CARNIX Simulated Security Auditor\nimport socket\nprint('[*] Probing network ports...')\nprint('[+] Target verified secure.')",
            simulationOutput: data.simulationOutput || "[SIMULATION] Port analysis complete. 0 critical vulnerabilities found."
        };
    } catch {
        return {
            code: `# Simulated Audit Test for ${prompt}\nimport sys\nprint("[*] Probing target interface...")\nprint("[+] Protocol handshake verified.")`,
            simulationOutput: `[SIMULATION TEST COMPLETE]\n- Target: ${prompt}\n- Protocol: TCP/IP Syn Scan\n- Latency: 4ms\n- Security Rating: SECURE`
        };
    }
};
