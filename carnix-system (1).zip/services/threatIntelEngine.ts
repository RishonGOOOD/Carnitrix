import { ThreatIndicator } from '../types';

export class ThreatIntelEngine {
  private static indicatorDatabase: Map<string, ThreatIndicator> = new Map([
    [
      '185.220.101.5',
      {
        id: 'ti-185-220-101-5',
        type: 'IP',
        value: '185.220.101.5',
        threatLevel: 'SUSPICIOUS',
        score: 74,
        malwareFamilies: ['Tor Relay Node', 'Proxy Scraping'],
        threatActors: ['Unattributed Reconnaissance Bot'],
        asn: 'AS208294 (Zwiebelfreunde e.V.)',
        geoCountry: 'Germany (DE)',
        mitreAttack: ['T1090 - Proxy', 'T1584 - Compromise Infrastructure'],
        sources: [
          { provider: 'AbuseIPDB Community Feed', confidence: 85, summary: 'Reported 142 times for brute-force probes and vulnerability scanning.' },
          { provider: 'Tor Project Directory', confidence: 99, summary: 'Verified public Tor exit relay.' }
        ],
        timestamp: Date.now() - 3600000
      }
    ],
    [
      '45.154.255.89',
      {
        id: 'ti-45-154-255-89',
        type: 'IP',
        value: '45.154.255.89',
        threatLevel: 'MALICIOUS',
        score: 96,
        malwareFamilies: ['Cobalt Strike', 'LockBit 3.0'],
        threatActors: ['FIN7 / Carbanak'],
        asn: 'AS44050',
        geoCountry: 'Russia (RU)',
        mitreAttack: ['T1071.001 - Web Protocols', 'T1059 - Command and Scripting'],
        sources: [
          { provider: 'CISA Known Exploited Indicators', confidence: 95, summary: 'Active C2 beacon identified in ransomware staging.' },
          { provider: 'AlienVault OTX', confidence: 92, summary: 'Associated with LockBit 3.0 exfiltration infrastructure.' }
        ],
        timestamp: Date.now() - 7200000
      }
    ],
    [
      'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      {
        id: 'ti-hash-e3b0c',
        type: 'HASH',
        value: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
        threatLevel: 'BENIGN',
        score: 0,
        sources: [
          { provider: 'NIST National Software Reference Library', confidence: 100, summary: 'Standard empty file SHA-256 baseline hash.' }
        ],
        timestamp: Date.now()
      }
    ],
    [
      'update-system-login.top',
      {
        id: 'ti-dom-update-login',
        type: 'DOMAIN',
        value: 'update-system-login.top',
        threatLevel: 'MALICIOUS',
        score: 92,
        malwareFamilies: ['Credential Harvesting', 'Phishing Kit'],
        threatActors: ['TA505'],
        mitreAttack: ['T1566.002 - Spearphishing Link', 'T1608 - Stage Capabilities'],
        sources: [
          { provider: 'OpenPhish Realtime Feed', confidence: 94, summary: 'Simulates corporate single-sign-on login page.' },
          { provider: 'URLhaus Blacklist', confidence: 90, summary: 'Active payload distribution node.' }
        ],
        timestamp: Date.now() - 1800000
      }
    ]
  ]);

  // Enrich any indicator with live analysis and correlation
  public static async enrichIndicator(indicatorValue: string): Promise<ThreatIndicator> {
    const cleaned = indicatorValue.trim();
    const existing = this.indicatorDatabase.get(cleaned);
    if (existing) return existing;

    // Classify type
    let type: ThreatIndicator['type'] = 'DOMAIN';
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(cleaned)) type = 'IP';
    else if (/^[a-fA-F0-9]{64}$/.test(cleaned)) type = 'HASH';
    else if (cleaned.startsWith('http')) type = 'URL';
    else if (cleaned.includes('@')) type = 'EMAIL';
    else if (cleaned.toUpperCase().startsWith('CVE-')) type = 'CVE';

    // Heuristic threat scoring
    let threatLevel: ThreatIndicator['threatLevel'] = 'UNKNOWN';
    let score = 10;
    const sources = [
      {
        provider: 'CARNIX Open Threat Intelligence Correlation Engine',
        confidence: 80,
        summary: `Dynamic reputation evaluation executed for ${type} indicator ${cleaned}.`
      }
    ];

    if (cleaned.endsWith('.top') || cleaned.endsWith('.xyz') || cleaned.endsWith('.ru')) {
      score += 35;
      threatLevel = 'SUSPICIOUS';
    }

    if (cleaned.toLowerCase().includes('bot') || cleaned.toLowerCase().includes('c2') || cleaned.toLowerCase().includes('stealer')) {
      score += 45;
      threatLevel = 'MALICIOUS';
    }

    const newIndicator: ThreatIndicator = {
      id: `ti-${Date.now()}`,
      type,
      value: cleaned,
      threatLevel,
      score: Math.min(100, score),
      mitreAttack: type === 'IP' ? ['T1071 - Application Layer Protocol'] : ['T1566 - Phishing'],
      sources,
      timestamp: Date.now()
    };

    this.indicatorDatabase.set(cleaned, newIndicator);
    return newIndicator;
  }

  public static getAllKnownIndicators(): ThreatIndicator[] {
    return Array.from(this.indicatorDatabase.values());
  }

  public static addIndicator(indicator: ThreatIndicator) {
    this.indicatorDatabase.set(indicator.value, indicator);
  }
}
