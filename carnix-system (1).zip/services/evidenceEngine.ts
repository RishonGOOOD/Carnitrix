import { EvidenceGraph, EvidenceNode, EvidenceEdge, EvidenceConfidence } from '../types';

export class EvidenceEngine {
  private static defaultGraph: EvidenceGraph = {
    nodes: [
      {
        id: 'node-target-corp',
        label: 'apex-defense.org',
        type: 'DOMAIN',
        confidence: 'CONFIRMED',
        properties: { registrar: 'NameCheap', created: '2022-04-10' },
        source: 'ICANN RDAP Authority',
        timestamp: Date.now() - 86400000
      },
      {
        id: 'node-ip-primary',
        label: '104.21.55.19',
        type: 'IP',
        confidence: 'CONFIRMED',
        properties: { asn: 'AS13335 (Cloudflare)', country: 'United States' },
        source: 'Authoritative DNS DoH Query',
        timestamp: Date.now() - 86400000
      },
      {
        id: 'node-cert-edge',
        label: 'Let\'s Encrypt TLS (SAN: apex-defense.org, api.apex-defense.org)',
        type: 'CERTIFICATE',
        confidence: 'CONFIRMED',
        properties: { issuer: 'R3 CA', validUntil: '2026-11-20' },
        source: 'Certificate Transparency Log (crt.sh)',
        timestamp: Date.now() - 86400000
      },
      {
        id: 'node-org-holding',
        label: 'Apex Defense Holdings LLC',
        type: 'ORGANIZATION',
        confidence: 'LIKELY',
        properties: { jurisdiction: 'Delaware, USA', status: 'Active Entity' },
        source: 'Public Secretary of State Registry',
        timestamp: Date.now() - 43200000
      },
      {
        id: 'node-sub-api',
        label: 'api.apex-defense.org',
        type: 'DOMAIN',
        confidence: 'CONFIRMED',
        properties: { openPorts: [443, 8080], status: 'REST Gateway' },
        source: 'Subfinder / CT Log Scraping',
        timestamp: Date.now() - 21600000
      }
    ],
    edges: [
      {
        id: 'edge-1',
        fromId: 'node-target-corp',
        toId: 'node-ip-primary',
        relationship: 'RESOLVES_TO',
        confidence: 'CONFIRMED',
        evidence: 'A-Record lookup against 8.8.8.8 returned 104.21.55.19 with TTL 300.',
        source: 'DNS RFC 8484 DoH',
        timestamp: Date.now() - 86400000
      },
      {
        id: 'edge-2',
        fromId: 'node-target-corp',
        toId: 'node-cert-edge',
        relationship: 'SECURED_BY_CERT',
        confidence: 'CONFIRMED',
        evidence: 'X.509 Certificate SAN matched apex-defense.org serial 03:a1:4f:...',
        source: 'crt.sh CT Logs',
        timestamp: Date.now() - 86400000
      },
      {
        id: 'edge-3',
        fromId: 'node-target-corp',
        toId: 'node-org-holding',
        relationship: 'OPERATED_BY',
        confidence: 'LIKELY',
        evidence: 'Corporate registration copyright notice and WHOIS organization attribute match legal entity.',
        source: 'RDAP Entity Organization tag',
        timestamp: Date.now() - 43200000
      },
      {
        id: 'edge-4',
        fromId: 'node-cert-edge',
        toId: 'node-sub-api',
        relationship: 'INCLUDES_SAN_HOST',
        confidence: 'CONFIRMED',
        evidence: 'Certificate Subject Alternative Name explicitly specifies DNS:api.apex-defense.org.',
        source: 'X.509 Extension inspection',
        timestamp: Date.now() - 21600000
      }
    ]
  };

  public static getGraph(): EvidenceGraph {
    try {
      const saved = localStorage.getItem('carnix_evidence_graph');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return this.defaultGraph;
  }

  public static saveGraph(graph: EvidenceGraph) {
    try {
      localStorage.setItem('carnix_evidence_graph', JSON.stringify(graph));
    } catch {
      // ignore
    }
  }

  public static addNode(node: EvidenceNode) {
    const graph = this.getGraph();
    if (!graph.nodes.some(n => n.id === node.id)) {
      graph.nodes.push(node);
      this.saveGraph(graph);
    }
  }

  public static addEdge(edge: EvidenceEdge) {
    const graph = this.getGraph();
    if (!graph.edges.some(e => e.id === edge.id)) {
      graph.edges.push(edge);
      this.saveGraph(graph);
    }
  }

  public static clearGraph() {
    this.saveGraph({ nodes: [], edges: [] });
  }

  public static resetToDefault() {
    this.saveGraph(this.defaultGraph);
  }
}
