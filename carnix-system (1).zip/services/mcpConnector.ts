import { McpServerConfig } from '../types';

export class McpConnectorManager {
  private servers: Map<string, McpServerConfig> = new Map();
  private auditLogs: Array<{ timestamp: number; server: string; tool: string; status: string; details: string }> = [];

  constructor() {
    // Initial pre-configured MCP adapters
    const defaultMcpServers: McpServerConfig[] = [
      {
        id: 'mcp-github',
        name: 'GitHub MCP Server',
        description: 'Enables model inspection of public GitHub repositories, commits, issues, and security advisories.',
        endpoint: 'stdio://mcp-server-github',
        transport: 'stdio',
        enabled: true,
        status: 'CONNECTED',
        capabilities: ['read_repositories', 'search_code', 'list_releases'],
        discoveredTools: [
          { name: 'search_repositories', description: 'Search for public GitHub repos by keyword, license, and stars', inputSchema: { query: { type: 'string' } } },
          { name: 'get_file_contents', description: 'Inspect README, security policy, or configuration from repository', inputSchema: { repo: { type: 'string' }, path: { type: 'string' } } }
        ],
        lastPing: Date.now()
      },
      {
        id: 'mcp-brave-search',
        name: 'Brave Search MCP Server',
        description: 'Enables real-time public web queries for threat actor research, CVE advisories, and organization news.',
        endpoint: 'http://localhost:8081/mcp',
        transport: 'http',
        enabled: true,
        status: 'CONNECTED',
        capabilities: ['web_search', 'news_search'],
        discoveredTools: [
          { name: 'brave_web_search', description: 'Execute privacy-preserving search query across indexed web', inputSchema: { q: { type: 'string' }, count: { type: 'number' } } }
        ],
        lastPing: Date.now()
      },
      {
        id: 'mcp-filesystem',
        name: 'Filesystem DFIR MCP Server',
        description: 'Sandboxed local forensic log reader for inspecting syslog, auth.log, and packet capture metadata.',
        endpoint: 'stdio://mcp-server-filesystem',
        transport: 'stdio',
        enabled: false,
        status: 'DISCONNECTED',
        capabilities: ['read_file', 'list_directory'],
        discoveredTools: [
          { name: 'read_log_buffer', description: 'Read forensic event log buffer lines', inputSchema: { path: { type: 'string' } } }
        ],
        lastPing: undefined
      },
      {
        id: 'mcp-memory',
        name: 'Memory Graph MCP Server',
        description: 'Persistent contextual investigative memory maintaining entity knowledge across multi-turn sessions.',
        endpoint: 'stdio://mcp-server-memory',
        transport: 'stdio',
        enabled: true,
        status: 'CONNECTED',
        capabilities: ['create_entities', 'read_graph', 'search_nodes'],
        discoveredTools: [
          { name: 'query_entity_graph', description: 'Query investigative knowledge graph for nodes and connections', inputSchema: { entityName: { type: 'string' } } }
        ],
        lastPing: Date.now()
      }
    ];

    defaultMcpServers.forEach(s => this.servers.set(s.id, s));
  }

  public getServers(): McpServerConfig[] {
    return Array.from(this.servers.values());
  }

  public toggleServer(id: string): boolean {
    const s = this.servers.get(id);
    if (!s) return false;
    s.enabled = !s.enabled;
    s.status = s.enabled ? 'CONNECTED' : 'DISCONNECTED';
    if (s.enabled) s.lastPing = Date.now();
    this.logAudit(s.name, 'TOGGLE_STATUS', s.enabled ? 'ENABLED' : 'DISABLED', `Server toggled by analyst.`);
    return s.enabled;
  }

  public async executeMcpTool(serverId: string, toolName: string, params: any): Promise<{ success: boolean; data?: any; error?: string }> {
    const server = this.servers.get(serverId);
    if (!server) {
      return { success: false, error: `MCP Server "${serverId}" not registered.` };
    }
    if (!server.enabled) {
      return { success: false, error: `MCP Server "${server.name}" is disabled.` };
    }

    try {
      // Simulate safe MCP schema check & call
      await new Promise(r => setTimeout(r, 400));
      this.logAudit(server.name, toolName, 'SUCCESS', `Executed tool with params: ${JSON.stringify(params)}`);
      return {
        success: true,
        data: {
          server: server.name,
          tool: toolName,
          result: `Executed ${toolName} via MCP transport ${server.transport}.`,
          timestamp: new Date().toISOString()
        }
      };
    } catch (err: any) {
      this.logAudit(server.name, toolName, 'ERROR', err.message);
      return { success: false, error: err.message };
    }
  }

  private logAudit(server: string, tool: string, status: string, details: string) {
    this.auditLogs.unshift({
      timestamp: Date.now(),
      server,
      tool,
      status,
      details
    });
    if (this.auditLogs.length > 50) this.auditLogs.pop();
  }

  public getAuditLogs() {
    return this.auditLogs;
  }
}

export const mcpConnector = new McpConnectorManager();
