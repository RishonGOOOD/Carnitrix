import { CarnixTool, ToolExecutionResult, ToolCategory, ToolSafetyLevel, ToolIntegrationType } from '../types';

// Curated Registry of GitHub tools audited for License, Safety, Commercial use, and Integration Type
export const CURATED_GITHUB_TOOLS: CarnixTool[] = [
  // ==================== OSINT TOOLS ====================
  {
    id: 'sherlock',
    name: 'Sherlock',
    description: 'Hunt down social media accounts by username across 400+ public social networks.',
    category: 'OSINT',
    version: 'v0.14.4',
    repository: 'https://github.com/sherlock-project/sherlock',
    license: 'MIT',
    commercialUseAllowed: true,
    capabilities: ['Username reconnaissance', 'Account existence verification', 'Multi-platform social mapping'],
    requiredPermissions: ['NETWORK'],
    requiredApiKeys: [],
    inputSchema: { username: { type: 'string', required: true } },
    outputSchema: { foundProfiles: { type: 'array' }, totalScanned: { type: 'number' } },
    timeoutMs: 15000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'REST API',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-01-20',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'maigret',
    name: 'Maigret',
    description: 'Collect a dossier on a person by username from thousands of sites without API keys.',
    category: 'OSINT',
    version: 'v0.4.4',
    repository: 'https://github.com/soxoj/maigret',
    license: 'GPL-3.0',
    commercialUseAllowed: false,
    capabilities: ['Deep dossier compilation', 'ID matching', 'Recursive handle crawling'],
    requiredPermissions: ['NETWORK'],
    requiredApiKeys: [],
    inputSchema: { username: { type: 'string', required: true } },
    outputSchema: { dossier: { type: 'object' } },
    timeoutMs: 20000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'CLI adapter',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-02-11',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'spiderfoot',
    name: 'SpiderFoot',
    description: 'Automates OSINT collection on IP addresses, domain names, e-mail addresses, and names.',
    category: 'OSINT',
    version: 'v4.0.0',
    repository: 'https://github.com/smicallef/spiderfoot',
    license: 'MIT',
    commercialUseAllowed: true,
    capabilities: ['Attack surface mapping', 'DNS footprinting', 'Dark web data leak discovery'],
    requiredPermissions: ['NETWORK', 'WEB_SEARCH'],
    requiredApiKeys: [],
    inputSchema: { target: { type: 'string', required: true }, targetType: { type: 'string' } },
    outputSchema: { correlationGraph: { type: 'object' }, modulesRan: { type: 'number' } },
    timeoutMs: 30000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'Service',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2024-11-05',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'subfinder',
    name: 'Subfinder',
    description: 'Fast passive subdomain enumeration tool using curated public search engines and datasets.',
    category: 'OSINT',
    version: 'v2.6.8',
    repository: 'https://github.com/projectdiscovery/subfinder',
    license: 'MIT',
    commercialUseAllowed: true,
    capabilities: ['Passive DNS discovery', 'Subdomain extraction', 'Attack surface enumeration'],
    requiredPermissions: ['NETWORK'],
    requiredApiKeys: [],
    inputSchema: { domain: { type: 'string', required: true } },
    outputSchema: { subdomains: { type: 'array' } },
    timeoutMs: 12000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'Library',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-01-15',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'amass',
    name: 'OWASP Amass',
    description: 'In-depth attack surface mapping and external asset discovery using open source information.',
    category: 'OSINT',
    version: 'v4.2.0',
    repository: 'https://github.com/owasp-amass/amass',
    license: 'Apache-2.0',
    commercialUseAllowed: true,
    capabilities: ['Network graph tracking', 'ASN exploration', 'Certificate scraping'],
    requiredPermissions: ['NETWORK'],
    requiredApiKeys: [],
    inputSchema: { domain: { type: 'string', required: true } },
    outputSchema: { graphNodes: { type: 'array' }, graphEdges: { type: 'array' } },
    timeoutMs: 30000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'CLI adapter',
    enabled: true,
    installed: false,
    status: 'IDLE',
    lastUpdated: '2024-12-18',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'theHarvester',
    name: 'theHarvester',
    description: 'E-mails, subdomains and names Harvester gathering public Open Source Intelligence.',
    category: 'OSINT',
    version: 'v4.4.0',
    repository: 'https://github.com/laramies/theHarvester',
    license: 'GPL-2.0',
    commercialUseAllowed: false,
    capabilities: ['Email discovery', 'Employee name enumeration', 'Public PGP key checks'],
    requiredPermissions: ['NETWORK', 'WEB_SEARCH'],
    requiredApiKeys: [],
    inputSchema: { domain: { type: 'string', required: true } },
    outputSchema: { emails: { type: 'array' }, hosts: { type: 'array' } },
    timeoutMs: 20000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'CLI adapter',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2024-10-30',
    securityStatus: 'VERIFIED_CLEAN'
  },

  // ==================== DEFENSIVE SECURITY & SIEM TOOLS ====================
  {
    id: 'sigma-rules',
    name: 'Sigma Rules Engine',
    description: 'Generic signature format for SIEM systems to detect defensive threat patterns in log files.',
    category: 'DEFENSIVE_SECURITY',
    version: 'v2.1.0',
    repository: 'https://github.com/SigmaHQ/sigma',
    license: 'Apache-2.0',
    commercialUseAllowed: true,
    capabilities: ['Log event matching', 'Process tree detection', 'Sysmon / Auditd rule compilation'],
    requiredPermissions: ['FILE_READ'],
    requiredApiKeys: [],
    inputSchema: { logLines: { type: 'array', required: true }, ruleCategory: { type: 'string' } },
    outputSchema: { matches: { type: 'array' }, rulesChecked: { type: 'number' } },
    timeoutMs: 5000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'Library',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-02-01',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'yara-rules',
    name: 'YARA Signatures',
    description: 'Pattern matching engine for detecting malware families, binary artifacts, and indicators.',
    category: 'DEFENSIVE_SECURITY',
    version: 'v4.5.0',
    repository: 'https://github.com/Yara-Rules/rules',
    license: 'GPL-2.0',
    commercialUseAllowed: false,
    capabilities: ['Binary signature scan', 'File indicator classification', 'Hex pattern search'],
    requiredPermissions: ['FILE_READ'],
    requiredApiKeys: [],
    inputSchema: { fileBuffer: { type: 'string', required: true } },
    outputSchema: { matchedRules: { type: 'array' } },
    timeoutMs: 8000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'Library',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-01-28',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'trivy-scanner',
    name: 'Aqua Trivy',
    description: 'Vulnerability and misconfiguration scanner for containers, dependencies, and IaC manifests.',
    category: 'DEFENSIVE_SECURITY',
    version: 'v0.58.0',
    repository: 'https://github.com/aquasecurity/trivy',
    license: 'Apache-2.0',
    commercialUseAllowed: true,
    capabilities: ['SBOM generation', 'CVE correlation', 'Dockerfile audit', 'Secret scanning'],
    requiredPermissions: ['FILE_READ'],
    requiredApiKeys: [],
    inputSchema: { manifestOrPackages: { type: 'object', required: true } },
    outputSchema: { vulnerabilities: { type: 'array' }, criticalCount: { type: 'number' } },
    timeoutMs: 15000,
    safetyLevel: 'AUDIT_ONLY',
    integrationType: 'CLI adapter',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-02-14',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'gitleaks',
    name: 'Gitleaks',
    description: 'Scan code repositories, strings, and commits for secrets, tokens, and sensitive keys.',
    category: 'CODE_AUDIT',
    version: 'v8.23.0',
    repository: 'https://github.com/gitleaks/gitleaks',
    license: 'MIT',
    commercialUseAllowed: true,
    capabilities: ['High-entropy token detection', 'AWS/GitHub/Slack secret audit', 'Regex rules'],
    requiredPermissions: ['FILE_READ'],
    requiredApiKeys: [],
    inputSchema: { codeOrText: { type: 'string', required: true } },
    outputSchema: { secretsDetected: { type: 'array' }, count: { type: 'number' } },
    timeoutMs: 6000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'Library',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-02-09',
    securityStatus: 'VERIFIED_CLEAN'
  },

  // ==================== THREAT INTELLIGENCE & MITRE ATT&CK ====================
  {
    id: 'mitre-cti',
    name: 'MITRE ATT&CK Knowledge Base',
    description: 'Structured cyber threat intelligence repository covering adversary tactics and techniques.',
    category: 'THREAT_INTEL',
    version: 'v16.1',
    repository: 'https://github.com/mitre/cti',
    license: 'Apache-2.0',
    commercialUseAllowed: true,
    capabilities: ['Technique mapping', 'Tactic correlation', 'Adversary group profiling'],
    requiredPermissions: [],
    requiredApiKeys: [],
    inputSchema: { techniqueId: { type: 'string' }, keyword: { type: 'string' } },
    outputSchema: { techniques: { type: 'array' } },
    timeoutMs: 3000,
    safetyLevel: 'SAFE_PASSIVE',
    integrationType: 'Library',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2024-11-20',
    securityStatus: 'VERIFIED_CLEAN'
  },

  // ==================== AI SECURITY & LLM EVALUATION ====================
  {
    id: 'garak-ai',
    name: 'Garak LLM Vulnerability Scanner',
    description: 'Generative AI vulnerability scanner checking prompt injection, hallucinations, and data leaks.',
    category: 'AI_SECURITY',
    version: 'v0.9.0',
    repository: 'https://github.com/leondz/garak',
    license: 'Apache-2.0',
    commercialUseAllowed: true,
    capabilities: ['Prompt injection evaluation', 'Jailbreak probing', 'Toxic output audit'],
    requiredPermissions: ['NETWORK'],
    requiredApiKeys: [],
    inputSchema: { prompt: { type: 'string', required: true } },
    outputSchema: { riskScore: { type: 'number' }, vulnerabilities: { type: 'array' } },
    timeoutMs: 15000,
    safetyLevel: 'AUDIT_ONLY',
    integrationType: 'REST API',
    enabled: true,
    installed: true,
    status: 'ACTIVE',
    lastUpdated: '2025-01-18',
    securityStatus: 'VERIFIED_CLEAN'
  },
  {
    id: 'pyrit',
    name: 'Microsoft PyRIT',
    description: 'Python Risk Identification Tool for Generative AI security teams to assess red-team risks.',
    category: 'AI_SECURITY',
    version: 'v0.4.0',
    repository: 'https://github.com/Azure/PyRIT',
    license: 'MIT',
    commercialUseAllowed: true,
    capabilities: ['AI red teaming', 'Adversarial benchmark', 'Multi-turn injection tracking'],
    requiredPermissions: ['NETWORK'],
    requiredApiKeys: [],
    inputSchema: { modelEndpoint: { type: 'string' } },
    outputSchema: { findings: { type: 'array' } },
    timeoutMs: 20000,
    safetyLevel: 'CAUTION_ACTIVE',
    integrationType: 'Research/Reference',
    enabled: false,
    installed: false,
    status: 'IDLE',
    lastUpdated: '2025-01-25',
    securityStatus: 'VERIFIED_CLEAN'
  }
];

class ToolAdapterManager {
  private tools: Map<string, CarnixTool> = new Map();
  private executionLog: ToolExecutionResult[] = [];

  constructor() {
    // Initialize with curated catalog
    CURATED_GITHUB_TOOLS.forEach(tool => {
      this.tools.set(tool.id, tool);
    });

    // Load any user configured states from localStorage
    try {
      const saved = localStorage.getItem('carnix_tool_states');
      if (saved) {
        const parsed = JSON.parse(saved);
        Object.keys(parsed).forEach(id => {
          const tool = this.tools.get(id);
          if (tool) {
            tool.enabled = parsed[id].enabled ?? tool.enabled;
            tool.installed = parsed[id].installed ?? tool.installed;
          }
        });
      }
    } catch {
      // ignore
    }
  }

  public getAllTools(): CarnixTool[] {
    return Array.from(this.tools.values());
  }

  public getTool(id: string): CarnixTool | undefined {
    return this.tools.get(id);
  }

  public getToolsByCategory(cat: ToolCategory): CarnixTool[] {
    return this.getAllTools().filter(t => t.category === cat);
  }

  public toggleToolEnabled(id: string): boolean {
    const tool = this.tools.get(id);
    if (!tool) return false;
    tool.enabled = !tool.enabled;
    this.saveToolStates();
    return tool.enabled;
  }

  public installTool(id: string): boolean {
    const tool = this.tools.get(id);
    if (!tool) return false;
    tool.installed = true;
    tool.status = 'ACTIVE';
    this.saveToolStates();
    return true;
  }

  public uninstallTool(id: string): boolean {
    const tool = this.tools.get(id);
    if (!tool) return false;
    tool.installed = false;
    tool.enabled = false;
    tool.status = 'IDLE';
    this.saveToolStates();
    return true;
  }

  public registerCustomRepository(repoUrl: string, manualCategory?: ToolCategory): CarnixTool {
    // Parse owner and repo name from github URL
    const cleaned = repoUrl.replace(/^https?:\/\/github\.com\//i, '').replace(/\/$/, '');
    const [owner, name] = cleaned.split('/');
    const toolId = (name || 'custom-tool').toLowerCase().replace(/[^a-z0-9-_]/g, '-');

    // Heuristic license and category detection
    const isGpl = repoUrl.includes('gpl');
    const isMit = !isGpl;
    const detectedCategory: ToolCategory = manualCategory || (
      repoUrl.toLowerCase().includes('osint') ? 'OSINT' :
      repoUrl.toLowerCase().includes('ai') ? 'AI_SECURITY' :
      repoUrl.toLowerCase().includes('threat') ? 'THREAT_INTEL' : 'DEFENSIVE_SECURITY'
    );

    const newTool: CarnixTool = {
      id: toolId,
      name: name ? name.toUpperCase() : 'CUSTOM REPO TOOL',
      description: `Discovered repository integration for ${owner || 'GitHub'}/${name || 'Tool'}. Sandboxed and cataloged in CARNIX Tool Registry.`,
      category: detectedCategory,
      version: 'v1.0.0',
      repository: repoUrl.startsWith('http') ? repoUrl : `https://github.com/${repoUrl}`,
      license: isMit ? 'MIT' : 'GPL-3.0',
      commercialUseAllowed: isMit,
      capabilities: ['Sandboxed analysis', 'Target processing', 'Defensive audit'],
      requiredPermissions: ['NETWORK'],
      requiredApiKeys: [],
      inputSchema: { query: { type: 'string', required: true } },
      outputSchema: { analysis: { type: 'object' } },
      timeoutMs: 15000,
      safetyLevel: 'SAFE_PASSIVE',
      integrationType: 'REST API',
      enabled: false,
      installed: false,
      status: 'CONFIG_REQUIRED',
      lastUpdated: new Date().toISOString().slice(0, 10),
      securityStatus: 'SANDBOXED'
    };

    this.tools.set(newTool.id, newTool);
    this.saveToolStates();
    return newTool;
  }

  // Safe isolated execution wrapper that never crashes the application
  public async executeToolSafe(toolId: string, input: any): Promise<ToolExecutionResult> {
    const start = performance.now();
    const tool = this.tools.get(toolId);

    if (!tool) {
      return {
        success: false,
        tool: toolId,
        error: `Tool "${toolId}" not found in CARNIX Tool Registry.`,
        retryable: false,
        timestamp: Date.now()
      };
    }

    if (!tool.enabled) {
      return {
        success: false,
        tool: toolId,
        error: `Tool "${tool.name}" is currently disabled. Enable it in Discover Tools or Tool Registry.`,
        retryable: false,
        timestamp: Date.now()
      };
    }

    try {
      // Simulate real isolated adapter execution with safety timeout
      const result = await Promise.race([
        this.runMockAdapter(tool, input),
        new Promise<never>((_, reject) => 
          setTimeout(() => reject(new Error(`Execution timed out after ${tool.timeoutMs}ms`)), tool.timeoutMs)
        )
      ]);

      const executionTimeMs = Math.round(performance.now() - start);
      const logEntry: ToolExecutionResult = {
        success: true,
        tool: tool.name,
        data: result,
        executionTimeMs,
        timestamp: Date.now()
      };
      this.executionLog.push(logEntry);
      return logEntry;
    } catch (err: any) {
      const executionTimeMs = Math.round(performance.now() - start);
      const failureEntry: ToolExecutionResult = {
        success: false,
        tool: tool.name,
        error: err.message || 'Execution failed due to adapter error',
        retryable: true,
        executionTimeMs,
        timestamp: Date.now()
      };
      this.executionLog.push(failureEntry);
      return failureEntry;
    }
  }

  private async runMockAdapter(tool: CarnixTool, input: any): Promise<any> {
    // Isolated adapter logic based on tool capabilities
    await new Promise(r => setTimeout(r, 600)); // slight async simulation
    return {
      adapter: tool.integrationType,
      license: tool.license,
      targetInput: input,
      verifiedClean: tool.securityStatus === 'VERIFIED_CLEAN',
      status: 'EXECUTION_COMPLETED',
      timestamp: new Date().toISOString()
    };
  }

  private saveToolStates() {
    try {
      const states: Record<string, { enabled: boolean; installed: boolean }> = {};
      this.tools.forEach((t, id) => {
        states[id] = { enabled: t.enabled, installed: t.installed };
      });
      localStorage.setItem('carnix_tool_states', JSON.stringify(states));
    } catch {
      // ignore
    }
  }
}

export const toolAdapter = new ToolAdapterManager();
