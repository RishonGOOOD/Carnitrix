import { InvestigationCase, OsintResult, SecurityFinding } from '../types';
import { EvidenceEngine } from './evidenceEngine';

export class InvestigationService {
  private static defaultCases: InvestigationCase[] = [
    {
      id: 'inv-case-001',
      title: 'Project Apex Defense Recon & Attack Surface',
      description: 'Authorized defensive attack surface investigation on apex-defense.org corporate perimeter and sub-infrastructure.',
      scope: 'Strictly passive public reconnaissance and DNS/TLS auditing within apex-defense.org scope.',
      targets: ['apex-defense.org', '104.21.55.19', 'api.apex-defense.org'],
      queries: ['apex-defense.org', '104.21.55.19'],
      findings: [
        {
          id: 'sec-hdr-csp',
          title: 'Missing Content-Security-Policy',
          severity: 'HIGH',
          category: 'Web Security',
          description: 'No Content-Security-Policy header discovered on root landing endpoint.',
          remediation: 'Deploy strict CSP header to prevent unauthorized cross-origin script injection.',
          target: 'apex-defense.org',
          source: 'CARNIX Security Auditor',
          timestamp: Date.now() - 3600000
        }
      ],
      evidence: [
        {
          id: 'ev-1',
          source: 'Google DoH Resolver',
          timestamp: Date.now() - 7200000,
          query: 'apex-defense.org [A]',
          result: { ip: '104.21.55.19' },
          confidence: 'CONFIRMED',
          evidence: 'A record authoritative resolution confirmed.',
          processingMethod: 'RFC 8484 DoH',
          category: 'DNS Intelligence'
        }
      ],
      graph: EvidenceEngine.getGraph(),
      timeline: [
        {
          id: 'time-1',
          timestamp: Date.now() - 7200000,
          dateStr: new Date(Date.now() - 7200000).toLocaleString(),
          title: 'Initial Scope Defined',
          description: 'Authorized investigation opened for apex-defense.org perimeter.',
          type: 'NOTE',
          confidence: 'CONFIRMED',
          source: 'Lead Analyst'
        },
        {
          id: 'time-2',
          timestamp: Date.now() - 3600000,
          dateStr: new Date(Date.now() - 3600000).toLocaleString(),
          title: 'DNS Resolution Completed',
          description: 'Identified Cloudflare AS13335 edge relay node at 104.21.55.19.',
          type: 'OSINT',
          confidence: 'CONFIRMED',
          source: 'CARNIX DNS Intelligence'
        }
      ],
      notes: 'Analyst note: Target uses Cloudflare WAF/CDN. No origin IP leakage detected in SPF or MX records.',
      reports: ['Investigation Briefing v1.0'],
      status: 'OPEN',
      createdAt: Date.now() - 86400000,
      updatedAt: Date.now(),
      leadAnalyst: 'OPERATIVE_CARNIX_01'
    }
  ];

  public static getCases(): InvestigationCase[] {
    try {
      const saved = localStorage.getItem('carnix_investigation_cases');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return this.defaultCases;
  }

  public static saveCases(cases: InvestigationCase[]) {
    try {
      localStorage.setItem('carnix_investigation_cases', JSON.stringify(cases));
    } catch {
      // ignore
    }
  }

  public static getActiveCaseId(): string {
    return localStorage.getItem('carnix_active_case_id') || 'inv-case-001';
  }

  public static setActiveCaseId(id: string) {
    localStorage.setItem('carnix_active_case_id', id);
  }

  public static getActiveCase(): InvestigationCase | undefined {
    const id = this.getActiveCaseId();
    const cases = this.getCases();
    return cases.find(c => c.id === id) || cases[0];
  }

  public static updateActiveCase(updater: (c: InvestigationCase) => InvestigationCase) {
    const active = this.getActiveCase();
    if (!active) return;
    const updated = updater(active);
    updated.updatedAt = Date.now();
    const cases = this.getCases().map(c => c.id === updated.id ? updated : c);
    this.saveCases(cases);
  }

  public static addEvidenceToActiveCase(evidence: OsintResult) {
    this.updateActiveCase(c => ({
      ...c,
      evidence: [evidence, ...c.evidence.filter(e => e.id !== evidence.id)],
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: Date.now(),
          dateStr: new Date().toLocaleString(),
          title: `Evidence: ${evidence.category}`,
          description: evidence.evidence || `Collected from ${evidence.source}`,
          type: 'OSINT',
          confidence: evidence.confidence,
          source: evidence.source
        },
        ...c.timeline
      ]
    }));
  }

  public static addFindingToActiveCase(finding: SecurityFinding) {
    this.updateActiveCase(c => ({
      ...c,
      findings: [finding, ...c.findings.filter(f => f.id !== finding.id)],
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: Date.now(),
          dateStr: new Date().toLocaleString(),
          title: `Security Finding: ${finding.title}`,
          description: `[${finding.severity}] ${finding.description}`,
          type: 'SECURITY',
          confidence: 'CONFIRMED',
          source: finding.source
        },
        ...c.timeline
      ]
    }));
  }

  public static createNewCase(title: string, scope: string, targets: string[]): InvestigationCase {
    const newCase: InvestigationCase = {
      id: `inv-case-${Date.now()}`,
      title,
      description: `Target investigation for: ${targets.join(', ')}`,
      scope,
      targets,
      queries: [...targets],
      findings: [],
      evidence: [],
      graph: { nodes: [], edges: [] },
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: Date.now(),
          dateStr: new Date().toLocaleString(),
          title: 'Case Initialized',
          description: `Scope established for targets: ${targets.join(', ')}`,
          type: 'NOTE',
          confidence: 'CONFIRMED',
          source: 'Analyst'
        }
      ],
      notes: '',
      reports: [],
      status: 'OPEN',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      leadAnalyst: 'OPERATIVE_CARNIX_01'
    };

    const cases = [newCase, ...this.getCases()];
    this.saveCases(cases);
    this.setActiveCaseId(newCase.id);
    return newCase;
  }
}
