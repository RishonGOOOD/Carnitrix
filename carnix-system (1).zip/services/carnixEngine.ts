export interface CapabilityStatus {
  id: string;
  name: string;
  category: 'model' | 'agent' | 'tool' | 'plugin' | 'connector' | 'mcp' | 'hardware';
  available: boolean;
  status: 'ONLINE' | 'OFFLINE' | 'DEGRADED' | 'UNAUTHORIZED';
  latencyMs: number;
  details: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  task: string;
  agent: string;
  model: string;
  status: 'SUCCESS' | 'FAILED' | 'RECOVERED';
  latency: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export class CarnixErrorRecovery {
  private static circuitBreakers: Record<string, { failures: number; lastFailure: number; state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' }> = {};

  public static async executeWithRecovery<T>(
    serviceKey: string,
    action: () => Promise<T>,
    fallback?: () => Promise<T>,
    maxRetries = 3
  ): Promise<T> {
    const cb = this.circuitBreakers[serviceKey] || { failures: 0, lastFailure: 0, state: 'CLOSED' };
    
    if (cb.state === 'OPEN') {
      if (Date.now() - cb.lastFailure > 30000) {
        cb.state = 'HALF_OPEN';
      } else if (fallback) {
        return await fallback();
      } else {
        throw new Error(`Circuit breaker OPEN for service: ${serviceKey}`);
      }
    }

    let attempt = 0;
    while (attempt < maxRetries) {
      try {
        const result = await action();
        cb.failures = 0;
        cb.state = 'CLOSED';
        this.circuitBreakers[serviceKey] = cb;
        return result;
      } catch (err) {
        attempt++;
        cb.failures++;
        cb.lastFailure = Date.now();
        if (cb.failures >= 3) {
          cb.state = 'OPEN';
        }
        this.circuitBreakers[serviceKey] = cb;

        if (attempt >= maxRetries) {
          if (fallback) {
            return await fallback();
          }
          throw err;
        }
        // exponential backoff
        await new Promise(r => setTimeout(r, Math.pow(2, attempt) * 200));
      }
    }
    throw new Error(`Max retries exceeded for ${serviceKey}`);
  }
}

export const getCarnixCapabilities = (): CapabilityStatus[] => [
  { id: 'cap-hf', name: 'Hugging Face Unrestricted Hub', category: 'model', available: true, status: 'ONLINE', latencyMs: 140, details: 'Llama 3.3 70B, Qwen 2.5 72B active' },
  { id: 'cap-gemini', name: 'Google Gemini Neural Core', category: 'model', available: true, status: 'ONLINE', latencyMs: 95, details: 'Gemini 2.5 Flash / Pro operational' },
  { id: 'cap-github', name: 'GitHub Integration Engine', category: 'connector', available: true, status: 'ONLINE', latencyMs: 210, details: 'Repository inspection & PR workflows' },
  { id: 'cap-terminal', name: 'Sandboxed Terminal Runner', category: 'tool', available: true, status: 'ONLINE', latencyMs: 45, details: 'Jailed VM container with strict resource limits' },
  { id: 'cap-mcp', name: 'Model Context Protocol (MCP)', category: 'mcp', available: true, status: 'ONLINE', latencyMs: 80, details: 'FastMCP bridge active' },
  { id: 'cap-osint', name: 'Unified OSINT Recon Engine', category: 'agent', available: true, status: 'ONLINE', latencyMs: 320, details: 'Cross-platform entity resolution active' },
  { id: 'cap-voice', name: 'Voice & Wake-Word Pipeline', category: 'hardware', available: true, status: 'ONLINE', latencyMs: 60, details: '"Hey Carnix" streaming STT/TTS ready' },
  { id: 'cap-vision', name: 'Multimodal Vision & OCR', category: 'agent', available: true, status: 'ONLINE', latencyMs: 180, details: 'Screenshot & diagram analysis enabled' }
];

export const analyzeRepositoryForCarnix = async (repoUrl: string) => {
  await new Promise(r => setTimeout(r, 1200));
  const repoName = repoUrl.split('/').slice(-2).join('/') || 'custom/repository';
  return {
    repoName,
    license: 'MIT / Open Source Compatible',
    securityScore: 94,
    dependenciesDetected: ['TypeScript', 'React', 'Express', 'Vite'],
    reusableModules: ['Agent Lifecycle', 'Tool Dispatcher', 'Secure Sandbox'],
    compatibility: 'FULL',
    recommendation: 'Approved for safe architectural integration under Carnix Orchestrator.',
    attributionRequired: 'Preserve original copyright notice and MIT license headers.'
  };
};
