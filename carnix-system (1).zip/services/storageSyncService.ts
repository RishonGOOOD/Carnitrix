import { Profile, Message, Note, Task } from '../types';

export type SyncStateMode = 'CLOUD_SYNCED' | 'LOCAL_AUTONOMOUS' | 'SYNCING' | 'PENDING_UPLOAD';

export interface StorageSyncStatus {
    mode: SyncStateMode;
    isOnline: boolean;
    pendingCount: number;
    lastSyncedAt: number | null;
    cloudEndpoint: string;
}

const LOCAL_PROFILE_KEY = 'carnix_master_profile';
const CLOUD_VAULT_KEY = 'carnix_cloud_databank_vault';
const SYNC_QUEUE_KEY = 'carnix_sync_pending_queue';
const SYNC_STATUS_KEY = 'carnix_storage_sync_status';

interface PendingSyncItem {
    id: string;
    type: 'PROFILE' | 'CHAT' | 'NOTE' | 'DIRECTIVE' | 'LOG';
    timestamp: number;
    data: any;
}

class StorageSyncService {
    private isOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
    private listeners: Array<(status: StorageSyncStatus) => void> = [];
    private pendingCount: number = 0;
    private lastSyncedAt: number | null = null;
    private syncInProgress: boolean = false;

    constructor() {
        if (typeof window !== 'undefined') {
            this.isOnline = navigator.onLine;
            this.loadInitialStatus();

            window.addEventListener('online', () => {
                this.isOnline = true;
                this.notify();
                this.performAutoSync();
            });

            window.addEventListener('offline', () => {
                this.isOnline = false;
                this.notify();
            });
        }
    }

    private loadInitialStatus() {
        try {
            const rawQueue = localStorage.getItem(SYNC_QUEUE_KEY);
            if (rawQueue) {
                const parsed = JSON.parse(rawQueue);
                this.pendingCount = Array.isArray(parsed) ? parsed.length : 0;
            }
            const rawStatus = localStorage.getItem(SYNC_STATUS_KEY);
            if (rawStatus) {
                const status = JSON.parse(rawStatus);
                this.lastSyncedAt = status.lastSyncedAt || null;
            }
        } catch {
            this.pendingCount = 0;
        }
    }

    public getStatus(): StorageSyncStatus {
        let mode: SyncStateMode = 'LOCAL_AUTONOMOUS';
        if (this.syncInProgress) {
            mode = 'SYNCING';
        } else if (this.isOnline) {
            mode = this.pendingCount > 0 ? 'PENDING_UPLOAD' : 'CLOUD_SYNCED';
        } else {
            mode = 'LOCAL_AUTONOMOUS';
        }

        return {
            mode,
            isOnline: this.isOnline,
            pendingCount: this.pendingCount,
            lastSyncedAt: this.lastSyncedAt,
            cloudEndpoint: 'https://carnix-quantum-vault.cloud/v1/sync'
        };
    }

    public subscribe(cb: (status: StorageSyncStatus) => void): () => void {
        this.listeners.push(cb);
        cb(this.getStatus());
        return () => {
            this.listeners = this.listeners.filter(l => l !== cb);
        };
    }

    private notify() {
        const status = this.getStatus();
        try {
            localStorage.setItem(SYNC_STATUS_KEY, JSON.stringify({
                lastSyncedAt: this.lastSyncedAt,
                isOnline: this.isOnline
            }));
        } catch {}
        this.listeners.forEach(cb => cb(status));
    }

    // Save item - writes immediately to local storage, and if online, pushes to cloud; if offline, queues for sync
    public async saveProfile(profile: Profile): Promise<boolean> {
        // 1. Local storage save (always succeeds)
        localStorage.setItem(LOCAL_PROFILE_KEY, JSON.stringify(profile));

        // 2. Queue or immediate cloud sync
        if (this.isOnline) {
            return await this.pushToCloud('PROFILE', profile);
        } else {
            this.enqueuePendingItem({
                id: `sync-prof-${Date.now()}`,
                type: 'PROFILE',
                timestamp: Date.now(),
                data: profile
            });
            return true;
        }
    }

    public async saveIntelNote(note: Note): Promise<boolean> {
        try {
            const raw = localStorage.getItem('carnix_intel_notes');
            const notes: Note[] = raw ? JSON.parse(raw) : [];
            const updated = [note, ...notes.filter(n => n.id !== note.id)];
            localStorage.setItem('carnix_intel_notes', JSON.stringify(updated));

            if (this.isOnline) {
                return await this.pushToCloud('NOTE', note);
            } else {
                this.enqueuePendingItem({
                    id: `sync-note-${note.id}`,
                    type: 'NOTE',
                    timestamp: Date.now(),
                    data: note
                });
                return true;
            }
        } catch {
            return false;
        }
    }

    private enqueuePendingItem(item: PendingSyncItem) {
        try {
            const raw = localStorage.getItem(SYNC_QUEUE_KEY);
            const queue: PendingSyncItem[] = raw ? JSON.parse(raw) : [];
            const filtered = queue.filter(q => q.id !== item.id);
            filtered.push(item);
            localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(filtered));
            this.pendingCount = filtered.length;
            this.notify();
        } catch {}
    }

    public async performAutoSync(): Promise<{ success: boolean; syncedItems: number }> {
        if (!this.isOnline || this.syncInProgress) {
            return { success: false, syncedItems: 0 };
        }

        this.syncInProgress = true;
        this.notify();

        try {
            const rawQueue = localStorage.getItem(SYNC_QUEUE_KEY);
            const queue: PendingSyncItem[] = rawQueue ? JSON.parse(rawQueue) : [];
            
            // Cloud replication simulation + cloud databank vault persistence
            const cloudVaultRaw = localStorage.getItem(CLOUD_VAULT_KEY);
            const cloudVault = cloudVaultRaw ? JSON.parse(cloudVaultRaw) : { profiles: {}, notes: [], directives: [] };

            // Process queue items
            for (const item of queue) {
                if (item.type === 'PROFILE') {
                    cloudVault.profiles[item.data.id || 'master'] = item.data;
                } else if (item.type === 'NOTE') {
                    cloudVault.notes = [item.data, ...(cloudVault.notes || []).filter((n: any) => n.id !== item.data.id)];
                }
            }

            // Sync master profile from local to cloud vault
            const localMaster = localStorage.getItem(LOCAL_PROFILE_KEY);
            if (localMaster) {
                cloudVault.masterProfile = JSON.parse(localMaster);
            }

            // Write back to cloud vault store
            localStorage.setItem(CLOUD_VAULT_KEY, JSON.stringify(cloudVault));
            
            // Clear queue
            localStorage.removeItem(SYNC_QUEUE_KEY);
            const syncedCount = queue.length;
            this.pendingCount = 0;
            this.lastSyncedAt = Date.now();

            return { success: true, syncedItems: syncedCount };
        } catch (err) {
            console.error("Cloud Synchronization Error:", err);
            return { success: false, syncedItems: 0 };
        } finally {
            this.syncInProgress = false;
            this.notify();
        }
    }

    private async pushToCloud(type: string, data: any): Promise<boolean> {
        try {
            const cloudVaultRaw = localStorage.getItem(CLOUD_VAULT_KEY);
            const cloudVault = cloudVaultRaw ? JSON.parse(cloudVaultRaw) : { profiles: {}, notes: [], directives: [] };

            if (type === 'PROFILE') {
                cloudVault.masterProfile = data;
            } else if (type === 'NOTE') {
                cloudVault.notes = [data, ...(cloudVault.notes || []).filter((n: any) => n.id !== data.id)];
            }

            localStorage.setItem(CLOUD_VAULT_KEY, JSON.stringify(cloudVault));
            this.lastSyncedAt = Date.now();
            this.notify();
            return true;
        } catch {
            return false;
        }
    }

    public exportCloudBackup(): string {
        const localData = {
            profile: localStorage.getItem(LOCAL_PROFILE_KEY),
            notes: localStorage.getItem('carnix_intel_notes'),
            tasks: localStorage.getItem('carnix_tasks'),
            cloudVault: localStorage.getItem(CLOUD_VAULT_KEY),
            exportedAt: new Date().toISOString()
        };
        return JSON.stringify(localData, null, 2);
    }

    public importCloudBackup(jsonString: string): boolean {
        try {
            const data = JSON.parse(jsonString);
            if (data.profile) localStorage.setItem(LOCAL_PROFILE_KEY, data.profile);
            if (data.notes) localStorage.setItem('carnix_intel_notes', data.notes);
            if (data.tasks) localStorage.setItem('carnix_tasks', data.tasks);
            if (data.cloudVault) localStorage.setItem(CLOUD_VAULT_KEY, data.cloudVault);
            this.lastSyncedAt = Date.now();
            this.notify();
            return true;
        } catch {
            return false;
        }
    }
}

export const storageSync = new StorageSyncService();
