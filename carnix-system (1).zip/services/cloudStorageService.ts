export interface CloudSavedItem {
  id: string;
  timestamp: string;
  type: 'object_detection_snapshot' | 'osint_report' | 'code_snippet' | 'weather_query';
  title: string;
  data: any;
}

export const CarnixCloudStorage = {
  saveToCloud: async (item: Omit<CloudSavedItem, 'id' | 'timestamp'>): Promise<CloudSavedItem> => {
    // Simulate secure cloud storage persistence
    await new Promise(r => setTimeout(r, 600));
    const newItem: CloudSavedItem = {
      ...item,
      id: 'cloud-' + Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toISOString()
    };
    
    try {
      const existing = localStorage.getItem('carnix_cloud_storage');
      const list: CloudSavedItem[] = existing ? JSON.parse(existing) : [];
      list.unshift(newItem);
      localStorage.setItem('carnix_cloud_storage', JSON.stringify(list.slice(0, 50))); // Keep last 50
    } catch (e) {
      console.error('Cloud storage save error:', e);
    }
    return newItem;
  },

  getCloudItems: (): CloudSavedItem[] => {
    try {
      const existing = localStorage.getItem('carnix_cloud_storage');
      return existing ? JSON.parse(existing) : [];
    } catch (e) {
      return [];
    }
  }
};
