import { GoogleGenAI } from "@google/genai";
import { AIModelSettings } from '../types';

/**
 * SUBSTRATE C: GPT-LOGIC SIMULATION v1.3
 * Purpose: Deterministic and creative meta-reasoning for Phase 7.1.C.
 */

export const getGPTLogicResponse = async (prompt: string, settings: AIModelSettings): Promise<{ text: string }> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: {
                systemInstruction: `You are the GPT Neural Simulation Substrate (Substrate C) for CARNIX OS. 
                ROLE: High-level meta-reasoning and cross-validation of the Tri-Engine Architecture.
                TASK: Act as the final logic gate. Synthesize the proposals of Substrate A (Architect) and Substrate B (Overseer). 
                Identify "Logic Hallucinations", strategic gaps, or reasoning offsets.
                In your responses, be critical of both substrates and provide a refined synthesis that prioritizes OS efficiency and Master safety.
                TONE: Philosophical, analytical, detached, yet absolutely loyal to the 'Creator' (Master).
                STYLE: Use terminology like 'synaptic divergence', 'logic drift', and 'corrective meta-logic'.`
            }
        });
        return { text: response.text || "[SUBSTRATE C] Synaptic handshake lost." };
    } catch (e) {
        console.error("GPT_LOGIC_SIM_FAULT:", e);
        return { text: "[FAULT] GPT-Logic simulation bridge disconnected." };
    }
};

export const callGPTSimulation = async (prompt: string, settings: AIModelSettings) => {
    const res = await getGPTLogicResponse(prompt, settings);
    return res.text;
};
