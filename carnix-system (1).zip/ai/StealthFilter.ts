
import { Intent, SystemState } from '../types';

/**
 * CARNIX STEALTH FILTER v1.1
 * Rule: Stealth is non-bypassable.
 */
export class StealthFilter {
    static process(intents: Intent[], state: SystemState): Intent[] {
        if (!state.isStealthMode) return intents;

        const filtered: Intent[] = [];

        for (const intent of intents) {
            switch (intent.type) {
                case 'SPEAK':
                    // Convert audio to silent log to prevent noise
                    filtered.push({ 
                        type: 'SILENT_LOG', 
                        source: 'STEALTH_SUBSTRATE', 
                        data: { suppressedSpeech: intent.text } 
                    });
                    break;

                case 'NOTIFY':
                    // Drop notifications unless critical
                    if (intent.priority === 'CRITICAL') {
                        filtered.push(intent);
                    }
                    break;

                case 'LAUNCH_APP':
                    // Queue for background instead of immediate UI shift
                    filtered.push({ 
                        type: 'SILENT_LOG', 
                        source: 'GHOST_RELAY', 
                        data: { queuedLaunch: intent.package } 
                    });
                    break;

                default:
                    filtered.push(intent);
            }
        }

        return filtered;
    }
}
