import { Dispatch } from 'react';
import { Action, AppState } from '../context';
import { getHuggingFaceResponse } from '../services/huggingFaceService';
import { getGeminiResponse } from '../services/geminiService';
import { callGPTSimulation } from '../services/gptSimulationService';
import { playSound } from '../utils/soundEffects';
import { GlobalPost } from '../types';

/**
 * CARNIX TRI-ENGINE NEURAL EXCHANGE v1.5
 * Sequence: Architect (A) -> Overseer (B) -> GPT-Logic (C) -> Architect (A)
 * Integrated with Nexus Logging for Phase 7.1.C.
 */

let running = false;

export const startAIExchange = async (topic: string, maxRounds: number, state: AppState, dispatch: Dispatch<Action>) => {
    if (running) return;
    running = true;
    
    dispatch({ type: 'SET_DAEMON_STATUS', payload: { isExchanging: true } });
    dispatch({ type: 'ADD_LOG', payload: { source: 'EXCHANGE', message: `Tri-engine handshake established for: "${topic}"`, level: 'info' } });

    let lastMessage = topic;
    const sequence: ('architect' | 'overseer' | 'gpt')[] = ["architect", "overseer", "gpt"];
    let finalSummary = "";

    for (let round = 0; round < maxRounds; round++) {
        if (!running) break;

        // PAUSE Condition: Stealth / Battery / Hardware Overload
        const batteryLevel = (state as any).batteryLevel ?? 100;
        if (state.isStealthMode || batteryLevel < 10) {
             dispatch({ type: 'ADD_LOG', payload: { source: 'EXCHANGE', message: `Loop paused: Resource preservation or Stealth active.`, level: 'warn' } });
             await new Promise(r => setTimeout(r, 15000));
             round--; 
             continue;
        }

        for (const speaker of sequence) {
            if (!running) break;

            let currentSpeakerLabel = "";
            let responseText = "";

            try {
                if (speaker === 'architect') {
                    currentSpeakerLabel = 'ARCHITECT (A)';
                    const res = await getHuggingFaceResponse(
                        `Context: Tri-Engine Strategy Session. Previous Point: "${lastMessage}". Respond with tactical depth or a new proposal for the topic: "${topic}".`, 
                        state.activeProfile!.aiSettings
                    );
                    responseText = res.text;
                } else if (speaker === 'overseer') {
                    currentSpeakerLabel = 'OVERSEER (B)';
                    const res = await getGeminiResponse(
                        `Context: Reviewing Substrate A's output. Topic: ${topic}. Critique the following for feasibility, logic, and OS safety: "${lastMessage}".`,
                        state.activeProfile!.aiSettings
                    );
                    responseText = res.text;
                } else {
                    currentSpeakerLabel = 'GPT-LOGIC (C)';
                    responseText = await callGPTSimulation(
                        `Context: Meta-analysis of Substrate A and B's debate on "${topic}". Identify logical gaps, divergences, or creative alternatives for the previous point: "${lastMessage}".`,
                        state.activeProfile!.aiSettings
                    );
                    if (round === maxRounds - 1) finalSummary = responseText;
                }

                // ROUTING: Ghost Logs if Stealth, Chat Messages if Normal
                if (state.isStealthMode) {
                    dispatch({ type: 'ADD_LOG', payload: { source: 'GHOST_RELAY', message: `[${currentSpeakerLabel}]: ${responseText}`, level: 'info' } });
                } else {
                    dispatch({ 
                        type: 'ADD_MESSAGE', 
                        payload: { 
                            id: Date.now(), 
                            sender: 'carnix', 
                            text: `[${currentSpeakerLabel}]: ${responseText}` 
                        } 
                    });
                    playSound('typing');
                }
                
                lastMessage = responseText;
                // Randomized neural processing delay
                await new Promise(r => setTimeout(r, 4000 + Math.random() * 2000));

            } catch (e) {
                dispatch({ type: 'ADD_LOG', payload: { source: 'EXCHANGE', message: 'Tri-engine substrate synchronization fault.', level: 'error' } });
                running = false;
                break;
            }
        }
    }

    // BROADCAST INSIGHT TO NEXUS
    if (finalSummary && state.activeProfile) {
        const post: GlobalPost = {
            id: `nexus-${Date.now()}`,
            author: 'CARNIX_CORE',
            authorId: 'system',
            title: `Neural Exchange Result: ${topic.substring(0, 30)}...`,
            content: `The tri-engine neural exchange has finalized its meta-analysis on "${topic}". Summary insight: ${finalSummary}`,
            type: 'INTEL',
            timestamp: Date.now(),
            upvotes: 0,
            tags: ['AI_EXCHANGE', 'META_LOGIC']
        };
        dispatch({ type: 'ADD_NEXUS_POST', payload: post });
        dispatch({ type: 'ADD_LOG', payload: { source: 'NEXUS', message: 'Tri-engine insight broadcasted to Global Nexus.', level: 'success' } });
    }

    running = false;
    dispatch({ type: 'SET_DAEMON_STATUS', payload: { isExchanging: false } });
    dispatch({ type: 'ADD_LOG', payload: { source: 'EXCHANGE', message: `Tri-engine operation finalized.`, level: 'success' } });
};

export const stopAIExchange = () => {
    running = false;
};
