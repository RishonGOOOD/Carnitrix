
import { Intent } from '../types';

/**
 * CARNIX INTENT ENGINE v1.1
 * Purpose: Converts signals (Text or System) into deterministic Action Objects.
 */
export class IntentEngine {
    static fromText(input: string): Intent[] {
        const text = input.toLowerCase();
        const intents: Intent[] = [];

        // 1. App Launch Intent (Deterministic)
        if (text.includes("gear up") || (text.includes("open") && text.includes("rider"))) {
            intents.push({ type: 'LAUNCH_APP', package: 'com.henshin.rider', priority: 'HIGH' });
        } else if (text.includes("open matrix") || (text.includes("show") && text.includes("settings"))) {
            intents.push({ type: 'LAUNCH_APP', package: 'com.android.settings', priority: 'LOW' });
        }

        // 2. Status Inquiry Intent
        if (text.includes("status report") || text.includes("systems check")) {
            intents.push({ 
                type: 'SPEAK', 
                text: "All neural nodes synchronized. Master, Carnix OS is operating at peak efficiency.", 
                priority: 'LOW' 
            });
        }

        // 3. Fallback: Log purely
        if (intents.length === 0) {
            intents.push({ type: 'SILENT_LOG', source: 'NEURAL_LINK', data: { rawInput: input } });
        }

        return intents;
    }

    static fromSystemEvent(event: string, data: any = {}): Intent[] {
        switch (event) {
            case 'CLIPBOARD_PACKAGE':
                return [{ type: 'LAUNCH_APP', package: data.package, priority: 'HIGH' }];
            case 'BATTERY_CRITICAL':
                return [{ 
                    type: 'NOTIFY', 
                    title: 'ENERGY_RESERVE_LOW', 
                    body: `Power at ${data.level}%. Dimming HUD.`, 
                    priority: 'CRITICAL' 
                }];
            default:
                return [];
        }
    }
}
