
/**
 * CARNIX MODEL ROUTER
 * Hard routing table for neural tasks.
 */
export class ModelRouter {
    static route(task: 'CHAT' | 'VISION' | 'CODE' | 'INTENT') {
        switch (task) {
            case 'CHAT':
                return 'meta-llama/Meta-Llama-3-8B-Instruct';
            case 'VISION':
                return 'Salesforce/blip-image-captioning-large';
            case 'CODE':
                return 'deepseek-ai/deepseek-coder-6.7b-instruct';
            case 'INTENT':
                return 'qwen/qwen2.5-7b-instruct';
            default:
                return 'meta-llama/Meta-Llama-3-8B-Instruct';
        }
    }
}
