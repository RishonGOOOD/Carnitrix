
import React, { useState, useEffect } from 'react';
import { Smartphone, Zap, MapPin, Compass as CompassIcon, Activity, HardDrive, ShieldCheck, RefreshCw, AlertTriangle } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const SensorCard: React.FC<{ title: string; icon: any; children: React.ReactNode }> = ({ title, icon: Icon, children }) => (
    <div className="bg-black/40 border border-white/5 p-4 rounded-lg flex flex-col gap-2 group hover:border-[var(--color-primary)]/30 transition-all relative overflow-hidden">
        <div className="flex items-center gap-3">
            <div className="p-2 rounded bg-white/5 text-[var(--color-primary)]">
                <Icon size={18} />
            </div>
            <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{title}</h3>
        </div>
        <div className="flex-1 flex flex-col justify-center">
            {children}
        </div>
    </div>
);

const AndroidSensorHubPanel: React.FC = () => {
    // Functional Sensors
    const [orientation, setOrientation] = useState({ alpha: 0, beta: 0, gamma: 0 });
    const [motion, setMotion] = useState({ x: 0, y: 0, z: 0 });
    const [battery, setBattery] = useState({ level: 100, charging: false });
    const [storage, setStorage] = useState({ quota: 0, usage: 0 });
    const [geo, setGeo] = useState<GeolocationCoordinates | null>(null);

    const requestPermission = async () => {
        if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
            await (DeviceOrientationEvent as any).requestPermission();
        }
        playSound('success');
    };

    useEffect(() => {
        // Battery
        if ((navigator as any).getBattery) {
            (navigator as any).getBattery().then((b: any) => {
                setBattery({ level: Math.round(b.level * 100), charging: b.charging });
            });
        }

        // Orientation
        const handleOrient = (e: DeviceOrientationEvent) => {
            if (e.alpha !== null) {
                setOrientation({ alpha: e.alpha || 0, beta: e.beta || 0, gamma: e.gamma || 0 });
            }
        };
        window.addEventListener('deviceorientation', handleOrient);

        // Motion
        const handleMotion = (e: DeviceMotionEvent) => {
            if (e.acceleration && e.acceleration.x !== null) {
                setMotion({
                    x: e.acceleration.x || 0,
                    y: e.acceleration.y || 0,
                    z: e.acceleration.z || 0
                });
            }
        };
        window.addEventListener('devicemotion', handleMotion);

        // Geolocation
        navigator.geolocation.getCurrentPosition((pos) => setGeo(pos.coords));

        // Storage
        if (navigator.storage && navigator.storage.estimate) {
            navigator.storage.estimate().then(est => {
                setStorage({ quota: est.quota || 0, usage: est.usage || 0 });
            });
        }

        return () => {
            window.removeEventListener('deviceorientation', handleOrient);
            window.removeEventListener('devicemotion', handleMotion);
        };
    }, []);

    const bytesToGB = (b: number) => (b / (1024 ** 3)).toFixed(2);

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-white/10 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-500/10 border border-green-500/50 rounded-xl flex items-center justify-center text-green-500 shadow-[0_0_20px_rgba(34,197,94,0.2)]">
                        <Smartphone size={28} className="animate-pulse" />
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-white uppercase italic tracking-tighter">Android Neural Link</h2>
                        <div className="text-[10px] font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                             <ShieldCheck size={10} className="text-green-500" /> Secure Device Bridge v3.1 // Status: Nominal
                        </div>
                    </div>
                </div>
                <button onClick={requestPermission} className="hud-button !py-2 !px-4 text-[10px] flex items-center gap-2">
                    <RefreshCw size={12} /> RE-CALIBRATE SENSORS
                </button>
            </div>

            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 overflow-y-auto scrollbar-carnix pr-1">
                {/* 1. Compass / Direction (FUNCTIONAL) */}
                <SensorCard title="Magnetic Direction" icon={CompassIcon}>
                    <div className="flex items-center justify-between">
                        <div className="text-3xl font-black text-white font-mono">{Math.round(orientation.alpha)}°</div>
                        <div className="relative w-12 h-12 border border-white/10 rounded-full flex items-center justify-center">
                             <div className="w-1 h-6 bg-red-600 rounded-full transition-transform duration-200" style={{ transform: `rotate(${orientation.alpha}deg)` }} />
                        </div>
                    </div>
                    <div className="text-[8px] text-gray-500 font-bold uppercase mt-1">Azimuth Lock: TRUE</div>
                </SensorCard>

                {/* 2. Gravity / Accelerometer (FUNCTIONAL) */}
                <SensorCard title="Gravity Matrix" icon={Activity}>
                    <div className="grid grid-cols-3 gap-1">
                        <div className="text-center bg-white/5 p-1 rounded">
                             <div className="text-[7px] text-gray-600">X-AXIS</div>
                             <div className="text-xs font-bold text-white">{motion.x.toFixed(2)}</div>
                        </div>
                        <div className="text-center bg-white/5 p-1 rounded">
                             <div className="text-[7px] text-gray-600">Y-AXIS</div>
                             <div className="text-xs font-bold text-white">{motion.y.toFixed(2)}</div>
                        </div>
                        <div className="text-center bg-white/5 p-1 rounded">
                             <div className="text-[7px] text-gray-600">Z-AXIS</div>
                             <div className="text-xs font-bold text-white">{motion.z.toFixed(2)}</div>
                        </div>
                    </div>
                </SensorCard>

                {/* 3. Location (FUNCTIONAL) */}
                <SensorCard title="Spatial Position" icon={MapPin}>
                    <div className="text-xs font-mono space-y-1">
                        <div className="flex justify-between"><span>LAT:</span> <span className="text-cyan-400">{geo?.latitude.toFixed(5) || 'Scanning...'}</span></div>
                        <div className="flex justify-between"><span>LON:</span> <span className="text-cyan-400">{geo?.longitude.toFixed(5) || 'Scanning...'}</span></div>
                        <div className="flex justify-between"><span>ALT:</span> <span className="text-gray-400">{geo?.altitude?.toFixed(1) || '0.0'}m</span></div>
                    </div>
                </SensorCard>

                {/* 4. Battery (FUNCTIONAL) */}
                <SensorCard title="Energy Reservoir" icon={Zap}>
                    <div className="flex items-center gap-4">
                        <div className="text-4xl font-black text-white font-mono">{battery.level}%</div>
                        <div className={`text-[8px] px-2 py-0.5 rounded font-black ${battery.charging ? 'bg-green-600 text-black animate-pulse' : 'bg-gray-800 text-gray-500'}`}>
                            {battery.charging ? 'UPLINK_CHARGING' : 'INTERNAL_POWER'}
                        </div>
                    </div>
                </SensorCard>

                {/* 5. Storage (FUNCTIONAL) */}
                <SensorCard title="Neural Memory" icon={HardDrive}>
                    <div className="w-full bg-gray-900 h-1 rounded-full overflow-hidden mt-2">
                        <div className="bg-red-600 h-full" style={{ width: `${storage.quota > 0 ? (storage.usage / storage.quota) * 100 : 0}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] mt-2 font-mono">
                        <span className="text-gray-500">USED: {bytesToGB(storage.usage)}GB</span>
                        <span className="text-white">FREE: {bytesToGB(storage.quota - storage.usage)}GB</span>
                    </div>
                </SensorCard>
            </div>

            <div className="bg-red-900/10 border border-red-900/30 p-4 rounded-lg flex items-start gap-4">
                <AlertTriangle size={24} className="text-red-500 shrink-0" />
                <div className="text-[10px] text-gray-400 font-mono leading-relaxed">
                    <span className="text-red-500 font-black">SYSTEM NOTICE:</span> Accessing raw sensor data requires a secure context (HTTPS) and user permission on mobile devices.
                </div>
            </div>
        </div>
    );
};

export default AndroidSensorHubPanel;
