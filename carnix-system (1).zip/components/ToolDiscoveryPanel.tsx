import React, { useState } from 'react';
import { 
  toolAdapter, CURATED_GITHUB_TOOLS 
} from '../services/toolAdapter';
import { CarnixTool, ToolCategory } from '../types';
import { 
  Search, Shield, CheckCircle2, AlertTriangle, ExternalLink, 
  Download, Power, Settings, RefreshCw, Plus, Check, Filter, Terminal, Cpu
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const ToolDiscoveryPanel: React.FC = () => {
  const [tools, setTools] = useState<CarnixTool[]>(toolAdapter.getAllTools());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [filterLicense, setFilterLicense] = useState<string>('ALL');
  const [executingToolId, setExecutingToolId] = useState<string | null>(null);
  const [executionResult, setExecutionResult] = useState<any | null>(null);
  
  // Custom repo modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [customRepoUrl, setCustomRepoUrl] = useState('');
  const [customCategory, setCustomCategory] = useState<ToolCategory>('OSINT');

  const refreshTools = () => {
    setTools(toolAdapter.getAllTools());
  };

  const handleToggle = (id: string) => {
    playSound('switch');
    triggerHaptic('light');
    toolAdapter.toggleToolEnabled(id);
    refreshTools();
  };

  const handleInstall = (id: string) => {
    playSound('success');
    triggerHaptic('medium');
    toolAdapter.installTool(id);
    refreshTools();
  };

  const handleUninstall = (id: string) => {
    playSound('alert');
    triggerHaptic('light');
    toolAdapter.uninstallTool(id);
    refreshTools();
  };

  const handleRunTest = async (tool: CarnixTool) => {
    setExecutingToolId(tool.id);
    playSound('scan');
    triggerHaptic('medium');
    const res = await toolAdapter.executeToolSafe(tool.id, { testQuery: 'target.example.org' });
    setExecutionResult(res);
    setExecutingToolId(null);
    playSound(res.success ? 'success' : 'alert');
  };

  const handleAddCustomRepo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customRepoUrl.trim()) return;
    playSound('access');
    const newTool = toolAdapter.registerCustomRepository(customRepoUrl.trim(), customCategory);
    setTools(toolAdapter.getAllTools());
    setShowAddModal(false);
    setCustomRepoUrl('');
    handleInstall(newTool.id);
  };

  // Filter tools
  const filteredTools = tools.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.repository.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || t.category === selectedCategory;
    const matchesLic = filterLicense === 'ALL' || 
                       (filterLicense === 'COMMERCIAL' ? t.commercialUseAllowed : t.license.includes(filterLicense));
    return matchesSearch && matchesCat && matchesLic;
  });

  const categories = ['ALL', 'OSINT', 'DEFENSIVE_SECURITY', 'THREAT_INTEL', 'AI_SECURITY', 'CODE_AUDIT'];

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-red-950/20 border border-red-900/30 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-red-600/20 border border-red-500 rounded text-red-400">
              <Terminal size={18} />
            </span>
            <h1 className="text-xl font-black font-orbitron text-white tracking-wider">
              GITHUB SECURITY TOOLS CATALOG & DISCOVERY
            </h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Curated, license-audited OSINT, defensive security, and AI security repositories with isolated adapter runtimes.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded transition-all shadow-[0_0_15px_rgba(255,0,0,0.4)] active:scale-95"
          >
            <Plus size={14} /> IMPORT GITHUB REPO
          </button>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
        <div className="sm:col-span-6 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Filter by tool name, capability, or GitHub repo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-black/70 border border-red-900/40 rounded-lg text-sm font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
          />
        </div>

        <div className="sm:col-span-3">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full py-2 px-3 bg-black/70 border border-red-900/40 rounded-lg text-xs font-mono text-gray-300 focus:outline-none focus:border-red-500"
          >
            {categories.map(c => (
              <option key={c} value={c}>{c.replace('_', ' ')}</option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-3">
          <select
            value={filterLicense}
            onChange={(e) => setFilterLicense(e.target.value)}
            className="w-full py-2 px-3 bg-black/70 border border-red-900/40 rounded-lg text-xs font-mono text-gray-300 focus:outline-none focus:border-red-500"
          >
            <option value="ALL">ALL LICENSES</option>
            <option value="COMMERCIAL">COMMERCIAL PERMITTED</option>
            <option value="MIT">MIT LICENSE</option>
            <option value="Apache-2.0">APACHE 2.0</option>
            <option value="GPL">GPL LICENSE</option>
          </select>
        </div>
      </div>

      {/* Execution Test Alert Result Modal / Drawer */}
      {executionResult && (
        <div className="p-3 bg-cyan-950/30 border border-cyan-500/40 rounded-xl font-mono text-xs space-y-2 animate-fadeIn">
          <div className="flex justify-between items-center text-cyan-400 font-bold">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 size={14} /> ADAPTER TEST RESULT: {executionResult.tool}
            </span>
            <button 
              onClick={() => setExecutionResult(null)}
              className="text-gray-400 hover:text-white"
            >
              ✕
            </button>
          </div>
          <div className="text-[11px] text-gray-300 bg-black/60 p-2 rounded border border-cyan-900/30">
            <div>Status: <span className={executionResult.success ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
              {executionResult.success ? "SUCCESS" : "ERROR"}
            </span> ({executionResult.executionTimeMs}ms)</div>
            {executionResult.error && <div className="text-red-400 mt-1">Error: {executionResult.error}</div>}
            {executionResult.data && <pre className="text-gray-300 overflow-x-auto mt-1">{JSON.stringify(executionResult.data, null, 2)}</pre>}
          </div>
        </div>
      )}

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {filteredTools.map(tool => {
          const isExecuting = executingToolId === tool.id;

          return (
            <div 
              key={tool.id} 
              className={`flex flex-col justify-between p-4 rounded-xl border transition-all ${
                tool.enabled 
                  ? 'bg-red-950/10 border-red-900/40 hover:border-red-500/60 shadow-[0_0_15px_rgba(255,0,0,0.05)]' 
                  : 'bg-black/40 border-white/5 opacity-70 hover:opacity-100'
              }`}
            >
              <div className="space-y-2">
                {/* Top badges */}
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/60 text-red-400 border border-red-900/40 font-bold">
                    {tool.category}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                      tool.commercialUseAllowed 
                        ? 'border-emerald-500/40 text-emerald-400 bg-emerald-950/30' 
                        : 'border-amber-500/40 text-amber-400 bg-amber-950/30'
                    }`}>
                      {tool.license}
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/40 border border-cyan-900/30 text-cyan-300">
                      {tool.integrationType}
                    </span>
                  </div>
                </div>

                {/* Title and Repo Link */}
                <div className="flex items-center justify-between pt-1">
                  <h3 className="text-base font-bold font-orbitron text-white">
                    {tool.name}
                  </h3>
                  <a 
                    href={tool.repository} 
                    target="_blank" 
                    rel="noreferrer"
                    className="text-gray-400 hover:text-red-400 transition-colors p-1"
                    title="View GitHub Repository"
                  >
                    <ExternalLink size={14} />
                  </a>
                </div>

                <p className="text-xs text-gray-400 leading-relaxed font-mono line-clamp-2">
                  {tool.description}
                </p>

                {/* Capabilities chips */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {tool.capabilities.slice(0, 3).map((cap, i) => (
                    <span key={i} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/60 text-gray-400 border border-white/5">
                      • {cap}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action controls */}
              <div className="pt-4 mt-3 border-t border-white/5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {tool.installed ? (
                    <button
                      onClick={() => handleToggle(tool.id)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-mono tracking-wider font-bold transition-all ${
                        tool.enabled 
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30' 
                          : 'bg-gray-800 text-gray-400 border border-gray-700 hover:bg-gray-700'
                      }`}
                    >
                      <Power size={11} /> {tool.enabled ? 'ENABLED' : 'DISABLED'}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleInstall(tool.id)}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-mono tracking-wider font-bold bg-cyan-600/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-600/30 transition-all"
                    >
                      <Download size={11} /> INSTALL
                    </button>
                  )}
                </div>

                <button
                  disabled={!tool.enabled || isExecuting}
                  onClick={() => handleRunTest(tool)}
                  className="flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-mono tracking-wider font-bold bg-red-950/40 border border-red-900/40 hover:border-red-500 text-red-400 disabled:opacity-30 transition-all"
                >
                  <RefreshCw size={11} className={isExecuting ? 'animate-spin' : ''} />
                  {isExecuting ? 'PROBING...' : 'RUN TEST'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Custom GitHub Repo Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0a0003] border border-red-600/60 rounded-xl p-5 space-y-4 font-mono">
            <div className="flex justify-between items-center text-white border-b border-red-900/40 pb-2">
              <span className="font-bold text-sm tracking-wider text-red-500 flex items-center gap-2">
                <Plus size={16} /> REGISTER EXTERNAL GITHUB REPOSITORY
              </span>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddCustomRepo} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-400 mb-1">GitHub Repository URL or owner/repo:</label>
                <input
                  type="text"
                  required
                  placeholder="https://github.com/projectdiscovery/nuclei"
                  value={customRepoUrl}
                  onChange={(e) => setCustomRepoUrl(e.target.value)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-white focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-400 mb-1">Target Engine Category:</label>
                <select
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value as ToolCategory)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-gray-300 focus:border-red-500 focus:outline-none"
                >
                  <option value="OSINT">OSINT (Public Recon)</option>
                  <option value="DEFENSIVE_SECURITY">DEFENSIVE SECURITY (Auditing)</option>
                  <option value="THREAT_INTEL">THREAT INTELLIGENCE</option>
                  <option value="AI_SECURITY">AI SECURITY (LLM Red Team)</option>
                  <option value="CODE_AUDIT">CODE AUDIT & SAST</option>
                </select>
              </div>

              <div className="p-3 bg-red-950/20 border border-red-900/30 rounded text-[11px] text-gray-400 space-y-1">
                <div className="text-red-400 font-bold flex items-center gap-1">
                  <Shield size={12} /> ISOLATION & COMPLIANCE POLICY:
                </div>
                <p>CARNIX analyzes license type, commercial viability, and security clearance. External code runs strictly inside sandboxed adapters.</p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-gray-800 text-gray-400 rounded hover:text-white"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black uppercase tracking-wider rounded"
                >
                  CATALOG TOOL
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ToolDiscoveryPanel;
