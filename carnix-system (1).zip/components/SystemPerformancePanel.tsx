import React, { useState, useEffect, useRef } from 'react';
import { Cpu, MemoryStick, Activity } from 'lucide-react';
import { SystemPerformanceMetrics } from '../types';

const SystemPerformancePanel: React.FC = () => {
    const [metrics, setMetrics] = useState<SystemPerformanceMetrics>({
        cpuCores: navigator.hardwareConcurrency || 0,
        memory: { totalJSHeapSize: 0, usedJSHeapSize: 0, jsHeapSizeLimit: 0 },
        cpuUsage: new Array(50).fill(0),
        gpuUsage: 0,
    });

    useEffect(() => {
        const interval = setInterval(() => {
            const memory = (performance as any).memory;
            const newCpuUsage = Math.random() * 50 + 10; // Simulate 10-60% usage

            setMetrics(prev => ({
                ...prev,
                memory: memory ? {
                    totalJSHeapSize: memory.totalJSHeapSize,
                    usedJSHeapSize: memory.usedJSHeapSize,
                    jsHeapSizeLimit: memory.jsHeapSizeLimit,
                } : prev.memory,
                cpuUsage: [...prev.cpuUsage.slice(1), newCpuUsage],
            }));
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const bytesToMB = (bytes: number) => (bytes / 1024 / 1024).toFixed(1);

    const memoryUsagePercent = metrics.memory.jsHeapSizeLimit > 0
        ? (metrics.memory.usedJSHeapSize / metrics.memory.jsHeapSizeLimit) * 100
        : 0;

    const renderCpuGraph = (data: number[], color: string) => (
        <svg viewBox="0 0 100 40" className="w-full h-full" preserveAspectRatio="none">
            <path 
                d={`M 0 40 L ` + data.map((p, i) => `${(i / (data.length - 1)) * 100} ${40 - (p / 100) * 40}`).join(' L ')}
                fill={`${color}20`} stroke={color} strokeWidth="1"/>
        </svg>
    );

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-black/30 border-l-4 border-blue-500 rounded-r-md p-4">
                    <div className="text-xs text-gray-400">CPU CORES</div>
                    <div className="text-4xl font-bold font-mono text-white">{metrics.cpuCores}</div>
                </div>
                 <div className="bg-black/30 border-l-4 border-green-500 rounded-r-md p-4">
                    <div className="text-xs text-gray-400">MEMORY USAGE</div>
                    <div className="text-4xl font-bold font-mono text-white">{bytesToMB(metrics.memory.usedJSHeapSize)} <span className="text-lg">MB</span></div>
                </div>
                <div className="bg-black/30 border-l-4 border-yellow-500 rounded-r-md p-4">
                    <div className="text-xs text-gray-400">MEMORY LIMIT</div>
                    <div className="text-4xl font-bold font-mono text-white">{bytesToMB(metrics.memory.jsHeapSizeLimit)} <span className="text-lg">MB</span></div>
                </div>
                <div className="bg-black/30 border-l-4 border-purple-500 rounded-r-md p-4">
                    <div className="text-xs text-gray-400">CPU LOAD (SIM)</div>
                    <div className="text-4xl font-bold font-mono text-white">{metrics.cpuUsage[metrics.cpuUsage.length - 1].toFixed(1)}<span className="text-lg">%</span></div>
                </div>
            </div>

            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 overflow-hidden">
                <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <h3 className="p-2 border-b border-gray-700 text-xs font-bold text-blue-400 flex items-center gap-2"><Cpu size={14} /> CPU USAGE HISTORY</h3>
                    <div className="flex-1 p-2">
                        {renderCpuGraph(metrics.cpuUsage, '#3b82f6')}
                    </div>
                </div>
                 <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col p-4 justify-between">
                     <div>
                        <h3 className="text-sm font-bold text-green-400 flex items-center gap-2 mb-4"><MemoryStick size={16} /> MEMORY ALLOCATION</h3>
                        <div className="w-full bg-gray-800 rounded-full h-4">
                            <div className="bg-green-500 h-4 rounded-full" style={{ width: `${memoryUsagePercent}%` }}></div>
                        </div>
                        <div className="text-xs text-center mt-2 font-mono">{memoryUsagePercent.toFixed(1)}% Used</div>
                    </div>
                     <div className="text-xs text-gray-500 font-mono">
                        <p>Used: {bytesToMB(metrics.memory.usedJSHeapSize)} MB</p>
                        <p>Allocated: {bytesToMB(metrics.memory.totalJSHeapSize)} MB</p>
                        <p>Limit: {bytesToMB(metrics.memory.jsHeapSizeLimit)} MB</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SystemPerformancePanel;