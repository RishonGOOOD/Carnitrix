
import React, { useState } from 'react';
import { History, Plus, AlertTriangle } from 'lucide-react';

interface RestorePoint {
    id: string;
    date: Date;
    description: string;
}

const RecoveryBackupPanel: React.FC = () => {
    const [restorePoints, setRestorePoints] = useState<RestorePoint[]>([
        { id: 'rp-1', date: new Date(Date.now() - 86400000), description: 'System Update v2.9 Pre-Patch' }
    ]);
    const [isWorking, setIsWorking] = useState(false);
    const [workStatus, setWorkStatus] = useState('');

    const createRestorePoint = () => {
        setIsWorking(true);
        setWorkStatus('Creating system snapshot...');
        setTimeout(() => {
            const newPoint: RestorePoint = {
                id: `rp-${Date.now()}`,
                date: new Date(),
                description: `Manual Restore Point`,
            };
            setRestorePoints(prev => [newPoint, ...prev]);
            setWorkStatus('Snapshot created successfully.');
            setTimeout(() => {
                setIsWorking(false);
                setWorkStatus('');
            }, 1500);
        }, 2000);
    };

    const restoreSystem = (id: string) => {
        if (!confirm('Are you sure you want to restore? This will reload the application.')) return;
        setIsWorking(true);
        setWorkStatus(`Restoring from point ${id}...`);
        setTimeout(() => {
            window.location.reload();
        }, 3000);
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex flex-col sm:flex-row items-center gap-4">
                <button onClick={createRestorePoint} disabled={isWorking} className="flex-1 w-full sm:w-auto p-3 bg-blue-900/40 text-blue-300 border border-blue-700 rounded text-sm flex items-center justify-center gap-2 disabled:opacity-50">
                    <Plus size={16} /> CREATE RESTORE POINT
                </button>
                <div className="flex-1 w-full sm:w-auto bg-black/40 p-3 rounded text-xs border border-gray-800">
                    <div className="text-gray-400 mb-1">STATUS</div>
                    <div className="font-mono text-white truncate">{isWorking ? workStatus : 'System nominal. Ready for backup.'}</div>
                </div>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden">
                <h3 className="p-2 border-b border-gray-700 text-sm font-bold text-white flex items-center gap-2">
                    <History size={16} /> AVAILABLE RESTORE POINTS
                </h3>
                <div className="flex-1 overflow-y-auto">
                    {restorePoints.map(rp => (
                        <div key={rp.id} className="p-3 border-b border-gray-800 flex justify-between items-center group">
                            <div>
                                <p className="font-bold text-white">{rp.description}</p>
                                <p className="text-xs text-gray-400">{rp.date.toLocaleString()}</p>
                            </div>
                            <button onClick={() => restoreSystem(rp.id)} disabled={isWorking} className="px-3 py-1 bg-yellow-900/40 text-yellow-300 border border-yellow-700 rounded text-xs disabled:opacity-50 opacity-0 group-hover:opacity-100 transition-opacity">
                                RESTORE
                            </button>
                        </div>
                    ))}
                </div>
            </div>
            <div className="bg-red-900/20 border border-red-700 rounded-md p-3 text-xs text-red-300 flex items-center gap-2">
                <AlertTriangle size={24} />
                <div>
                    <span className="font-bold">WARNING:</span> System restore is a simulation. It will only reload the current application state.
                </div>
            </div>
        </div>
    );
};

export default RecoveryBackupPanel;
