import React, { useState } from 'react';
import { 
  Cpu, ShieldCheck, Activity, Search, Terminal, Globe, Lock, Unlock, 
  CheckCircle2, AlertTriangle, RefreshCw, Layers, Zap, GitBranch, FileCode, Server 
} from 'lucide-react';
import { getCarnixCapabilities, analyzeRepositoryForCarnix, CapabilityStatus } from '../services/carnixEngine';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const CarnixPlatformHub: React.FC = () => {
  const [capabilities, setCapabilities] = useState<CapabilityStatus[]>(getCarnixCapabilities());
  const [repoUrl, setRepoUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'capabilities' | 'import' | 'observability'>('capabilities');

  const handleAnalyzeRepo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!repoUrl.trim()) return;
    setIsAnalyzing(true);
    playSound('click');
    triggerHaptic('medium');

    try {
      const res = await analyzeRepositoryForCarnix(repoUrl);
      setAnalysisResult(res);
      playSound('success');
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050102] text-white font-[Rajdhani] p-2 sm:p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-red-900/40">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="text-red-500 animate-pulse" size={24} />
            <h1 className="text-xl font-black tracking-wider text-red-500 uppercase">CARNIX UNIFIED PLATFORM HUB</h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-0.5">
            Dynamic capability discovery, repository safety analysis, circuit breakers, and universal multi-agent orchestration.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {['capabilities', 'import', 'observability'].map(tab => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab as any);
                playSound('click');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase transition-all ${
                activeTab === tab 
                  ? 'bg-red-600 text-black font-bold shadow-[0_0_15px_rgba(255,0,0,0.4)]' 
                  : 'bg-black/60 text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Capabilities Tab */}
      {activeTab === 'capabilities' && (
        <div className="space-y-4 mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {capabilities.map(cap => (
              <div key={cap.id} className="bg-black/70 border border-red-950/80 rounded-xl p-3.5 flex flex-col justify-between hover:border-red-500/50 transition-all">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-900/40 uppercase">
                      {cap.category}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                      {cap.status}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white">{cap.name}</h3>
                  <p className="text-xs text-gray-400 font-mono mt-1">{cap.details}</p>
                </div>
                <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/5 text-[10px] font-mono text-gray-500">
                  <span>Latency: <strong className="text-emerald-400">{cap.latencyMs}ms</strong></span>
                  <span className="text-red-400 font-bold">AUTHORIZED</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Repository Import Tab ("Make Carnix") */}
      {activeTab === 'import' && (
        <div className="space-y-4 mt-4">
          <div className="bg-black/70 border border-red-950/80 rounded-xl p-4">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
              <GitBranch size={16} className="text-red-500" />
              "Make Carnix" Repository Safety & License Importer
            </h2>
            <p className="text-xs text-gray-400 font-mono mb-4">
              Analyze public GitHub repositories for safe integration, dependency mapping, license compatibility, and security auditing.
            </p>

            <form onSubmit={handleAnalyzeRepo} className="flex gap-2">
              <div className="relative flex-1">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={repoUrl}
                  onChange={(e) => setRepoUrl(e.target.value)}
                  placeholder="Enter public GitHub repository URL (e.g. https://github.com/aviarytech/jarvis)..."
                  className="w-full bg-black/90 border border-red-900/50 rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
                />
              </div>
              <button
                type="submit"
                disabled={isAnalyzing}
                className="px-5 py-2 bg-red-600 hover:bg-red-500 text-black font-bold rounded-lg text-xs font-mono flex items-center gap-2 shadow-[0_0_15px_rgba(255,0,0,0.4)] transition-all shrink-0 disabled:opacity-50"
              >
                {isAnalyzing ? <RefreshCw size={14} className="animate-spin" /> : <ShieldCheck size={14} />}
                {isAnalyzing ? 'ANALYZING...' : 'ANALYZE REPO'}
              </button>
            </form>

            {analysisResult && (
              <div className="mt-4 p-4 bg-black/90 border border-emerald-500/40 rounded-xl space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-emerald-400" />
                    <span className="text-xs font-mono font-bold text-white">Repository Analysis Successful: {analysisResult.repoName}</span>
                  </div>
                  <span className="text-[10px] font-mono bg-emerald-950/80 text-emerald-400 px-2 py-0.5 rounded border border-emerald-900">
                    Security Score: {analysisResult.securityScore}/100
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                  <div className="bg-black/60 p-2.5 rounded-lg border border-white/5">
                    <span className="text-gray-400">License Status:</span>
                    <div className="text-emerald-400 font-bold mt-0.5">{analysisResult.license}</div>
                  </div>
                  <div className="bg-black/60 p-2.5 rounded-lg border border-white/5">
                    <span className="text-gray-400">Compatibility:</span>
                    <div className="text-red-400 font-bold mt-0.5">{analysisResult.compatibility}</div>
                  </div>
                </div>

                <div className="text-xs font-mono text-gray-300">
                  <span className="text-gray-400 block mb-1">Reusable Modules Detected:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {analysisResult.reusableModules.map((m: string) => (
                      <span key={m} className="px-2 py-0.5 bg-red-950/60 text-red-400 border border-red-900/40 rounded text-[10px]">
                        {m}
                      </span>
                    ))}
                  </div>
                </div>

                <p className="text-xs font-mono text-gray-400 pt-2 border-t border-white/5">
                  <strong>Recommendation:</strong> {analysisResult.recommendation} ({analysisResult.attributionRequired})
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Observability Tab */}
      {activeTab === 'observability' && (
        <div className="space-y-4 mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-black/70 border border-red-950/80 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-gray-400">CIRCUIT BREAKERS</span>
              <div className="text-lg font-black text-emerald-400 mt-1">ALL CLOSED (NORMAL)</div>
            </div>
            <div className="bg-black/70 border border-red-950/80 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-gray-400">AVERAGE LATENCY</span>
              <div className="text-lg font-black text-white mt-1 font-mono">112 ms</div>
            </div>
            <div className="bg-black/70 border border-red-950/80 rounded-xl p-3.5">
              <span className="text-[10px] font-mono text-gray-400">ERROR RECOVERY RATE</span>
              <div className="text-lg font-black text-emerald-400 mt-1 font-mono">100%</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CarnixPlatformHub;
