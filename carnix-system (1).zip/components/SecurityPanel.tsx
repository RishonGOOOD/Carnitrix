
import React, { useState } from 'react';
import { Shield, Lock, Terminal, FileCode, Check, Copy, Loader2, Send } from 'lucide-react';
import { useAppContext } from '../context';
import { generateHackingScript } from '../services/geminiService';
import { playSound } from '../utils/soundEffects';
import { copyToClipboard } from '../utils/nativeBridge';

const SecurityPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [prompt, setPrompt] = useState('');
    const [code, setCode] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [hasCopied, setHasCopied] = useState(false);

    const handleGenerate = async () => {
        if (!activeProfile || !prompt.trim()) return;
        setIsLoading(true);
        setCode(null);
        playSound('process');
        try {
            const res = await generateHackingScript(prompt, activeProfile.aiSettings);
            setCode(res.code);
            playSound('success');
        } catch (e: any) {
            setCode(`// Error generating script: ${e.message}`);
            playSound('error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopy = async () => {
        if (!code) return;
        const success = await copyToClipboard(code);
        if (success) {
            setHasCopied(true);
            playSound('click');
            setTimeout(() => setHasCopied(false), 2000);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-white/10 p-4 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <Shield size={24} className="text-red-500" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic tracking-tighter">Security Lab</h2>
                        <p className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Penetration Testing // Educational Scripting</p>
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-3 overflow-hidden">
                <div className="w-full md:w-1/3 flex flex-col gap-3">
                    <div className="bg-black/40 border border-white/10 p-4 rounded-lg flex-1">
                        <label className="text-[10px] font-bold text-red-400 uppercase mb-2 block">Payload Definition</label>
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="Describe the tool to generate..."
                            className="w-full h-32 bg-black/50 border border-gray-700 rounded p-3 text-xs text-white focus:border-red-500 outline-none resize-none font-mono"
                        />
                        <button 
                            onClick={handleGenerate} 
                            disabled={isLoading || !prompt.trim()}
                            className="w-full mt-3 py-3 bg-red-900/30 border border-red-600 text-red-500 font-black text-xs uppercase tracking-widest hover:bg-red-600 hover:text-black transition-all flex items-center justify-center gap-2"
                        >
                            {isLoading ? <Loader2 size={14} className="animate-spin" /> : <Terminal size={14} />}
                            GENERATE SCRIPT
                        </button>
                    </div>
                    <div className="p-4 bg-red-900/10 border border-red-900/30 rounded text-[10px] text-red-400 font-mono">
                        <Lock size={12} className="inline mr-2"/>
                        WARNING: Generated scripts are for educational and authorized testing purposes only.
                    </div>
                </div>

                <div className="flex-1 bg-black border border-white/10 rounded-lg overflow-hidden flex flex-col relative">
                    <div className="bg-white/5 border-b border-white/5 p-2 flex justify-between items-center">
                        <div className="text-[10px] font-bold text-gray-400 flex items-center gap-2"><FileCode size={12}/> SOURCE OUTPUT</div>
                        {code && (
                            <button onClick={handleCopy} className="text-gray-400 hover:text-white transition-colors">
                                {hasCopied ? <Check size={14} className="text-green-500"/> : <Copy size={14}/>}
                            </button>
                        )}
                    </div>
                    <div className="flex-1 overflow-auto p-4 font-mono text-xs text-green-500/80 scrollbar-carnix">
                        {code ? <pre>{code}</pre> : <div className="text-gray-700 italic opacity-50 flex items-center justify-center h-full">Awaiting generation...</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SecurityPanel;
