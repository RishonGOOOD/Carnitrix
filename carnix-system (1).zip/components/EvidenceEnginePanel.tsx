import React, { useState } from 'react';
import { EvidenceEngine } from '../services/evidenceEngine';
import { EvidenceGraph, EvidenceNode, EvidenceEdge, EvidenceConfidence } from '../types';
import { 
  Network, Shield, ExternalLink, Info, CheckCircle2, 
  HelpCircle, AlertCircle, Plus, RefreshCw, Download, Layers
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const EvidenceEnginePanel: React.FC = () => {
  const [graph, setGraph] = useState<EvidenceGraph>(EvidenceEngine.getGraph());
  const [selectedNode, setSelectedNode] = useState<EvidenceNode | null>(graph.nodes[0] || null);
  const [selectedEdge, setSelectedEdge] = useState<EvidenceEdge | null>(null);
  const [filterConfidence, setFilterConfidence] = useState<string>('ALL');

  // Add node modal
  const [showAddNode, setShowAddNode] = useState(false);
  const [newNodeLabel, setNewNodeLabel] = useState('');
  const [newNodeType, setNewNodeType] = useState<EvidenceNode['type']>('DOMAIN');
  const [newNodeConfidence, setNewNodeConfidence] = useState<EvidenceConfidence>('CONFIRMED');

  const handleSelectNode = (node: EvidenceNode) => {
    setSelectedNode(node);
    setSelectedEdge(null);
    playSound('click');
    triggerHaptic('light');
  };

  const handleSelectEdge = (edge: EvidenceEdge) => {
    setSelectedEdge(edge);
    playSound('click');
    triggerHaptic('light');
  };

  const handleAddNode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNodeLabel.trim()) return;
    const node: EvidenceNode = {
      id: `node-${Date.now()}`,
      label: newNodeLabel.trim(),
      type: newNodeType,
      confidence: newNodeConfidence,
      properties: {},
      source: 'Analyst Manual Linkage',
      timestamp: Date.now()
    };
    EvidenceEngine.addNode(node);
    setGraph(EvidenceEngine.getGraph());
    setSelectedNode(node);
    setShowAddNode(false);
    setNewNodeLabel('');
    playSound('success');
  };

  const handleExportGraphJson = () => {
    playSound('click');
    const blob = new Blob([JSON.stringify(graph, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `carnix-evidence-graph-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const confidenceBadge = (conf: EvidenceConfidence) => {
    switch (conf) {
      case 'CONFIRMED':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800">CONFIRMED</span>;
      case 'LIKELY':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-400 border border-cyan-800">LIKELY</span>;
      case 'POSSIBLE':
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/80 text-amber-400 border border-amber-800">POSSIBLE</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-gray-900 text-gray-400 border border-gray-700">UNKNOWN</span>;
    }
  };

  const nodeColor = (type: EvidenceNode['type']) => {
    switch (type) {
      case 'DOMAIN': return 'text-cyan-400 border-cyan-500/50 bg-cyan-950/30';
      case 'IP': return 'text-emerald-400 border-emerald-500/50 bg-emerald-950/30';
      case 'CERTIFICATE': return 'text-amber-400 border-amber-500/50 bg-amber-950/30';
      case 'ORGANIZATION': return 'text-purple-400 border-purple-500/50 bg-purple-950/30';
      case 'USERNAME': return 'text-red-400 border-red-500/50 bg-red-950/30';
      default: return 'text-gray-300 border-gray-600 bg-gray-900/40';
    }
  };

  const filteredNodes = graph.nodes.filter(n => {
    if (filterConfidence === 'ALL') return true;
    return n.confidence === filterConfidence;
  });

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-red-950/20 border border-red-900/30 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-red-600/20 border border-red-500 rounded text-red-400">
              <Network size={18} />
            </span>
            <h1 className="text-xl font-black font-orbitron text-white tracking-wider">
              EVIDENCE GRAPH & ATTRIBUTION ENGINE
            </h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Entity → Relationship → Evidence → Source → Timestamp. Strict factual attribution; no simulated relationships.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddNode(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded transition-all shadow-[0_0_15px_rgba(255,0,0,0.4)]"
          >
            <Plus size={14} /> ADD ENTITY
          </button>
          <button
            onClick={handleExportGraphJson}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-black border border-red-900/40 hover:border-red-500 text-red-400 font-mono text-xs uppercase tracking-wider rounded transition-all"
          >
            <Download size={14} /> EXPORT JSON
          </button>
        </div>
      </div>

      {/* Main Graph Grid (Visualizer on Left, Inspector on Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Visual Graph Viewport (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-3 p-4 bg-black/70 border border-red-900/30 rounded-xl">
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <span className="text-xs font-mono font-bold text-gray-400 flex items-center gap-1.5">
              <Layers size={14} className="text-red-500" /> ENTITY ATTRIBUTION NODES ({filteredNodes.length})
            </span>
            <div className="flex gap-2">
              <select
                value={filterConfidence}
                onChange={(e) => setFilterConfidence(e.target.value)}
                className="py-1 px-2 bg-black border border-red-900/40 rounded text-xs font-mono text-gray-300 focus:outline-none"
              >
                <option value="ALL">ALL CONFIDENCE LEVELS</option>
                <option value="CONFIRMED">CONFIRMED ONLY</option>
                <option value="LIKELY">LIKELY</option>
                <option value="POSSIBLE">POSSIBLE</option>
              </select>
            </div>
          </div>

          {/* Node Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 overflow-y-auto max-h-[420px] p-1">
            {filteredNodes.map(node => {
              const isSelected = selectedNode?.id === node.id;
              return (
                <div
                  key={node.id}
                  onClick={() => handleSelectNode(node)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected ? 'ring-2 ring-red-500 shadow-[0_0_15px_rgba(255,0,0,0.3)]' : 'hover:border-white/20'
                  } ${nodeColor(node.type)}`}
                >
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-[10px] font-mono uppercase font-bold tracking-wider opacity-80">
                      {node.type}
                    </span>
                    {confidenceBadge(node.confidence)}
                  </div>
                  <div className="font-bold text-sm text-white truncate font-orbitron">
                    {node.label}
                  </div>
                  <div className="text-[10px] text-gray-400 font-mono mt-1 truncate">
                    Source: {node.source}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Relationship Edges List */}
          <div className="mt-2 pt-3 border-t border-white/5 space-y-2">
            <div className="text-xs font-mono font-bold text-gray-400">
              CONFIRMED RELATIONSHIPS & BRIDGES ({graph.edges.length})
            </div>
            <div className="space-y-1.5 max-h-[140px] overflow-y-auto">
              {graph.edges.map(edge => {
                const fromNode = graph.nodes.find(n => n.id === edge.fromId);
                const toNode = graph.nodes.find(n => n.id === edge.toId);
                return (
                  <div
                    key={edge.id}
                    onClick={() => handleSelectEdge(edge)}
                    className="p-2 rounded bg-red-950/20 border border-red-900/30 hover:border-red-500 text-xs font-mono flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="text-cyan-400 font-bold truncate max-w-[120px]">{fromNode?.label || edge.fromId}</span>
                      <span className="text-red-400 text-[10px] px-1.5 py-0.5 rounded bg-black">--[{edge.relationship}]--&gt;</span>
                      <span className="text-emerald-400 font-bold truncate max-w-[120px]">{toNode?.label || edge.toId}</span>
                    </div>
                    {confidenceBadge(edge.confidence)}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Node & Edge Inspector (5 Cols) */}
        <div className="lg:col-span-5 p-4 bg-red-950/10 border border-red-900/30 rounded-xl font-mono text-xs space-y-4">
          <div className="border-b border-red-900/30 pb-2 flex justify-between items-center">
            <span className="font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Info size={14} className="text-red-400" /> RELATIONSHIP & ATTRIBUTION PROOF
            </span>
            <span className="text-[10px] text-gray-400">INSPECTOR</span>
          </div>

          {selectedEdge ? (
            <div className="space-y-3">
              <div>
                <span className="text-gray-400 text-[10px]">RELATIONSHIP TYPE</span>
                <div className="text-base font-bold text-red-400 font-orbitron">{selectedEdge.relationship}</div>
              </div>
              <div className="p-3 bg-black/60 rounded border border-red-900/30 space-y-1">
                <span className="text-gray-400 text-[10px]">EVIDENCE REASONING (WHY THIS EXISTS)</span>
                <p className="text-gray-200 leading-relaxed">{selectedEdge.evidence}</p>
              </div>
              <div>
                <span className="text-gray-400 text-[10px]">AUTHORITATIVE SOURCE</span>
                <div className="text-emerald-400 font-bold">{selectedEdge.source}</div>
              </div>
              <div>
                <span className="text-gray-400 text-[10px]">CONFIDENCE LEVEL</span>
                <div className="mt-0.5">{confidenceBadge(selectedEdge.confidence)}</div>
              </div>
              <div>
                <span className="text-gray-400 text-[10px]">TIMESTAMP OBSERVED</span>
                <div className="text-gray-300">{new Date(selectedEdge.timestamp).toLocaleString()}</div>
              </div>
            </div>
          ) : selectedNode ? (
            <div className="space-y-3">
              <div>
                <span className="text-gray-400 text-[10px]">ENTITY IDENTIFIER</span>
                <div className="text-base font-bold text-white font-orbitron break-all">{selectedNode.label}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <span className="text-gray-400 text-[10px]">ENTITY TYPE</span>
                  <div className="text-cyan-400 font-bold">{selectedNode.type}</div>
                </div>
                <div>
                  <span className="text-gray-400 text-[10px]">CONFIDENCE</span>
                  <div className="mt-0.5">{confidenceBadge(selectedNode.confidence)}</div>
                </div>
              </div>
              <div className="p-3 bg-black/60 rounded border border-red-900/30 space-y-1">
                <span className="text-gray-400 text-[10px]">AUTHORITATIVE DISCOVERY SOURCE</span>
                <div className="text-emerald-400 font-bold">{selectedNode.source}</div>
                <div className="text-gray-400 text-[10px] mt-1">Recorded: {new Date(selectedNode.timestamp).toLocaleString()}</div>
              </div>

              {selectedNode.properties && Object.keys(selectedNode.properties).length > 0 && (
                <div>
                  <span className="text-gray-400 text-[10px]">VERIFIED PROPERTIES</span>
                  <pre className="p-2 bg-black/70 rounded text-[11px] text-gray-300 overflow-x-auto mt-1 border border-white/5">
                    {JSON.stringify(selectedNode.properties, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          ) : (
            <div className="text-gray-500 py-10 text-center">
              Select an entity node or relationship link to inspect evidence reasoning.
            </div>
          )}
        </div>
      </div>

      {/* Add Entity Modal */}
      {showAddNode && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0a0003] border border-red-600/60 rounded-xl p-5 space-y-4 font-mono">
            <div className="flex justify-between items-center text-white border-b border-red-900/40 pb-2">
              <span className="font-bold text-sm tracking-wider text-red-500 flex items-center gap-2">
                <Plus size={16} /> ADD EVIDENCE GRAPH ENTITY
              </span>
              <button onClick={() => setShowAddNode(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddNode} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-400 mb-1">Entity Label / Value:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 198.51.100.42 or api.target.com"
                  value={newNodeLabel}
                  onChange={(e) => setNewNodeLabel(e.target.value)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-white focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-400 mb-1">Entity Type:</label>
                <select
                  value={newNodeType}
                  onChange={(e) => setNewNodeType(e.target.value as EvidenceNode['type'])}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-gray-300 focus:border-red-500 focus:outline-none"
                >
                  <option value="DOMAIN">DOMAIN</option>
                  <option value="IP">IP ADDRESS</option>
                  <option value="CERTIFICATE">CERTIFICATE</option>
                  <option value="ORGANIZATION">ORGANIZATION</option>
                  <option value="USERNAME">USERNAME</option>
                  <option value="HASH">FILE / HASH</option>
                  <option value="INFRASTRUCTURE">INFRASTRUCTURE</option>
                  <option value="VULNERABILITY">VULNERABILITY</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-400 mb-1">Confidence Assessment:</label>
                <select
                  value={newNodeConfidence}
                  onChange={(e) => setNewNodeConfidence(e.target.value as EvidenceConfidence)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-gray-300 focus:border-red-500 focus:outline-none"
                >
                  <option value="CONFIRMED">CONFIRMED (Authoritative Record)</option>
                  <option value="LIKELY">LIKELY (Corroborated by &gt;1 source)</option>
                  <option value="POSSIBLE">POSSIBLE (Single unverified reference)</option>
                  <option value="UNKNOWN">UNKNOWN</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddNode(false)}
                  className="px-3 py-1.5 bg-gray-800 text-gray-400 rounded hover:text-white"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black uppercase tracking-wider rounded"
                >
                  SAVE NODE
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EvidenceEnginePanel;
