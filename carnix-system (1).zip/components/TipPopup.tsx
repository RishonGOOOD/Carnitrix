import React, { useState, useEffect } from 'react';
import { Bot, Sparkles, X, Info } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const TIPS = [
  "Double-tap the Dashboard Reactor to jump to Neural Link instantly.",
  "You can drag and drop files into the Vision Hub for rapid tactical analysis.",
  "Type 'CHECK' in the Registry Node to unlock all system modules at once.",
  "System Evolution happens every 12 hours. Level up to reduce latency.",
  "The Ring Array can be rotated with your mouse wheel or swipe gestures.",
  "Use the Ethical Hacking Lab strictly for authorized educational penetration tests.",
  "Psionic Interface signals are encrypted. Focus on the core for detection.",
  "The File Guardian can scan local directories recursively for metadata."
];

const TipPopup: React.FC = () => {
    const { state } = useAppContext();
    const [isVisible, setIsVisible] = useState(false);
    const [currentTip, setCurrentTip] = useState('');
    
    useEffect(() => {
        if (!state.activeProfile) return;

        // Condition: User profile is older than 7 weeks (49 days)
        const SEVEN_WEEKS_MS = 7 * 7 * 24 * 60 * 60 * 1000;
        const profileAge = Date.now() - state.activeProfile.nodeCreatedAt;
        if (profileAge > SEVEN_WEEKS_MS) return;

        // Trigger logic: Randomly every few minutes or on mode change
        const triggerTip = () => {
            if (isVisible) return;
            setCurrentTip(TIPS[Math.floor(Math.random() * TIPS.length)]);
            setIsVisible(true);
            playSound('alert');
        };

        const timer = setTimeout(triggerTip, 30000); // 30s after login
        const interval = setInterval(triggerTip, 180000); // Every 3 mins

        return () => {
            clearTimeout(timer);
            clearInterval(interval);
        };
    }, [state.activeProfile, isVisible]);

    if (!isVisible) return null;

    return (
        <div className="fixed bottom-12 right-4 z-[999] w-64 animate-enter font-[Rajdhani]">
            <div className="jarvis-panel bg-black/90 border-cyan-500/50 p-3 nanotech-border shadow-[0_0_20px_rgba(0,240,255,0.2)]">
                <div className="flex items-center justify-between mb-2 border-b border-cyan-900/50 pb-1">
                    <div className="flex items-center gap-2 text-cyan-400">
                        <Bot size={14} className="animate-pulse" />
                        <span className="text-[10px] font-black tracking-widest uppercase">CARNIX_AI TIP</span>
                    </div>
                    <button onClick={() => setIsVisible(false)} className="text-gray-500 hover:text-white"><X size={12}/></button>
                </div>
                <div className="flex gap-3">
                    <div className="mt-1 flex-shrink-0">
                        <Sparkles size={14} className="text-yellow-500" />
                    </div>
                    <p className="text-[11px] text-gray-300 leading-relaxed italic">
                        "{currentTip}"
                    </p>
                </div>
                <div className="mt-2 flex justify-end">
                     <span className="text-[7px] text-cyan-800 font-mono tracking-tighter">INTELLIGENCE_LAYER_ACTIVE</span>
                </div>
            </div>
        </div>
    );
};

export default TipPopup;