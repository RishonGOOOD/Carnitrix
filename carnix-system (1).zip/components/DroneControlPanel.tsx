
import React, { useState, useEffect } from 'react';
import { Send, Camera, Video, Battery, Wifi, Locate, ArrowUp, ArrowDown, Eye, Gamepad2 } from 'lucide-react';
import FlightHUD from './FlightHUD';

const DroneControlPanel: React.FC = () => {
    const [isArmed, setIsArmed] = useState(false);
    const [altitude, setAltitude] = useState(0);
    const [speed, setSpeed] = useState(0);
    const [heading, setHeading] = useState(0);
    const [pitch, setPitch] = useState(0);
    const [roll, setRoll] = useState(0);
    const [viewMode, setViewMode] = useState<'STANDARD' | 'HUD'>('STANDARD');

    // Simulate flight dynamics
    useEffect(() => {
        if (!isArmed) return;
        const interval = setInterval(() => {
            // Gentle hover drift
            setPitch(p => p * 0.95 + (Math.random() - 0.5) * 2);
            setRoll(r => r * 0.95 + (Math.random() - 0.5) * 2);
            setHeading(h => (h + (Math.random() - 0.5)) % 360);
            if (altitude > 0) setSpeed(s => Math.max(0, s + (Math.random() - 0.5)));
        }, 100);
        return () => clearInterval(interval);
    }, [isArmed, altitude]);

    const handleArmDisarm = () => {
        setIsArmed(!isArmed);
        if (isArmed) {
            setAltitude(0);
            setSpeed(0);
        }
    };

    const handleAltitudeChange = (delta: number) => {
        if (isArmed) {
            setAltitude(prev => Math.max(0, Math.min(200, prev + delta)));
            setPitch(delta > 0 ? 5 : -5); // Visual feedback
        }
    };

    return (
        <div className="w-full h-full flex gap-4 p-1">
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md relative overflow-hidden flex flex-col">
                <div className="flex-1 relative bg-gray-900 overflow-hidden">
                    {/* Simulated Video Background */}
                    <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=80&w=2613&auto=format&fit=crop')] bg-cover bg-center opacity-40"></div>
                    
                    {viewMode === 'HUD' && (
                        <FlightHUD 
                            pitch={pitch} 
                            roll={roll} 
                            heading={heading} 
                            altitude={altitude} 
                            speed={speed} 
                        />
                    )}
                    
                    {!isArmed && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-sm">
                            <div className="text-red-500 font-black tracking-widest text-lg border-2 border-red-500 p-4 rounded">SYSTEM DISARMED</div>
                        </div>
                    )}
                </div>
                
                <div className="p-2 bg-black/60 border-t border-white/10 flex justify-between items-center text-xs font-mono text-white">
                    <div className="flex gap-4">
                        <span className="flex items-center gap-1"><Battery size={12} className="text-green-500"/> 98%</span>
                        <span className="flex items-center gap-1"><Wifi size={12} className="text-blue-500"/> LINK: 100%</span>
                        <span>CAM: 4K/60</span>
                    </div>
                    <button onClick={() => setViewMode(v => v === 'HUD' ? 'STANDARD' : 'HUD')} className="flex items-center gap-2 hover:text-[var(--color-primary)]">
                        {viewMode === 'HUD' ? <Video size={14}/> : <Eye size={14}/>} {viewMode === 'HUD' ? 'VIDEO' : 'HUD'}
                    </button>
                </div>
            </div>

            <div className="w-1/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white border-b border-gray-700 pb-2 flex items-center gap-2">
                    <Gamepad2 size={16}/> FLIGHT CONTROLLER
                </h3>
                
                <div className="flex justify-between items-center bg-black/40 p-3 rounded border border-white/5">
                    <span className="text-xs text-gray-400">STATUS</span>
                    <span className={`font-bold text-xs ${isArmed ? 'text-green-500 animate-pulse' : 'text-red-500'}`}>{isArmed ? 'MOTORS ACTIVE' : 'STANDBY'}</span>
                </div>
                
                <button onClick={handleArmDisarm} className={`w-full p-4 text-xs font-black tracking-widest rounded transition-all shadow-[0_0_15px_rgba(0,0,0,0.3)] ${isArmed ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-green-600 hover:bg-green-500 text-black'}`}>
                    {isArmed ? 'EMERGENCY CUTOFF' : 'ARM MOTORS'}
                </button>
                
                <div className="grid grid-cols-2 gap-2 mt-2">
                    <button onMouseDown={() => handleAltitudeChange(1)} className="p-4 bg-blue-900/30 border border-blue-600/50 rounded flex flex-col items-center justify-center gap-1 hover:bg-blue-800/50 active:scale-95 transition-all">
                        <ArrowUp size={20} className="text-blue-400"/> 
                        <span className="text-[9px] font-bold">ASCEND</span>
                    </button>
                    <button onMouseDown={() => handleAltitudeChange(-1)} className="p-4 bg-blue-900/30 border border-blue-600/50 rounded flex flex-col items-center justify-center gap-1 hover:bg-blue-800/50 active:scale-95 transition-all">
                        <ArrowDown size={20} className="text-blue-400"/> 
                        <span className="text-[9px] font-bold">DESCEND</span>
                    </button>
                </div>
                
                <div className="space-y-2 mt-auto">
                    <button className="w-full p-2 bg-white/5 border border-white/10 text-[10px] font-bold rounded hover:bg-white/10 flex items-center justify-center gap-2">
                        <Camera size={12}/> SNAPSHOT
                    </button>
                    <button className="w-full p-2 bg-white/5 border border-white/10 text-[10px] font-bold rounded hover:bg-white/10 flex items-center justify-center gap-2">
                        <Locate size={12}/> RETURN TO HOME
                    </button>
                </div>
            </div>
        </div>
    );
};

export default DroneControlPanel;
