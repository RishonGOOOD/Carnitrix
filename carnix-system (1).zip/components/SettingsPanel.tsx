
import React, { useState, useRef } from 'react';
import { Settings, BrainCircuit, Save, Download, Upload, HardDrive, Shield, LogOut, RefreshCw, Cpu } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const SettingsPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    
    const [localAI, setLocalAI] = useState(activeProfile?.aiSettings || {});
    const fileInputRef = useRef<HTMLInputElement>(null);

    const saveAI = () => {
        if (!activeProfile) return;
        dispatch({ type: 'UPDATE_PROFILE', payload: { aiSettings: { ...activeProfile.aiSettings, ...localAI } } });
        playSound('success');
    };

    const reset = () => {
        playSound('scan');
        setTimeout(() => window.location.reload(), 1000);
    };

    const exportMemory = () => {
        if (!activeProfile) return;
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(activeProfile));
        const a = document.createElement('a');
        a.setAttribute("href", dataStr);
        a.setAttribute("download", `carnix_memory_backup_${Date.now()}.json`);
        document.body.appendChild(a);
        a.click();
        a.remove();
        playSound('success');
    };

    const importMemory = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target?.result as string);
                if (data.id && data.name) {
                    dispatch({ type: 'SET_PROFILE', payload: data });
                    playSound('access');
                    alert("Memory restored successfully. System reloading...");
                    window.location.reload();
                } else {
                    throw new Error("Invalid format");
                }
            } catch (err) {
                alert("Corrupt memory file.");
                playSound('error');
            }
        };
        reader.readAsText(file);
    };

    if (!activeProfile) return null;

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="bg-black/60 border border-white/10 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Settings size={20} className="text-gray-400" />
                    <h2 className="text-sm font-black text-white uppercase italic">Core Configuration</h2>
                </div>
            </div>

            <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 overflow-y-auto">
                {/* AI Configuration */}
                <div className="jarvis-panel p-4 space-y-4 bg-black/40">
                    <h3 className="text-[10px] font-black text-blue-400 uppercase flex items-center gap-2"><BrainCircuit size={12}/> Neural Bridge</h3>
                    
                    <div className="space-y-4">
                        <div>
                            <label className="text-[8px] text-gray-600 font-black uppercase mb-1 block">AI Provider</label>
                            <div className="flex gap-2">
                                <button className="flex-1 p-2 text-xs font-bold border rounded bg-blue-600 text-black border-blue-600">
                                    GEMINI CLOUD
                                </button>
                                <button className="flex-1 p-2 text-xs font-bold border rounded bg-transparent text-gray-500 border-gray-700 hover:bg-white/5">
                                    LOCAL GGUF (Soon)
                                </button>
                            </div>
                        </div>

                        <button onClick={saveAI} className="w-full p-2 bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-bold rounded flex items-center justify-center gap-2">
                            <Save size={12}/> SAVE AI CONFIG
                        </button>
                    </div>
                </div>

                {/* Memory & Storage */}
                <div className="jarvis-panel p-4 space-y-4 bg-black/40">
                     <h3 className="text-[10px] font-black text-cyan-400 uppercase flex items-center gap-2"><HardDrive size={12}/> Memory Persistence</h3>
                     <div className="space-y-3">
                        <div className="p-3 border border-dashed border-gray-700 rounded text-center">
                            <p className="text-[9px] text-gray-400 mb-3">Backup complete profile state including notes, history, and settings to local JSON.</p>
                            <div className="flex gap-2">
                                <button onClick={exportMemory} className="flex-1 p-2 bg-cyan-900/30 text-cyan-400 border border-cyan-700 rounded text-[10px] font-bold flex items-center justify-center gap-2 hover:bg-cyan-900/50">
                                    <Download size={12}/> EXPORT MEMORY
                                </button>
                                <button onClick={() => fileInputRef.current?.click()} className="flex-1 p-2 bg-gray-800 text-gray-300 border border-gray-600 rounded text-[10px] font-bold flex items-center justify-center gap-2 hover:bg-gray-700">
                                    <Upload size={12}/> IMPORT MEMORY
                                </button>
                                <input type="file" ref={fileInputRef} onChange={importMemory} className="hidden" accept=".json"/>
                            </div>
                        </div>
                     </div>
                </div>

                {/* System Ops */}
                <div className="jarvis-panel p-4 space-y-4 bg-black/40 border-l-2 border-red-600 lg:col-span-2">
                    <h3 className="text-[10px] font-black text-white uppercase flex items-center gap-2"><Shield size={12}/> Authority Protocols</h3>
                    <div className="grid grid-cols-2 gap-2">
                        <button onClick={reset} className="p-3 bg-white/5 border border-white/10 rounded text-[10px] font-black text-gray-400 hover:text-white flex items-center justify-center gap-2"><RefreshCw size={12}/> SOFT_REBOOT</button>
                        <button onClick={() => dispatch({type: 'LOGOUT'})} className="p-3 bg-red-900/20 border border-red-600 rounded text-[10px] font-black text-red-500 hover:bg-red-600 hover:text-black flex items-center justify-center gap-2"><LogOut size={12}/> TERMINATE</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SettingsPanel;
