import React, { useState, useMemo } from 'react';
import { 
    ScanEye, Map, FileText, Database, Radio, Globe, Terminal, 
    Layers, ChevronRight, Search, Activity, ShieldAlert, Newspaper, ListTodo, Brain, Zap, Cpu,
    Crosshair, PlaneTakeoff, CloudRain, Satellite, Lock, Music, Mic, Heart,
    Key, ShieldCheck, HardDrive, RefreshCw, Smartphone, Sliders, MessageCircle, AlertTriangle,
    Code, Wand2, Fingerprint, Telescope, Bot, Users, Siren, Flame, Languages, TrendingUp,
    Sparkles, EyeOff, Calendar, Sun, Disc, BookOpen, MapPin, Puzzle, Hammer
} from 'lucide-react';
import { Mode } from '../types';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

interface PanelItem {
    id: Mode;
    label: string;
    desc: string;
    category: 'AI' | 'TACTICAL' | 'CYBER' | 'RECON' | 'SYSTEM';
    icon: any;
    color: string;
    border: string;
}

const ALL_MODULES: PanelItem[] = [
    // NEURAL & REAL AI TOOLS
    { id: Mode.ObjectRecognition, label: 'High-Speed Object Recognition', desc: 'Real-time YOLOv11 & MediaPipe edge object detector and tracking', category: 'AI', icon: ScanEye, color: 'text-red-500', border: 'border-red-500/40' },
    { id: Mode.DeepOsintAI, label: 'Deep OSINT AI Engine', desc: 'Universal multi-vector cyber reconnaissance: Usernames, Domains, DNS, IPs, EXIF', category: 'RECON', icon: Fingerprint, color: 'text-red-400', border: 'border-red-500/40' },
    { id: Mode.FreeAiGithubHub, label: 'Free AI GitHub Hub', desc: 'Curated 100% free open-weights AI repositories across Vision, LLMs, Audio, Agents', category: 'AI', icon: Cpu, color: 'text-yellow-400', border: 'border-yellow-500/40' },
    { id: Mode.Chat, label: 'Neural Link', desc: 'Gemini 2.5 tactical conversation core', category: 'AI', icon: MessageCircle, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.Vision, label: 'Vision Hub', desc: 'Multimodal optical reconnaissance & detection', category: 'AI', icon: ScanEye, color: 'text-red-500', border: 'border-red-500/30' },
    { id: Mode.Workspace, label: 'AI Forge', desc: 'Code generator, neural imager, video & blueprint engine', category: 'AI', icon: Wand2, color: 'text-purple-400', border: 'border-purple-500/30' },
    { id: Mode.CodeAssistant, label: 'Tactical Code Assistant', desc: 'Synthesize algorithms, scripts and bug fixes', category: 'AI', icon: Code, color: 'text-emerald-400', border: 'border-emerald-500/30' },
    { id: Mode.AIModelRegistry, label: 'Neural Registry', desc: 'Active model substrates & inference weights', category: 'AI', icon: Cpu, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.HFModelHub, label: 'HuggingFace Substrates', desc: 'Open-weights Llama & Mistral router', category: 'AI', icon: Brain, color: 'text-yellow-400', border: 'border-yellow-500/30' },
    { id: Mode.AudioVoice, label: 'Tactical Voice Relay', desc: 'Real-time low latency vocal telemetry', category: 'AI', icon: Mic, color: 'text-blue-400', border: 'border-blue-500/30' },
    { id: Mode.LinguisticsTranslator, label: 'Linguistics Translator', desc: 'Quantum multi-language neural decryption', category: 'AI', icon: Languages, color: 'text-sky-400', border: 'border-sky-500/30' },

    // TACTICAL & COMBAT OPS
    { id: Mode.BallisticsCalculator, label: '6-DOF Ballistics Solver', desc: 'Real-time kinetic projectile trajectory & G1/G7 drag model', category: 'TACTICAL', icon: Crosshair, color: 'text-red-500', border: 'border-red-500/40' },
    { id: Mode.RoboticsControl, label: '3-DOF Robotics Kinematics', desc: 'Analytical inverse kinematics, G-code generator & WebSerial bridge', category: 'TACTICAL', icon: Bot, color: 'text-cyan-400', border: 'border-cyan-500/40' },
    { id: Mode.Tactical, label: 'Tactical Deployment', desc: 'Grid deployment & combat unit matrix', category: 'TACTICAL', icon: Crosshair, color: 'text-red-500', border: 'border-red-500/40' },
    { id: Mode.DriveControl, label: 'Drone Swarm Control', desc: 'Autonomous UAV telemetry & route patrol', category: 'TACTICAL', icon: Radio, color: 'text-amber-400', border: 'border-amber-500/30' },
    { id: Mode.FlightTracker, label: 'Airspace Radar', desc: 'Global ADS-B flight telemetry intercept', category: 'TACTICAL', icon: PlaneTakeoff, color: 'text-purple-400', border: 'border-purple-500/30' },
    { id: Mode.WeatherRadar, label: 'Atmospheric Radar', desc: 'Doppler satellite storm & thermal analysis', category: 'TACTICAL', icon: CloudRain, color: 'text-sky-400', border: 'border-sky-500/30' },
    { id: Mode.Tasks, label: 'Tactical Directives', desc: 'Prioritized mission objectives & timers', category: 'TACTICAL', icon: ListTodo, color: 'text-blue-400', border: 'border-blue-500/30' },

    // CYBER WARFARE & SECURITY
    { id: Mode.ForensicAnalysis, label: 'Digital Forensics Workbench', desc: 'Web Crypto SHA/MD5 hashing, Shannon entropy & hex inspection', category: 'CYBER', icon: Fingerprint, color: 'text-teal-400', border: 'border-teal-500/30' },
    { id: Mode.StealthSystems, label: 'Stealth & Acoustic Monitor', desc: 'Web Audio dB sensor, FFT spectrogram & browser fingerprint auditor', category: 'CYBER', icon: EyeOff, color: 'text-gray-300', border: 'border-gray-500/40' },
    { id: Mode.EthicalHacking, label: 'Cyber Warfare Lab', desc: 'Penetration testing & vulnerability audit', category: 'CYBER', icon: Terminal, color: 'text-emerald-400', border: 'border-emerald-500/30' },
    { id: Mode.Terminal, label: 'Dev Console CLI', desc: 'Direct kernel interactive bash environment', category: 'CYBER', icon: Terminal, color: 'text-emerald-500', border: 'border-emerald-500/30' },
    { id: Mode.SecureComms, label: 'Encrypted Comms', desc: 'AES-256 peer-to-peer cipher channels', category: 'CYBER', icon: Lock, color: 'text-amber-400', border: 'border-amber-500/30' },
    { id: Mode.SubspaceComms, label: 'Subspace Relay', desc: 'Deep-band quantum frequency transmitter', category: 'CYBER', icon: Satellite, color: 'text-teal-400', border: 'border-teal-500/30' },
    { id: Mode.Crypto, label: 'Crypto Matrix', desc: 'Distributed ledger & wallet signature hub', category: 'CYBER', icon: Key, color: 'text-yellow-400', border: 'border-yellow-500/30' },
    { id: Mode.AccessControl, label: 'Access Control', desc: 'Biometric authorization gates & PIN security', category: 'CYBER', icon: ShieldCheck, color: 'text-red-400', border: 'border-red-500/30' },

    // SENSORS & RECON
    { id: Mode.GeothermalAnalysis, label: 'Geothermal & Seismic Sensor', desc: 'Real-time USGS live seismic feed & crustal thermodynamics', category: 'RECON', icon: Flame, color: 'text-orange-400', border: 'border-orange-500/40' },
    { id: Mode.Geo, label: 'Tactical Geo Intel', desc: 'Satellite coordinates & perimeter mapping', category: 'RECON', icon: Map, color: 'text-blue-400', border: 'border-blue-500/30' },
    { id: Mode.GlobalSearch, label: 'Omni Search Index', desc: 'Real-time global intelligence query', category: 'RECON', icon: Search, color: 'text-red-500', border: 'border-red-500/30' },
    { id: Mode.QuantumSearch, label: 'Quantum Deep Search', desc: 'Multi-vector contextual web & system crawl', category: 'RECON', icon: Search, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.WebIntelligence, label: 'Web Intelligence', desc: 'Google Search grounded OSINT gatherer', category: 'RECON', icon: Globe, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.News, label: 'Satellite News Feed', desc: 'Live global geopolitical telemetry stream', category: 'RECON', icon: Newspaper, color: 'text-green-400', border: 'border-green-500/30' },
    { id: Mode.ThreatIntel, label: 'Threat Intel Matrix', desc: 'Live zero-day vulnerabilities & cyber telemetry', category: 'RECON', icon: ShieldAlert, color: 'text-red-400', border: 'border-red-500/30' },
    { id: Mode.Sensors, label: 'Device Scanner', desc: 'Local Bluetooth & Wi-Fi spectrum radar', category: 'RECON', icon: Activity, color: 'text-pink-400', border: 'border-pink-500/30' },
    { id: Mode.SignalIntercept, label: 'Signal Spectrum Intercept', desc: 'Real-time audio frequency analyzer & spectrogram', category: 'RECON', icon: Radio, color: 'text-lime-400', border: 'border-lime-500/30' },
    { id: Mode.StellarCartography, label: 'Stellar Map', desc: 'Deep-sky astrometric sector tracker', category: 'RECON', icon: Satellite, color: 'text-indigo-400', border: 'border-indigo-500/30' },
    { id: Mode.Health, label: 'Operative Vitals', desc: 'Biometric telemetry & neurological status', category: 'RECON', icon: Heart, color: 'text-rose-500', border: 'border-rose-500/30' },
    { id: Mode.WorldStatus, label: 'World DEFCON Monitor', desc: 'Geopolitical alert levels & incident maps', category: 'RECON', icon: ShieldAlert, color: 'text-red-400', border: 'border-red-500/40' },
    { id: Mode.EmergencyServicesMonitor, label: 'Emergency Dispatch Monitor', desc: 'Municipal 911 / emergency tactical feed', category: 'RECON', icon: Siren, color: 'text-amber-400', border: 'border-amber-500/30' },
    { id: Mode.Climate, label: 'Climate Telemetry', desc: 'Barometric pressure, precipitation & UV index', category: 'RECON', icon: Sun, color: 'text-yellow-400', border: 'border-yellow-500/30' },
    { id: Mode.Satellite, label: 'Orbital Satellite View', desc: 'Live aerial & orbital tile mapping', category: 'RECON', icon: Satellite, color: 'text-sky-400', border: 'border-sky-500/30' },

    // SYSTEM & HARDWARE
    { id: Mode.SystemCore, label: 'System Core Engine', desc: 'Carnix microkernel configuration', category: 'SYSTEM', icon: Cpu, color: 'text-red-500', border: 'border-red-500/40' },
    { id: Mode.Diagnostics, label: 'Kernel Audit', desc: 'Integrity benchmark & diagnostic telemetry', category: 'SYSTEM', icon: Activity, color: 'text-purple-400', border: 'border-purple-500/30' },
    { id: Mode.Notes, label: 'Encrypted Intel DB', desc: 'Local persistent mission notebooks', category: 'SYSTEM', icon: Database, color: 'text-yellow-400', border: 'border-yellow-500/30' },
    { id: Mode.MemoryVault, label: '3D Neural Memory Vault', desc: 'Spatial coordinate associative memory graph', category: 'SYSTEM', icon: Brain, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.Files, label: 'Secure Databanks', desc: 'Cryptographic file vault & artifact store', category: 'SYSTEM', icon: HardDrive, color: 'text-gray-300', border: 'border-gray-500/30' },
    { id: Mode.Logs, label: 'System Event Logs', desc: 'Audit trail of all daemon interactions', category: 'SYSTEM', icon: FileText, color: 'text-gray-400', border: 'border-gray-500/30' },
    { id: Mode.Calendar, label: 'Temporal Calendar Grid', desc: 'Mission deadlines & temporal synchronization', category: 'SYSTEM', icon: Calendar, color: 'text-blue-400', border: 'border-blue-500/30' },
    { id: Mode.Journal, label: 'Mission Journal Log', desc: 'Chronological operative logs & mission notes', category: 'SYSTEM', icon: BookOpen, color: 'text-amber-400', border: 'border-amber-500/30' },
    { id: Mode.Radio, label: 'Tactical Radio Streamer', desc: 'Live cyberpunk, synthwave & defcon audio stream', category: 'SYSTEM', icon: Radio, color: 'text-rose-400', border: 'border-rose-500/30' },
    { id: Mode.Media, label: 'Signal Media Player', desc: 'Local video/audio playback & visualizer', category: 'SYSTEM', icon: Disc, color: 'text-indigo-400', border: 'border-indigo-500/30' },
    { id: Mode.AudioLab, label: 'Tactical Audio Lab', desc: 'Web Audio frequency generator & synth', category: 'SYSTEM', icon: Music, color: 'text-amber-400', border: 'border-amber-500/30' },
    { id: Mode.Microcontroller, label: 'Microcontroller Bridge', desc: 'UART / GPIO embedded hardware link', category: 'SYSTEM', icon: Smartphone, color: 'text-blue-400', border: 'border-blue-500/30' },
    { id: Mode.Hardware, label: 'Hardware WebSerial Link', desc: 'Direct physical port communications', category: 'SYSTEM', icon: Cpu, color: 'text-emerald-400', border: 'border-emerald-500/30' },
    { id: Mode.Cybernetics, label: 'Cybernetics Manifest', desc: 'Augmentation diagnostics & neural bus', category: 'SYSTEM', icon: Zap, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.EconomicForecaster, label: 'Economic Forecaster', desc: 'Real-time equity market analysis & prediction', category: 'SYSTEM', icon: TrendingUp, color: 'text-green-400', border: 'border-green-500/30' },
    { id: Mode.PluginForge, label: 'Plugin Forge', desc: 'AI-assisted dynamic module architect', category: 'SYSTEM', icon: Hammer, color: 'text-orange-400', border: 'border-orange-500/30' },
    { id: Mode.PluginHub, label: 'Plugin Hub', desc: 'Enable, disable & configure HUD modules', category: 'SYSTEM', icon: Puzzle, color: 'text-pink-400', border: 'border-pink-500/30' },
    { id: Mode.Location, label: 'Waypoint Navigation', desc: 'GPS geolocation route & vector tracking', category: 'SYSTEM', icon: MapPin, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { id: Mode.RecoveryBackup, label: 'Recovery & Backup', desc: 'Node state snapshots & restore points', category: 'SYSTEM', icon: RefreshCw, color: 'text-emerald-400', border: 'border-emerald-500/30' },
    { id: Mode.Browser, label: 'Secure Browser', desc: 'Sandboxed darknet web proxy navigator', category: 'SYSTEM', icon: Globe, color: 'text-blue-400', border: 'border-blue-500/30' },
    { id: Mode.Settings, label: 'HUD Settings', desc: 'Tactical interface & visual theme manager', category: 'SYSTEM', icon: Sliders, color: 'text-gray-300', border: 'border-gray-500/30' },
];

export const PanelsHubPanel: React.FC = () => {
    const { dispatch } = useAppContext();
    const [search, setSearch] = useState('');
    const [activeCategory, setActiveCategory] = useState<'ALL' | 'AI' | 'TACTICAL' | 'CYBER' | 'RECON' | 'SYSTEM'>('ALL');

    const filtered = useMemo(() => {
        return ALL_MODULES.filter(m => {
            const matchesCategory = activeCategory === 'ALL' || m.category === activeCategory;
            const matchesSearch = !search.trim() || 
                m.label.toLowerCase().includes(search.toLowerCase()) || 
                m.desc.toLowerCase().includes(search.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [search, activeCategory]);

    const openPanel = (m: Mode) => {
        playSound('access');
        dispatch({ type: 'SET_MODE', payload: m });
    };

    const categories: { id: typeof activeCategory; label: string; count: number }[] = [
        { id: 'ALL', label: 'ALL MODULES', count: ALL_MODULES.length },
        { id: 'AI', label: 'NEURAL AI', count: ALL_MODULES.filter(m => m.category === 'AI').length },
        { id: 'TACTICAL', label: 'TACTICAL OPS', count: ALL_MODULES.filter(m => m.category === 'TACTICAL').length },
        { id: 'CYBER', label: 'CYBER WARFARE', count: ALL_MODULES.filter(m => m.category === 'CYBER').length },
        { id: 'RECON', label: 'SENSORS & RECON', count: ALL_MODULES.filter(m => m.category === 'RECON').length },
        { id: 'SYSTEM', label: 'SYSTEM & HW', count: ALL_MODULES.filter(m => m.category === 'SYSTEM').length },
    ];

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-[Rajdhani] select-none">
            {/* Header with Search and Filter */}
            <div className="flex-shrink-0 bg-black/80 border border-red-600/30 p-4 rounded-xl flex flex-col md:flex-row justify-between items-center gap-3 backdrop-blur-md">
                <div className="flex items-center gap-3 w-full md:w-auto">
                    <div className="p-2 bg-red-600/20 border border-red-500 rounded-lg shadow-[0_0_15px_rgba(255,0,0,0.3)]">
                        <Layers size={24} className="text-red-500 animate-pulse" />
                    </div>
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic tracking-widest font-orbitron">
                            CARNIX SUBSYSTEM MATRIX
                        </h2>
                        <div className="text-[10px] font-mono text-gray-400 tracking-wider">
                            37 ACTIVE TACTICAL PANELS READY // KERNEL v7.4
                        </div>
                    </div>
                </div>

                <div className="relative w-full md:w-80">
                    <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input 
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        placeholder="FILTER SUBSYSTEM MATRIX..."
                        className="w-full bg-black/90 border border-red-900/50 rounded-lg pl-10 pr-4 py-2 text-xs text-white placeholder-gray-500 outline-none focus:border-red-500 font-mono transition-all"
                    />
                </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex-shrink-0 flex items-center gap-1.5 overflow-x-auto scrollbar-carnix pb-1">
                {categories.map(cat => (
                    <button
                        key={cat.id}
                        onClick={() => {
                            setActiveCategory(cat.id);
                            playSound('click');
                        }}
                        className={`px-3 py-1.5 rounded-lg border font-mono text-xs tracking-wider whitespace-nowrap transition-all ${activeCategory === cat.id ? 'bg-red-600 text-black border-red-500 font-black shadow-[0_0_12px_rgba(255,0,0,0.5)]' : 'bg-black/60 text-gray-400 border-red-950/60 hover:text-white hover:border-red-800'}`}
                    >
                        {cat.label} ({cat.count})
                    </button>
                ))}
            </div>

            {/* Modules Grid */}
            <div className="flex-1 bg-black/50 border border-red-950/40 rounded-xl overflow-y-auto p-3 scrollbar-carnix">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 pb-8">
                    {filtered.map(panel => {
                        const Icon = panel.icon;
                        return (
                            <button 
                                key={panel.id}
                                onClick={() => openPanel(panel.id)}
                                className={`bg-black/80 border ${panel.border} hover:border-red-500 rounded-xl p-3.5 flex items-start gap-3 transition-all text-left group shadow-lg hover:scale-[1.02] active:scale-95 relative overflow-hidden backdrop-blur-sm`}
                            >
                                <div className={`p-2.5 rounded-lg bg-black border border-white/10 group-hover:border-red-500/50 ${panel.color} shadow-inner flex-shrink-0`}>
                                    <Icon size={20} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between">
                                        <div className="text-xs font-black text-white uppercase tracking-wider truncate font-orbitron">
                                            {panel.label}
                                        </div>
                                        <ChevronRight size={14} className="text-gray-600 group-hover:text-red-400 group-hover:translate-x-0.5 transition-all flex-shrink-0" />
                                    </div>
                                    <div className="text-[10px] font-mono text-gray-400 leading-snug mt-1 line-clamp-2">
                                        {panel.desc}
                                    </div>
                                </div>
                            </button>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default PanelsHubPanel;
