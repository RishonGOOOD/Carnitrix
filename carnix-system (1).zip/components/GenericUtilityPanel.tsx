
import React, { useState, useEffect } from 'react';
import { Mode } from '../types';
import { Terminal, Database, Activity, Command, Cpu, Hash, Globe, Shield, Zap, Info, Binary, Settings } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface Props { mode: Mode; }

const GenericUtilityPanel: React.FC<Props> = ({ mode }) => {
    const [stream, setStream] = useState<string[]>([]);
    const [stats, setStats] = useState({
        integrity: 99.9,
        load: 12,
        throughput: 440
    });

    useEffect(() => {
        setStream([
            `[SYSTEM] NODE_INITIALIZED: ${mode.toUpperCase()}`,
            `> Establishing secure buffer... [OK]`,
            `> Synchronizing with neural lattice...`,
            `> Awaiting master command input...`
        ]);
        
        const interval = setInterval(() => {
            const prefixes = ['>', '[LOG]', '[DATA]', '[UPLINK]'];
            const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
            const hex = Math.random().toString(16).slice(2, 10).toUpperCase();
            const log = `${prefix} 0x${hex}: Node transaction successful. Checksum verified.`;
            
            setStream(prev => [log, ...prev].slice(0, 40));
            setStats({
                integrity: 99.8 + Math.random() * 0.2,
                load: Math.floor(5 + Math.random() * 25),
                throughput: Math.floor(400 + Math.random() * 100)
            });
            
            if (Math.random() > 0.95) playSound('typing');
        }, 1500);

        return () => clearInterval(interval);
    }, [mode]);

    return (
        <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] animate-in fade-in zoom-in duration-500">
            {/* Header Readout */}
            <div className="flex-shrink-0 flex flex-col md:flex-row items-center justify-between bg-black/60 border border-white/5 p-5 rounded-lg shadow-xl">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-red-600/10 rounded border border-red-600/30">
                        <Cpu size={28} className="text-red-600 animate-pulse" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black tracking-[0.2em] text-white uppercase italic leading-none">{mode}</h2>
                        <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest mt-2">Neural Sub-Module // Sector_{Math.floor(Math.random() * 100)} // Alpha_State</div>
                    </div>
                </div>
                <div className="flex gap-6 mt-4 md:mt-0">
                    <div className="text-right">
                        <div className="text-[8px] text-gray-600 font-bold uppercase tracking-widest">Latency</div>
                        <div className="text-sm font-black text-cyan-400 font-mono">0.02ms</div>
                    </div>
                    <div className="text-right">
                        <div className="text-[8px] text-gray-600 font-bold uppercase tracking-widest">Uplink</div>
                        <div className="text-sm font-black text-green-500 font-mono">STABLE</div>
                    </div>
                </div>
            </div>

            <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-4 overflow-hidden">
                {/* Visual Data Stream */}
                <div className="lg:col-span-3 bg-black/40 border border-white/10 rounded-lg flex flex-col overflow-hidden shadow-inner">
                    <div className="p-2 border-b border-white/5 bg-white/5 text-[10px] font-black text-gray-500 uppercase tracking-[0.3em] flex items-center justify-between">
                        <div className="flex items-center gap-2"><Binary size={12} /> Live Telemetry Feed</div>
                        <div className="flex gap-1">
                             <div className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse"></div>
                             <div className="w-1.5 h-1.5 rounded-full bg-gray-800"></div>
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-5 font-mono text-[11px] text-gray-400 space-y-2 scrollbar-carnix">
                        {stream.map((line, i) => (
                            <div key={i} className={`flex gap-3 ${line.startsWith('[') ? 'text-red-500/80 font-bold' : ''}`}>
                                <span className="text-gray-800">[{new Date().toLocaleTimeString()}]</span>
                                <span className="break-all">{line}</span>
                            </div>
                        ))}
                    </div>
                </div>
                
                {/* Secondary Tactical Stats */}
                <div className="flex flex-col gap-4">
                    <div className="bg-black/60 border border-white/10 rounded-lg p-5 flex flex-col gap-6">
                        <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest border-b border-white/5 pb-2">Diagnostic Vitals</h3>
                        <div className="space-y-5">
                            <div>
                                <div className="flex justify-between text-[9px] font-black mb-1">
                                    <span className="text-gray-500">INTEGRITY</span>
                                    <span className="text-white">{stats.integrity.toFixed(2)}%</span>
                                </div>
                                <div className="h-1 w-full bg-gray-900 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-500 shadow-[0_0_8px_cyan]" style={{ width: `${stats.integrity}%` }}></div>
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between text-[9px] font-black mb-1">
                                    <span className="text-gray-500">THREAD_LOAD</span>
                                    <span className="text-white">{stats.load}%</span>
                                </div>
                                <div className="h-1 w-full bg-gray-900 rounded-full overflow-hidden">
                                    <div className="h-full bg-red-600 shadow-[0_0_8px_red]" style={{ width: `${stats.load}%` }}></div>
                                </div>
                            </div>
                            <div>
                                <div className="flex justify-between text-[9px] font-black mb-1">
                                    <span className="text-gray-500">BITRATE</span>
                                    <span className="text-white">{stats.throughput} Mb/s</span>
                                </div>
                                <div className="h-1 w-full bg-gray-900 rounded-full overflow-hidden">
                                    <div className="h-full bg-cyan-400 shadow-[0_0_8px_cyan]" style={{ width: `${(stats.throughput/500)*100}%` }}></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="flex-1 bg-black/60 border border-white/10 rounded-lg p-5 flex flex-col justify-between">
                        <div className="space-y-4">
                            <div className="p-3 bg-white/5 border border-white/5 rounded">
                                <div className="text-[9px] text-gray-500 font-bold uppercase mb-1">Node Status</div>
                                <div className="text-sm font-black text-white flex items-center gap-2">
                                    <Shield size={14} className="text-green-500" /> PROTECTED
                                </div>
                            </div>
                            <div className="p-3 bg-white/5 border border-white/5 rounded">
                                <div className="text-[9px] text-gray-500 font-bold uppercase mb-1">Architecture</div>
                                <div className="text-sm font-black text-white">Quantum_Link_v7</div>
                            </div>
                        </div>
                        
                        <div className="mt-6 flex flex-col gap-2">
                            <button className="w-full py-2 bg-red-600/10 border border-red-600/40 text-red-500 text-[10px] font-black uppercase tracking-widest hover:bg-red-600 hover:text-black transition-all">Emergency Halt</button>
                            <button className="w-full py-2 bg-white/5 border border-white/10 hover:border-cyan-400 text-gray-400 text-[10px] font-black uppercase tracking-widest transition-all">Purge Cache</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GenericUtilityPanel;
