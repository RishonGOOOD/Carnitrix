
import React, { useState, useEffect } from 'react';
import { Smartphone, Zap, MapPin, Compass, Activity, ShieldCheck } from 'lucide-react';

const SensorPanel: React.FC = () => {
    const [battery, setBattery] = useState({ level: 0, charging: false });
    const [orient, setOrient] = useState({ alpha: 0, beta: 0, gamma: 0 });
    const [geo, setGeo] = useState<any>(null);

    useEffect(() => {
        if ((navigator as any).getBattery) {
            (navigator as any).getBattery().then((b: any) => {
                setBattery({ level: Math.round(b.level * 100), charging: b.charging });
            });
        }
        window.addEventListener('deviceorientation', (e) => {
            setOrient({ alpha: e.alpha || 0, beta: e.beta || 0, gamma: e.gamma || 0 });
        });
        navigator.geolocation.getCurrentPosition(pos => setGeo(pos.coords));
    }, []);

    const Card = ({ label, icon: Icon, children }: any) => (
        <div className="bg-black/40 border border-white/5 p-4 rounded-lg flex flex-col gap-2 hover:border-red-600/30 transition-all">
            <div className="flex items-center gap-2">
                <Icon size={14} className="text-red-600" />
                <span className="text-[9px] font-black text-gray-500 uppercase tracking-widest">{label}</span>
            </div>
            <div className="flex-1 flex items-center justify-center">{children}</div>
        </div>
    );

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-white/10 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Smartphone size={20} className="text-green-500" />
                    <h2 className="text-sm font-black text-white uppercase italic">Mobile Sensor Link</h2>
                </div>
                <div className="flex items-center gap-2 text-green-500">
                    <ShieldCheck size={12}/>
                    <span className="text-[9px] font-black uppercase tracking-widest">Hardware Lock</span>
                </div>
            </div>

            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 overflow-y-auto scrollbar-tactical pr-1">
                <Card label="Power Source" icon={Zap}>
                    <div className="text-4xl font-black text-white font-mono">{battery.level}%</div>
                </Card>
                <Card label="Compass" icon={Compass}>
                    <div className="text-3xl font-black text-cyan-400 font-mono">{Math.round(orient.alpha)}°</div>
                </Card>
                <Card label="Spatial Lock" icon={MapPin}>
                    <div className="text-[10px] font-mono text-gray-400 space-y-1">
                        <div>LAT: {geo?.latitude.toFixed(4) || '---'}</div>
                        <div>LON: {geo?.longitude.toFixed(4) || '---'}</div>
                    </div>
                </Card>
                <Card label="Motion" icon={Activity}>
                    <div className="flex gap-4">
                        <div className="text-center"><p className="text-[6px] text-gray-600">BETA</p><p className="font-bold text-xs">{Math.round(orient.beta)}</p></div>
                        <div className="text-center"><p className="text-[6px] text-gray-600">GAMMA</p><p className="font-bold text-xs">{Math.round(orient.gamma)}</p></div>
                    </div>
                </Card>
            </div>
            
            <div className="bg-red-900/10 border border-red-900/30 p-3 rounded text-[9px] text-red-500 italic uppercase tracking-wider flex items-center gap-4">
                <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></div>
                Real-time data streaming active via native device bridge. Use carefully in high-latency zones.
            </div>
        </div>
    );
};

export default SensorPanel;
