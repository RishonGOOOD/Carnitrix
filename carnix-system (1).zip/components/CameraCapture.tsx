
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Camera, Video as VideoIcon, StopCircle, X, Aperture, RefreshCw } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface CameraCaptureProps {
    mode: 'PHOTO' | 'VIDEO';
    onCapture: (data: string | Blob) => void;
    onClose: () => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ mode, onCapture, onClose }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const chunksRef = useRef<Blob[]>([]);
    
    const [isStreaming, setIsStreaming] = useState(false);
    const [isRecording, setIsRecording] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

    const startCamera = useCallback(async () => {
        try {
            let stream: MediaStream;
            try {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { facingMode: facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
                    audio: mode === 'VIDEO' 
                });
            } catch {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: true,
                    audio: mode === 'VIDEO' 
                });
            }
            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
            setIsStreaming(true);
            setError(null);
            playSound('process');
        } catch (err: any) {
            setError("Optical Sensor Link Offline: " + (err.message || "Camera permission not granted"));
            playSound('error');
        }
    }, [mode, facingMode]);

    const toggleFacing = () => {
        setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
        playSound('click');
    };

    const stopCamera = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        setIsStreaming(false);
    }, []);

    useEffect(() => {
        startCamera();
        return () => stopCamera();
    }, [startCamera, stopCamera]);

    const takePhoto = () => {
        if (!videoRef.current) return;
        playSound('click');
        
        const canvas = document.createElement('canvas');
        canvas.width = videoRef.current.videoWidth;
        canvas.height = videoRef.current.videoHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
            ctx.drawImage(videoRef.current, 0, 0);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            stopCamera(); // Immediately cut stream
            onCapture(dataUrl); // Return base64 string
        }
    };

    const toggleRecording = () => {
        if (isRecording) {
            // Stop
            if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
                mediaRecorderRef.current.stop();
            }
            playSound('success');
        } else {
            // Start
            if (!streamRef.current) return;
            chunksRef.current = [];
            const recorder = new MediaRecorder(streamRef.current);
            
            recorder.ondataavailable = (e) => {
                if (e.data.size > 0) chunksRef.current.push(e.data);
            };
            
            recorder.onstop = () => {
                const blob = new Blob(chunksRef.current, { type: 'video/webm' });
                stopCamera(); // Immediately cut stream
                onCapture(blob);
            };
            
            recorder.start();
            mediaRecorderRef.current = recorder;
            setIsRecording(true);
            playSound('alert'); // Recording start sound
        }
    };

    return (
        <div className="absolute inset-0 z-50 bg-black flex flex-col">
            <div className="relative flex-1 bg-black overflow-hidden flex items-center justify-center">
                {error ? (
                    <div className="text-red-500 text-center p-4 border border-red-900 bg-red-900/20 rounded">
                        <p className="font-bold mb-2">OPTICAL SENSOR ERROR</p>
                        <p className="text-xs">{error}</p>
                        <button onClick={startCamera} className="mt-4 px-4 py-2 bg-red-800 text-white rounded text-xs flex items-center gap-2 mx-auto">
                            <RefreshCw size={14} /> RETRY
                        </button>
                    </div>
                ) : (
                    <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        muted 
                        className={`w-full h-full object-cover ${isRecording ? 'border-4 border-red-500 animate-pulse' : ''}`}
                    />
                )}
                 <div className="absolute top-4 right-4">
                    <button onClick={onClose} className="p-2 bg-black/50 rounded-full text-white">
                        <X size={20} />
                    </button>
                </div>
                 <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-black/80 to-transparent flex items-center justify-center gap-12">
                    <button onClick={onClose} className="p-3 text-gray-300 hover:text-white">
                        <X size={24} />
                    </button>
                    
                    {mode === 'PHOTO' ? (
                        <button onClick={takePhoto} disabled={!isStreaming} className="w-16 h-16 rounded-full border-4 border-white bg-white/30 hover:bg-white/50 transition-colors flex items-center justify-center">
                            <Aperture size={32} className="text-white" />
                        </button>
                    ) : (
                        <button onClick={toggleRecording} disabled={!isStreaming} className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center transition-colors bg-red-500/50">
                            {isRecording ? (
                                <StopCircle size={32} className="text-white animate-pulse" />
                            ) : (
                                <div className="w-8 h-8 rounded-full bg-red-500"></div>
                            )}
                        </button>
                    )}
                    
                    <button onClick={toggleFacing} className="p-3 text-cyan-400 hover:text-cyan-200 flex flex-col items-center gap-1 transition-colors" title="Switch Optical Lens">
                        <RefreshCw size={20} />
                        <span className="text-[9px] font-mono tracking-wider uppercase">{facingMode === 'environment' ? 'REAR' : 'USER'}</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CameraCapture;
