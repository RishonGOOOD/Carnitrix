import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, Compass, MapPin, Shield, Zap, Cpu, Terminal, RefreshCw, 
  Wifi, Navigation, Radio, Play, Pause, Layers, AlertCircle, CheckCircle2, Cloud
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { CarnixCloudStorage } from '../services/cloudStorageService';

export const JarvisSensorsHub: React.FC = () => {
  // Sensor State
  const [accelerometer, setAccelerometer] = useState({ x: 0.02, y: 9.81, z: 0.45 });
  const [gravity, setGravity] = useState({ x: 0.00, y: 9.80, z: 0.00 });
  const [gyroscope, setGyroscope] = useState({ x: 0.01, y: -0.02, z: 0.04 });
  const [compassHeading, setCompassHeading] = useState(142); // Degrees
  const [barometer, setBarometer] = useState(1013.25); // hPa
  const [isSensorsActive, setIsSensorsActive] = useState(true);

  // Position & Map State
  const [currentPos, setCurrentPos] = useState({ lat: 40.7128, lng: -74.0060, name: 'Secure Sector 7 (Encrypted)' });
  const [pointedPos, setPointedPos] = useState<{ lat: number; lng: number; name: string } | null>({ lat: 40.7180, lng: -73.9920, name: 'Target Vector Alpha' });
  const [distanceKm, setDistanceKm] = useState<number | null>(null);

  // Jarvis Autonomous Sentinel State
  const [jarvisActive, setJarvisActive] = useState(true);
  const [jarvisLogs, setJarvisLogs] = useState<string[]>([
    '[JARVIS v9.4] Autonomous ambient surveillance active.',
    '[SENSOR HUB] Accelerometer & Gravity telemetry locked.',
    '[ANTI-TRACKER MAP] Zero Google telemetry routing enabled.'
  ]);
  const [jarvisVoiceInput, setJarvisVoiceInput] = useState('');
  const [githubReposIntegrated] = useState([
    { name: 'android-sensor-fusion-hub', repo: 'github.com/sensor-fusion/android-sensor-hub', status: 'ACTIVE' },
    { name: 'openstreetmap-anti-google-vector', repo: 'github.com/openstreetmap/openstreetmap-carto', status: 'CONNECTED' },
    { name: 'jarvis-autonomous-sentinel', repo: 'github.com/jarvis-ai/core-engine', status: 'ONLINE' }
  ]);

  const mapCanvasRef = useRef<HTMLCanvasElement>(null);

  // Sensor Simulation & DeviceMotion listener
  useEffect(() => {
    if (!isSensorsActive) return;

    const handleMotionEvent = (event: DeviceMotionEvent) => {
      if (event.accelerationIncludingGravity) {
        setAccelerometer({
          x: Number((event.accelerationIncludingGravity.x || 0).toFixed(2)),
          y: Number((event.accelerationIncludingGravity.y || 9.81).toFixed(2)),
          z: Number((event.accelerationIncludingGravity.z || 0).toFixed(2))
        });
      }
      if (event.rotationRate) {
        setGyroscope({
          x: Number((event.rotationRate.alpha || 0).toFixed(2)),
          y: Number((event.rotationRate.beta || 0).toFixed(2)),
          z: Number((event.rotationRate.gamma || 0).toFixed(2))
        });
      }
    };

    window.addEventListener('devicemotion', handleMotionEvent);

    // Continuous Telemetry & Jarvis Scan Loop
    const interval = setInterval(() => {
      // Slight fluctuation for realism if no hardware sensor
      setAccelerometer(prev => ({
        x: Number((prev.x + (Math.random() - 0.5) * 0.1).toFixed(2)),
        y: Number((9.81 + (Math.random() - 0.5) * 0.05).toFixed(2)),
        z: Number((prev.z + (Math.random() - 0.5) * 0.1).toFixed(2))
      }));

      setGravity({
        x: Number((Math.sin(Date.now() / 1000) * 0.1).toFixed(2)),
        y: 9.80,
        z: Number((Math.cos(Date.now() / 1000) * 0.1).toFixed(2))
      });

      setBarometer(prev => Number((1013.25 + Math.sin(Date.now() / 5000) * 1.5).toFixed(2)));

      // Jarvis periodic autonomous scan logs
      if (Math.random() < 0.25 && jarvisActive) {
        const scans = [
          `[JARVIS SCAN] Perimeter secure. Magnetic interference nominal (${compassHeading}°).`,
          `[GRAVITY KERNEL] Vertical acceleration stable at ${accelerometer.y} m/s².`,
          `[ANTI-TRACKER] Zero external beacons detected on local subnet.`,
          `[VECTOR DISTANCE] Path to target calculated: ${distanceKm ? distanceKm.toFixed(2) + ' km' : 'Calculating...'}`
        ];
        const randomLog = scans[Math.floor(Math.random() * scans.length)];
        setJarvisLogs(l => [randomLog, ...l.slice(0, 19)]);
      }
    }, 1500);

    return () => {
      window.removeEventListener('devicemotion', handleMotionEvent);
      clearInterval(interval);
    };
  }, [isSensorsActive, jarvisActive, distanceKm, compassHeading, accelerometer.y]);

  // Calculate distance using Haversine formula
  useEffect(() => {
    if (!pointedPos) return;
    const R = 6371; // Earth radius in km
    const dLat = (pointedPos.lat - currentPos.lat) * (Math.PI / 180);
    const dLon = (pointedPos.lng - currentPos.lng) * (Math.PI / 180);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(currentPos.lat * (Math.PI / 180)) * Math.cos(pointedPos.lat * (Math.PI / 180)) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c;
    setDistanceKm(d);
  }, [currentPos, pointedPos]);

  // Render Anti-Google Vector Map Canvas
  useEffect(() => {
    const canvas = mapCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const renderMap = () => {
      ctx.fillStyle = '#020102';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw Anti-Google Tactical Grid (OpenStreetMap Vector Grid style)
      ctx.strokeStyle = 'rgba(255, 0, 0, 0.12)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Draw Radar Scan Sweep
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const time = Date.now() / 1000;

      ctx.strokeStyle = 'rgba(255, 0, 0, 0.3)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(centerX, centerY, 120, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(centerX, centerY, 220, 0, Math.PI * 2);
      ctx.stroke();

      // Sweep Line
      const angle = time * 1.5;
      ctx.strokeStyle = 'rgba(255, 0, 0, 0.6)';
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(centerX + Math.cos(angle) * 240, centerY + Math.sin(angle) * 240);
      ctx.stroke();

      // Current Position Marker (User)
      ctx.fillStyle = '#00ffcc';
      ctx.beginPath();
      ctx.arc(centerX, centerY, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = 'rgba(0, 255, 204, 0.3)';
      ctx.beginPath();
      ctx.arc(centerX, centerY, 14 + Math.sin(time * 4) * 4, 0, Math.PI * 2);
      ctx.stroke();

      // Pointed Destination Marker
      if (pointedPos) {
        // Map lat/lng offset to canvas coordinates
        const targetX = centerX + (pointedPos.lng - currentPos.lng) * 15000;
        const targetY = centerY - (pointedPos.lat - currentPos.lat) * 15000;

        // Draw Line from Current to Pointed
        ctx.strokeStyle = '#ff0055';
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Target Pin
        ctx.fillStyle = '#ff0055';
        ctx.beginPath();
        ctx.arc(targetX, targetY, 8, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = '10px monospace';
        ctx.fillText(`TARGET (${distanceKm ? distanceKm.toFixed(2) : 0} km)`, targetX + 12, targetY + 4);
      }

      animId = requestAnimationFrame(renderMap);
    };

    renderMap();
    return () => cancelAnimationFrame(animId);
  }, [currentPos, pointedPos, distanceKm]);

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = mapCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    const dLng = (x - centerX) / 15000;
    const dLat = (centerY - y) / 15000;

    const newTarget = {
      lat: Number((currentPos.lat + dLat).toFixed(4)),
      lng: Number((currentPos.lng + dLng).toFixed(4)),
      name: `Pointed Vector (${(currentPos.lat + dLat).toFixed(2)}, ${(currentPos.lng + dLng).toFixed(2)})`
    };

    setPointedPos(newTarget);
    playSound('click');
    triggerHaptic('medium');
  };

  const handleJarvisSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jarvisVoiceInput.trim()) return;
    const query = jarvisVoiceInput;
    setJarvisVoiceInput('');
    playSound('process');

    setTimeout(() => {
      const response = `[JARVIS SENTINEL] Analyzing query "${query}": Accelerometer stability at ${accelerometer.y}m/s², distance to target vector is ${distanceKm ? distanceKm.toFixed(2) : 'N/A'} km. Anti-google privacy perimeter fully verified.`;
      setJarvisLogs(l => [response, ...l]);
      playSound('success');

      CarnixCloudStorage.saveToCloud({
        type: 'osint_report',
        title: `Jarvis Audit: ${query.substring(0, 25)}`,
        data: { query, response, sensors: { accelerometer, gravity, barometer } }
      });
    }, 600);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#030102] text-white font-[Rajdhani] p-2 sm:p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-red-900/40">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="text-red-500 animate-pulse" size={22} />
            <h1 className="text-lg font-black tracking-wider text-red-500 uppercase">JARVIS & ANDROID SENSORIUM HUD</h1>
          </div>
          <p className="text-[11px] text-gray-400 font-mono mt-0.5">
            Android Accelerometer, Gravity, Gyroscope & Anti-Google Offline Vector Mapping with Autonomous Jarvis Sentinel.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setJarvisActive(!jarvisActive);
              playSound('click');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
              jarvisActive 
                ? 'bg-emerald-600/30 border border-emerald-500/50 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                : 'bg-red-950/40 border border-red-500/50 text-red-400'
            }`}
          >
            <Zap size={14} />
            <span>JARVIS: {jarvisActive ? 'ALWAYS-ON ACTIVE' : 'STANDBY'}</span>
          </button>

          <button
            onClick={() => {
              setIsSensorsActive(!isSensorsActive);
              playSound('click');
            }}
            className="px-3 py-1.5 rounded-lg text-xs font-mono bg-black/60 border border-red-900/50 text-gray-300 hover:text-white"
          >
            {isSensorsActive ? 'SENSORS STREAMING' : 'SENSORS PAUSED'}
          </button>
        </div>
      </div>

      {/* Main Grid: Sensors + Anti-Google Map + Jarvis Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 mt-3 flex-1 min-h-0">
        
        {/* Col 1: Android Hardware Sensors & Gravity/Accelerometer */}
        <div className="flex flex-col gap-3">
          <div className="bg-black/80 border border-red-950/80 rounded-xl p-3.5 space-y-3">
            <h2 className="text-xs font-bold text-red-400 uppercase tracking-wider flex items-center gap-2">
              <Activity size={15} />
              Android Hardware Telemetry
            </h2>
            
            <div className="grid grid-cols-3 gap-2 font-mono text-center">
              <div className="bg-black/60 border border-white/5 p-2 rounded-lg">
                <span className="text-[9px] text-gray-400">ACCEL X/Y/Z</span>
                <div className="text-xs font-bold text-emerald-400 mt-0.5">
                  {accelerometer.x}, {accelerometer.y}, {accelerometer.z}
                </div>
              </div>
              <div className="bg-black/60 border border-white/5 p-2 rounded-lg">
                <span className="text-[9px] text-gray-400">GRAVITY KERNEL</span>
                <div className="text-xs font-bold text-cyan-400 mt-0.5">
                  {gravity.x}, {gravity.y}, {gravity.z}
                </div>
              </div>
              <div className="bg-black/60 border border-white/5 p-2 rounded-lg">
                <span className="text-[9px] text-gray-400">BAROMETER</span>
                <div className="text-xs font-bold text-amber-400 mt-0.5">{barometer} hPa</div>
              </div>
            </div>

            <div className="bg-black/60 border border-white/5 p-3 rounded-lg space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-gray-400">Compass Heading:</span>
                <span className="text-red-400 font-bold">{compassHeading}° (Magnetic North)</span>
              </div>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-gray-400">Sensor Driver:</span>
                <span className="text-emerald-400">Android Sensor HAL v2.1</span>
              </div>
              <div className="flex justify-between text-xs font-mono">
                <span className="text-gray-400">Tracking Status:</span>
                <span className="text-emerald-400 font-bold">ZERO GOOGLE / OFFLINE SECURE</span>
              </div>
            </div>
          </div>

          {/* GitHub Integration Repositories */}
          <div className="bg-black/80 border border-red-950/80 rounded-xl p-3.5 space-y-2.5">
            <h2 className="text-xs font-bold text-yellow-400 uppercase tracking-wider flex items-center gap-2">
              <Layers size={15} />
              GitHub Repositories Integrated
            </h2>
            <div className="space-y-2">
              {githubReposIntegrated.map(repo => (
                <div key={repo.name} className="bg-black/60 border border-white/5 p-2.5 rounded-lg flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-white block">{repo.name}</span>
                    <span className="text-[10px] text-gray-400 font-mono">{repo.repo}</span>
                  </div>
                  <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-900">
                    {repo.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Col 2 & 3: Anti-Google Offline Map & Distance Vector Calculator */}
        <div className="lg:col-span-2 flex flex-col gap-3">
          <div className="flex-1 flex flex-col bg-black/90 border border-red-950/80 rounded-xl p-3.5 relative overflow-hidden min-h-[360px]">
            <div className="flex items-center justify-between pb-2 border-b border-red-950/60 mb-2">
              <div className="flex items-center gap-2">
                <Navigation size={16} className="text-red-500 animate-spin" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Anti-Google Offline Tactical Map & Distance Vector
                </span>
              </div>
              <div className="text-[10px] font-mono text-cyan-400">
                {distanceKm !== null ? `Distance to Pointed: ${distanceKm.toFixed(3)} km` : 'Click map to point vector'}
              </div>
            </div>

            {/* Map Canvas */}
            <div className="flex-1 relative rounded-lg overflow-hidden border border-red-900/40 bg-black cursor-crosshair">
              <canvas
                ref={mapCanvasRef}
                width={800}
                height={400}
                onClick={handleCanvasClick}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-2 left-2 bg-black/80 border border-red-500/30 px-2.5 py-1 rounded text-[10px] font-mono text-gray-300 backdrop-blur-sm pointer-events-none">
                📍 Tap anywhere on map to calculate distance & set pointed vector
              </div>
            </div>

            {/* Target Info Bar */}
            <div className="grid grid-cols-2 gap-2 mt-2 font-mono text-xs">
              <div className="bg-black/60 border border-white/5 p-2.5 rounded-lg">
                <span className="text-[9px] text-gray-400 block">CURRENT POSITION</span>
                <span className="text-emerald-400 font-bold">{currentPos.lat}, {currentPos.lng}</span>
              </div>
              <div className="bg-black/60 border border-white/5 p-2.5 rounded-lg">
                <span className="text-[9px] text-gray-400 block">POINTED VECTOR TARGET</span>
                <span className="text-red-400 font-bold">
                  {pointedPos ? `${pointedPos.lat}, ${pointedPos.lng} (${distanceKm?.toFixed(2)} km)` : 'None'}
                </span>
              </div>
            </div>
          </div>

          {/* Autonomous Jarvis Terminal */}
          <div className="bg-black/90 border border-red-950/80 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
                <Terminal size={15} />
                Jarvis Autonomous Surveillance & Voice Prompt
              </h2>
              <span className="text-[10px] font-mono text-emerald-400 animate-pulse">● ALWAYS LISTENING</span>
            </div>

            <div className="bg-black/95 border border-red-900/40 rounded-lg p-2.5 h-28 overflow-y-auto font-mono text-[11px] space-y-1 scrollbar-carnix">
              {jarvisLogs.map((log, i) => (
                <div key={i} className="text-gray-300 flex items-start gap-2">
                  <span className="text-red-500 font-bold">&gt;</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>

            <form onSubmit={handleJarvisSend} className="flex gap-2">
              <input
                type="text"
                value={jarvisVoiceInput}
                onChange={(e) => setJarvisVoiceInput(e.target.value)}
                placeholder="Ask Jarvis anything or command tactical sensor scan..."
                className="flex-1 bg-black/90 border border-red-900/50 rounded-lg px-3 py-1.5 text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
              />
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-black font-bold rounded-lg text-xs font-mono shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all"
              >
                EXECUTE
              </button>
            </form>
          </div>

        </div>

      </div>
    </div>
  );
};

export default JarvisSensorsHub;
