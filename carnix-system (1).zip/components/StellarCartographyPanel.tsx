import React, { useState, useEffect, useRef } from 'react';
import { Globe, Loader2, Star } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

const StellarCartographyPanel: React.FC = () => {
    const { state } = useAppContext();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [selectedStar, setSelectedStar] = useState<any>(null);
    const [starInfo, setStarInfo] = useState<string | null>(null);
    const [isLoadingInfo, setIsLoadingInfo] = useState(false);
    const rotationRef = useRef({ x: 0, y: 0 });
    const starsRef = useRef<any[]>([]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        const starCount = 500;
        
        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        if (starsRef.current.length === 0) {
            for (let i = 0; i < starCount; i++) {
                starsRef.current.push({
                    x: (Math.random() - 0.5) * 2000,
                    y: (Math.random() - 0.5) * 2000,
                    z: (Math.random() - 0.5) * 2000,
                    size: Math.random() * 2 + 0.5,
                });
            }
        }
        
        let lastMousePos = { x: 0, y: 0 };
        const handleMouseDown = (e: MouseEvent) => {
            lastMousePos = { x: e.clientX, y: e.clientY };
            canvas.addEventListener('mousemove', handleMouseMove);
            canvas.addEventListener('mouseup', handleMouseUp);
        };
        const handleMouseMove = (e: MouseEvent) => {
            const dx = e.clientX - lastMousePos.x;
            const dy = e.clientY - lastMousePos.y;
            rotationRef.current.y += dx * 0.2;
            rotationRef.current.x -= dy * 0.2;
            lastMousePos = { x: e.clientX, y: e.clientY };
        };
        const handleMouseUp = () => {
            canvas.removeEventListener('mousemove', handleMouseMove);
            canvas.removeEventListener('mouseup', handleMouseUp);
        };
        canvas.addEventListener('mousedown', handleMouseDown);

        const draw = () => {
            ctx.fillStyle = 'black';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            const rotX = rotationRef.current.x * (Math.PI / 180);
            const rotY = rotationRef.current.y * (Math.PI / 180);

            starsRef.current.forEach(star => {
                // Rotate Y
                let rz = star.z * Math.cos(rotY) - star.x * Math.sin(rotY);
                let rx = star.z * Math.sin(rotY) + star.x * Math.cos(rotY);
                // Rotate X
                let ry = star.y * Math.cos(rotX) - rz * Math.sin(rotX);
                rz = star.y * Math.sin(rotX) + rz * Math.cos(rotX);
                
                const f = 200 / (rz + 300);
                const px = rx * f + canvas.width / 2;
                const py = ry * f + canvas.height / 2;
                const psize = star.size * f;
                
                if(psize > 0 && px > 0 && px < canvas.width && py > 0 && py < canvas.height) {
                    ctx.fillStyle = `rgba(255, 255, 255, ${psize / 2})`;
                    ctx.beginPath();
                    ctx.arc(px, py, psize, 0, Math.PI * 2);
                    ctx.fill();
                }
                star.projected = {x: px, y: py, size: psize};
            });

            animationFrameId = requestAnimationFrame(draw);
        };
        draw();
        
        const handleClick = (e: MouseEvent) => {
            const rect = canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            let closestStar = null;
            let minDistance = 20;

            starsRef.current.forEach(star => {
                if (star.projected) {
                    const distance = Math.hypot(mouseX - star.projected.x, mouseY - star.projected.y);
                    if (distance < minDistance && distance < star.projected.size + 5) {
                        minDistance = distance;
                        closestStar = star;
                    }
                }
            });

            if (closestStar) {
                setSelectedStar(closestStar);
            }
        };
        canvas.addEventListener('click', handleClick);

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
            canvas.removeEventListener('mousedown', handleMouseDown);
            canvas.removeEventListener('click', handleClick);
        };
    }, []);
    
    useEffect(() => {
        if (selectedStar && state.activeProfile) {
            const fetchInfo = async () => {
                setIsLoadingInfo(true);
                setStarInfo(null);
                try {
                    const res = await getAIResponse(
                        "Generate fictional but plausible data for a star system. Include star type, number of planets, and a brief description.",
                        Mode.StellarCartography,
                        state.activeProfile.aiSettings
                    );
                    setStarInfo(res.text);
                } catch (e) {
                    setStarInfo("Failed to retrieve data from stellar archives.");
                }
                setIsLoadingInfo(false);
            };
            fetchInfo();
        }
    }, [selectedStar, state.activeProfile]);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Globe size={14}/> STELLAR CARTOGRAPHY
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="flex-1 relative bg-black cursor-grab active:cursor-grabbing">
                    <canvas ref={canvasRef} className="w-full h-full" />
                </div>
                <div className="w-full lg:w-1/3 border-t lg:border-t-0 lg:border-l border-[var(--color-panel-header-border)] flex flex-col">
                    <div className="hud-panel-header">
                        <Star size={14} /> SYSTEM DATA
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 bg-black/20">
                        {isLoadingInfo && <Loader2 className="animate-spin" />}
                        {starInfo ? (
                             <pre className="whitespace-pre-wrap font-mono text-sm text-gray-300">{starInfo}</pre>
                        ) : (
                            <p className="text-sm text-gray-500">Select a star to view system data.</p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StellarCartographyPanel;