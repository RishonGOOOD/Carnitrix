import React, { useState } from 'react';
import { mcpConnector } from '../services/mcpConnector';
import { McpServerConfig } from '../types';
import { 
  Boxes, Power, Play, CheckCircle2, AlertCircle, 
  Terminal, ShieldCheck, RefreshCw, FileText, Code
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const McpConnectorPanel: React.FC = () => {
  const [servers, setServers] = useState<McpServerConfig[]>(mcpConnector.getServers());
  const [selectedServer, setSelectedServer] = useState<McpServerConfig | null>(servers[0] || null);
  const [executingTool, setExecutingTool] = useState<string | null>(null);
  const [auditLogs, setAuditLogs] = useState(mcpConnector.getAuditLogs());
  const [toolParamInput, setToolParamInput] = useState('{"query": "defensive cybersecurity"}');
  const [execResult, setExecResult] = useState<any | null>(null);

  const refreshServers = () => {
    setServers(mcpConnector.getServers());
    setAuditLogs([...mcpConnector.getAuditLogs()]);
  };

  const handleToggle = (id: string) => {
    playSound('switch');
    triggerHaptic('light');
    mcpConnector.toggleServer(id);
    refreshServers();
  };

  const handleRunTool = async (server: McpServerConfig, toolName: string) => {
    setExecutingTool(toolName);
    playSound('scan');
    let parsedParams = {};
    try {
      parsedParams = JSON.parse(toolParamInput);
    } catch {
      parsedParams = { raw: toolParamInput };
    }

    const res = await mcpConnector.executeMcpTool(server.id, toolName, parsedParams);
    setExecResult(res);
    setExecutingTool(null);
    refreshServers();
    playSound(res.success ? 'success' : 'alert');
  };

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-red-950/20 border border-red-900/30 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-red-600/20 border border-red-500 rounded text-red-400">
              <Boxes size={18} />
            </span>
            <h1 className="text-xl font-black font-orbitron text-white tracking-wider">
              MODEL CONTEXT PROTOCOL (MCP) INTEGRATION HUB
            </h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Standardized client-server bridge connecting AI models to GitHub repositories, Brave Search, filesystems, and memory graphs.
          </p>
        </div>
      </div>

      {/* Main Grid: Server List on Left, Tool Inspector & Tester on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* Servers List (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="text-xs font-mono font-bold text-gray-400">
            CONFIGURED MCP SERVERS ({servers.length})
          </div>

          <div className="space-y-2.5">
            {servers.map(server => {
              const isSelected = selectedServer?.id === server.id;
              return (
                <div
                  key={server.id}
                  onClick={() => {
                    setSelectedServer(server);
                    playSound('click');
                  }}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected ? 'bg-red-950/30 border-red-500 shadow-[0_0_15px_rgba(255,0,0,0.2)]' : 'bg-black/60 border-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-sm text-white font-orbitron">{server.name}</div>
                      <div className="text-[10px] font-mono text-cyan-400 mt-0.5">{server.endpoint}</div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggle(server.id);
                      }}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold flex items-center gap-1 ${
                        server.enabled 
                          ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800' 
                          : 'bg-gray-900 text-gray-400 border border-gray-700'
                      }`}
                    >
                      <Power size={10} /> {server.enabled ? 'ACTIVE' : 'DISABLED'}
                    </button>
                  </div>

                  <p className="text-xs text-gray-400 font-mono mt-2 line-clamp-2">
                    {server.description}
                  </p>

                  <div className="flex flex-wrap gap-1 mt-2.5">
                    {server.capabilities.map((cap, i) => (
                      <span key={i} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/60 text-gray-400 border border-white/5">
                        {cap}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Server Tool Runner & Audit Log (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {selectedServer ? (
            <div className="p-4 bg-black/70 border border-red-900/30 rounded-xl space-y-4 font-mono text-xs">
              <div className="flex justify-between items-center border-b border-white/5 pb-2">
                <span className="font-bold text-white uppercase text-sm">
                  {selectedServer.name} — DISCOVERED MCP TOOLS
                </span>
                <span className="text-[10px] text-cyan-400">Transport: {selectedServer.transport}</span>
              </div>

              {/* Discovered tools list */}
              <div className="space-y-3">
                {selectedServer.discoveredTools.map(tool => (
                  <div key={tool.name} className="p-3 bg-red-950/10 border border-red-900/30 rounded-lg space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-cyan-300 text-xs flex items-center gap-1.5">
                        <Code size={13} /> {tool.name}
                      </span>
                      <button
                        disabled={!selectedServer.enabled || executingTool === tool.name}
                        onClick={() => handleRunTool(selectedServer, tool.name)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-500 text-black font-black uppercase tracking-wider rounded text-[10px] flex items-center gap-1 disabled:opacity-40"
                      >
                        <Play size={10} /> {executingTool === tool.name ? 'CALLING...' : 'CALL TOOL'}
                      </button>
                    </div>
                    <p className="text-gray-400 text-[11px]">{tool.description}</p>
                    <div className="text-[10px] text-gray-500 bg-black/40 p-1.5 rounded">
                      Schema: {JSON.stringify(tool.inputSchema)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Execution Result Box */}
              {execResult && (
                <div className="p-3 bg-cyan-950/20 border border-cyan-500/30 rounded-lg space-y-1">
                  <div className="text-xs font-bold text-cyan-400">EXECUTION RESPONSE</div>
                  <pre className="text-[11px] text-gray-200 overflow-x-auto p-2 bg-black/60 rounded">
                    {JSON.stringify(execResult, null, 2)}
                  </pre>
                </div>
              )}

              {/* Audit Log Stream */}
              <div className="pt-2 border-t border-white/5 space-y-2">
                <div className="text-xs font-bold text-gray-400 flex items-center gap-1.5">
                  <FileText size={12} /> MCP AUDIT & SECURITY TRAIL
                </div>
                <div className="space-y-1 max-h-[140px] overflow-y-auto">
                  {auditLogs.map((log, i) => (
                    <div key={i} className="p-1.5 bg-black/40 rounded border border-white/5 text-[10px] flex justify-between items-center">
                      <span className="text-gray-400">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                      <span className="text-white font-bold">{log.server}::{log.tool}</span>
                      <span className={log.status === 'SUCCESS' ? 'text-emerald-400' : 'text-cyan-400'}>{log.status}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-10 text-center text-gray-500 font-mono">
              Select an MCP server from the catalog to inspect tools.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
