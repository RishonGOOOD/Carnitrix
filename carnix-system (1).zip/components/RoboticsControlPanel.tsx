import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Bot, Cpu, Zap, RotateCcw, RotateCw, Play, Sliders, CheckCircle2, AlertTriangle, Terminal, Usb, Bluetooth, Download, RefreshCw } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

interface JointState {
    theta1: number; // Shoulder angle (degrees)
    theta2: number; // Elbow angle (degrees)
    theta3: number; // Wrist angle (degrees)
}

const L1 = 130; // Length of link 1 in pixels
const L2 = 100; // Length of link 2 in pixels
const L3 = 50;  // Length of end effector in pixels

const RoboticsControlPanel: React.FC = () => {
    const { state } = useAppContext();
    const canvasRef = useRef<HTMLCanvasElement>(null);

    // Target Coordinates (X, Y) relative to base (0, 0)
    const [targetX, setTargetX] = useState(160);
    const [targetY, setTargetY] = useState(140);
    const [gripperOpen, setGripperOpen] = useState(true);
    const [feedRate, setFeedRate] = useState(1200); // mm/min
    const [serialStatus, setSerialStatus] = useState<'DISCONNECTED' | 'CONNECTED' | 'UNSUPPORTED'>('DISCONNECTED');
    const [gcodeLog, setGcodeLog] = useState<string[]>([
        '(CARNIX 3-DOF ROBOTICS KINEMATICS INITIALIZED)',
        'G90 ; Absolute Coordinates',
        'G21 ; Metric units',
        'G28 ; Home all axes'
    ]);

    // Compute Analytical Inverse Kinematics: (X, Y) -> (theta1, theta2, theta3)
    const kinematics = useMemo(() => {
        // Distance to target
        const dist = Math.sqrt(targetX * targetX + targetY * targetY);
        const maxReach = L1 + L2 + L3 - 10;
        const clampedX = dist > maxReach ? (targetX / dist) * maxReach : targetX;
        const clampedY = dist > maxReach ? (targetY / dist) * maxReach : targetY;

        // Simplify with 2-link IK to wrist center
        const wristTargetX = clampedX - L3 * 0.707;
        const wristTargetY = clampedY - L3 * 0.707;

        const r2 = wristTargetX * wristTargetX + wristTargetY * wristTargetY;
        const cosTheta2 = (r2 - L1 * L1 - L2 * L2) / (2 * L1 * L2);
        const clampedCos2 = Math.max(-1, Math.min(1, cosTheta2));
        
        // Elbow-down solution
        const theta2Rad = Math.acos(clampedCos2);
        const k1 = L1 + L2 * Math.cos(theta2Rad);
        const k2 = L2 * Math.sin(theta2Rad);
        const theta1Rad = Math.atan2(wristTargetY, wristTargetX) - Math.atan2(k2, k1);

        const theta1Deg = (theta1Rad * 180) / Math.PI;
        const theta2Deg = (theta2Rad * 180) / Math.PI;
        const theta3Deg = -(theta1Deg + theta2Deg - 45); // orient tool downward

        // Forward Kinematics Verification: Compute Joint Positions
        const joint0 = { x: 0, y: 0 };
        const joint1 = {
            x: L1 * Math.cos(theta1Rad),
            y: L1 * Math.sin(theta1Rad)
        };
        const joint2 = {
            x: joint1.x + L2 * Math.cos(theta1Rad + theta2Rad),
            y: joint1.y + L2 * Math.sin(theta1Rad + theta2Rad)
        };
        const endEffector = {
            x: joint2.x + L3 * Math.cos(theta1Rad + theta2Rad + (theta3Deg * Math.PI) / 180),
            y: joint2.y + L3 * Math.sin(theta1Rad + theta2Rad + (theta3Deg * Math.PI) / 180)
        };

        return {
            theta1: Math.round(theta1Deg),
            theta2: Math.round(theta2Deg),
            theta3: Math.round(theta3Deg),
            joint0,
            joint1,
            joint2,
            endEffector,
            isReachable: dist <= maxReach
        };
    }, [targetX, targetY]);

    // Canvas Render of Robotic Arm at 60 FPS
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const width = canvas.width;
        const height = canvas.height;
        ctx.clearRect(0, 0, width, height);

        // Origin at bottom-center
        const originX = width / 2;
        const originY = height - 40;

        // Draw Coordinate Grid & Reach Envelope
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.1)';
        ctx.lineWidth = 1;
        for (let r = 50; r <= L1 + L2 + L3; r += 50) {
            ctx.beginPath();
            ctx.arc(originX, originY, r, Math.PI, 0);
            ctx.stroke();
        }

        // Draw Base Pedestal
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(originX - 35, originY, 70, 25);
        ctx.strokeStyle = '#06b6d4';
        ctx.strokeRect(originX - 35, originY, 70, 25);

        // Transform coords to canvas space
        const toCanvas = (pt: { x: number; y: number }) => ({
            x: originX + pt.x,
            y: originY - pt.y
        });

        const p0 = toCanvas(kinematics.joint0);
        const p1 = toCanvas(kinematics.joint1);
        const p2 = toCanvas(kinematics.joint2);
        const p3 = toCanvas(kinematics.endEffector);

        // Draw Link 1 (Shoulder to Elbow)
        ctx.strokeStyle = '#06b6d4';
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(p0.x, p0.y); ctx.lineTo(p1.x, p1.y); ctx.stroke();

        // Draw Link 2 (Elbow to Wrist)
        ctx.strokeStyle = '#3b82f6';
        ctx.lineWidth = 6;
        ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();

        // Draw End Effector Link
        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(p2.x, p2.y); ctx.lineTo(p3.x, p3.y); ctx.stroke();

        // Draw Joint Servos (Circles)
        const drawJoint = (p: { x: number; y: number }, color: string, label: string) => {
            ctx.fillStyle = color;
            ctx.beginPath(); ctx.arc(p.x, p.y, 7, 0, Math.PI * 2); ctx.fill();
            ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.5; ctx.stroke();
            ctx.fillStyle = '#ffffff'; ctx.font = '9px monospace';
            ctx.fillText(label, p.x + 10, p.y - 5);
        };

        drawJoint(p0, '#06b6d4', `J1: ${kinematics.theta1}°`);
        drawJoint(p1, '#3b82f6', `J2: ${kinematics.theta2}°`);
        drawJoint(p2, '#a855f7', `J3: ${kinematics.theta3}°`);

        // Draw Gripper Tool
        ctx.strokeStyle = gripperOpen ? '#22c55e' : '#ef4444';
        ctx.lineWidth = 3;
        const gSpread = gripperOpen ? 12 : 3;
        ctx.beginPath();
        ctx.moveTo(p3.x - gSpread, p3.y + 10);
        ctx.lineTo(p3.x, p3.y);
        ctx.lineTo(p3.x + gSpread, p3.y + 10);
        ctx.stroke();

        // Target Crosshair
        const tPos = toCanvas({ x: targetX, y: targetY });
        ctx.strokeStyle = '#22c55e';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(tPos.x, tPos.y, 9, 0, Math.PI * 2);
        ctx.moveTo(tPos.x - 14, tPos.y); ctx.lineTo(tPos.x + 14, tPos.y);
        ctx.moveTo(tPos.x, tPos.y - 14); ctx.lineTo(tPos.x, tPos.y + 14);
        ctx.stroke();

    }, [kinematics, targetX, targetY, gripperOpen]);

    // Interactive Canvas Click / Drag Handler
    const handleCanvasInteraction = (e: React.MouseEvent<HTMLCanvasElement>) => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const rect = canvas.getBoundingClientRect();
        const mouseX = (e.clientX - rect.left) * (canvas.width / rect.width);
        const mouseY = (e.clientY - rect.top) * (canvas.height / rect.height);

        const originX = canvas.width / 2;
        const originY = canvas.height - 40;

        const newTargetX = Math.round(mouseX - originX);
        const newTargetY = Math.round(originY - mouseY);

        if (newTargetY >= 0) {
            setTargetX(newTargetX);
            setTargetY(newTargetY);
            
            // Append G-code line
            const line = `G01 X${newTargetX}.0 Y${newTargetY}.0 F${feedRate}`;
            setGcodeLog(prev => [...prev.slice(-15), line]);
            playSound('click');
        }
    };

    // Connect WebSerial Hardware Bridge
    const handleConnectSerial = async () => {
        if (!('serial' in navigator)) {
            setSerialStatus('UNSUPPORTED');
            alert('WebSerial API is not supported in this browser. Use Chrome/Edge desktop.');
            return;
        }
        try {
            const port = await (navigator as any).serial.requestPort();
            await port.open({ baudRate: 115200 });
            setSerialStatus('CONNECTED');
            playSound('success');
            setGcodeLog(prev => [...prev, '(SERIAL BRIDGE ESTABLISHED @ 115200 BAUD)']);
        } catch (e: any) {
            console.warn(e);
            playSound('error');
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-2 bg-black/95 font-mono text-xs select-none">
            {/* Header */}
            <div className="flex-shrink-0 flex items-center justify-between border-b border-cyan-600/40 pb-2 px-1">
                <div className="flex items-center gap-2 text-cyan-400">
                    <Bot size={18} className="animate-pulse" />
                    <span className="font-bold tracking-wider text-sm">3-DOF ROBOTICS KINEMATICS & G-CODE CONTROLLER</span>
                    <span className="bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-[10px] px-2 py-0.5 rounded">
                        ANALYTICAL INVERSE KINEMATICS
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setGripperOpen(!gripperOpen)}
                        className={`px-3 py-1 rounded text-[11px] font-bold border transition-all ${
                            gripperOpen ? 'bg-green-950/40 border-green-500 text-green-400' : 'bg-red-950/40 border-red-500 text-red-400'
                        }`}
                    >
                        GRIPPER: {gripperOpen ? 'OPEN' : 'CLAMPED'}
                    </button>
                    <button 
                        onClick={handleConnectSerial}
                        className="bg-cyan-600 hover:bg-cyan-500 text-black font-bold px-3 py-1 rounded text-[11px] flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                    >
                        <Usb size={12} /> {serialStatus === 'CONNECTED' ? 'SERIAL CONNECTED' : 'CONNECT HARDWARE'}
                    </button>
                </div>
            </div>

            {/* Main Workbench Grid */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-0 overflow-y-auto">
                {/* Left Column: Interactive 60fps Arm Kinematics Canvas */}
                <div className="lg:col-span-7 flex flex-col bg-black/90 border border-cyan-500/30 rounded-lg p-2 min-h-[340px]">
                    <div className="flex items-center justify-between pb-1.5 border-b border-cyan-950 text-[10px] text-gray-400">
                        <span className="text-cyan-400 font-bold">CLICK OR DRAG RETICLE ON CANVAS TO SOLVE IK</span>
                        <span>TARGET: ({targetX}, {targetY}) mm</span>
                    </div>
                    <canvas 
                        ref={canvasRef} 
                        width={540} 
                        height={320} 
                        onClick={handleCanvasInteraction}
                        className="w-full h-full block cursor-crosshair rounded"
                    />
                </div>

                {/* Right Column: Joint Angles, Sliders & G-Code Feed */}
                <div className="lg:col-span-5 flex flex-col gap-3">
                    {/* Computed Joint Angles Card */}
                    <div className="grid grid-cols-3 gap-2 bg-black/80 border border-cyan-500/30 p-2.5 rounded-lg text-center">
                        <div className="bg-cyan-950/30 border border-cyan-500/20 p-2 rounded">
                            <span className="text-gray-400 text-[10px] block">THETA 1 (SHOULDER)</span>
                            <span className="text-xl font-black text-cyan-400">{kinematics.theta1}°</span>
                        </div>
                        <div className="bg-blue-950/30 border border-blue-500/20 p-2 rounded">
                            <span className="text-gray-400 text-[10px] block">THETA 2 (ELBOW)</span>
                            <span className="text-xl font-black text-blue-400">{kinematics.theta2}°</span>
                        </div>
                        <div className="bg-purple-950/30 border border-purple-500/20 p-2 rounded">
                            <span className="text-gray-400 text-[10px] block">THETA 3 (WRIST)</span>
                            <span className="text-xl font-black text-purple-400">{kinematics.theta3}°</span>
                        </div>
                    </div>

                    {/* Coordinate Slider Controls */}
                    <div className="bg-black/80 border border-cyan-500/30 p-3 rounded-lg flex flex-col gap-2.5">
                        <div>
                            <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                                <span>TARGET X COORDINATE</span>
                                <span className="text-cyan-400 font-bold">{targetX} mm</span>
                            </div>
                            <input 
                                type="range" min={-240} max={240} step={2} value={targetX} 
                                onChange={e => setTargetX(Number(e.target.value))}
                                className="w-full h-1.5 bg-gray-800 rounded appearance-none cursor-pointer accent-cyan-500"
                            />
                        </div>
                        <div>
                            <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                                <span>TARGET Y ELEVATION</span>
                                <span className="text-cyan-400 font-bold">{targetY} mm</span>
                            </div>
                            <input 
                                type="range" min={10} max={250} step={2} value={targetY} 
                                onChange={e => setTargetY(Number(e.target.value))}
                                className="w-full h-1.5 bg-gray-800 rounded appearance-none cursor-pointer accent-cyan-500"
                            />
                        </div>
                    </div>

                    {/* Real G-Code Terminal Feed */}
                    <div className="bg-black/90 border border-cyan-500/30 rounded-lg p-2.5 flex-1 flex flex-col min-h-[140px]">
                        <span className="text-cyan-400 text-[10px] font-bold flex items-center gap-1 mb-1.5 pb-1 border-b border-cyan-950">
                            <Terminal size={12} /> G-CODE TELEMETRY STREAM
                        </span>
                        <div className="flex-1 overflow-y-auto font-mono text-[10px] text-gray-400 space-y-0.5">
                            {gcodeLog.map((line, idx) => (
                                <div key={idx} className="hover:text-white">{line}</div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RoboticsControlPanel;
