import React, { useState } from 'react';
import { Bot, Zap, Send, Loader2, Code, FileJson } from 'lucide-react';
import { useAppContext } from '../context';
import { generateModuleBlueprint } from '../services/geminiService';

const ModuleCreatorPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [description, setDescription] = useState('');
    const [blueprint, setBlueprint] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerate = async () => {
        if (!description.trim() || !activeProfile) return;
        setIsLoading(true);
        setBlueprint(null);
        try {
            const res = await generateModuleBlueprint(activeProfile.aiSettings, description);
            const formattedJson = JSON.stringify(JSON.parse(res.text), null, 2);
            setBlueprint(formattedJson);
        } catch (e: any) {
            setBlueprint(`{\n  "error": "Failed to generate a valid blueprint. Please try refining your description.",\n  "details": "${e.message}"\n}`);
        }
        setIsLoading(false);
    };

    return (
        <div className="w-full h-full flex flex-col md:flex-row gap-4 p-1">
            <div className="w-full md:w-1/3 flex flex-col gap-4">
                <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4">
                    <h2 className="text-sm font-bold text-[var(--color-primary)] flex items-center gap-2 mb-3">
                        <Bot size={16} /> MODULE GENERATOR
                    </h2>
                    <p className="text-xs text-gray-400 mb-3">Describe a new panel or feature you want to create. The AI will generate a technical blueprint for it.</p>
                     <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="e.g., A panel that tracks global stock market data using an external API, with charts for major indices."
                        className="w-full h-40 bg-black/50 border border-gray-700 rounded p-2 text-sm resize-y focus:outline-none focus:border-[var(--color-primary)]"
                        disabled={isLoading}
                    />
                </div>
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !description.trim()}
                    className="w-full flex items-center justify-center gap-2 p-4 bg-[var(--color-button-background)] hover:bg-[var(--color-button-hover)] border border-[var(--color-button-border)] rounded-md transition-colors disabled:opacity-50"
                >
                    {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                    {isLoading ? 'DESIGNING...' : 'GENERATE BLUEPRINT'}
                </button>
            </div>
            <div className="flex-1 bg-black border border-[var(--color-terminal-border)] rounded-md p-2 font-mono text-sm flex flex-col min-h-0 relative">
                <div className="p-2 border-b border-gray-700 text-xs text-gray-400 flex items-center gap-2">
                    <FileJson size={14} /> GENERATED BLUEPRINT (JSON)
                </div>
                 <div className="flex-1 overflow-auto p-2">
                    {isLoading && (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            <Loader2 size={24} className="animate-spin mr-2" /> AI Architect is processing...
                        </div>
                    )}
                    {blueprint ? (
                        <pre><code className="whitespace-pre-wrap text-sm">{blueprint}</code></pre>
                    ) : (
                        <div className="text-gray-600">Blueprint will appear here.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ModuleCreatorPanel;