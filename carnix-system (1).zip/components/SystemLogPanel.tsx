
import React, { useState, useRef, useEffect } from 'react';
import { LogEntry } from '../types';
import { FileText, Filter, Trash2, Download, AlertCircle, Info, CheckCircle, AlertTriangle } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface SystemLogPanelProps {
    logs: LogEntry[];
    onClearLogs: () => void;
}

const SystemLogPanel: React.FC<SystemLogPanelProps> = ({ logs, onClearLogs }) => {
    const [filterSource, setFilterSource] = useState<string>('ALL');
    const [filterLevel, setFilterLevel] = useState<string>('ALL');
    const [searchTerm, setSearchTerm] = useState('');
    const bottomRef = useRef<HTMLDivElement>(null);

    const filteredLogs = logs.filter(log => {
        if (filterSource !== 'ALL' && log.source !== filterSource) return false;
        if (filterLevel !== 'ALL' && log.level !== filterLevel) return false;
        if (searchTerm && !log.message.toLowerCase().includes(searchTerm.toLowerCase())) return false;
        return true;
    });

    // Auto-scroll
    useEffect(() => {
        if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }, [logs]);

    const getLevelIcon = (level: string) => {
        switch (level) {
            case 'error': return <AlertTriangle size={12} className="text-red-500" />;
            case 'warn': return <AlertCircle size={12} className="text-yellow-500" />;
            case 'success': return <CheckCircle size={12} className="text-green-500" />;
            default: return <Info size={12} className="text-blue-400" />;
        }
    };

    const getLevelClass = (level: string) => {
        switch (level) {
            case 'error': return 'text-red-500 bg-red-900/10 border-red-900/30';
            case 'warn': return 'text-yellow-500 bg-yellow-900/10 border-yellow-900/30';
            case 'success': return 'text-green-400 bg-green-900/10 border-green-900/30';
            default: return 'text-blue-400 bg-blue-900/10 border-blue-900/30';
        }
    };

    const exportLogs = () => {
        const data = JSON.stringify(logs, null, 2);
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `carnix-logs-${Date.now()}.json`;
        a.click();
        playSound('success');
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 relative p-1">
            {/* Controls */}
            <div className="bg-black/40 border border-[var(--color-panel-border)] rounded-lg p-2 flex flex-wrap gap-2 items-center justify-between">
                <div className="flex items-center gap-2 text-[var(--color-primary)] font-bold text-xs px-2">
                    <FileText size={16} /> SYSTEM LOGS
                </div>
                
                <div className="flex gap-2 flex-1 justify-end">
                     <input 
                        type="text" 
                        placeholder="Search logs..." 
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="bg-black border border-gray-700 rounded px-2 py-1 text-xs w-32 md:w-48 focus:border-[var(--color-primary)] outline-none"
                    />
                     <select value={filterLevel} onChange={e => setFilterLevel(e.target.value)} className="bg-black border border-gray-700 rounded px-2 py-1 text-xs outline-none">
                        <option value="ALL">All Levels</option>
                        <option value="info">Info</option>
                        <option value="warn">Warn</option>
                        <option value="error">Error</option>
                        <option value="success">Success</option>
                     </select>
                     <select value={filterSource} onChange={e => setFilterSource(e.target.value)} className="bg-black border border-gray-700 rounded px-2 py-1 text-xs outline-none">
                        <option value="ALL">All Sources</option>
                        <option value="SYS">System</option>
                        <option value="NET">Network</option>
                        <option value="AI">AI Core</option>
                        <option value="AIM">AIM</option>
                     </select>
                </div>
            </div>

            {/* Log Display */}
            <div className="flex-1 bg-black border border-[var(--color-panel-border)] rounded-lg overflow-hidden flex flex-col font-mono text-xs">
                <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin">
                    {filteredLogs.length === 0 && (
                        <div className="text-center text-gray-500 mt-10 italic">No entries found matching criteria.</div>
                    )}
                    {filteredLogs.map((log) => (
                        <div key={log.id} className={`flex items-start gap-2 p-1.5 border rounded ${getLevelClass(log.level)} hover:bg-white/5 transition-colors`}>
                            <span className="text-gray-500 whitespace-nowrap shrink-0 w-16 text-[10px]">
                                {new Date(log.timestamp).toLocaleTimeString([], {hour12:false, hour:'2-digit', minute:'2-digit', second:'2-digit'})}
                            </span>
                            <span className="font-bold w-10 shrink-0 text-center">{log.source}</span>
                            <span className="shrink-0 pt-0.5">{getLevelIcon(log.level)}</span>
                            <span className="break-all">{log.message}</span>
                        </div>
                    ))}
                    <div ref={bottomRef} />
                </div>
                
                {/* Footer Actions */}
                <div className="p-2 border-t border-[var(--color-panel-border)] bg-black/60 flex justify-between items-center text-[10px] text-[var(--color-text-muted)]">
                    <div>TOTAL ENTRIES: {logs.length}</div>
                    <div className="flex gap-2">
                        <button onClick={exportLogs} className="flex items-center gap-1 hover:text-white transition-colors"><Download size={12}/> EXPORT JSON</button>
                        <button onClick={() => { onClearLogs(); playSound('click'); }} className="flex items-center gap-1 text-red-500 hover:text-red-400 transition-colors"><Trash2 size={12}/> CLEAR LOGS</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SystemLogPanel;
