import React, { useState } from 'react';
import { Languages, Send, Loader2, ArrowRight } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

const LinguisticsTranslatorPanel: React.FC = () => {
    const { state } = useAppContext();
    const [text, setText] = useState('');
    const [targetLang, setTargetLang] = useState('Spanish');
    const [translation, setTranslation] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const languages = ['Spanish', 'French', 'German', 'Japanese', 'Russian', 'Mandarin Chinese', 'Tamil'];

    const handleTranslate = async () => {
        if (!text.trim() || !state.activeProfile) return;
        setIsLoading(true);
        setTranslation(null);
        try {
            const prompt = `Translate the following text to ${targetLang}: "${text}"`;
            const res = await getAIResponse(prompt, Mode.LinguisticsTranslator, state.activeProfile.aiSettings);
            setTranslation(res.text);
        } catch (e) {
            setTranslation('Translation failed.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Languages size={14}/> LINGUISTICS TRANSLATOR
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col overflow-hidden">
                <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4 border-b border-[var(--color-panel-header-border)]">
                    <textarea
                        value={text}
                        onChange={e => setText(e.target.value)}
                        placeholder="Enter text to translate..."
                        className="w-full h-32 hud-textarea resize-none"
                    />
                    <div className="w-full h-32 hud-textarea bg-black/50 p-2 overflow-y-auto">
                        {isLoading ? <Loader2 className="animate-spin" /> : (translation || 'Translation will appear here.')}
                    </div>
                </div>
                <div className="p-4 flex items-center gap-4">
                     <span className="text-xs font-bold text-gray-400">TRANSLATE TO:</span>
                     <select value={targetLang} onChange={e => setTargetLang(e.target.value)} className="hud-select flex-1">
                        {languages.map(lang => <option key={lang} value={lang}>{lang}</option>)}
                    </select>
                    <button onClick={handleTranslate} disabled={isLoading || !text.trim()} className="hud-button flex items-center gap-2">
                        <Send size={16}/> TRANSLATE
                    </button>
                </div>
            </div>
        </div>
    );
};

export default LinguisticsTranslatorPanel;
