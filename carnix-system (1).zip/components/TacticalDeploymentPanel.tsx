
import React, { useState, useMemo } from 'react';
import { Move, User, Shield, Bot, Zap, Heart, Activity, Info, Crosshair, Target, ShieldAlert } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

interface Unit {
    id: string;
    type: 'Infantry' | 'Armor' | 'Drone' | 'Sniper' | 'Heavy';
    x: number;
    y: number;
    health: number;
    fuel: number;
    status: 'ACTIVE' | 'ENGAGED' | 'CRITICAL';
}

const TacticalDeploymentPanel: React.FC = () => {
    const [units, setUnits] = useState<Unit[]>([]);
    const [selectedUnitType, setSelectedUnitType] = useState<Unit['type']>('Infantry');
    const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);

    const handleGridClick = (row: number, col: number) => {
        const existing = units.find(u => u.x === col && u.y === row);
        if (existing) {
            setSelectedUnitId(existing.id);
            playSound('click');
            triggerHaptic('light');
            return;
        }

        const newUnit: Unit = {
            id: `unit-${Date.now()}`,
            type: selectedUnitType,
            x: col,
            y: row,
            health: 100,
            fuel: 100,
            status: 'ACTIVE'
        };
        setUnits(prev => [...prev, newUnit]);
        setSelectedUnitId(newUnit.id);
        playSound('access');
        triggerHaptic('medium');
    };

    const removeUnit = (id: string) => {
        setUnits(prev => prev.filter(u => u.id !== id));
        if (selectedUnitId === id) setSelectedUnitId(null);
        playSound('error');
    };

    const getUnitIcon = (type: Unit['type']) => {
        switch(type) {
            case 'Infantry': return <User size={16} />;
            case 'Armor': return <Shield size={16} />;
            case 'Drone': return <Bot size={16} />;
            case 'Sniper': return <Crosshair size={16} />;
            case 'Heavy': return <Zap size={16} />;
        }
    };

    const selectedUnit = useMemo(() => units.find(u => u.id === selectedUnitId), [units, selectedUnitId]);

    const rows = 12;
    const cols = 12;

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-[Rajdhani]">
            {/* Control Header */}
            <div className="flex-shrink-0 bg-black/60 border border-red-600/30 p-4 rounded-lg flex justify-between items-center shadow-lg">
                <div className="flex items-center gap-4">
                    <div className="p-2 bg-red-600/10 rounded border border-red-600/50">
                        <Target size={24} className="text-red-600" />
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-white uppercase italic tracking-tighter">Tactical Deployment Matrix</h2>
                        <p className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Grid Protocol: MIL-SPEC 810G // Active Deployments: {units.length}</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={() => { setUnits([]); setSelectedUnitId(null); playSound('switch'); }} className="text-[10px] font-black text-red-500 border border-red-900/50 px-4 py-2 hover:bg-red-900/20 rounded uppercase tracking-widest">Wipe Grid</button>
                </div>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row overflow-hidden gap-3">
                {/* GRID INTERFACE */}
                <div className="flex-1 relative bg-black/40 border border-white/5 overflow-auto p-4 flex items-center justify-center select-none rounded-lg shadow-inner">
                    {/* Visual Grid Decor */}
                    <div className="absolute inset-0 pointer-events-none opacity-5 overflow-hidden">
                        <div className="w-full h-full" style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                    </div>

                    <div 
                        className="grid gap-1 bg-gray-900/40 p-1 border border-red-600/10 shadow-[0_0_50px_rgba(0,0,0,0.5)]"
                        style={{ 
                            gridTemplateColumns: `repeat(${cols}, 1fr)`,
                            width: 'min(90vw, 550px)',
                            aspectRatio: '1/1'
                        }}
                    >
                        {Array.from({ length: rows * cols }).map((_, i) => {
                            const r = Math.floor(i / cols);
                            const c = i % cols;
                            const unit = units.find(u => u.x === c && u.y === r);
                            const isSelected = selectedUnitId === unit?.id;

                            return (
                                <div 
                                    key={i} 
                                    onClick={() => handleGridClick(r, c)}
                                    className={`relative aspect-square border border-white/5 flex items-center justify-center transition-all cursor-crosshair
                                        ${unit ? 'bg-red-600/20' : 'hover:bg-white/10'}
                                        ${isSelected ? 'ring-2 ring-red-600 shadow-[0_0_20px_rgba(255,0,60,0.6)] z-10' : ''}
                                    `}
                                >
                                    {unit && (
                                        <div className={`transition-transform duration-300 ${isSelected ? 'scale-125 text-white' : 'text-red-500 opacity-80'}`}>
                                            {getUnitIcon(unit.type)}
                                        </div>
                                    )}
                                    {/* Coordinate Marker */}
                                    <span className="absolute bottom-0.5 right-0.5 text-[6px] text-gray-700 opacity-20 pointer-events-none">{c}:{r}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* COMMAND ROSTER */}
                <div className="w-full lg:w-80 flex flex-col gap-3">
                    <div className="bg-black/60 border border-white/10 p-4 rounded-lg flex flex-col gap-3">
                        <p className="text-[10px] font-black text-gray-500 tracking-widest uppercase mb-1">Roster Class Selection</p>
                        <div className="grid grid-cols-3 gap-2">
                            {(['Infantry', 'Armor', 'Drone', 'Sniper', 'Heavy'] as const).map(type => (
                                <button 
                                    key={type}
                                    onClick={() => { setSelectedUnitType(type); playSound('click'); }}
                                    className={`p-3 border flex flex-col items-center gap-1.5 rounded-md transition-all ${selectedUnitType === type ? 'border-red-600 bg-red-600/20 text-white shadow-[0_0_10px_rgba(255,0,60,0.2)]' : 'border-gray-800 text-gray-500 hover:border-gray-600'}`}
                                >
                                    {getUnitIcon(type)}
                                    <span className="text-[8px] font-black uppercase">{type}</span>
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="flex-1 bg-black/60 border border-white/10 p-5 rounded-lg overflow-hidden flex flex-col shadow-xl">
                        <div className="text-[10px] font-black text-white uppercase tracking-[0.3em] mb-6 flex items-center gap-2 border-b border-white/5 pb-2">
                            <Activity size={14} className="text-red-600" /> Unit Telemetry
                        </div>
                        
                        {selectedUnit ? (
                            <div className="space-y-6 animate-enter">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="text-2xl font-black text-white tracking-tighter uppercase italic">{selectedUnit.type}</h3>
                                        <p className="text-[10px] font-mono text-gray-600">SERIAL_ID: {selectedUnit.id.slice(-8).toUpperCase()}</p>
                                    </div>
                                    <div className={`px-2 py-0.5 rounded border text-[8px] font-black ${selectedUnit.status === 'ACTIVE' ? 'bg-green-900/20 border-green-500 text-green-500' : 'bg-red-900/20 border-red-500 text-red-500'}`}>
                                        {selectedUnit.status}
                                    </div>
                                </div>

                                <div className="space-y-4">
                                    <div className="space-y-1.5">
                                        <div className="flex justify-between text-[10px] font-black">
                                            <span className="text-gray-500">STRUCTURAL INTEGRITY</span>
                                            <span className="text-green-500">{selectedUnit.health}%</span>
                                        </div>
                                        <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                                            <div className="h-full bg-green-500 shadow-[0_0_10px_#22c55e]" style={{ width: `${selectedUnit.health}%` }}></div>
                                        </div>
                                    </div>
                                    <div className="space-y-1.5">
                                        <div className="flex justify-between text-[10px] font-black">
                                            <span className="text-gray-500">ENERGY_RESERVE</span>
                                            <span className="text-blue-400">{selectedUnit.fuel}%</span>
                                        </div>
                                        <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                                            <div className="h-full bg-blue-400 shadow-[0_0_10px_#3b82f6]" style={{ width: `${selectedUnit.fuel}%` }}></div>
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-white/5 border border-white/10 p-3 rounded font-mono text-[10px] text-gray-400 space-y-1.5">
                                    <div className="flex justify-between"><span>GRID_LOCKED:</span> <span className="text-white">[{selectedUnit.x}, {selectedUnit.y}]</span></div>
                                    <div className="flex justify-between"><span>AMMO_COUNT:</span> <span className="text-white">MAX</span></div>
                                    <div className="flex justify-between"><span>UPTIME:</span> <span className="text-white">00:14:22</span></div>
                                </div>
                                
                                <div className="flex gap-2">
                                    <button className="flex-1 py-3 bg-red-600 text-black font-black uppercase text-[10px] tracking-widest hover:bg-white transition-all shadow-[0_0_20px_rgba(255,0,60,0.3)]">Engage Target</button>
                                    <button onClick={() => removeUnit(selectedUnit.id)} className="p-3 bg-white/5 border border-white/10 text-red-500 hover:bg-red-500 hover:text-black transition-all rounded">
                                        <ShieldAlert size={18} />
                                    </button>
                                </div>
                            </div>
                        ) : (
                            <div className="flex-1 flex flex-col items-center justify-center text-center opacity-20 py-10">
                                <Crosshair size={64} className="mb-4 animate-pulse" />
                                <p className="text-[10px] font-black tracking-[0.5em] uppercase">Awaiting Unit Uplink<br/>Select Node on Grid</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TacticalDeploymentPanel;
