
import React, { useState } from 'react';
import { Cpu, Zap, Terminal, Power, RefreshCw, Send } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const HardwarePanel: React.FC = () => {
    const [connected, setConnected] = useState(false);
    const [logs, setLogs] = useState<string[]>(['[SYS] Port Scanner Ready.']);
    const [input, setInput] = useState('');

    const log = (m: string) => setLogs(p => [`[${new Date().toLocaleTimeString()}] ${m}`, ...p].slice(0, 20));

    const connect = async () => {
        if (!('serial' in navigator)) {
            log('ERR: WebSerial API not detected.');
            return;
        }
        try {
            const p = await (navigator as any).serial.requestPort();
            await p.open({ baudRate: 115200 });
            setConnected(true);
            log('UPLINK SUCCESS: Hardware sync active.');
            playSound('success');
        } catch (e) {
            log('ERR: Link aborted by user.');
        }
    };

    const tx = (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim()) return;
        log(`TX: ${input}`);
        setInput('');
        playSound('click');
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-red-600/30 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Cpu size={20} className={connected ? 'text-red-600 animate-pulse' : 'text-gray-600'} />
                    <h2 className="text-sm font-black text-white uppercase italic">Hardware Bridge</h2>
                </div>
                <button 
                    onClick={connect} 
                    className={`px-4 py-1.5 rounded text-[9px] font-black transition-all ${connected ? 'bg-green-600 text-black' : 'bg-red-600 text-black'}`}
                >
                    {connected ? 'LINK ACTIVE' : 'INITIALIZE USB'}
                </button>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row gap-2 overflow-hidden">
                <div className="flex-1 bg-black/30 border border-[var(--color-panel-header-border)] rounded-lg flex flex-col overflow-hidden">
                    <div className="p-2 border-b border-white/5 text-[9px] font-black text-gray-500 uppercase flex items-center gap-2"><Terminal size={12}/> Comms Log</div>
                    <div className="flex-1 overflow-y-auto p-3 font-mono text-[10px] text-gray-400 space-y-1 scrollbar-tactical flex flex-col-reverse">
                        {logs.map((l, i) => <div key={i} className={l.includes('ERR') ? 'text-red-500' : l.includes('TX') ? 'text-cyan-400' : ''}>{l}</div>)}
                    </div>
                </div>

                <div className="w-full lg:w-64 bg-black/60 border border-white/10 rounded-lg p-4 flex flex-col gap-4">
                    <div className="space-y-4">
                        <div className="text-center p-4 border border-gray-800 rounded bg-black/40">
                            <Power size={32} className={`mx-auto mb-2 ${connected ? 'text-red-600' : 'text-gray-800'}`} />
                            <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{connected ? 'Power Online' : 'No Hardware'}</p>
                        </div>
                        <div className="space-y-2">
                             <div className="flex justify-between text-[8px] font-bold text-gray-500 uppercase"><span>Baud Rate</span> <span className="text-white">115200</span></div>
                             <div className="flex justify-between text-[8px] font-bold text-gray-500 uppercase"><span>Port</span> <span className="text-white">/dev/ttyUSB0</span></div>
                        </div>
                    </div>
                    <form onSubmit={tx} className="mt-auto flex gap-1">
                        <input value={input} onChange={e => setInput(e.target.value)} className="flex-1 bg-black/40 border border-gray-800 p-2 text-[10px] text-white font-mono outline-none" placeholder="CMD_TX..." />
                        <button className="p-2 bg-red-600 text-black rounded"><Send size={12}/></button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default HardwarePanel;
