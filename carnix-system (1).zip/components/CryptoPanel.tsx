
import React, { useState, useEffect } from 'react';
import { Bitcoin, ArrowUp, ArrowDown, Loader2 } from 'lucide-react';
import { CryptoData } from '../types';
import { ListSkeleton } from './Loading';

const CryptoPanel: React.FC = () => {
    const [cryptoData, setCryptoData] = useState<CryptoData[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, 60000); // Refresh every minute
        return () => clearInterval(interval);
    }, []);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const res = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false');
            if (!res.ok) throw new Error('Failed to fetch crypto data from API');
            const data: CryptoData[] = await res.json();
            setCryptoData(data);
            setError(null);
        } catch (e: any) {
            setError(e.message);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                 <h2 className="text-sm font-bold text-white flex items-center gap-2"><Bitcoin size={16}/> CRYPTO MARKET DATA</h2>
                 {isLoading && <Loader2 size={16} className="animate-spin text-[var(--color-primary)]" />}
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden">
                <div className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400 grid grid-cols-3 gap-2">
                    <span>ASSET</span>
                    <span className="text-right">PRICE (USD)</span>
                    <span className="text-right">24H CHANGE</span>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {isLoading && cryptoData.length === 0 ? (
                        <div className="p-2">
                            <ListSkeleton count={10} />
                        </div>
                    ) : error ? (
                        <div className="p-4 text-center text-red-500">{error}</div>
                    ) : (
                        cryptoData.map(coin => (
                            <div key={coin.id} className="grid grid-cols-3 gap-2 p-3 border-b border-gray-800/50 items-center font-mono text-sm hover:bg-white/5">
                                <div className="flex items-center gap-2">
                                    <img src={coin.image} alt={coin.name} className="w-5 h-5"/>
                                    <span className="text-white font-bold">{coin.symbol.toUpperCase()}</span>
                                </div>
                                <span className="text-right text-white">${coin.current_price.toLocaleString()}</span>
                                <span className={`flex items-center justify-end font-bold ${coin.price_change_percentage_24h >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                                    {coin.price_change_percentage_24h >= 0 ? <ArrowUp size={12}/> : <ArrowDown size={12}/>}
                                    {coin.price_change_percentage_24h.toFixed(2)}%
                                </span>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

export default CryptoPanel;
