

import React, { useState } from 'react';
import { Mic, Send } from 'lucide-react';

interface CommandTerminalProps {
  onCommand: (command: string) => void;
  isLoading: boolean;
  isListening: boolean;
  onToggleVoice: () => void;
}

const CommandTerminal: React.FC<CommandTerminalProps> = ({ onCommand, isLoading, isListening, onToggleVoice }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onCommand(input.trim());
      setInput('');
    }
  };
  
  const buttonStyle = "p-2 bg-black/50 border border-[var(--color-panel-header-border)] text-[var(--color-accent)] rounded-md transition-colors hover:bg-[var(--color-accent)] hover:text-black hover:shadow-[0_0_10px_var(--color-accent)]";

  return (
    <div className="w-full">
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <button
            type="button"
            onClick={onToggleVoice}
            className={`${buttonStyle} ${isListening ? 'animate-pulse' : ''}`}
            title={isListening ? 'Global Voice Command Active' : 'Activate Global Voice Command'}
            aria-label={isListening ? 'Deactivate global voice command' : 'Activate global voice command'}
        >
          <Mic size={20} className={isListening ? 'text-[var(--color-primary)]' : 'text-gray-500'}/>
        </button>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Awaiting command..."
          className="flex-1 bg-black/40 border border-[var(--color-panel-header-border)] rounded-md px-3 py-2 focus:outline-none focus:border-[var(--color-accent)] focus:shadow-[0_0_10px_var(--color-accent)] placeholder-gray-500 text-[var(--color-text)] transition-all"
          disabled={isLoading}
          aria-label="Command input"
        />
        <button type="submit" className={buttonStyle} disabled={isLoading} aria-label="Send command">
          <Send size={20} />
        </button>
      </form>
    </div>
  );
};

export default CommandTerminal;