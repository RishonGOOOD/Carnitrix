
import React from 'react';
import { GitCommit, GitBranch, Plus, Wrench, Shield } from 'lucide-react';

const changelogData = [
    {
        version: '2.0 - "Phoenix"',
        date: '2024-07-26',
        changes: [
            { type: 'NEW', text: 'Complete UI overhaul to a modular Dashboard interface with an interactive AI Orb.' },
            { type: 'NEW', text: 'Integrated 10 new, fully functional panels (Threat Intel, Performance, Flight Tracker, etc.).' },
            { type: 'NEW', text: 'Deployed consolidated "Vision Hub" for all image and video analysis tasks.' },
            { type: 'NEW', text: 'Added "Module Creator" panel for AI-driven system design.' },
            { type: 'FIX', text: 'Upgraded AI core to Gemini 3 Pro for enhanced accuracy and capabilities.' },
            { type: 'FIX', text: 'Implemented fully functional Local Databanks with file scanning and categorization.' },
            { type: 'FIX', text: 'Resolved CSS theme color bug and system-wide stability issues.' },
        ]
    },
    {
        version: '1.5 - "Stabilize"',
        date: '2024-07-25',
        changes: [
            { type: 'NEW', text: 'Replaced Radar with functional Network Scanner (BT/WiFi).' },
            { type: 'FIX', text: 'Automated Radio Panel to auto-tune on load.' },
            { type: 'FIX', text: 'Removed experimental Vision features (Object Tracking, Gestures) to improve stability.' },
            { type: 'FIX', text: 'Purged non-functional AIM/Attack/Rage protocols.' },
        ]
    },
];

const ChangeIcon = ({ type }: { type: string }) => {
    switch (type) {
        case 'NEW': return <Plus size={14} className="text-green-500" />;
        case 'FIX': return <Wrench size={14} className="text-blue-500" />;
        case 'SECURITY': return <Shield size={14} className="text-red-500" />;
        default: return <GitBranch size={14} className="text-gray-500" />;
    }
};

const ChangelogPanel: React.FC = () => {
    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <GitCommit size={16}/> SYSTEM CHANGELOG
                </h2>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md overflow-y-auto p-4">
                <div className="max-w-3xl mx-auto">
                    {changelogData.map(entry => (
                        <div key={entry.version} className="mb-8 relative pl-8">
                             <div className="absolute left-0 top-1 w-4 h-4 bg-[var(--color-primary)] rounded-full border-4 border-black"></div>
                             <div className="absolute left-[7px] top-4 h-full w-px bg-gray-800"></div>

                            <p className="text-xs text-gray-500">{entry.date}</p>
                            <h3 className="text-lg font-bold text-[var(--color-primary)]">{entry.version}</h3>
                            <ul className="mt-2 space-y-2">
                                {entry.changes.map((change, i) => (
                                    <li key={i} className="flex items-start gap-3 text-sm">
                                        <ChangeIcon type={change.type} />
                                        <span className="text-gray-300">{change.text}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ChangelogPanel;
