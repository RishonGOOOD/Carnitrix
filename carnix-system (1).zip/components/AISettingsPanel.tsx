
import React, { useState, useEffect } from 'react';
import { AIModelSettings, RegisteredAIModel, AIEngine } from '../types';
import { BrainCircuit, Cpu, HardDrive, Zap, ShieldCheck, Loader2, Save, RefreshCw, Terminal as TerminalIcon, Server, Database, Key, FastForward } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const AISettingsPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    if (!activeProfile) return null;

    const { aiSettings } = activeProfile;
    const registeredModels = activeProfile.registeredModels || [];
    const [localSettings, setLocalSettings] = useState<AIModelSettings>(aiSettings);
    const [isSaving, setIsSaving] = useState(false);
    const [kernelStatus, setKernelStatus] = useState<'OFFLINE' | 'READY' | 'SYNCING'>('OFFLINE');

    useEffect(() => {
        setLocalSettings(aiSettings);
        checkKernelStatus();
    }, [aiSettings]);

    const checkKernelStatus = async () => {
        try {
            const res = await fetch(`${aiSettings.localEndpoint}/health`, { mode: 'no-cors' });
            setKernelStatus('READY');
        } catch (e) {
            setKernelStatus('OFFLINE');
        }
    };

    const handleSaveSettings = () => {
        setIsSaving(true);
        playSound('process');
        setTimeout(() => {
            dispatch({ type: 'UPDATE_PROFILE', payload: { aiSettings: localSettings }});
            setIsSaving(false);
            playSound('success');
            dispatch({ type: 'ADD_LOG', payload: { source: 'NEURAL', message: 'Engine configuration updated.', level: 'success' }});
        }, 800);
    };

    const inputClass = "w-full bg-black/50 border border-gray-800 rounded p-2 text-xs focus:border-red-600 outline-none font-mono text-white";
    const labelClass = "block text-[9px] text-gray-500 mb-1 font-black tracking-widest uppercase";

    return (
        <div className="w-full h-full flex flex-col gap-4 overflow-y-auto pr-2 scrollbar-thin font-[Rajdhani]">
            
            {/* ENGINE SELECTION MATRIX */}
            <section className="bg-black/30 border border-red-600/30 p-5 rounded-xl">
                <h3 className="text-xs font-black text-white flex items-center gap-2 mb-6 uppercase tracking-widest border-b border-white/10 pb-2">
                    <Cpu size={16} className="text-red-500" /> Neural Engine Matrix
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
                    {(['GEMINI_CLOUD', 'HUGGING_FACE', 'LOCAL_GGUF'] as AIEngine[]).map((eng) => (
                        <button
                            key={eng}
                            onClick={() => setLocalSettings({...localSettings, engine: eng})}
                            className={`p-4 border rounded-xl flex flex-col items-center gap-2 transition-all ${localSettings.engine === eng ? 'bg-red-600/20 border-red-500 text-white shadow-[0_0_20px_rgba(255,0,0,0.2)]' : 'bg-black/40 border-white/5 text-gray-600 hover:border-white/10'}`}
                        >
                            <span className="text-[10px] font-black uppercase tracking-widest">{eng.replace('_', ' ')}</span>
                            <span className="text-[7px] opacity-60 font-mono italic">
                                {eng === 'GEMINI_CLOUD' && 'High Precision / Search'}
                                {eng === 'HUGGING_FACE' && 'Sub-second / Open-Weights'}
                                {eng === 'LOCAL_GGUF' && 'Offline / Privacy First'}
                            </span>
                        </button>
                    ))}
                </div>

                {/* DYNAMIC ENGINE CONFIG */}
                <div className="space-y-4 animate-enter">
                    {localSettings.engine === 'HUGGING_FACE' && (
                        <div className="space-y-4 p-4 bg-black/40 border border-cyan-500/20 rounded-lg">
                            <div className="flex items-center gap-3 text-cyan-400 mb-2">
                                <FastForward size={18} />
                                <span className="text-[11px] font-black uppercase tracking-widest">Turbo-Inference Protocol</span>
                            </div>
                            <div>
                                <label className={labelClass}>HF Access Token</label>
                                <div className="relative">
                                    <Key size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
                                    <input 
                                        type="password"
                                        value={localSettings.hfToken || ""} 
                                        onChange={e => setLocalSettings({...localSettings, hfToken: e.target.value})}
                                        className={`${inputClass} pl-8`}
                                        placeholder="hf_xxxxxxxxxxxx"
                                    />
                                </div>
                            </div>
                            <div>
                                <label className={labelClass}>Ultra-Fast Model selection</label>
                                <select 
                                    value={localSettings.model} 
                                    onChange={e => setLocalSettings({...localSettings, model: e.target.value})}
                                    className={inputClass}
                                >
                                    <option value="meta-llama/Llama-3.2-3B-Instruct">Llama 3.2 3B (Fastest)</option>
                                    <option value="mistralai/Mistral-7B-v0.3">Mistral 7B (Standard)</option>
                                    <option value="Qwen/Qwen2.5-7B-Instruct">Qwen 2.5 7B (Code/Math)</option>
                                </select>
                            </div>
                        </div>
                    )}

                    {localSettings.engine === 'GEMINI_CLOUD' && (
                        <div className="space-y-4 p-4 bg-black/40 border border-blue-500/20 rounded-lg">
                            <div>
                                <label className={labelClass}>Cloud Matrix Model</label>
                                <select 
                                    value={localSettings.model} 
                                    onChange={e => setLocalSettings({...localSettings, model: e.target.value})}
                                    className={inputClass}
                                >
                                    <option value="gemini-3-pro-preview">Gemini 3 Pro (Heavy Reasoning)</option>
                                    <option value="gemini-3-flash-preview">Gemini 3 Flash (Fast Cloud)</option>
                                </select>
                            </div>
                            <div className="flex gap-2">
                                <button 
                                    onClick={() => setLocalSettings({...localSettings, useSearchGrounding: !localSettings.useSearchGrounding})}
                                    className={`flex-1 p-2 rounded text-[8px] font-black uppercase border transition-all ${localSettings.useSearchGrounding ? 'bg-blue-600/20 border-blue-500 text-blue-400' : 'bg-black/40 border-white/10 text-gray-600'}`}
                                >
                                    Search Grounding: {localSettings.useSearchGrounding ? 'Active' : 'Muted'}
                                </button>
                                <button 
                                    onClick={() => setLocalSettings({...localSettings, useThinking: !localSettings.useThinking})}
                                    className={`flex-1 p-2 rounded text-[8px] font-black uppercase border transition-all ${localSettings.useThinking ? 'bg-purple-600/20 border-purple-500 text-purple-400' : 'bg-black/40 border-white/10 text-gray-600'}`}
                                >
                                    Deep Thinking: {localSettings.useThinking ? 'Active' : 'Muted'}
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </section>

            {/* IDENTITY & VOCALS */}
            <section className="bg-black/30 border border-white/5 p-5 rounded-xl">
                 <h3 className="text-xs font-black text-cyan-400 flex items-center gap-2 mb-4 border-b border-white/10 pb-2 uppercase tracking-widest">
                    <BrainCircuit size={16} /> Identity Mapping
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className={labelClass}>Vocal Speed: {localSettings.speechSpeed}x</label>
                        <input type="range" min="0.5" max="2.0" step="0.1" value={localSettings.speechSpeed} onChange={e => setLocalSettings({...localSettings, speechSpeed: parseFloat(e.target.value)})} className="w-full accent-cyan-500" />
                    </div>
                    <div>
                        <label className={labelClass}>Response Temperature</label>
                        <input type="range" min="0" max="1" step="0.1" value={localSettings.temperature} onChange={e => setLocalSettings({...localSettings, temperature: parseFloat(e.target.value)})} className="w-full accent-red-600" />
                    </div>
                </div>
            </section>

            <div className="flex gap-4 pt-4 mb-20">
                <button onClick={handleSaveSettings} disabled={isSaving} className="flex-1 hud-button !py-4 flex items-center justify-center gap-2 !bg-red-600 !text-black !border-none font-black uppercase tracking-[0.2em]">
                    {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                    Sync Engine Parameters
                </button>
            </div>
        </div>
    );
};

export default AISettingsPanel;
