import React, { useState, useEffect, memo } from 'react';
import { Clock, Battery, MapPin, Zap, Smartphone } from 'lucide-react';
import { useAppContext } from '../context';

const SystemStatusBar: React.FC = () => {
    const { state } = useAppContext();
    const [time, setTime] = useState(new Date());
    const [battery, setBattery] = useState<number | null>(null);

    useEffect(() => {
        // Reduced frequency for clock to 5 seconds - saves CPU cycles
        const t = setInterval(() => setTime(new Date()), 5000);
        
        if ('getBattery' in navigator) {
            (navigator as any).getBattery().then((bat: any) => {
                setBattery(Math.round(bat.level * 100));
                bat.addEventListener('levelchange', () => setBattery(Math.round(bat.level * 100)));
            });
        }
        
        return () => clearInterval(t);
    }, []);

    const S = ({ children, color }: any) => (
        <div className="flex items-center gap-2 px-4 h-full border-l border-white/10" style={{ color }}>
            {children}
        </div>
    );

    const geo = state.geolocation;
    const locString = geo ? `${geo.latitude.toFixed(2)}, ${geo.longitude.toFixed(2)}` : 'SCAN...';

    return (
        <div className="w-full bg-[#050002]/95 border-t border-white/10 flex items-center justify-between text-[11px] font-mono text-gray-500 select-none z-40 backdrop-blur-md h-[36px] shrink-0 px-2 will-change-contents">
            <div className="flex items-center h-full">
                <div className="flex items-center gap-2 px-4 text-red-600 font-black tracking-widest h-full">
                    <Zap size={14} className="animate-pulse" /> CARNIX_OS
                </div>
                <S color="#00F0FF">
                    <MapPin size={12}/> {locString}
                </S>
            </div>

            <div className="hidden sm:flex items-center h-full">
                <S color="#ffffff"><Clock size={12}/> {time.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' })}</S>
                <S color={battery && battery < 20 ? "#ef4444" : "#eab308"}>
                    <Battery size={14}/> {battery ? `${battery}%` : '---'}
                </S>
                <S color={state.isOnline ? "#22c55e" : "#ef4444"}>
                    <Smartphone size={12}/> {state.isOnline ? 'STABLE' : 'OFFLINE'}
                </S>
            </div>
        </div>
    );
};

export default memo(SystemStatusBar);