import React, { useState, useEffect, useRef } from 'react';
import { 
  NetworkAnalysisEngine, NetworkPacketRecord, NetworkAuditSummary 
} from '../services/networkAnalysisEngine';
import { 
  Network, ArrowDown, ArrowUp, Globe, Shield, Upload, 
  AlertTriangle, Filter, Download, Activity, FileSpreadsheet,
  CheckCircle2, RefreshCw, Radio
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const NetworkAnalyzerPanel: React.FC = () => {
  const [packets, setPackets] = useState<NetworkPacketRecord[]>([]);
  const [summary, setSummary] = useState<NetworkAuditSummary | null>(null);
  const [filterProto, setFilterProto] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [activeTab, setActiveTab] = useState<'PACKETS' | 'TALKERS' | 'IOCS' | 'SUSPICIOUS' | 'ZEEK'>('PACKETS');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Initial analysis on baseline packet telemetry
    const defaultAudit = NetworkAnalysisEngine.analyzeTraffic();
    setSummary(defaultAudit);
    // Grab mock packets
    NetworkAnalysisEngine.parseCaptureFile(new File([''], 'initial.pcap')).then(pkts => {
      setPackets(pkts);
    });
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    playSound('scan');
    triggerHaptic('medium');

    try {
      const parsed = await NetworkAnalysisEngine.parseCaptureFile(file);
      const audit = NetworkAnalysisEngine.analyzeTraffic(parsed);
      setPackets(parsed);
      setSummary(audit);
      playSound('success');
    } catch (err) {
      playSound('alert');
    } finally {
      setIsUploading(false);
    }
  };

  const handleExportZeek = () => {
    playSound('click');
    const zeekJson = NetworkAnalysisEngine.exportToZeekJson(packets);
    const blob = new Blob([zeekJson], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `carnix_zeek_conn_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredPackets = packets.filter(p => {
    const matchProto = filterProto === 'ALL' || p.protocol === filterProto;
    const matchSearch = !searchQuery || 
      p.srcIp.includes(searchQuery) || 
      p.dstIp.includes(searchQuery) || 
      p.info.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.dnsQuery && p.dnsQuery.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchProto && matchSearch;
  });

  return (
    <div className="w-full h-full flex flex-col gap-3 font-[Rajdhani] bg-[#050002]/95 text-white overflow-hidden p-2 sm:p-4">
      {/* Top Banner & File Upload Control */}
      <div className="flex flex-wrap items-center justify-between p-3.5 bg-black/80 border border-red-900/30 rounded-xl gap-2 shadow-inner">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-blue-950/80 border border-blue-600/40 rounded-lg">
            <Network size={18} className="text-blue-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black font-orbitron text-white">DEFENSIVE NETWORK ANALYZER</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-950 text-blue-300 border border-blue-800">
                PCAP & ZEEK/SURICATA INSPECTOR
              </span>
            </div>
            <div className="text-[11px] font-mono text-gray-400">
              Host → Connection → Protocol → Domain → IP → Security Event Correlation
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".pcap,.cap,.pcapng,.log,.json,.csv,.txt"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-black font-black font-mono text-xs uppercase rounded-lg transition-all flex items-center gap-1.5"
          >
            <Upload size={13} /> {isUploading ? 'PARSING...' : 'UPLOAD CAPTURE / LOG'}
          </button>
          <button
            onClick={handleExportZeek}
            className="px-3 py-1.5 bg-black/60 hover:bg-blue-950/40 border border-blue-500/40 text-blue-300 hover:text-white font-mono text-xs uppercase rounded-lg transition-all flex items-center gap-1.5"
          >
            <Download size={13} /> EXPORT ZEEK JSON
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
          <div className="p-2.5 bg-black/70 border border-white/5 rounded-lg flex items-center justify-between">
            <span className="text-gray-400">TOTAL PACKETS:</span>
            <span className="font-bold text-cyan-400 text-sm">{summary.totalPackets}</span>
          </div>
          <div className="p-2.5 bg-black/70 border border-white/5 rounded-lg flex items-center justify-between">
            <span className="text-gray-400">TRAFFIC VOLUME:</span>
            <span className="font-bold text-white text-sm">{(summary.totalBytes / 1024).toFixed(1)} KB</span>
          </div>
          <div className="p-2.5 bg-black/70 border border-white/5 rounded-lg flex items-center justify-between">
            <span className="text-gray-400">DISCOVERED IOCS:</span>
            <span className="font-bold text-yellow-400 text-sm">{summary.detectedIocs.length}</span>
          </div>
          <div className="p-2.5 bg-black/70 border border-white/5 rounded-lg flex items-center justify-between">
            <span className="text-gray-400">SUSPICIOUS VECTORS:</span>
            <span className="font-bold text-red-500 text-sm">{summary.suspiciousEvents.length}</span>
          </div>
        </div>
      )}

      {/* Navigation Sub-Tabs & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setActiveTab('PACKETS')}
            className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
              activeTab === 'PACKETS' ? 'bg-blue-600 text-black font-black' : 'bg-black/40 text-gray-400 hover:text-white'
            }`}
          >
            PACKET STREAM ({filteredPackets.length})
          </button>
          <button
            onClick={() => setActiveTab('TALKERS')}
            className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
              activeTab === 'TALKERS' ? 'bg-blue-600 text-black font-black' : 'bg-black/40 text-gray-400 hover:text-white'
            }`}
          >
            TOP TALKERS ({summary?.topTalkers.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('IOCS')}
            className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
              activeTab === 'IOCS' ? 'bg-blue-600 text-black font-black' : 'bg-black/40 text-gray-400 hover:text-white'
            }`}
          >
            NETWORK IOCS ({summary?.detectedIocs.length || 0})
          </button>
          <button
            onClick={() => setActiveTab('SUSPICIOUS')}
            className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all ${
              activeTab === 'SUSPICIOUS' ? 'bg-red-600 text-black font-black' : 'bg-black/40 text-gray-400 hover:text-white'
            }`}
          >
            SUSPICIOUS VECTORS ({summary?.suspiciousEvents.length || 0})
          </button>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center gap-2 font-mono text-xs">
          <input
            type="text"
            placeholder="Search IP, host, or query..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="px-2.5 py-1 bg-black/80 border border-white/10 rounded text-xs text-white placeholder-gray-500 focus:outline-none focus:border-blue-500"
          />
          <select
            value={filterProto}
            onChange={e => setFilterProto(e.target.value)}
            className="px-2 py-1 bg-black/80 border border-white/10 rounded text-xs text-gray-300 focus:outline-none"
          >
            <option value="ALL">ALL PROTOCOLS</option>
            <option value="DNS">DNS</option>
            <option value="TLS">TLS</option>
            <option value="HTTP">HTTP</option>
            <option value="TCP">TCP</option>
            <option value="UDP">UDP</option>
          </select>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto scrollbar-carnix bg-black/80 border border-white/5 rounded-xl p-3">
        {activeTab === 'PACKETS' && (
          <div className="space-y-1.5 font-mono text-xs">
            <div className="grid grid-cols-12 gap-2 text-gray-500 font-bold px-2 py-1 border-b border-white/5 text-[11px]">
              <span className="col-span-2">TIMESTAMP</span>
              <span className="col-span-1">PROTO</span>
              <span className="col-span-3">SOURCE IP:PORT</span>
              <span className="col-span-3">DESTINATION IP:PORT</span>
              <span className="col-span-3">PROTOCOL PAYLOAD / INFO</span>
            </div>
            {filteredPackets.map(p => (
              <div 
                key={p.id} 
                className={`grid grid-cols-12 gap-2 p-2 rounded items-center transition-all ${
                  p.suspiciousTag 
                    ? 'bg-red-950/30 border border-red-900/40 text-red-300' 
                    : 'bg-black/50 hover:bg-white/5 text-gray-300'
                }`}
              >
                <span className="col-span-2 text-[10px] text-gray-400 truncate">{p.timestamp.slice(11, 23)}</span>
                <span className={`col-span-1 text-[10px] font-bold px-1.5 py-0.5 rounded text-center ${
                  p.protocol === 'DNS' ? 'bg-cyan-950 text-cyan-400' :
                  p.protocol === 'TLS' ? 'bg-purple-950 text-purple-400' :
                  p.protocol === 'HTTP' ? 'bg-emerald-950 text-emerald-400' : 'bg-gray-800 text-gray-300'
                }`}>
                  {p.protocol}
                </span>
                <span className="col-span-3 truncate text-white">{p.srcIp}:{p.srcPort}</span>
                <span className="col-span-3 truncate text-white">{p.dstIp}:{p.dstPort}</span>
                <div className="col-span-3 truncate flex items-center justify-between">
                  <span className="truncate">{p.info}</span>
                  {p.suspiciousTag && (
                    <span className="px-1.5 py-0.5 rounded bg-red-900 text-red-100 text-[9px] font-bold shrink-0 ml-1">
                      {p.suspiciousTag}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'TALKERS' && (
          <div className="space-y-2 font-mono text-xs">
            <div className="text-gray-400 font-bold pb-1 border-b border-white/5">
              BANDWIDTH CONCENTRATION & HIGH-FREQUENCY TALKERS
            </div>
            {summary?.topTalkers.map((t, idx) => (
              <div key={idx} className="p-3 bg-black/60 rounded-lg border border-white/5 flex items-center justify-between">
                <div>
                  <div className="font-bold text-cyan-400 text-sm">{t.ip}</div>
                  <div className="text-[11px] text-gray-500">Transmitted Packets: {t.packets}</div>
                </div>
                <div className="text-right">
                  <div className="text-white font-bold">{(t.bytes / 1024).toFixed(2)} KB</div>
                  <div className="text-[10px] text-emerald-400">ACTIVE COMMUNICATOR</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'IOCS' && (
          <div className="space-y-2 font-mono text-xs">
            <div className="text-gray-400 font-bold pb-1 border-b border-white/5">
              EXTRACTED NETWORK INDICATORS OF COMPROMISE
            </div>
            {summary?.detectedIocs.map((ioc, idx) => (
              <div key={idx} className="p-3 bg-black/60 rounded-lg border border-amber-900/30 flex items-center justify-between">
                <div>
                  <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-400 font-bold text-[10px] mr-2">
                    {ioc.type}
                  </span>
                  <span className="text-white font-bold select-all">{ioc.value}</span>
                  <div className="text-[11px] text-gray-500 mt-1">{ioc.context}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'SUSPICIOUS' && (
          <div className="space-y-2.5 font-mono text-xs">
            <div className="text-gray-400 font-bold pb-1 border-b border-white/5">
              HEURISTIC ANOMALY & THREAT VECTOR DETECTIONS
            </div>
            {summary?.suspiciousEvents.map((evt, idx) => (
              <div key={idx} className="p-3 bg-red-950/20 rounded-lg border border-red-900/50 space-y-1.5">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-red-400 font-orbitron">{evt.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-900 text-red-200">
                    {evt.severity}
                  </span>
                </div>
                <p className="text-gray-300 text-[11px] leading-relaxed">{evt.details}</p>
                <div className="text-[10px] text-gray-500">
                  Vector: {evt.sourceIp} → {evt.targetIp} | Time: {new Date(evt.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NetworkAnalyzerPanel;
