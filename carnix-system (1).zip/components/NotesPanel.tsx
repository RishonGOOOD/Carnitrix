
import React, { useState, useMemo, useEffect } from 'react';
import { Note } from '../types';
import { Save, Trash2, Plus, Search, FileText, Tag, Database, Filter, X, Calendar, Edit, Eye } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { useAppContext } from '../context';

const NotesPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const notes = state.activeProfile!.notes;

    const onSaveNote = (note: Note) => {
        const newNotes = [...notes.filter(n => n.id !== note.id), note];
        dispatch({ type: 'UPDATE_PROFILE', payload: { notes: newNotes } });
    };

    const onDeleteNote = (id: string) => {
        const newNotes = notes.filter(n => n.id !== id);
        dispatch({ type: 'UPDATE_PROFILE', payload: { notes: newNotes } });
        if (selectedNoteId === id) {
            setSelectedNoteId(null);
            setIsEditing(false);
        }
    };
    
    const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
    const [isEditing, setIsEditing] = useState(false);
    const [editTitle, setEditTitle] = useState('');
    const [editContent, setEditContent] = useState('');
    const [editTags, setEditTags] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    
    const allTags = useMemo(() => {
        const tags = new Set<string>();
        notes.forEach(n => n.tags.forEach(t => tags.add(t.trim())));
        return Array.from(tags).sort();
    }, [notes]);
    
    const filteredNotes = useMemo(() => {
        return notes
            .filter(note => note.title.toLowerCase().includes(searchTerm.toLowerCase()) || note.content.toLowerCase().includes(searchTerm.toLowerCase()))
            .sort((a, b) => b.timestamp - a.timestamp);
    }, [notes, searchTerm]);

    const selectedNote = useMemo(() => {
        return notes.find(n => n.id === selectedNoteId);
    }, [notes, selectedNoteId]);

    useEffect(() => {
        if (selectedNote) {
            setEditTitle(selectedNote.title);
            setEditContent(selectedNote.content);
            setEditTags(selectedNote.tags.join(', '));
        } else {
            setIsEditing(false);
        }
    }, [selectedNote]);

    const handleSelectNote = (note: Note) => {
        setSelectedNoteId(note.id);
        setIsEditing(false);
        playSound('click');
    };

    const handleNewNote = () => {
        const newNote: Note = {
            id: `note-${Date.now()}`,
            title: 'New Note',
            content: '',
            tags: [],
            timestamp: Date.now(),
        };
        onSaveNote(newNote);
        setSelectedNoteId(newNote.id);
        setIsEditing(true);
        playSound('success');
    };

    const handleSave = () => {
        if (!selectedNoteId) return;
        const note: Note = {
            ...selectedNote!,
            id: selectedNoteId,
            title: editTitle || 'Untitled',
            content: editContent,
            tags: editTags.split(',').map(t => t.trim()).filter(t => t),
            timestamp: Date.now(),
        };
        onSaveNote(note);
        setIsEditing(false);
        playSound('access');
    };
    
    const handleDelete = () => {
        if (selectedNoteId && confirm(`Are you sure you want to delete "${selectedNote?.title}"?`)) {
            onDeleteNote(selectedNoteId);
            playSound('error');
        }
    }

    return (
        <div className="w-full h-full flex flex-col md:flex-row gap-4 p-1">
            {/* Note List */}
            <div className="w-full md:w-1/3 flex flex-col bg-black/30 border border-[var(--color-panel-border)] rounded-md overflow-hidden">
                <div className="p-2 border-b border-[var(--color-panel-border)] flex items-center justify-between">
                     <div className="flex items-center gap-2">
                        <Database size={14} className="text-[var(--color-primary)]"/>
                        <span className="text-xs font-bold">INTEL DATABASE</span>
                     </div>
                     <button onClick={handleNewNote} className="p-1 bg-[var(--color-primary)]/20 text-[var(--color-primary)] rounded hover:bg-[var(--color-primary)] hover:text-black"><Plus size={14} /></button>
                </div>
                <div className="p-2 border-b border-[var(--color-panel-border)]">
                    <div className="relative">
                        <Search size={14} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
                        <input 
                            type="text" 
                            placeholder="Search..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full bg-black/50 border border-gray-700 rounded-md pl-7 pr-2 py-1 text-xs focus:outline-none focus:border-[var(--color-primary)]"
                        />
                    </div>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {filteredNotes.map(note => (
                         <div 
                            key={note.id} 
                            onClick={() => handleSelectNote(note)}
                            className={`p-3 border-b border-gray-800 cursor-pointer hover:bg-white/5 ${selectedNoteId === note.id ? 'bg-[var(--color-primary)]/10' : ''}`}
                        >
                             <h4 className={`font-bold text-sm truncate ${selectedNoteId === note.id ? 'text-[var(--color-primary)]' : 'text-white'}`}>{note.title}</h4>
                             <p className="text-xs text-gray-400 truncate mt-1">{note.content || 'No content'}</p>
                             <div className="flex items-center justify-between mt-2 text-[10px] text-gray-500">
                                 <span>{new Date(note.timestamp).toLocaleDateString()}</span>
                                 <div className="flex gap-1">
                                    {note.tags.slice(0, 2).map(tag => <span key={tag} className="bg-gray-700 px-1 rounded">{tag}</span>)}
                                 </div>
                             </div>
                         </div>
                    ))}
                </div>
            </div>

            {/* Note Editor/Viewer */}
            <div className="flex-1 flex flex-col bg-black/30 border border-[var(--color-panel-border)] rounded-md overflow-hidden">
                {selectedNote ? (
                    <>
                        <div className="p-2 border-b border-[var(--color-panel-border)] flex justify-between items-center">
                            <div className="flex items-center gap-2">
                                {isEditing ? <Edit size={14} className="text-[var(--color-primary)]"/> : <Eye size={14} className="text-[var(--color-primary)]"/>}
                                <span className="text-xs font-bold">{isEditing ? 'EDIT MODE' : 'VIEW MODE'}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                {isEditing ? (
                                    <button onClick={handleSave} className="px-2 py-1 bg-green-800 text-white rounded text-xs flex items-center gap-1"><Save size={12}/> SAVE</button>
                                ) : (
                                    <button onClick={() => setIsEditing(true)} className="px-2 py-1 bg-[var(--color-button-background)] rounded text-xs flex items-center gap-1"><Edit size={12}/> EDIT</button>
                                )}
                                <button onClick={handleDelete} className="p-2 bg-red-900/50 text-red-400 rounded hover:bg-red-800"><Trash2 size={12}/></button>
                            </div>
                        </div>
                        {isEditing ? (
                            <div className="flex-1 flex flex-col p-3 gap-3 overflow-y-auto">
                                <div>
                                    <label className="text-xs text-gray-400">Title</label>
                                    <input type="text" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} className="w-full bg-black/50 border border-gray-700 rounded p-2 mt-1 text-sm"/>
                                </div>
                                <div>
                                    <label className="text-xs text-gray-400">Content</label>
                                    <textarea value={editContent} onChange={(e) => setEditContent(e.target.value)} className="w-full h-64 bg-black/50 border border-gray-700 rounded p-2 mt-1 text-sm resize-y"/>
                                </div>
                                <div>
                                    <label className="text-xs text-gray-400">Tags (comma-separated)</label>
                                    <input type="text" value={editTags} onChange={(e) => setEditTags(e.target.value)} className="w-full bg-black/50 border border-gray-700 rounded p-2 mt-1 text-sm"/>
                                </div>
                            </div>
                        ) : (
                            <div className="flex-1 p-4 overflow-y-auto">
                                <h2 className="text-xl font-bold mb-2 text-white">{selectedNote.title}</h2>
                                <div className="text-xs text-gray-500 mb-4 flex items-center gap-4">
                                     <span className="flex items-center gap-1"><Calendar size={12}/> {new Date(selectedNote.timestamp).toLocaleString()}</span>
                                     <div className="flex items-center gap-1"><Tag size={12}/> {selectedNote.tags.join(', ') || 'No tags'}</div>
                                </div>
                                <div className="prose prose-sm prose-invert max-w-none whitespace-pre-wrap text-gray-300">
                                    {selectedNote.content}
                                </div>
                            </div>
                        )}
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center text-center text-gray-500">
                        <div>
                            <FileText size={40} className="mx-auto mb-2 opacity-20"/>
                            <p>Select a note to view or create a new one.</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default NotesPanel;