
import React, { useEffect, useRef, useMemo } from 'react';
import { Dna } from 'lucide-react';

const GeneticSequencerPanel: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const bases = useMemo(() => ['A', 'T', 'C', 'G'], []);
    const colors = useMemo(() => ({
        A: '#22c55e', // green
        T: '#ef4444', // red
        C: '#3b82f6', // blue
        G: '#eab308', // yellow
    }), []);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        const fontSize = 14;
        const columns = Math.floor(canvas.offsetWidth / fontSize);
        const drops = Array(columns).fill(1).map(() => Math.random() * canvas.height);

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        const draw = () => {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.font = `${fontSize}px monospace`;

            for (let i = 0; i < drops.length; i++) {
                const text = bases[Math.floor(Math.random() * bases.length)];
                ctx.fillStyle = colors[text as keyof typeof colors];
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);

                if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                }
                drops[i]++;
            }
            animationFrameId = requestAnimationFrame(draw);
        };
        draw();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, [bases, colors]);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Dna size={16}/> GENETIC SEQUENCER
                </h2>
                <div className="text-xs font-mono text-green-400 flex items-center gap-2">
                    STATUS: <span className="animate-pulse">ANALYZING SAMPLE</span>
                </div>
            </div>
            <div className="flex-1 bg-black border border-[var(--color-panel-border)] rounded-md relative overflow-hidden">
                <canvas ref={canvasRef} className="w-full h-full" />
                 <div className="absolute top-4 left-4 font-mono text-xs text-white bg-black/50 p-2 rounded border border-white/10 backdrop-blur-sm">
                    <p>SAMPLE ID: XJ-734-B</p>
                    <p>PROGRESS: 67%</p>
                    <p>MATCH PROBABILITY: 89.4%</p>
                </div>
            </div>
        </div>
    );
};

export default GeneticSequencerPanel;
