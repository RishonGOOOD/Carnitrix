
import React, { useState, useEffect } from 'react';
import { Brain, Zap, Loader2, Network, ShieldAlert, Sparkles, Send, Activity, Triangle } from 'lucide-react';
import { useAppContext } from '../context';
import { callGPTSimulation } from '../services/gptSimulationService';
import { playSound } from '../utils/soundEffects';

const SubstrateCPanel: React.FC = () => {
    const { state } = useAppContext();
    const [input, setInput] = useState('');
    const [output, setOutput] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [divergence, setDivergence] = useState(12.5);

    // Randomize divergence for visual flair
    useEffect(() => {
        const interval = setInterval(() => {
            setDivergence(prev => Math.max(5, Math.min(95, prev + (Math.random() - 0.5) * 5)));
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const handleProbe = async () => {
        if (!input.trim() || !state.activeProfile) return;
        setLoading(true);
        setOutput(null);
        playSound('process');
        
        try {
            const res = await callGPTSimulation(input, state.activeProfile.aiSettings);
            setOutput(res);
            playSound('success');
        } catch (e) {
            setOutput("Substrate C failed to cross-validate. Kernel error.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani] animate-in fade-in zoom-in-95 duration-500 bg-black/20">
            {/* Header Readout */}
            <div className="flex-shrink-0 bg-black/60 border border-purple-500/30 p-5 rounded-2xl flex justify-between items-center shadow-[0_0_40px_rgba(168,85,247,0.1)]">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-purple-600/10 rounded border border-purple-600/50 shadow-[0_0_20px_rgba(168,85,247,0.3)]">
                        <Triangle size={28} className="text-purple-400 animate-pulse fill-purple-400/20" />
                    </div>
                    <div>
                        <h2 className="text-lg font-black text-white uppercase tracking-widest leading-none italic">Substrate C // GPT Neural Simulation</h2>
                        <div className="text-[9px] font-mono text-purple-800 uppercase tracking-widest mt-1">
                            Tri-Engine Status: Synchronized // v7.1.C
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-6">
                    <div className="text-right">
                        <div className="text-[8px] text-purple-600 font-bold uppercase">Neural Divergence</div>
                        <div className="text-sm font-black text-cyan-400 font-mono tracking-tighter">{divergence.toFixed(2)}%</div>
                    </div>
                    <div className="flex items-center gap-2 text-cyan-400 font-black text-[9px] uppercase tracking-widest bg-cyan-500/5 border border-cyan-500/20 px-3 py-1 rounded-full">
                        <Sparkles size={10} className="animate-spin-slow" /> Meta-Logic: ON
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row gap-4 overflow-hidden">
                {/* Input Control */}
                <div className="w-full lg:w-1/3 flex flex-col gap-4">
                    <div className="bg-black/40 border border-white/5 rounded-2xl p-5 flex flex-col flex-1 shadow-inner relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-2 opacity-5 pointer-events-none">
                            <Activity size={100} className="text-purple-500" />
                        </div>
                        <div className="text-[10px] font-black text-purple-400 uppercase tracking-widest mb-4 border-b border-purple-500/10 pb-1 flex items-center gap-2">
                             <Zap size={12} className="text-cyan-500" /> Manual Probe Interface
                        </div>
                        <textarea 
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            placeholder="Input command for cross-validation..."
                            className="flex-1 bg-black/40 border border-purple-900/30 p-4 text-sm text-purple-100 outline-none focus:border-cyan-500 font-mono resize-none rounded-xl transition-all"
                            disabled={loading}
                        />
                        <button 
                            onClick={handleProbe}
                            disabled={loading || !input.trim()}
                            className="w-full mt-4 py-4 bg-purple-600 text-black font-black uppercase text-xs tracking-widest hover:bg-cyan-400 transition-all shadow-[0_0_30px_rgba(168,85,247,0.5)] flex items-center justify-center gap-2 rounded-xl active:scale-95"
                        >
                            {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                            {loading ? 'CROSS-VALIDATING...' : 'EXECUTE SIMULATION'}
                        </button>
                    </div>
                </div>

                {/* Output Buffer */}
                <div className="flex-1 bg-black/60 border border-white/10 rounded-3xl overflow-hidden flex flex-col shadow-2xl relative">
                    {/* Visual Grid Decor */}
                    <div className="absolute inset-0 pointer-events-none opacity-5 bg-[linear-gradient(rgba(168,85,247,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.05)_1px,transparent_1px)]" style={{backgroundSize: '20px 20px'}}></div>
                    
                    <div className="p-4 border-b border-white/5 bg-purple-600/5 text-[10px] font-black text-cyan-400 uppercase tracking-widest flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <Brain size={14} className="text-purple-400" /> Meta-Reasoning Buffer
                        </div>
                        <span className="text-[8px] font-mono text-gray-600">SUBSTRATE_C_READY</span>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-6 scrollbar-carnix">
                        {loading && (
                            <div className="h-full flex flex-col items-center justify-center gap-4 text-cyan-400 animate-pulse">
                                <Loader2 size={48} className="animate-spin text-purple-500" />
                                <span className="text-xs font-black uppercase tracking-[0.5em]">Synthesizing Divergent Logic...</span>
                            </div>
                        )}
                        {output && !loading && (
                            <div className="animate-enter">
                                <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-gray-300 bg-purple-950/10 p-6 border-l-2 border-cyan-500 rounded-r-xl shadow-inner">
                                    {output}
                                </div>
                                <div className="mt-4 flex gap-2">
                                    <div className="px-2 py-1 bg-cyan-900/20 border border-cyan-500/30 rounded text-[8px] font-black text-cyan-400 uppercase">Architecture: GPT_SIM_v1</div>
                                    <div className="px-2 py-1 bg-purple-900/20 border border-purple-500/30 rounded text-[8px] font-black text-purple-400 uppercase">Engine: Gemini_3_Flash</div>
                                </div>
                            </div>
                        )}
                        {!output && !loading && (
                            <div className="h-full flex flex-col items-center justify-center opacity-10 text-center gap-4">
                                <Network size={64} className="text-purple-500" />
                                <p className="text-xs font-black uppercase tracking-[0.5em]">Awaiting Neural Feed</p>
                            </div>
                        )}
                    </div>
                    
                    {/* Divergence Footer */}
                    <div className="p-4 bg-purple-900/10 border-t border-white/5 flex items-start gap-4">
                        <ShieldAlert size={20} className="text-purple-600 shrink-0 mt-0.5" />
                        <p className="text-[9px] text-gray-500 font-mono leading-relaxed uppercase">
                            SUBSTRATE_C NOTICE: CROSS-VALIDATION DETECTS {divergence.toFixed(1)}% REASONING OFFSET BETWEEN ARCHITECT AND OVERSEER. 
                            SUBSTRATE C HAS INJECTED CORRECTIVE META-LOGIC INTO THE NEXT FEEDBACK ROUND.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SubstrateCPanel;
