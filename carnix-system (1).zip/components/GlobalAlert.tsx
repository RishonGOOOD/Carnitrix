
import React, { useEffect, useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';

interface GlobalAlertProps {
    message: string | null;
    onDismiss: () => void;
}

const GlobalAlert: React.FC<GlobalAlertProps> = ({ message, onDismiss }) => {
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        if (message) {
            setVisible(true);
            const timer = setTimeout(() => {
                setVisible(false);
            }, 7000); // Show for 7 seconds

            const dismissTimer = setTimeout(() => {
                onDismiss();
            }, 7500); // Dismiss after fade out

            return () => {
                clearTimeout(timer);
                clearTimeout(dismissTimer);
            };
        }
    }, [message, onDismiss]);

    const handleManualDismiss = () => {
        setVisible(false);
        setTimeout(onDismiss, 500);
    };

    if (!message) return null;

    return (
        <div 
            className={`fixed top-5 right-5 z-50 flex items-center gap-3 max-w-sm p-4 bg-yellow-900/80 backdrop-blur-md border border-yellow-500 rounded-lg text-yellow-200 shadow-lg transition-all duration-500 ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}
        >
            <AlertTriangle size={24} className="flex-shrink-0" />
            <div className="flex-1">
                <p className="text-sm font-bold">SYSTEM ALERT</p>
                <p className="text-xs">{message}</p>
            </div>
            <button onClick={handleManualDismiss} className="p-1 rounded-full hover:bg-white/10">
                <X size={16} />
            </button>
        </div>
    );
};

export default GlobalAlert;
