
import React, { useState, useRef, useEffect } from 'react';
import { Disc, Music, Play, Pause, SkipForward, SkipBack, FolderOpen, Video } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const MediaPanel: React.FC = () => {
    const [files, setFiles] = useState<File[]>([]);
    const [curr, setCurr] = useState(-1);
    const [playing, setPlaying] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
        const list = Array.from(e.target.files || []) as File[];
        setFiles(prev => [...prev, ...list]);
        playSound('success');
    };

    const play = (idx: number) => {
        if (!files[idx]) return;
        setCurr(idx);
        setPlaying(true);
        if (audioRef.current) {
            audioRef.current.src = URL.createObjectURL(files[idx]);
            audioRef.current.play();
        }
        playSound('click');
    };

    const togglePlay = () => {
        if (!files[curr]) return;
        if (playing) {
            audioRef.current?.pause();
            setPlaying(false);
        } else {
            audioRef.current?.play();
            setPlaying(true);
        }
        playSound('switch');
    }

    // Visualizer Logic
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let frame: number;
        const bars = 24;
        
        const draw = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const w = canvas.width / bars;
            for (let i = 0; i < bars; i++) {
                // If not playing, simulate idle noise
                const h = playing 
                    ? Math.random() * canvas.height 
                    : Math.random() * (canvas.height * 0.2); 
                
                ctx.fillStyle = `rgba(0, 240, 255, ${0.3 + (h / canvas.height) * 0.7})`;
                ctx.fillRect(i * w + 1, canvas.height - h, w - 2, h);
            }
            frame = requestAnimationFrame(draw);
        };
        draw();
        return () => cancelAnimationFrame(frame);
    }, [playing]);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="bg-black/40 border border-white/10 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Disc size={20} className={`text-cyan-400 ${playing ? 'animate-spin-slow' : ''}`} />
                    <h2 className="text-sm font-black text-white uppercase italic">Media Relay Node</h2>
                </div>
                <button onClick={() => document.getElementById('media-up')?.click()} className="text-[10px] font-black text-gray-400 border border-gray-800 px-3 py-1 rounded hover:bg-white hover:text-black transition-all">
                    <FolderOpen size={12} className="inline mr-1"/> MOUNT
                </button>
                <input id="media-up" type="file" className="hidden" multiple accept="audio/*,video/*" onChange={onFile} />
            </div>

            <div className="flex-1 flex flex-col lg:flex-row gap-2 overflow-hidden">
                <div className="flex-1 bg-black/60 border border-white/5 rounded-lg flex flex-col items-center justify-center p-8 relative overflow-hidden">
                    <canvas ref={canvasRef} className="absolute inset-0 w-full h-full opacity-30 pointer-events-none" />
                    <div className="z-10 text-center space-y-4">
                        <div className={`w-32 h-32 border-2 border-red-600 rounded-full flex items-center justify-center bg-red-600/5 shadow-[0_0_40px_rgba(255,0,60,0.1)] transition-all ${playing ? 'scale-105 shadow-[0_0_60px_rgba(255,0,60,0.3)]' : ''}`}>
                            <Music size={48} className={playing ? 'animate-pulse text-white' : 'opacity-20 text-gray-500'} />
                        </div>
                        <h3 className="text-xl font-black text-white uppercase truncate max-w-xs">{curr >= 0 ? files[curr].name : 'AWAITING_SIGNAL'}</h3>
                        <div className="flex gap-8 justify-center">
                            <button className="text-gray-500 hover:text-white" disabled={files.length === 0}><SkipBack size={24}/></button>
                            <button 
                                onClick={togglePlay}
                                disabled={files.length === 0 && curr === -1} 
                                className={`w-12 h-12 rounded-full flex items-center justify-center hover:scale-110 transition-all ${files.length > 0 ? 'bg-red-600 text-black' : 'bg-gray-800 text-gray-600 cursor-not-allowed'}`}
                            >
                                {playing ? <Pause size={24} fill="currentColor"/> : <Play size={24} fill="currentColor"/>}
                            </button>
                            <button className="text-gray-500 hover:text-white" disabled={files.length === 0}><SkipForward size={24}/></button>
                        </div>
                        {files.length === 0 && <p className="text-[10px] text-red-500 animate-pulse font-mono">NO MEDIA MOUNTED</p>}
                    </div>
                    <audio ref={audioRef} onEnded={() => setPlaying(false)} className="hidden" />
                </div>

                <div className="w-full lg:w-64 bg-black/40 border border-white/10 rounded-lg flex flex-col overflow-hidden">
                    <div className="p-2 border-b border-white/5 text-[9px] font-black text-gray-500 uppercase tracking-widest">Library_Manifest</div>
                    <div className="flex-1 overflow-y-auto p-1 space-y-1 scrollbar-tactical">
                        {files.map((f, i) => (
                            <button 
                                key={i} 
                                onClick={() => play(i)}
                                className={`w-full p-2 text-left text-[10px] rounded flex items-center gap-2 transition-all ${curr === i ? 'bg-cyan-500/10 text-cyan-400' : 'text-gray-500 hover:bg-white/5 hover:text-white'}`}
                            >
                                <Music size={10}/> <span className="truncate">{f.name}</span>
                            </button>
                        ))}
                        {files.length === 0 && <div className="text-center py-10 opacity-10 text-[10px] font-black uppercase">Archives Empty</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MediaPanel;
