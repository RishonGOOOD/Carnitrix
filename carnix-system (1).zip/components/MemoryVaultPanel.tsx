


import React, { useState, useMemo } from 'react';
import { Brain, Search, Server } from 'lucide-react';
import { useAppContext } from '../context';
import { Note } from '../types';

const MemoryNode: React.FC<{ note: Note; position: any; onSelect: (id: string) => void; isSelected: boolean }> = ({ note, position, onSelect, isSelected }) => {
    return (
        <div
            className={`absolute w-32 h-20 p-2 text-xs border rounded-md cursor-pointer transition-all duration-300 transform-style-3d ${isSelected ? 'bg-[var(--color-primary)] text-black border-white scale-110' : 'bg-black/70 border-gray-700 hover:border-[var(--color-primary)]'}`}
            style={{ transform: `translate3D(${position.x}px, ${position.y}px, ${position.z}px)` }}
            onClick={() => onSelect(note.id)}
        >
            <p className="font-bold truncate">{note.title}</p>
            <p className="text-gray-400 truncate text-[10px]">{new Date(note.timestamp).toLocaleDateString()}</p>
        </div>
    );
};

const MemoryVaultPanel: React.FC = () => {
    const { state } = useAppContext();
    const notes = state.activeProfile?.notes || [];
    
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
    const [rotation, setRotation] = useState({ x: -15, y: 20 });

    const filteredNotes = useMemo(() => {
        if (!searchTerm) return notes;
        return notes.filter(n =>
            n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            n.content.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [notes, searchTerm]);

    const nodePositions = useMemo(() => {
        return filteredNotes.map((_, i) => {
            const angle = (i / filteredNotes.length) * Math.PI * 2;
            const radius = 150 + (i % 5) * 30;
            return {
                x: radius * Math.cos(angle),
                z: radius * Math.sin(angle),
                y: (i - filteredNotes.length / 2) * 15,
            };
        });
    }, [filteredNotes]);

    const selectedNote = useMemo(() => {
        return notes.find(n => n.id === selectedNodeId);
    }, [notes, selectedNodeId]);

    const handleMouseMove = (e: React.MouseEvent) => {
        if (e.buttons === 1) { // Left mouse button down
            setRotation(prev => ({
                x: Math.max(-90, Math.min(90, prev.x - e.movementY * 0.2)),
                y: prev.y + e.movementX * 0.2,
            }));
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center gap-4">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Brain size={16}/> MEMORY VAULT</h2>
                <div className="relative flex-1">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                    <input
                        type="text"
                        placeholder="Query memory vault..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full bg-black/50 border border-gray-700 rounded-full pl-8 pr-3 py-1.5 text-xs focus:outline-none focus:border-[var(--color-primary)]"
                    />
                </div>
            </div>
            <div className="flex-1 flex gap-2 overflow-hidden">
                <div onMouseMove={handleMouseMove} className="w-2/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex items-center justify-center overflow-hidden perspective-1000 cursor-grab active:cursor-grabbing">
                    <div className="transform-style-3d" style={{ transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
                        {filteredNotes.map((note, i) => (
                            <MemoryNode
                                key={note.id}
                                note={note}
                                position={nodePositions[i]}
                                onSelect={setSelectedNodeId}
                                isSelected={note.id === selectedNodeId}
                            />
                        ))}
                    </div>
                </div>
                <div className="w-1/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <h3 className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400">MEMORY FRAGMENT</h3>
                    <div className="flex-1 p-4 overflow-y-auto">
                        {selectedNote ? (
                            <div>
                                <h4 className="font-bold text-lg text-[var(--color-primary)]">{selectedNote.title}</h4>
                                <p className="text-xs text-gray-500 mt-1">Stored: {new Date(selectedNote.timestamp).toLocaleString()}</p>
                                <p className="text-sm text-gray-300 mt-4 whitespace-pre-wrap">{selectedNote.content}</p>
                            </div>
                        ) : (
                            <div className="text-center text-gray-500 mt-10">Select a memory node to view details.</div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MemoryVaultPanel;