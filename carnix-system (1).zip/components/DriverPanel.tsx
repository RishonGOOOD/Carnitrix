
import React, { useState } from 'react';
import { Shield, Zap, ArrowLeft, Cpu, Activity, ShieldCheck, Power, Loader2, ShieldAlert } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { useAppContext } from '../context';
import { Mode } from '../types';
import { launchAndroidApp } from '../utils/nativeBridge';

const DriverPanel: React.FC = () => {
    const { dispatch } = useAppContext();
    const [status, setStatus] = useState('STANDBY_MODE');
    const [isTransforming, setIsTransforming] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const executeGearApp = async () => {
        setIsTransforming(true);
        setStatus('UPLINK_INITIALIZING...');
        setError(null);
        playSound('process');
        triggerHaptic('heavy');
        
        // Fix D6: Hard-wired protocol target
        const pkg = 'com.henshin.rider';

        setTimeout(async () => {
            dispatch({ type: 'ADD_LOG', payload: { source: 'DRIVER', message: `Executing hardware link: ${pkg}`, level: 'success' }});
            
            const success = await launchAndroidApp(pkg);

            if (success) {
                setTimeout(() => {
                    setIsTransforming(false);
                    setStatus('STANDBY_MODE');
                }, 2000);
            } else {
                playSound('error');
                setError("INTENT_FAILURE");
                setIsTransforming(false);
            }
        }, 1200);
    };

    return (
        <div className="w-full h-full flex flex-col items-center justify-center p-4 font-[Rajdhani] bg-black">
            <div className="w-full max-w-lg flex flex-col items-center gap-6">
                <div className="w-full vamp-panel p-8 flex flex-col items-center justify-center relative overflow-hidden shadow-[0_0_100px_rgba(255,0,0,0.3)]">
                    <div className="absolute top-4 left-0 right-0 flex justify-center gap-12">
                        <div className="text-[7px] font-black text-red-600 uppercase tracking-[0.5em]">RIDER_LINK_SUBSTRATE</div>
                        <div className="text-[7px] font-black text-red-600 uppercase tracking-[0.5em]">LOCKED_ENCRYPTION</div>
                    </div>
                    
                    <div className="text-5xl font-black font-orbitron tracking-[0.3em] text-white my-6 h-20 flex items-center text-center italic drop-shadow-[0_0_15px_red]">
                        {isTransforming ? (
                            <div className="flex gap-3">
                                <div className="w-4 h-4 bg-red-600 rounded-sm animate-ping"></div>
                                <div className="w-4 h-4 bg-red-600 rounded-sm animate-ping [animation-delay:0.2s]"></div>
                                <div className="w-4 h-4 bg-red-600 rounded-sm animate-ping [animation-delay:0.4s]"></div>
                            </div>
                        ) : error ? (
                            <span className="text-red-600 text-2xl tracking-tighter">ACCESS_DENIED</span>
                        ) : (
                            <div className="flex flex-col items-center">
                                <span>GEAR</span>
                                <span className="text-[8px] tracking-[1.2em] text-red-900 opacity-60 uppercase font-bold">Ready</span>
                            </div>
                        )}
                    </div>

                    <div className="w-full grid grid-cols-3 gap-3 border-t border-red-600/20 pt-6">
                        <div className="flex flex-col items-center">
                            <Cpu size={14} className="text-red-600 mb-1" />
                            <span className="text-[8px] font-black text-gray-600 uppercase tracking-widest">Binary</span>
                        </div>
                        <div className="flex flex-col items-center">
                            <Activity size={14} className={`${error ? 'text-red-500' : 'text-green-500'} animate-pulse mb-1`} />
                            <span className="text-[8px] font-black text-white uppercase tracking-widest">{status}</span>
                        </div>
                        <div className="flex flex-col items-center">
                            <ShieldCheck size={14} className="text-red-600 mb-1" />
                            <span className="text-[8px] font-black text-gray-600 uppercase tracking-widest">Secure</span>
                        </div>
                    </div>
                </div>

                <button 
                    onClick={executeGearApp}
                    disabled={isTransforming}
                    className="group relative w-64 h-64 flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
                >
                    <div className="absolute inset-0 border-4 border-red-600/10 rounded-full animate-spin-slow"></div>
                    <div className="absolute inset-3 border border-dashed border-red-600/30 rounded-full animate-spin-reverse-slow"></div>
                    
                    <div className={`w-48 h-48 rounded-full bg-black border-4 transition-all duration-700 flex flex-col items-center justify-center shadow-[0_0_60px_rgba(0,0,0,1)] ${isTransforming ? 'border-white scale-90' : error ? 'border-red-900' : 'border-red-600 shadow-[0_0_40px_rgba(255,0,0,0.4)]'}`}>
                        {isTransforming ? <Loader2 size={60} className="text-white animate-spin" /> : error ? <ShieldAlert size={60} className="text-red-900" /> : <Power size={60} className="text-red-600 group-hover:text-white transition-colors" />}
                        <span className={`text-[10px] font-black mt-4 tracking-[0.4em] uppercase ${isTransforming ? 'text-white animate-pulse' : error ? 'text-red-900' : 'text-red-500'}`}>
                            {isTransforming ? 'UPLINKING' : error ? 'FAULT' : 'HENSHIN'}
                        </span>
                    </div>
                </button>

                <button onClick={() => dispatch({type: 'SET_MODE', payload: Mode.Home})} className="flex items-center gap-3 text-[10px] font-black text-red-900 hover:text-white uppercase tracking-[0.3em] transition-all group mt-4">
                    <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" /> 
                    Return to Command
                </button>
            </div>
            
            <style>{`
                .animate-spin-slow { animation: spin 20s linear infinite; }
                .animate-spin-reverse-slow { animation: spin-reverse 15s linear infinite; }
                @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
                @keyframes spin-reverse { from { transform: rotate(360deg); } to { transform: rotate(0deg); } }
            `}</style>
        </div>
    );
};

export default DriverPanel;
