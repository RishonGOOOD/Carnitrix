
import React, { useState, useEffect } from 'react';
import { Loader2, ShieldAlert, WifiOff, ExternalLink, RefreshCw } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const FaizAppPanel: React.FC = () => {
    const { state } = useAppContext();
    const [isLoading, setIsLoading] = useState(true);
    // Use the URL from profile or fallback to a default (this can be changed once you provide the link)
    const targetUrl = state.activeProfile?.faizAppUrl || 'https://faiz-next-driver.web.app'; 
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        setIsLoading(true);
        setError(null);
    }, [targetUrl]);

    const handleLoad = () => {
        setIsLoading(false);
        playSound('access');
    };

    const handleRefresh = () => {
        setIsLoading(true);
        setError(null);
        playSound('click');
        const iframe = document.getElementById('faiz-frame') as HTMLIFrameElement;
        if (iframe) iframe.src = targetUrl;
    };

    return (
        <div className="w-full h-full flex flex-col bg-black overflow-hidden relative">
            {isLoading && (
                <div className="absolute inset-0 z-50 bg-black flex flex-col items-center justify-center gap-4">
                    <div className="relative w-24 h-24 flex items-center justify-center">
                        <div className="absolute inset-0 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                        <img src="https://cdn-icons-png.flaticon.com/512/1691/1691984.png" alt="" className="w-12 h-12 opacity-50" />
                    </div>
                    <p className="text-[10px] font-black text-red-600 uppercase tracking-[0.4em] animate-pulse">Syncing Smart Brain Link...</p>
                </div>
            )}

            {error ? (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-black">
                    <ShieldAlert size={64} className="text-red-500 mb-6" />
                    <h2 className="text-xl font-black text-white uppercase italic mb-2">Link Interrupted</h2>
                    <p className="text-xs text-gray-500 max-w-xs mb-8 uppercase tracking-widest leading-loose">
                        The external neural node is currently unresponsive. This may be due to security protocols or network latency.
                    </p>
                    <div className="flex gap-4">
                        <button onClick={handleRefresh} className="px-6 py-2 bg-red-600 text-black font-black text-xs rounded uppercase tracking-widest flex items-center gap-2">
                             <RefreshCw size={14}/> Retry Link
                        </button>
                        <a href={targetUrl} target="_blank" rel="noopener noreferrer" className="px-6 py-2 border border-gray-700 text-gray-400 font-black text-xs rounded uppercase tracking-widest flex items-center gap-2">
                            <ExternalLink size={14}/> Open External
                        </a>
                    </div>
                </div>
            ) : (
                <iframe 
                    id="faiz-frame"
                    src={targetUrl} 
                    className={`w-full h-full border-0 transition-opacity duration-1000 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                    onLoad={handleLoad}
                    sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                    title="Faiz System Link"
                />
            )}
        </div>
    );
};

export default FaizAppPanel;
