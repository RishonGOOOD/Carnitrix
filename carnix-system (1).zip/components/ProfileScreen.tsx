import React, { useState, useEffect, useRef } from 'react';
import { Profile, ProfileClass, Mode } from '../types';
import { UserPlus, Trash2, Bot, Layout, Ghost, Radio, Crown, Binary, X, ChevronRight, Zap, Upload, Download, Terminal, ShieldCheck, Database, Fingerprint } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface ProfileScreenProps {
    profiles: Profile[];
    onSelectProfile: (id: string) => void;
    onCreateProfile: (name: string, speciality: ProfileClass) => void;
    onDeleteProfile: (id: string) => void;
    onImportProfile: (p: Profile) => void;
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ profiles, onSelectProfile, onCreateProfile, onDeleteProfile, onImportProfile }) => {
    const [isCreating, setIsCreating] = useState(false);
    const [name, setName] = useState('');
    const [speciality, setSpeciality] = useState<ProfileClass>('Generalist');
    const importInputRef = useRef<HTMLInputElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const classes: { id: ProfileClass, label: string, icon: any }[] = [
        { id: 'Generalist', label: 'OPERATIVE', icon: Bot },
        { id: 'Sentinel', label: 'SENTINEL', icon: ShieldCheck },
        { id: 'Infiltrator', label: 'STALKER', icon: Ghost },
        { id: 'Architect', label: 'SYSTEM ARCH', icon: Layout },
        { id: 'Overlord', label: 'COMMANDER', icon: Crown },
        { id: 'Custom', label: 'OMNI', icon: Zap },
    ];

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
        window.addEventListener('resize', resize);
        resize();

        const chars = '01ABCDEF#$@%&*'.split('');
        const fontSize = 16;
        const columns = Math.ceil(canvas.width / fontSize);
        const drops = Array(columns).fill(0).map(() => Math.random() * -100);

        const draw = () => {
            ctx.fillStyle = 'rgba(3, 0, 2, 0.15)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.font = fontSize + 'px monospace';
            
            for(let i = 0; i < drops.length; i++) {
                const text = chars[Math.floor(Math.random() * chars.length)];
                ctx.fillStyle = i % 8 === 0 ? '#FF003C' : '#1a1a1a';
                ctx.fillText(text, i * fontSize, drops[i] * fontSize);
                if(drops[i] * fontSize > canvas.height && Math.random() > 0.98) drops[i] = 0;
                drops[i]++;
            }
        };

        const interval = setInterval(draw, 45);
        return () => { clearInterval(interval); window.removeEventListener('resize', resize); };
    }, []);

    const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const data = JSON.parse(event.target?.result as string);
                if (!data.name || !data.id) throw new Error("CORRUPT");
                onImportProfile(data);
                playSound('success');
            } catch (err) {
                alert("CRITICAL_FAULT: Credential Packet Corrupted.");
                playSound('error');
            }
        };
        reader.readAsText(file);
    };

    const handleExport = (e: React.MouseEvent, p: Profile) => {
        e.stopPropagation();
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(p));
        const a = document.createElement('a');
        a.setAttribute("href", dataStr);
        a.setAttribute("download", `carnix_id_${p.name.toLowerCase()}.json`);
        document.body.appendChild(a);
        a.click();
        a.remove();
        playSound('success');
    };

    return (
        <div className="fixed inset-0 bg-[#030002] z-[1000] flex flex-col items-center justify-center p-4 overflow-hidden font-[Rajdhani]">
            <canvas ref={canvasRef} className="absolute inset-0 opacity-40 pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#030002] via-transparent to-[#030002] pointer-events-none" />

            <div className="relative z-10 w-full max-w-xl space-y-8 stagger-in">
                <div className="text-center space-y-3">
                    <h1 className="text-6xl md:text-8xl font-black tracking-tighter text-white uppercase italic leading-none drop-shadow-[0_0_30px_rgba(255,0,60,0.5)]">
                        CARNIX <span className="text-[var(--color-primary)]">AI STATION</span>
                    </h1>
                    <div className="flex flex-col items-center">
                        <p className="text-[10px] font-mono tracking-[0.8em] text-gray-500 uppercase">Neural Gateway Interface // v5.2.0</p>
                        <div className="mt-4 flex items-center gap-2 text-cyan-400 font-black text-[9px] uppercase tracking-widest border border-cyan-500/20 px-4 py-1.5 rounded-full bg-cyan-500/5">
                            <ShieldCheck size={12} className="animate-pulse"/> Biometric Verification Active
                        </div>
                    </div>
                </div>

                <div className="jarvis-panel p-8 md:p-10 bg-black/90 border-2 border-white/5 shadow-2xl backdrop-blur-3xl">
                    {isCreating ? (
                        <form onSubmit={(e) => { e.preventDefault(); onCreateProfile(name, speciality); }} className="space-y-8 animate-enter">
                            <div className="flex items-center justify-between border-b border-white/10 pb-4">
                                <h2 className="text-sm font-black text-white uppercase tracking-[0.4em] flex items-center gap-3">
                                    <Terminal size={18} className="text-red-500" /> ID Initialization Node
                                </h2>
                                <button type="button" onClick={() => setIsCreating(false)} className="text-gray-500 hover:text-white p-1 transition-colors"><X size={20}/></button>
                            </div>
                            
                            <div className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-gray-500 tracking-[0.4em] uppercase flex items-center gap-2">
                                        <ChevronRight size={14} className="text-red-600"/> Operator Callsign
                                    </label>
                                    <input 
                                        autoFocus 
                                        value={name} 
                                        onChange={e => setName(e.target.value)} 
                                        placeholder="SCAN NAME..." 
                                        className="w-full bg-black/60 border border-white/10 p-4 text-2xl font-black text-red-500 outline-none focus:border-red-600 uppercase font-mono transition-all"
                                    />
                                </div>

                                <div className="space-y-3">
                                    <label className="text-[10px] font-black text-gray-500 tracking-[0.4em] uppercase flex items-center gap-2">
                                        <Binary size={14} className="text-cyan-400"/> Operational Class
                                    </label>
                                    <div className="grid grid-cols-3 gap-3">
                                        {classes.map(c => (
                                            <button 
                                                key={c.id}
                                                type="button"
                                                onClick={() => { setSpeciality(c.id); playSound('click'); }}
                                                className={`text-[9px] font-black p-4 border transition-all flex flex-col items-center gap-2 rounded-lg ${speciality === c.id ? 'bg-red-600 text-black border-red-600 shadow-lg scale-105' : 'bg-white/5 border-white/5 text-gray-600 hover:border-gray-500'}`}
                                            >
                                                {React.createElement(c.icon, { size: 18 })}
                                                {c.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <button type="submit" disabled={!name.trim()} className="w-full py-5 bg-red-600 text-black font-black uppercase text-xs tracking-[0.6em] hover:bg-white disabled:opacity-20 transition-all shadow-[0_0_40px_rgba(255,0,60,0.5)] flex items-center justify-center gap-3">
                                <Fingerprint size={20}/> Authenticate & Mount
                            </button>
                        </form>
                    ) : (
                        <div className="space-y-8">
                            <div className="flex justify-between items-center border-b border-white/10 pb-4">
                                <span className="text-[10px] font-black text-gray-400 tracking-[0.5em] uppercase flex items-center gap-3">
                                    <Database size={18} className="text-red-600"/> Registry database
                                </span>
                                <div className="flex gap-4">
                                    <button onClick={() => importInputRef.current?.click()} className="text-[10px] font-black text-cyan-400 hover:text-white flex items-center gap-2 transition-all group">
                                        <Upload size={14} className="group-hover:translate-y-[-1px] transition-transform"/> IMPORT
                                    </button>
                                    <input type="file" ref={importInputRef} onChange={handleImport} className="hidden" accept=".json" />
                                    
                                    <button onClick={() => { setIsCreating(true); playSound('click'); }} className="text-[10px] font-black text-red-500 hover:text-white flex items-center gap-2 transition-all group">
                                        <UserPlus size={14} className="group-hover:scale-110 transition-transform"/> NEW_ID
                                    </button>
                                </div>
                            </div>
                            
                            <div className="max-h-[360px] overflow-y-auto space-y-3 scrollbar-tactical pr-2 min-h-[200px]">
                                {profiles.map(p => (
                                    <div 
                                        key={p.id} 
                                        onClick={() => onSelectProfile(p.id)}
                                        className="group p-4 bg-white/5 border border-white/5 hover:border-red-600/50 hover:bg-red-600/10 transition-all cursor-pointer flex justify-between items-center rounded-xl relative overflow-hidden"
                                    >
                                        <div className="flex items-center gap-5 relative z-10">
                                            <div className="w-14 h-14 border-2 border-white/10 rounded-xl flex items-center justify-center bg-black group-hover:border-red-600 group-hover:shadow-[0_0_20px_rgba(255,0,60,0.4)] transition-all">
                                                {p.speciality === 'Overlord' ? <Crown size={30} className="text-yellow-500" /> : <Bot size={30} className="text-gray-500 group-hover:text-red-500" />}
                                            </div>
                                            <div>
                                                <h3 className="font-black text-xl text-white uppercase truncate max-w-[200px] tracking-widest">{p.name}</h3>
                                                <div className="flex items-center gap-3 mt-1.5">
                                                    <span className="text-[9px] text-red-500 font-black uppercase tracking-widest bg-red-600/10 px-2 py-0.5 border border-red-600/20 rounded-full">{p.speciality}</span>
                                                    <span className="text-[9px] text-gray-500 font-mono tracking-tighter">NODE_{p.id.slice(-6).toUpperCase()}</span>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="flex gap-2 relative z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <button onClick={(e) => handleExport(e, p)} className="p-2.5 text-cyan-500 hover:text-white hover:bg-cyan-500/20 rounded-lg transition-all" title="Backup Identity">
                                                <Download size={18} />
                                            </button>
                                            <button onClick={(e) => { e.stopPropagation(); onDeleteProfile(p.id); }} className="p-2.5 text-red-600 hover:text-white hover:bg-red-600/20 rounded-lg transition-all" title="Purge Node">
                                                <Trash2 size={18} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                                {profiles.length === 0 && (
                                    <div className="h-48 flex flex-col items-center justify-center opacity-30 text-center">
                                        <Radio size={56} className="animate-pulse mb-4 text-red-600" />
                                        <p className="text-[12px] uppercase font-black tracking-[0.6em]">Awaiting Uplink Connection</p>
                                        <p className="text-[10px] text-gray-500 mt-3 font-mono">CARNIX_NETWORK // AI_HUB_V5.2</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex flex-col items-center gap-4 opacity-40 group hover:opacity-100 transition-opacity">
                    <div className="flex items-center gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_#22c55e]" />
                        <p className="text-[10px] font-mono text-gray-400 tracking-[0.4em] uppercase">Core Station Indian_Cluster_Node_01 // Online</p>
                    </div>
                    <p className="text-[9px] text-gray-600 font-black tracking-widest uppercase">&copy; 2024 CARNIX_SYSTEMS // SECURE_ACCESS_LAYER</p>
                </div>
            </div>
        </div>
    );
};

export default ProfileScreen;