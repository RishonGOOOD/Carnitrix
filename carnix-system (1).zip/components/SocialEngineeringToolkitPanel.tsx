import React, { useState } from 'react';
import { Users, Send, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

const SocialEngineeringToolkitPanel: React.FC = () => {
    const { state } = useAppContext();
    const [params, setParams] = useState({ target: 'Corporate Employee', goal: 'Obtain login credentials', method: 'Phishing Email' });
    const [result, setResult] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerate = async () => {
        if (!params.target || !params.goal || !state.activeProfile) return;
        setIsLoading(true);
        setResult(null);
        try {
            const prompt = `Generate a simulated ${params.method} for a social engineering exercise. The target is a '${params.target}' and the goal is to '${params.goal}'. The output should be clearly marked as a simulation and for educational purposes only.`;
            const res = await getAIResponse(prompt, Mode.SocialEngineeringToolkit, state.activeProfile.aiSettings);
            setResult(res.text);
        } catch (e) {
            setResult('Failed to generate scenario.');
        } finally {
            setIsLoading(false);
        }
    };

    const InputField: React.FC<{ label: string; value: string; onChange: (val: string) => void }> = ({ label, value, onChange }) => (
        <div>
            <label className="text-xs font-bold text-gray-400 block mb-1">{label}</label>
            <input type="text" value={value} onChange={e => onChange(e.target.value)} className="w-full hud-input text-sm" />
        </div>
    );

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Users size={14}/> SOCIAL ENGINEERING TOOLKIT (SIMULATION)
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="w-full lg:w-1/3 border-b lg:border-b-0 lg:border-r border-[var(--color-panel-header-border)] flex flex-col p-4 gap-4">
                    <InputField label="TARGET PROFILE" value={params.target} onChange={val => setParams(p => ({...p, target: val}))} />
                    <InputField label="OBJECTIVE" value={params.goal} onChange={val => setParams(p => ({...p, goal: val}))} />
                    <div>
                         <label className="text-xs font-bold text-gray-400 block mb-1">METHOD</label>
                         <select value={params.method} onChange={e => setParams(p => ({...p, method: e.target.value}))} className="w-full hud-select text-sm">
                             <option>Phishing Email</option>
                             <option>Pretexting Script</option>
                             <option>Baiting Scenario</option>
                         </select>
                    </div>
                    <button onClick={handleGenerate} disabled={isLoading} className="w-full hud-button mt-auto flex items-center justify-center gap-2">
                        {isLoading ? <Loader2 size={16} className="animate-spin"/> : <Send size={16}/>}
                        GENERATE SCENARIO
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 bg-black/20">
                    <h3 className="text-sm font-bold text-[var(--color-primary)] mb-2">GENERATED PAYLOAD</h3>
                     {isLoading && <Loader2 className="animate-spin"/>}
                    {result ? (
                        <pre className="whitespace-pre-wrap font-mono text-sm text-gray-300">{result}</pre>
                    ) : (
                        <p className="text-sm text-gray-500">Define parameters and generate a scenario.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default SocialEngineeringToolkitPanel;
