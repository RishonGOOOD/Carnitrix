
import React, { useState, useEffect, useMemo } from 'react';
import { CloudRain, MapPin, Loader2, RefreshCw } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { MapSkeleton } from './Loading';

const WeatherRadarPanel: React.FC = () => {
    const { state } = useAppContext();
    const { geolocation } = state;
    const [mapCenter, setMapCenter] = useState<{ latitude: number, longitude: number } | null>(null);

    // Set initial and periodic location
    useEffect(() => {
        if (geolocation && !mapCenter) {
            setMapCenter({ latitude: geolocation.latitude, longitude: geolocation.longitude });
        }
        
        const intervalId = setInterval(() => {
            if (geolocation) {
                setMapCenter({ latitude: geolocation.latitude, longitude: geolocation.longitude });
            }
        }, 60000); // 1 minute

        return () => clearInterval(intervalId);
    }, [geolocation, mapCenter]);

    const handleRecenter = () => {
        if (geolocation) {
            setMapCenter({ latitude: geolocation.latitude, longitude: geolocation.longitude });
            playSound('click');
            triggerHaptic('light');
        }
    };

    const mapUrl = useMemo(() => {
        if (mapCenter) {
            return `https://embed.windy.com/embed.html?lat=${mapCenter.latitude}&lon=${mapCenter.longitude}&zoom=7&level=surface&overlay=radar&product=radar&menu=&message=&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=&metricWind=default&metricTemp=default&radarRange=-1`;
        }
        return null;
    }, [mapCenter]);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <CloudRain size={16}/> LIVE WEATHER RADAR
                </h2>
                <div className="flex items-center gap-2">
                    <div className="text-xs font-mono text-gray-400 flex items-center gap-2">
                        <MapPin size={12} className={geolocation ? "text-green-500" : "text-red-500 animate-pulse"} />
                        <span>{geolocation ? "LOCATION LOCKED" : "AWAITING GPS..."}</span>
                    </div>
                    <button onClick={handleRecenter} className="p-1 text-gray-400 hover:text-white hover:bg-white/10 rounded" title="Re-center map">
                        <RefreshCw size={14} />
                    </button>
                </div>
            </div>

            <div className="flex-1 bg-black border border-[var(--color-panel-border)] rounded-md overflow-hidden relative">
                {mapUrl ? (
                    <iframe
                        key={mapUrl}
                        src={mapUrl}
                        className="w-full h-full border-0"
                        title="Weather Radar"
                        allowFullScreen
                    />
                ) : (
                    <div className="w-full h-full p-4">
                        <MapSkeleton />
                    </div>
                )}
            </div>
        </div>
    );
};

export default WeatherRadarPanel;
