
import React, { useState, useEffect, useRef } from 'react';
import { Activity, Zap, Play, Square, Settings, RefreshCw } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const HardwareLogicAnalyzer: React.FC = () => {
    const [isRunning, setIsRunning] = useState(false);
    const [channels] = useState(['CH1_RX', 'CH2_TX', 'CH3_SDA', 'CH4_SCL']);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [sampleRate, setSampleRate] = useState(115200);

    useEffect(() => {
        if (!isRunning) return;
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let frame: number;
        let x = 0;
        const data = channels.map(() => Array(100).fill(0));

        const draw = () => {
            ctx.fillStyle = 'rgba(5, 0, 5, 0.2)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            const laneHeight = canvas.height / channels.length;
            
            channels.forEach((_, i) => {
                const yBase = (i + 1) * laneHeight - 10;
                ctx.strokeStyle = i % 2 === 0 ? '#00f0ff' : '#ff003c';
                ctx.lineWidth = 2;
                ctx.beginPath();
                
                // Simulate logic high/low based on noise
                const val = Math.random() > 0.8 ? 1 : Math.random() > 0.9 ? 0 : data[i][data[i].length-1];
                data[i].push(val);
                data[i].shift();

                data[i].forEach((bit, idx) => {
                    const px = (idx / 100) * canvas.width;
                    const py = yBase - (bit * (laneHeight * 0.6));
                    if (idx === 0) ctx.moveTo(px, py);
                    else ctx.lineTo(px, py);
                });
                ctx.stroke();

                // Labels
                ctx.fillStyle = 'white';
                ctx.font = '8px monospace';
                ctx.fillText(channels[i], 10, yBase + 8);
            });

            frame = requestAnimationFrame(draw);
        };
        draw();
        return () => cancelAnimationFrame(frame);
    }, [isRunning, channels]);

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/40 border border-white/10 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Activity size={24} className="text-cyan-400" />
                    <div>
                        <h2 className="text-lg font-black tracking-widest text-white uppercase italic">Logic Analyzer</h2>
                        <p className="text-[9px] font-mono text-gray-500 uppercase">WebSerial Logic Capture // {sampleRate} Hz</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={() => { setIsRunning(!isRunning); playSound('click'); }} className={`px-6 py-2 rounded font-black text-xs flex items-center gap-2 ${isRunning ? 'bg-red-600 text-black' : 'bg-green-600 text-black'}`}>
                        {isRunning ? <Square size={14}/> : <Play size={14}/>} {isRunning ? 'HALT' : 'CAPTURE'}
                    </button>
                </div>
            </div>

            <div className="flex-1 bg-black border border-white/5 rounded overflow-hidden relative">
                <canvas ref={canvasRef} className="w-full h-full" width={800} height={400} />
                <div className="absolute top-2 right-2 flex gap-2">
                    <div className="bg-black/80 border border-white/10 px-2 py-1 text-[8px] font-mono text-cyan-400">TRIGGER: AUTO</div>
                    <div className="bg-black/80 border border-white/10 px-2 py-1 text-[8px] font-mono text-cyan-400">DEPTH: 100ms</div>
                </div>
            </div>
        </div>
    );
};

export default HardwareLogicAnalyzer;
