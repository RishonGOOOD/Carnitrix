


import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context';
import { Sun, Cloud, CloudRain, CloudSnow, Wind, Droplets, Thermometer, Sunrise, Sunset, Loader2, CloudSun, Cloudy, Zap } from 'lucide-react';

interface WeatherData {
    current: {
        temperature_2m: number;
        relative_humidity_2m: number;
        weather_code: number;
        wind_speed_10m: number;
    };
    hourly: {
        time: string[];
        temperature_2m: number[];
        weather_code: number[];
    };
    daily: {
        time: string[];
        weather_code: number[];
        temperature_2m_max: number[];
        temperature_2m_min: number[];
    };
}

const weatherCodeToIcon = (code: number, isDay: boolean = true): React.ReactNode => {
    switch (code) {
        case 0: return <Sun size={32} className="text-yellow-400" />;
        case 1: return <CloudSun size={32} className="text-yellow-300" />;
        case 2: return <Cloudy size={32} className="text-gray-400" />;
        case 3: return <Cloud size={32} className="text-gray-500" />;
        case 45: case 48: return <Cloud size={32} className="text-gray-500" />; // Fog
        case 51: case 53: case 55: return <CloudRain size={32} className="text-blue-400" />; // Drizzle
        case 61: case 63: case 65: return <CloudRain size={32} className="text-blue-300" />; // Rain
        case 71: case 73: case 75: return <CloudSnow size={32} className="text-white" />; // Snow
        case 80: case 81: case 82: return <CloudRain size={32} className="text-blue-500" />; // Rain showers
        case 95: case 96: case 99: return <Zap size={32} className="text-yellow-500" />; // Thunderstorm
        default: return <Cloud size={32} className="text-gray-400" />;
    }
};
const weatherCodeToString = (code: number): string => {
    const codes: { [key: number]: string } = {0: 'Clear sky', 1: 'Mainly clear', 2: 'Partly cloudy', 3: 'Overcast', 45: 'Fog', 48: 'Depositing rime fog', 51: 'Light drizzle', 53: 'Moderate drizzle', 55: 'Dense drizzle', 61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain', 71: 'Slight snow', 73: 'Moderate snow', 75: 'Heavy snow', 80: 'Slight rain showers', 81: 'Moderate rain showers', 82: 'Violent rain showers', 95: 'Thunderstorm', 96: 'Thunderstorm, slight hail', 99: 'Thunderstorm, heavy hail'};
    return codes[code] || "Unknown";
};


const ClimatePanel: React.FC = () => {
    const { state } = useAppContext();
    const { geolocation, address } = state;
    const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (geolocation) {
            setLoading(true);
            fetch(`https://api.open-meteo.com/v1/forecast?latitude=${geolocation.latitude}&longitude=${geolocation.longitude}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto`)
                .then(res => res.json())
                .then(data => {
                    setWeatherData(data);
                    setLoading(false);
                })
                .catch(err => {
                    console.error("Failed to fetch weather data:", err);
                    setLoading(false);
                });
        }
    }, [geolocation]);

    if (loading) {
        return (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
                <Loader2 size={32} className="animate-spin mr-4" />
                Acquiring satellite weather data...
            </div>
        );
    }
    
    if (!weatherData) {
        return <div className="w-full h-full flex items-center justify-center text-red-500">Weather data uplink failed. Check connection or location services.</div>;
    }

    const { current, hourly, daily } = weatherData;
    const now = new Date();
    const currentHourIndex = hourly.time.findIndex(t => new Date(t) > now);

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 overflow-hidden">
            <div className="flex-shrink-0 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex items-center gap-4">
                    {weatherCodeToIcon(current.weather_code)}
                    <div>
                        <div className="text-4xl font-bold font-mono text-white">{Math.round(current.temperature_2m)}°</div>
                        <div className="text-xs text-gray-300">{weatherCodeToString(current.weather_code)}</div>
                        <div className="text-xs text-[var(--color-primary)]">{address?.city || 'Current Location'}</div>
                    </div>
                </div>
                 <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex items-center gap-4">
                    <Droplets size={24} className="text-blue-400"/>
                    <div>
                        <div className="text-xs text-gray-400">HUMIDITY</div>
                        <div className="text-2xl font-bold font-mono text-white">{current.relative_humidity_2m}<span className="text-lg">%</span></div>
                    </div>
                </div>
                 <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex items-center gap-4">
                    <Wind size={24} className="text-gray-300"/>
                    <div>
                        <div className="text-xs text-gray-400">WIND</div>
                        <div className="text-2xl font-bold font-mono text-white">{current.wind_speed_10m.toFixed(1)} <span className="text-sm">km/h</span></div>
                    </div>
                </div>
                <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex items-center gap-4">
                    <Thermometer size={24} className="text-orange-400"/>
                    <div>
                        <div className="text-xs text-gray-400">HIGH / LOW</div>
                        <div className="text-2xl font-bold font-mono text-white">{Math.round(daily.temperature_2m_max[0])}° / {Math.round(daily.temperature_2m_min[0])}°</div>
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-4 overflow-hidden">
                <div className="flex-[2] bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                     <h3 className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400">HOURLY FORECAST</h3>
                     <div className="flex-1 overflow-x-auto overflow-y-hidden p-2">
                        <div className="flex h-full gap-2 w-max">
                            {hourly.time.slice(currentHourIndex, currentHourIndex + 24).map((time, i) => (
                                <div key={time} className="w-16 h-full flex flex-col items-center justify-between p-2 bg-black/20 rounded border border-gray-800">
                                    <div className="text-[10px] text-gray-500">{new Date(time).getHours()}:00</div>
                                    <div className="my-2">{weatherCodeToIcon(hourly.weather_code[currentHourIndex + i], true)}</div>
                                    <div className="text-sm font-bold">{Math.round(hourly.temperature_2m[currentHourIndex + i])}°</div>
                                </div>
                            ))}
                        </div>
                     </div>
                </div>
                <div className="flex-[1] bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <h3 className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400">7-DAY OUTLOOK</h3>
                    <div className="flex-1 overflow-y-auto p-2 space-y-1">
                        {daily.time.map((day, i) => (
                            <div key={day} className="flex items-center justify-between p-2 bg-black/20 rounded">
                                <div className="font-bold text-xs w-10">{new Date(day + 'T00:00:00').toLocaleDateString('en-US', { weekday: 'short' })}</div>
                                <div className="flex-1 text-center">{weatherCodeToIcon(daily.weather_code[i], true)}</div>
                                <div className="text-xs font-mono w-20 text-right">
                                    <span className="font-bold text-white">{Math.round(daily.temperature_2m_max[i])}°</span>
                                    <span className="text-gray-500"> / {Math.round(daily.temperature_2m_min[i])}°</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ClimatePanel;