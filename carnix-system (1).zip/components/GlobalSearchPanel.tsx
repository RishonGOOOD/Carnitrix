import React, { useState } from 'react';
import { OsintEngine } from '../services/osintEngine';
import { SecurityEngine } from '../services/securityEngine';
import { ThreatIntelEngine } from '../services/threatIntelEngine';
import { InvestigationService } from '../services/investigationService';
import { EvidenceEngine } from '../services/evidenceEngine';
import { OsintResult, SecurityFinding, ThreatIndicator } from '../types';
import { 
  Search, Shield, Globe, Terminal, CheckCircle2, 
  ArrowRight, Sparkles, FolderPlus, RefreshCw, AlertTriangle
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const GlobalSearchPanel: React.FC = () => {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [osintResults, setOsintResults] = useState<OsintResult[]>([]);
  const [threatIndicator, setThreatIndicator] = useState<ThreatIndicator | null>(null);
  const [securityAudit, setSecurityAudit] = useState<any | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = query.trim();
    if (!clean) return;

    setIsSearching(true);
    setStatusMessage(`Synthesizing intelligence across OSINT, Threat Intel, and Security nodes for "${clean}"...`);
    playSound('scan');
    triggerHaptic('medium');

    try {
      // 1. Run Universal OSINT Pipeline
      const osint = await OsintEngine.runUniversalInvestigation(clean);
      setOsintResults(osint);

      // 2. Correlate with Threat Intelligence Database
      const ti = await ThreatIntelEngine.enrichIndicator(clean);
      setThreatIndicator(ti);

      // 3. If domain or URL, run defensive configuration audit
      if (clean.includes('.') && !clean.includes(' ')) {
        const audit = await SecurityEngine.assessTarget(clean);
        setSecurityAudit(audit);
      } else {
        setSecurityAudit(null);
      }

      setStatusMessage(`Investigation complete. Correlated ${osint.length} OSINT vectors.`);
      playSound('success');
    } catch (err: any) {
      setStatusMessage(`Error during investigation: ${err.message}`);
      playSound('alert');
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddToActiveCase = () => {
    if (osintResults.length === 0) return;
    playSound('access');
    osintResults.forEach(r => InvestigationService.addEvidenceToActiveCase(r));
    if (securityAudit) {
      securityAudit.findings.forEach((f: SecurityFinding) => InvestigationService.addFindingToActiveCase(f));
    }
    alert('Intelligence and findings successfully added to active investigation case!');
  };

  const sampleQueries = [
    'Investigate apex-defense.org',
    '185.220.101.5',
    'github.com/torvalds',
    'https://update-system-login.top/login',
    '45.154.255.89'
  ];

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Omni-Search Hero Bar */}
      <div className="p-6 bg-gradient-to-r from-red-950/40 via-black to-red-950/20 border border-red-900/40 rounded-2xl space-y-4 shadow-[0_0_25px_rgba(255,0,0,0.1)]">
        <div className="flex items-center gap-2 text-red-500 font-mono text-xs uppercase tracking-wider font-bold">
          <Sparkles size={14} /> CARNIX OMNI-RECON INTELLIGENCE PIPELINE
        </div>
        <h1 className="text-2xl sm:text-3xl font-black font-orbitron text-white tracking-wider">
          UNIFIED AI & THREAT INTELLIGENCE SEARCH
        </h1>
        <p className="text-xs text-gray-400 font-mono max-w-2xl">
          Enter any domain, IPv4/IPv6, URL, username, file hash, or investigative prompt. CARNIX immediately executes authoritative DNS, CT transparency, BGP routing, and security audits.
        </p>

        <form onSubmit={handleSearch} className="flex gap-2 pt-2">
          <div className="relative flex-1">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. apex-defense.org, 185.220.101.5, or GitHub handle..."
              className="w-full pl-11 pr-4 py-3 bg-black/90 border border-red-900/50 rounded-xl text-base font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500 shadow-inner"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching}
            className="px-6 py-3 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded-xl transition-all shadow-[0_0_20px_rgba(255,0,0,0.5)] disabled:opacity-50 flex items-center gap-2"
          >
            <RefreshCw size={15} className={isSearching ? 'animate-spin' : ''} />
            {isSearching ? 'SCANNING...' : 'INVESTIGATE'}
          </button>
        </form>

        {/* Quick Suggestion Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 font-mono text-xs text-gray-400">
          <span className="text-[11px] text-gray-500">QUICK TARGETS:</span>
          {sampleQueries.map((q, i) => (
            <button
              key={i}
              onClick={() => {
                setQuery(q);
                playSound('click');
              }}
              className="px-2.5 py-1 rounded bg-black/60 hover:bg-red-950/40 border border-white/5 hover:border-red-900/50 text-gray-300 text-[11px] transition-all"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {statusMessage && (
        <div className="px-4 py-2 bg-red-950/20 border border-red-900/30 rounded-lg text-xs font-mono text-red-400 flex items-center justify-between">
          <span>{statusMessage}</span>
          {osintResults.length > 0 && (
            <button
              onClick={handleAddToActiveCase}
              className="flex items-center gap-1.5 px-3 py-1 bg-red-600 hover:bg-red-500 text-black font-black uppercase text-[10px] rounded"
            >
              <FolderPlus size={12} /> ADD ALL TO ACTIVE CASE
            </button>
          )}
        </div>
      )}

      {/* Results View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: OSINT Records (7 Cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="text-xs font-mono font-bold text-gray-400 flex items-center justify-between">
            <span>DISCOVERED OSINT EVIDENCE ({osintResults.length})</span>
          </div>

          {osintResults.length === 0 ? (
            <div className="p-12 text-center text-gray-500 font-mono bg-black/40 rounded-xl border border-white/5">
              Enter a query above to initiate universal cross-vector reconnaissance.
            </div>
          ) : (
            osintResults.map((res) => (
              <div key={res.id} className="p-4 bg-black/70 border border-red-900/30 rounded-xl font-mono text-xs space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-cyan-400 font-orbitron">{res.category}: {res.query}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {res.confidence}
                  </span>
                </div>
                <p className="text-gray-300 leading-relaxed">{res.evidence}</p>
                <div className="text-[10px] text-gray-500">Source: {res.source} | Method: {res.processingMethod}</div>
                {res.result && (
                  <pre className="p-2.5 bg-black/90 rounded border border-white/5 text-[11px] text-emerald-400 overflow-x-auto max-h-48">
                    {JSON.stringify(res.result, null, 2)}
                  </pre>
                )}
              </div>
            ))
          )}
        </div>

        {/* Right Column: Threat Intel & Security Audit (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Threat Intel Card */}
          {threatIndicator && (
            <div className="p-4 bg-red-950/20 border border-red-900/40 rounded-xl font-mono text-xs space-y-3">
              <div className="flex justify-between items-center border-b border-red-900/30 pb-2">
                <span className="font-bold text-white uppercase flex items-center gap-1.5">
                  <Shield size={14} className="text-red-500" /> THREAT INTEL CORRELATION
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  threatIndicator.threatLevel === 'MALICIOUS' ? 'bg-red-900 text-red-200' :
                  threatIndicator.threatLevel === 'SUSPICIOUS' ? 'bg-amber-900 text-amber-200' : 'bg-emerald-900 text-emerald-200'
                }`}>
                  {threatIndicator.threatLevel} ({threatIndicator.score}/100)
                </span>
              </div>

              <div>
                <span className="text-gray-400 text-[10px]">INDICATOR VALUE:</span>
                <div className="text-sm font-bold text-white break-all">{threatIndicator.value}</div>
              </div>

              {threatIndicator.mitreAttack && (
                <div>
                  <span className="text-gray-400 text-[10px]">MITRE ATT&CK TECHNIQUES:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {threatIndicator.mitreAttack.map((m, i) => (
                      <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-black/60 text-red-300 border border-red-900/40">
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {threatIndicator.sources && (
                <div className="space-y-1.5 pt-1">
                  <span className="text-gray-400 text-[10px]">CORROBORATING REPUTATION FEEDS:</span>
                  {threatIndicator.sources.map((s, i) => (
                    <div key={i} className="p-2 bg-black/60 rounded border border-white/5 text-[10px]">
                      <div className="text-cyan-400 font-bold">{s.provider} ({s.confidence}%)</div>
                      <div className="text-gray-300">{s.summary}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Security Audit Snapshot */}
          {securityAudit && (
            <div className="p-4 bg-black/70 border border-red-900/30 rounded-xl font-mono text-xs space-y-3">
              <div className="flex justify-between items-center border-b border-white/5 pb-2">
                <span className="font-bold text-white uppercase">DEFENSIVE POSTURE SNAPSHOT</span>
                <span className="text-base font-black font-orbitron text-red-500">
                  {securityAudit.grade} ({securityAudit.score}/100)
                </span>
              </div>
              <div className="text-gray-300">
                Target has {securityAudit.findings.length} configuration findings requiring defensive remediation.
              </div>
              <div className="space-y-1">
                {securityAudit.findings.slice(0, 3).map((f: SecurityFinding) => (
                  <div key={f.id} className="p-2 bg-red-950/20 rounded border border-red-900/30 text-[11px]">
                    <span className="text-amber-400 font-bold">[{f.severity}]</span> {f.title}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GlobalSearchPanel;
