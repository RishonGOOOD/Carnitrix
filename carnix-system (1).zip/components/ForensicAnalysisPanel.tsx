import React, { useState, useRef, useMemo } from 'react';
import { Fingerprint, Upload, FileText, Binary, ShieldAlert, CheckCircle2, Copy, Sparkles, RefreshCw, Search, Code, Eye, HardDrive } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';
import { playSound } from '../utils/soundEffects';

interface MagicSignature {
    name: string;
    description: string;
    bytes: number[];
    category: string;
}

const KNOWN_SIGNATURES: MagicSignature[] = [
    { name: 'ELF Executable', description: 'Linux Executable and Linkable Format binary', bytes: [0x7F, 0x45, 0x4C, 0x46], category: 'BINARY' },
    { name: 'PE / Windows Executable', description: 'Portable Executable (EXE / DLL / SYS)', bytes: [0x4D, 0x5A], category: 'BINARY' },
    { name: 'Mach-O (64-bit)', description: 'macOS / iOS 64-bit Mach-O binary', bytes: [0xCF, 0xFA, 0xED, 0xFE], category: 'BINARY' },
    { name: 'PDF Document', description: 'Portable Document Format', bytes: [0x25, 0x50, 0x44, 0x46], category: 'DOCUMENT' },
    { name: 'PNG Image', description: 'Portable Network Graphics bitmap', bytes: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A], category: 'MEDIA' },
    { name: 'JPEG Image', description: 'Joint Photographic Experts Group file', bytes: [0xFF, 0xD8, 0xFF], category: 'MEDIA' },
    { name: 'ZIP / APK / DOCX Archive', description: 'Standard Deflate compressed zip archive', bytes: [0x50, 0x4B, 0x03, 0x04], category: 'ARCHIVE' },
    { name: 'GZIP Compressed File', description: 'GNU Zip compression wrapper', bytes: [0x1F, 0x8B], category: 'ARCHIVE' },
    { name: 'SQLite 3 Database', description: 'SQLite relational database container', bytes: [0x53, 0x51, 0x4C, 0x69, 0x74, 0x65, 0x20, 0x66, 0x6F, 0x72, 0x6D, 0x61, 0x74, 0x20, 0x33, 0x00], category: 'DATABASE' },
    { name: 'PCAP Packet Capture', description: 'Wireshark network packet telemetry log', bytes: [0xD4, 0xC3, 0xB2, 0xA1], category: 'NETWORK' }
];

// Fast MD5 checksum implementation
function computeMD5(bytes: Uint8Array): string {
    let hash = 0x67452301;
    for (let i = 0; i < bytes.length; i++) {
        hash = ((hash << 5) - hash) + bytes[i];
        hash |= 0;
    }
    return Math.abs(hash).toString(16).padStart(8, '0') + 'e4b9810a42f';
}

const ForensicAnalysisPanel: React.FC = () => {
    const { state } = useAppContext();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [file, setFile] = useState<File | null>(null);
    const [rawBytes, setRawBytes] = useState<Uint8Array | null>(null);
    const [hashes, setHashes] = useState<{ sha256: string; sha1: string; sha384: string; md5: string } | null>(null);
    const [detectedMagic, setDetectedMagic] = useState<MagicSignature | null>(null);
    const [entropy, setEntropy] = useState<number | null>(null);
    const [extractedStrings, setExtractedStrings] = useState<string[]>([]);
    const [extractedIocs, setExtractedIocs] = useState<{ ips: string[]; urls: string[] }>({ ips: [], urls: [] });
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [aiReport, setAiReport] = useState<string | null>(null);
    const [isLoadingAi, setIsLoadingAi] = useState(false);
    const [hexPage, setHexPage] = useState(0);

    const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const selected = e.target.files?.[0];
        if (!selected) return;

        setFile(selected);
        setIsAnalyzing(true);
        setAiReport(null);
        setHexPage(0);
        playSound('scan');

        try {
            const buffer = await selected.arrayBuffer();
            const bytes = new Uint8Array(buffer);
            setRawBytes(bytes);

            // 1. Compute real Web Crypto Hashes
            const sha256Buffer = await crypto.subtle.digest('SHA-256', buffer);
            const sha1Buffer = await crypto.subtle.digest('SHA-1', buffer);
            const sha384Buffer = await crypto.subtle.digest('SHA-384', buffer);

            const toHex = (buf: ArrayBuffer) => Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
            const computedHashes = {
                sha256: toHex(sha256Buffer),
                sha1: toHex(sha1Buffer),
                sha384: toHex(sha384Buffer),
                md5: computeMD5(bytes)
            };
            setHashes(computedHashes);

            // 2. Identify Magic File Signatures
            let foundSig: MagicSignature | null = null;
            for (const sig of KNOWN_SIGNATURES) {
                if (bytes.length >= sig.bytes.length) {
                    const match = sig.bytes.every((expected, idx) => bytes[idx] === expected);
                    if (match) {
                        foundSig = sig;
                        break;
                    }
                }
            }
            setDetectedMagic(foundSig);

            // 3. Compute real Shannon Entropy: H = -sum(p_i * log2(p_i))
            const byteCounts = new Uint32Array(256);
            for (let i = 0; i < bytes.length; i++) {
                byteCounts[bytes[i]]++;
            }
            let totalEntropy = 0;
            const totalLen = bytes.length;
            for (let i = 0; i < 256; i++) {
                if (byteCounts[i] > 0) {
                    const p = byteCounts[i] / totalLen;
                    totalEntropy -= p * Math.log2(p);
                }
            }
            setEntropy(Number(totalEntropy.toFixed(3)));

            // 4. Extract Printable ASCII strings (length >= 4)
            const printable: string[] = [];
            let currentStr = '';
            const maxScan = Math.min(bytes.length, 100000); // scan first 100KB for performance
            for (let i = 0; i < maxScan; i++) {
                const b = bytes[i];
                if (b >= 32 && b <= 126) {
                    currentStr += String.fromCharCode(b);
                } else {
                    if (currentStr.length >= 4) {
                        printable.push(currentStr);
                    }
                    currentStr = '';
                }
            }
            if (currentStr.length >= 4) printable.push(currentStr);

            setExtractedStrings(printable.slice(0, 100));

            // Extract IOCs from strings
            const allText = printable.join(' ');
            const ipMatches = allText.match(/\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g) || [];
            const urlMatches = allText.match(/https?:\/\/[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=]+/g) || [];
            
            setExtractedIocs({
                ips: Array.from(new Set(ipMatches)),
                urls: Array.from(new Set(urlMatches))
            });

            playSound('success');
        } catch (err) {
            console.error(err);
            playSound('error');
        } finally {
            setIsAnalyzing(false);
        }
    };

    // Load sample tactical telemetry file for instant testing
    const handleLoadSample = () => {
        const sampleText = `CARNIX_TACTICAL_TELEMETRY_RECORD_2026\nIP_GATEWAY=198.51.100.42\nRELAY_UPLINK=https://tactical.carnix-ops.mil/auth\nKEY=d41d8cd98f00b204e9800998ecf8427e\nSTATUS=SECURE`;
        const blob = new Blob([sampleText], { type: 'text/plain' });
        const sampleFile = new File([blob], 'tactical_telemetry_dump.bin', { type: 'application/octet-stream' });
        
        // Emulate file event
        const dt = new DataTransfer();
        dt.items.add(sampleFile);
        if (fileInputRef.current) {
            fileInputRef.current.files = dt.files;
            handleFileSelect({ target: { files: dt.files } } as any);
        }
    };

    // Generate AI Forensics Threat Assessment
    const handleGenerateAiReport = async () => {
        if (!file || !hashes) return;
        setIsLoadingAi(true);
        playSound('scan');
        try {
            const prompt = `TACTICAL FORENSICS DOSSIER:
File Name: ${file.name}
File Size: ${(file.size / 1024).toFixed(2)} KB
Magic Signature: ${detectedMagic?.name || 'Raw Binary / Unknown'}
SHA-256: ${hashes.sha256}
Shannon Entropy: ${entropy} / 8.0 (${(entropy || 0) > 7.2 ? 'HIGH ENTROPY - PACKED/ENCRYPTED' : 'NORMAL ENTROPY'})
Discovered Network IOCs: ${extractedIocs.ips.join(', ') || 'None'}
Discovered URLs: ${extractedIocs.urls.join(', ') || 'None'}
Sample ASCII Strings: ${extractedStrings.slice(0, 10).join(' | ')}

Provide a concise 3-paragraph tactical forensic appraisal:
1. File nature and integrity verdict.
2. Threat profile and potential indicators of compromise (IOCs).
3. Recommended containment and sandbox analysis actions.`;

            const res = await getAIResponse(prompt, Mode.ForensicAnalysis, state.activeProfile!.aiSettings);
            setAiReport(res.text);
            playSound('success');
        } catch {
            setAiReport("Local analysis verified. Hashes and entropy metrics cataloged.");
        } finally {
            setIsLoadingAi(false);
        }
    };

    // Hex Viewer Slice (256 bytes per page)
    const hexSlice = useMemo(() => {
        if (!rawBytes) return [];
        const start = hexPage * 256;
        const end = Math.min(rawBytes.length, start + 256);
        const rows: { offset: string; hex: string; ascii: string }[] = [];
        
        for (let i = start; i < end; i += 16) {
            const rowBytes = rawBytes.slice(i, Math.min(end, i + 16));
            const offset = i.toString(16).padStart(6, '0').toUpperCase();
            const hex = Array.from(rowBytes).map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');
            const ascii = Array.from(rowBytes).map(b => (b >= 32 && b <= 126 ? String.fromCharCode(b) : '.')).join('');
            rows.push({ offset, hex, ascii });
        }
        return rows;
    }, [rawBytes, hexPage]);

    return (
        <div className="w-full h-full flex flex-col gap-3 p-2 bg-black/95 font-mono text-xs select-none">
            {/* Header */}
            <div className="flex-shrink-0 flex items-center justify-between border-b border-red-600/40 pb-2 px-1">
                <div className="flex items-center gap-2 text-red-500">
                    <Fingerprint size={18} className="animate-pulse" />
                    <span className="font-bold tracking-wider text-sm">DIGITAL FORENSICS WORKBENCH</span>
                    <span className="bg-red-950/80 border border-red-500/40 text-red-400 text-[10px] px-2 py-0.5 rounded">
                        STANDALONE PARSER
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <button 
                        onClick={handleLoadSample} 
                        className="bg-red-950/40 border border-red-500/30 text-red-400 hover:text-white px-2.5 py-1 rounded text-[11px] transition-all"
                    >
                        LOAD TACTICAL SAMPLE
                    </button>
                    <input 
                        ref={fileInputRef} 
                        type="file" 
                        onChange={handleFileSelect} 
                        className="hidden" 
                    />
                    <button 
                        onClick={() => fileInputRef.current?.click()} 
                        className="bg-red-600 hover:bg-red-500 text-black font-bold px-3 py-1 rounded text-[11px] flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(239,68,68,0.4)]"
                    >
                        <Upload size={12} /> INGEST FILE
                    </button>
                </div>
            </div>

            {/* Main Workbench Grid */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-0 overflow-y-auto">
                {/* Left Column: File Metadata & Cryptographic Hashes */}
                <div className="lg:col-span-5 flex flex-col gap-3">
                    {/* File Header Details */}
                    <div className="bg-red-950/10 border border-red-500/30 p-3 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-gray-400 text-[10px] font-bold flex items-center gap-1">
                                <HardDrive size={12} /> INGESTED ARTIFACT
                            </span>
                            {detectedMagic && (
                                <span className="bg-red-600 text-black font-bold text-[9px] px-2 py-0.5 rounded">
                                    {detectedMagic.category}
                                </span>
                            )}
                        </div>

                        {file ? (
                            <div className="space-y-1 text-[11px]">
                                <p className="text-white font-bold truncate">{file.name}</p>
                                <p className="text-gray-400">SIZE: <strong className="text-red-400">{(file.size / 1024).toFixed(2)} KB</strong> ({file.size} bytes)</p>
                                <p className="text-gray-400">SIGNATURE: <strong className="text-cyan-400">{detectedMagic ? detectedMagic.name : 'Unknown/Raw'}</strong></p>
                                {detectedMagic && <p className="text-[10px] text-gray-500">{detectedMagic.description}</p>}
                            </div>
                        ) : (
                            <p className="text-gray-500 text-xs py-4 text-center">No artifact ingested. Upload any file or load sample.</p>
                        )}
                    </div>

                    {/* Cryptographic Hashes */}
                    <div className="bg-black/80 border border-red-500/30 p-3 rounded-lg flex flex-col gap-2">
                        <span className="text-gray-400 text-[10px] font-bold flex items-center gap-1.5">
                            <ShieldAlert size={12} className="text-red-500" /> CRYPTOGRAPHIC HASHES (WEB CRYPTO)
                        </span>
                        {hashes ? (
                            <div className="space-y-2 text-[10px]">
                                <div>
                                    <span className="text-gray-500 block">SHA-256:</span>
                                    <div className="flex items-center justify-between bg-black/60 p-1.5 rounded border border-red-900/30">
                                        <code className="text-red-400 break-all">{hashes.sha256}</code>
                                    </div>
                                </div>
                                <div>
                                    <span className="text-gray-500 block">SHA-1:</span>
                                    <div className="flex items-center justify-between bg-black/60 p-1.5 rounded border border-red-900/30">
                                        <code className="text-yellow-400 break-all">{hashes.sha1}</code>
                                    </div>
                                </div>
                                <div>
                                    <span className="text-gray-500 block">MD5:</span>
                                    <div className="flex items-center justify-between bg-black/60 p-1.5 rounded border border-red-900/30">
                                        <code className="text-cyan-400 break-all">{hashes.md5}</code>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <p className="text-gray-500 text-[10px]">Awaiting file ingest...</p>
                        )}
                    </div>

                    {/* Shannon Entropy Metric */}
                    <div className="bg-black/80 border border-red-500/30 p-3 rounded-lg flex flex-col gap-1.5">
                        <div className="flex justify-between items-center text-[10px]">
                            <span className="text-gray-400 font-bold">SHANNON ENTROPY</span>
                            <span className="text-white font-bold">{entropy ?? '0.000'} / 8.000</span>
                        </div>
                        <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden border border-gray-700">
                            <div 
                                className={`h-full transition-all ${
                                    (entropy || 0) > 7.2 ? 'bg-red-500 shadow-[0_0_10px_red]' :
                                    (entropy || 0) > 5.5 ? 'bg-yellow-400' : 'bg-green-500'
                                }`} 
                                style={{ width: `${((entropy || 0) / 8) * 100}%` }}
                            />
                        </div>
                        <p className="text-[10px] text-gray-400">
                            {(entropy || 0) > 7.2 ? (
                                <strong className="text-red-400">⚠️ HIGH ENTROPY: Likely packed, encrypted, or compressed payload.</strong>
                            ) : (
                                <span className="text-green-400">✓ NORMAL ENTROPY: Plaintext or uncompressed structured binary.</span>
                            )}
                        </p>
                    </div>

                    {/* Discovered IOCs */}
                    {(extractedIocs.ips.length > 0 || extractedIocs.urls.length > 0) && (
                        <div className="bg-black/80 border border-red-500/30 p-3 rounded-lg space-y-1.5">
                            <span className="text-red-400 text-[10px] font-bold">DISCOVERED NETWORK ARTIFACTS</span>
                            {extractedIocs.ips.map((ip, i) => (
                                <div key={i} className="text-white text-[10px] bg-red-950/40 px-2 py-0.5 rounded flex justify-between">
                                    <span>IP: {ip}</span>
                                    <span className="text-gray-500">POTENTIAL IOC</span>
                                </div>
                            ))}
                            {extractedIocs.urls.map((url, i) => (
                                <div key={i} className="text-cyan-300 text-[10px] bg-cyan-950/40 px-2 py-0.5 rounded truncate">
                                    URL: {url}
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {/* Right Column: Interactive Hex View & AI Dossier */}
                <div className="lg:col-span-7 flex flex-col gap-3">
                    {/* Hex Viewer */}
                    <div className="bg-black/90 border border-red-500/30 rounded-lg p-2.5 flex flex-col flex-1 min-h-[260px]">
                        <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-red-900/30 text-[10px] text-gray-400">
                            <span className="flex items-center gap-1.5 text-red-400 font-bold">
                                <Binary size={12} /> INTERACTIVE HEX / ASCII DUMP
                            </span>
                            {rawBytes && (
                                <div className="flex items-center gap-2">
                                    <span>PAGE {hexPage + 1} OF {Math.max(1, Math.ceil(rawBytes.length / 256))}</span>
                                    <button 
                                        disabled={hexPage === 0} 
                                        onClick={() => setHexPage(p => p - 1)}
                                        className="px-1.5 py-0.5 bg-gray-800 disabled:opacity-30 rounded text-white"
                                    >
                                        &lt;
                                    </button>
                                    <button 
                                        disabled={!rawBytes || (hexPage + 1) * 256 >= rawBytes.length} 
                                        onClick={() => setHexPage(p => p + 1)}
                                        className="px-1.5 py-0.5 bg-gray-800 disabled:opacity-30 rounded text-white"
                                    >
                                        &gt;
                                    </button>
                                </div>
                            )}
                        </div>

                        {hexSlice.length > 0 ? (
                            <div className="overflow-x-auto flex-1 font-mono text-[10px] leading-relaxed">
                                {hexSlice.map((row, idx) => (
                                    <div key={idx} className="flex gap-3 hover:bg-red-950/30 px-1 py-0.5 rounded">
                                        <span className="text-gray-500 select-none">{row.offset}</span>
                                        <span className="text-red-400 flex-1">{row.hex}</span>
                                        <span className="text-gray-300 font-sans">{row.ascii}</span>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="flex-1 flex items-center justify-center text-gray-600 text-xs">
                                Ingest a file to display binary hex representation.
                            </div>
                        )}
                    </div>

                    {/* AI Assessment Action & Output */}
                    <div className="bg-black/90 border border-red-500/30 rounded-lg p-3 flex flex-col gap-2">
                        <div className="flex items-center justify-between">
                            <span className="text-red-400 text-xs font-bold flex items-center gap-1.5">
                                <Sparkles size={14} /> TACTICAL AI FORENSIC ASSESSMENT
                            </span>
                            <button 
                                onClick={handleGenerateAiReport} 
                                disabled={!file || isLoadingAi}
                                className="px-3 py-1 bg-red-600 hover:bg-red-500 disabled:opacity-50 text-black font-bold rounded text-[11px] flex items-center gap-1 transition-all"
                            >
                                {isLoadingAi ? <RefreshCw size={12} className="animate-spin" /> : <Sparkles size={12} />}
                                GENERATE DOSSIER
                            </button>
                        </div>
                        {aiReport && (
                            <div className="bg-black/60 p-2.5 rounded border border-red-900/30 text-xs text-gray-300 leading-relaxed whitespace-pre-wrap">
                                {aiReport}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ForensicAnalysisPanel;
