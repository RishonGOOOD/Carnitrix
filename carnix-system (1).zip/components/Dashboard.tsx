import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAppContext } from '../context';
import { Mode } from '../types';
import { 
    MessageCircle, ScanEye, Terminal, ShieldAlert, 
    Zap, Cpu, Brain, Globe, Crosshair, Radio,
    Compass, Activity, Volume2, VolumeX, Eye, Radar,
    ListTodo, FileText, Satellite, PlaneTakeoff, RefreshCw,
    ShieldCheck, Network, FolderKanban, FileCheck2, Fingerprint, Search
} from 'lucide-react';
import { playSound, triggerHaptic, isSoundMuted, toggleMuteSound } from '../utils/soundEffects';

export const Dashboard: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const [time, setTime] = useState(new Date());
    const [defconLevel, setDefconLevel] = useState<number>(2);
    const [isMuted, setIsMuted] = useState<boolean>(isSoundMuted());
    const [cpuLoad, setCpuLoad] = useState<number>(38);
    const [gpuLoad, setGpuLoad] = useState<number>(64);
    const [quickCommand, setQuickCommand] = useState('');
    const [nanobotDeploying, setNanobotDeploying] = useState(false);
    const [empActive, setEmpActive] = useState(false);

    // High frequency chrono
    useEffect(() => {
        const timer = setInterval(() => {
            setTime(new Date());
            setCpuLoad(prev => Math.min(95, Math.max(20, Math.floor(prev + (Math.random() * 8 - 4)))));
            setGpuLoad(prev => Math.min(99, Math.max(30, Math.floor(prev + (Math.random() * 10 - 5)))));
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const nav = useCallback((m: Mode) => {
        dispatch({ type: 'SET_MODE', payload: m });
        playSound('access');
        triggerHaptic('medium');
    }, [dispatch]);

    const cycleDefcon = () => {
        const next = defconLevel >= 5 ? 1 : defconLevel + 1;
        setDefconLevel(next);
        playSound(next >= 4 ? 'alert' : 'switch');
        triggerHaptic('heavy');
        dispatch({ 
            type: 'ADD_LOG', 
            payload: { 
                source: 'DEFCON', 
                message: `Defense condition escalated to DEFCON ${next}`, 
                level: next >= 4 ? 'error' : 'warn' 
            } 
        });
    };

    const handleSoundToggle = () => {
        const muted = toggleMuteSound();
        setIsMuted(muted);
        if (!muted) playSound('click');
    };

    const handleNanobotSweep = () => {
        setNanobotDeploying(true);
        playSound('scan');
        triggerHaptic('success');
        dispatch({ 
            type: 'ADD_LOG', 
            payload: { 
                source: 'SWARM', 
                message: '12,400 Nanobots deployed for perimeter spectral reconnaissance', 
                level: 'info' 
            } 
        });
        setTimeout(() => {
            setNanobotDeploying(false);
            playSound('success');
        }, 2500);
    };

    const handleToggleEmp = () => {
        setEmpActive(prev => !prev);
        playSound('alert');
        triggerHaptic('heavy');
        dispatch({ 
            type: 'ADD_LOG', 
            payload: { 
                source: 'SHIELD', 
                message: !empActive ? 'Defensive EMP Hardening Field Engaged' : 'EMP Field Normalizing', 
                level: 'warn' 
            } 
        });
    };

    const handleDirectCommandSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!quickCommand.trim()) return;
        const cmd = quickCommand.trim();
        setQuickCommand('');

        // Switch to chat and execute command
        dispatch({ type: 'SET_MODE', payload: Mode.Chat });
        playSound('process');
        triggerHaptic('light');

        // Let the chat handle it by updating profile activeChat
        setTimeout(() => {
            const profile = state.activeProfile;
            if (!profile) return;
            const chatId = profile.activeChatId || 'log-main';
            const userMsg = { id: Date.now(), sender: 'user' as const, text: cmd };
            const updated = profile.chats.map(c => 
                c.id === chatId ? { ...c, messages: [...c.messages, userMsg] } : c
            );
            dispatch({ type: 'UPDATE_PROFILE', payload: { chats: updated, activeChatId: chatId } });
        }, 100);
    };

    const coreSubsystems = useMemo(() => [
        { icon: Fingerprint, label: 'Unified OSINT', sub: 'Cross-Platform Feed', mode: Mode.UnifiedOsintAggregator, color: 'text-red-400', border: 'border-red-500/40 hover:border-red-500' },
        { icon: Activity, label: 'Tactical Tests', sub: 'Subsystem Health', mode: Mode.TacticalDiagnostics, color: 'text-emerald-400', border: 'border-emerald-500/40 hover:border-emerald-400' },
        { icon: ShieldCheck, label: 'Defensive Sec', sub: 'Audit & Rules', mode: Mode.SecurityEngine, color: 'text-emerald-400', border: 'border-emerald-500/40 hover:border-emerald-400' },
        { icon: ShieldAlert, label: 'Threat Intel', sub: 'Indicator Feeds', mode: Mode.ThreatIntel, color: 'text-amber-400', border: 'border-amber-500/40 hover:border-amber-400' },
        { icon: Network, label: 'Evidence Graph', sub: 'Knowledge Map', mode: Mode.EvidenceEngine, color: 'text-purple-400', border: 'border-purple-500/40 hover:border-purple-400' },
        { icon: FolderKanban, label: 'Case Workspace', sub: 'Live Investigations', mode: Mode.InvestigationWorkspace, color: 'text-blue-400', border: 'border-blue-500/40 hover:border-blue-400' },
        { icon: Terminal, label: 'GitHub Tools', sub: 'Registry & Adapters', mode: Mode.ToolDiscovery, color: 'text-yellow-400', border: 'border-yellow-500/40 hover:border-yellow-400' },
        { icon: MessageCircle, label: 'Neural AI Core', sub: 'Gemini Tactical', mode: Mode.Chat, color: 'text-cyan-400', border: 'border-cyan-500/40 hover:border-cyan-400' },
    ], []);

    const defconColors: Record<number, { bg: string; text: string; label: string; border: string }> = {
        1: { bg: 'bg-emerald-950/60', text: 'text-emerald-400', label: 'NORMAL READINESS', border: 'border-emerald-500/40' },
        2: { bg: 'bg-blue-950/60', text: 'text-blue-400', label: 'HEIGHTENED PATROL', border: 'border-blue-500/40' },
        3: { bg: 'bg-yellow-950/60', text: 'text-yellow-400', label: 'AIR FORCE READY', border: 'border-yellow-500/40' },
        4: { bg: 'bg-orange-950/60', text: 'text-orange-400', label: 'ARMED COMBAT ALERT', border: 'border-orange-500/40' },
        5: { bg: 'bg-red-950/90', text: 'text-red-400 animate-pulse', label: 'MAXIMUM DEFCON 5', border: 'border-red-500 shadow-[0_0_20px_rgba(255,0,0,0.5)]' },
    };

    const currentDefcon = defconColors[defconLevel];

    return (
        <div className="w-full h-full flex flex-col justify-between p-2 lg:p-4 font-[Rajdhani] bg-black/60 text-white overflow-y-auto scrollbar-carnix select-none">
            
            {/* TOP TELEMETRY HUD BAR */}
            <div className="w-full grid grid-cols-1 md:grid-cols-3 items-center gap-3 p-3 bg-red-950/20 border border-red-900/30 rounded-xl backdrop-blur-md">
                {/* Left: Tactical Chrono */}
                <div className="flex items-center gap-3">
                    <div className="w-2.5 h-10 bg-red-600 rounded-full shadow-[0_0_10px_red] animate-pulse"></div>
                    <div>
                        <div className="text-3xl font-black text-white tracking-widest font-orbitron drop-shadow-[0_0_10px_rgba(255,0,0,0.4)]">
                            {time.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-red-400 font-mono tracking-wider">
                            <span>CYCLE: {time.toISOString().slice(0, 10)}</span>
                            <span className="text-gray-500">//</span>
                            <span className="text-emerald-400 font-semibold">UPLINK_SYNCHRONIZED</span>
                        </div>
                    </div>
                </div>

                {/* Center: DEFCON Indicator (Interactive) */}
                <div className="flex justify-center">
                    <button 
                        onClick={cycleDefcon}
                        title="Click to cycle DEFCON level"
                        className={`flex items-center gap-3 px-4 py-2 rounded-lg border transition-all ${currentDefcon.bg} ${currentDefcon.border} hover:scale-105 active:scale-95`}
                    >
                        <ShieldAlert size={20} className={currentDefcon.text} />
                        <div className="text-left font-mono">
                            <div className={`text-xs font-black tracking-widest ${currentDefcon.text}`}>
                                DEFCON {defconLevel}
                            </div>
                            <div className="text-[9px] text-gray-400 tracking-wider">
                                {currentDefcon.label} (CLICK TO CYCLE)
                            </div>
                        </div>
                    </button>
                </div>

                {/* Right: Quick OS Status & Audio Controller */}
                <div className="flex items-center justify-end gap-3 font-mono text-[11px]">
                    <div className="hidden sm:flex flex-col text-right">
                        <span className="text-red-400 font-semibold tracking-wider">VAMPIRE CORE v7.4</span>
                        <span className="text-[9px] text-gray-400">STATUS: COMBAT READINESS</span>
                    </div>

                    <button 
                        onClick={handleSoundToggle}
                        title={isMuted ? "Unmute Tactical Audio" : "Mute Tactical Audio"}
                        className={`p-2 rounded-lg border transition-all ${isMuted ? 'bg-red-950/40 border-red-800 text-red-400' : 'bg-red-600/20 border-red-500 text-white shadow-[0_0_10px_rgba(255,0,0,0.3)]'}`}
                    >
                        {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                    </button>

                    <button 
                        onClick={() => nav(Mode.PanelsHub)}
                        className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black text-xs uppercase tracking-widest rounded transition-all shadow-[0_0_15px_rgba(255,0,0,0.4)]"
                    >
                        MATRIX [42]
                    </button>
                </div>
            </div>

            {/* MAIN TACTICAL WORKSPACE: 3-PANEL LAYOUT */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 my-3 flex-1 items-stretch min-h-[420px]">
                
                {/* LEFT FLANK: SYSTEM TELEMETRY & HARDWARE GAUGES (3 Cols) */}
                <div className="lg:col-span-3 flex flex-col justify-between gap-3 p-3 bg-red-950/10 border border-red-900/20 rounded-xl backdrop-blur-sm">
                    <div>
                        <div className="flex items-center justify-between border-b border-red-900/30 pb-1.5 mb-3">
                            <span className="text-xs font-black font-orbitron text-red-500 tracking-wider flex items-center gap-1.5">
                                <Cpu size={14} /> COMPUTATION LOAD
                            </span>
                            <span className="text-[10px] font-mono text-emerald-400">NOMINAL</span>
                        </div>

                        {/* CPU Bar */}
                        <div className="space-y-1.5 mb-3">
                            <div className="flex justify-between text-[11px] font-mono">
                                <span className="text-gray-400">NEURAL CORES (32X)</span>
                                <span className="text-red-400 font-bold">{cpuLoad}%</span>
                            </div>
                            <div className="w-full h-2 bg-red-950/60 rounded-full overflow-hidden border border-red-900/30">
                                <div 
                                    className="h-full bg-gradient-to-r from-red-600 to-amber-500 transition-all duration-500 rounded-full"
                                    style={{ width: `${cpuLoad}%` }}
                                ></div>
                            </div>
                        </div>

                        {/* GPU / Tensor Bar */}
                        <div className="space-y-1.5 mb-4">
                            <div className="flex justify-between text-[11px] font-mono">
                                <span className="text-gray-400">TENSOR BUS (160 TFLOPS)</span>
                                <span className="text-cyan-400 font-bold">{gpuLoad}%</span>
                            </div>
                            <div className="w-full h-2 bg-cyan-950/60 rounded-full overflow-hidden border border-cyan-900/30">
                                <div 
                                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-500 rounded-full"
                                    style={{ width: `${gpuLoad}%` }}
                                ></div>
                            </div>
                        </div>

                        {/* Nanobot Swarm Control */}
                        <div className="p-2.5 bg-red-950/30 border border-red-900/30 rounded-lg space-y-2">
                            <div className="flex justify-between items-center text-[10px] font-mono">
                                <span className="text-gray-300 font-bold flex items-center gap-1">
                                    <Activity size={12} className="text-amber-400" /> NANOBOT SWARM
                                </span>
                                <span className="text-amber-400">12,400 UNITS</span>
                            </div>
                            <p className="text-[10px] text-gray-400 leading-tight">
                                Autonomous micro-drones patrolling perimeter telemetry.
                            </p>
                            <button
                                onClick={handleNanobotSweep}
                                disabled={nanobotDeploying}
                                className="w-full py-1.5 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-mono text-[10px] tracking-wider rounded transition-all active:scale-95 flex items-center justify-center gap-1.5"
                            >
                                <RefreshCw size={11} className={nanobotDeploying ? 'animate-spin' : ''} />
                                {nanobotDeploying ? 'SWEEPING PERIMETER...' : 'DEPLOY RECON SWEEP'}
                            </button>
                        </div>
                    </div>

                    {/* Quick Access Utility Chips */}
                    <div className="space-y-1.5 border-t border-red-900/30 pt-2">
                        <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">TACTICAL CONSOLES</div>
                        <div className="grid grid-cols-2 gap-1.5">
                            <button 
                                onClick={() => nav(Mode.Terminal)}
                                className="px-2 py-1.5 bg-black/60 hover:bg-red-900/20 border border-red-900/40 rounded text-left text-[11px] font-mono text-gray-300 hover:text-white transition-all flex items-center gap-1.5"
                            >
                                <Terminal size={12} className="text-emerald-400" /> CLI Term
                            </button>
                            <button 
                                onClick={() => nav(Mode.Diagnostics)}
                                className="px-2 py-1.5 bg-black/60 hover:bg-red-900/20 border border-red-900/40 rounded text-left text-[11px] font-mono text-gray-300 hover:text-white transition-all flex items-center gap-1.5"
                            >
                                <Activity size={12} className="text-cyan-400" /> Audit
                            </button>
                        </div>
                    </div>
                </div>

                {/* CENTER: HOLOGRAPHIC QUANTUM CORE & RADIAL LAUNCHER (6 Cols) */}
                <div className="lg:col-span-6 flex flex-col items-center justify-center p-4 bg-gradient-to-b from-red-950/20 via-black/80 to-red-950/20 border border-red-900/30 rounded-xl relative overflow-hidden">
                    {/* Background Radar Rings */}
                    <div className="absolute w-[360px] h-[360px] sm:w-[440px] sm:h-[440px] border border-red-500/10 rounded-full animate-spin-slow pointer-events-none"></div>
                    <div className="absolute w-[260px] h-[260px] sm:w-[320px] sm:h-[320px] border border-red-500/15 border-dashed rounded-full pointer-events-none"></div>

                    {/* Center Core Button */}
                    <button 
                        onClick={() => nav(Mode.Chat)}
                        title="Engage CARNIX Neural Core"
                        className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-black/90 border-4 border-red-600 flex flex-col items-center justify-center z-10 group shadow-[0_0_50px_rgba(255,0,0,0.35)] hover:scale-105 active:scale-95 transition-transform"
                    >
                        <div className="p-4 sm:p-5 bg-red-600 rounded-2xl shadow-[0_0_30px_red] group-hover:rotate-[180deg] transition-transform duration-700">
                            <Zap size={36} className="text-black fill-black" />
                        </div>
                        <div className="text-[10px] sm:text-xs font-black text-red-400 tracking-[0.3em] mt-3 uppercase font-orbitron">
                            CARNIX_AI
                        </div>
                        <div className="text-[8px] font-mono text-gray-400 tracking-wider uppercase">
                            [NEURAL CORE]
                        </div>
                    </button>

                    {/* Surrounding Subsystem Grid (8 high-value subsystems) */}
                    <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-2 mt-6 z-10">
                        {coreSubsystems.map((sub, i) => {
                            const Icon = sub.icon;
                            return (
                                <button
                                    key={i}
                                    onClick={() => nav(sub.mode)}
                                    className={`p-2 sm:p-2.5 bg-black/75 border ${sub.border} rounded-lg flex flex-col items-center justify-center text-center transition-all hover:scale-105 active:scale-95 backdrop-blur-md shadow-lg`}
                                >
                                    <Icon size={18} className={`${sub.color} mb-1`} />
                                    <span className="text-[11px] font-black text-white tracking-wider uppercase">{sub.label}</span>
                                    <span className="text-[8px] font-mono text-gray-400 leading-none mt-0.5">{sub.sub}</span>
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* RIGHT FLANK: DEFENSIVE PROTOCOLS & RECENT DIRECTIVES (3 Cols) */}
                <div className="lg:col-span-3 flex flex-col justify-between gap-3 p-3 bg-red-950/10 border border-red-900/20 rounded-xl backdrop-blur-sm">
                    <div>
                        <div className="flex items-center justify-between border-b border-red-900/30 pb-1.5 mb-3">
                            <span className="text-xs font-black font-orbitron text-red-500 tracking-wider flex items-center gap-1.5">
                                <ShieldAlert size={14} /> DEFENSE PROTOCOLS
                            </span>
                            <span className="text-[10px] font-mono text-red-400">ACTIVE</span>
                        </div>

                        {/* Quick Protocols */}
                        <div className="space-y-2">
                            {/* Ghost Protocol Toggle */}
                            <button
                                onClick={() => {
                                    dispatch({ type: 'TOGGLE_STEALTH' });
                                    playSound(state.isStealthMode ? 'access' : 'alert');
                                    triggerHaptic('medium');
                                }}
                                className={`w-full p-2 rounded-lg border text-left flex items-center justify-between font-mono text-xs transition-all ${state.isStealthMode ? 'bg-cyan-950/50 border-cyan-500 text-cyan-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]' : 'bg-black/60 border-red-900/40 text-gray-300 hover:border-red-600'}`}
                            >
                                <div className="flex items-center gap-2">
                                    <Eye size={14} className={state.isStealthMode ? 'text-cyan-400' : 'text-red-500'} />
                                    <span>GHOST CLOAK</span>
                                </div>
                                <span className="text-[10px] font-bold">{state.isStealthMode ? 'ENGAGED' : 'OFF'}</span>
                            </button>

                            {/* EMP Shielding */}
                            <button
                                onClick={handleToggleEmp}
                                className={`w-full p-2 rounded-lg border text-left flex items-center justify-between font-mono text-xs transition-all ${empActive ? 'bg-amber-950/50 border-amber-500 text-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.3)]' : 'bg-black/60 border-red-900/40 text-gray-300 hover:border-red-600'}`}
                            >
                                <div className="flex items-center gap-2">
                                    <Radio size={14} className={empActive ? 'text-amber-400' : 'text-red-500'} />
                                    <span>EMP HARDENING</span>
                                </div>
                                <span className="text-[10px] font-bold">{empActive ? 'DEFENSE MAX' : 'STANDBY'}</span>
                            </button>

                            {/* Overclock Compute */}
                            <button
                                onClick={() => {
                                    setCpuLoad(98);
                                    setGpuLoad(99);
                                    playSound('access');
                                    triggerHaptic('heavy');
                                }}
                                className="w-full p-2 bg-black/60 hover:bg-red-900/30 border border-red-900/40 hover:border-red-500 rounded-lg text-left flex items-center justify-between font-mono text-xs text-gray-300 hover:text-white transition-all"
                            >
                                <div className="flex items-center gap-2">
                                    <Zap size={14} className="text-yellow-400" />
                                    <span>CORE OVERCLOCK</span>
                                </div>
                                <span className="text-[10px] text-yellow-400 font-bold">BOOST</span>
                            </button>
                        </div>
                    </div>

                    {/* Directives & Recent Logs */}
                    <div className="border-t border-red-900/30 pt-2 space-y-1.5">
                        <div className="flex justify-between items-center text-[9px] font-mono text-gray-400 uppercase tracking-widest">
                            <span>DIRECTIVE LOG</span>
                            <button onClick={() => nav(Mode.Notes)} className="hover:text-red-400 underline">Intel DB</button>
                        </div>
                        <div className="bg-black/60 border border-red-900/30 p-2 rounded text-[10px] font-mono text-gray-400 space-y-1">
                            <div className="text-emerald-400 truncate">• [SEC] Vampire Core kernel initialized</div>
                            <div className="text-cyan-400 truncate">• [AI] Substrate uplink ready (Gemini 2.5)</div>
                            <div className="text-amber-400 truncate">• [DEF] Radar sweeps reporting 0 breaches</div>
                        </div>
                    </div>
                </div>

            </div>

            {/* INTEGRATED HUD DIRECTIVE COMMAND BAR */}
            <form onSubmit={handleDirectCommandSubmit} className="w-full mt-2 flex flex-col sm:flex-row items-center gap-2 p-2 bg-red-950/20 border border-red-900/40 rounded-xl backdrop-blur-md">
                <div className="flex items-center gap-2 text-red-500 font-mono text-xs pl-2 font-bold whitespace-nowrap">
                    <Crosshair size={16} className="animate-spin-slow text-red-500" />
                    <span>[DIRECTIVE]:</span>
                </div>
                <input 
                    type="text"
                    value={quickCommand}
                    onChange={(e) => setQuickCommand(e.target.value)}
                    placeholder="Enter tactical command, query Gemini Tactical Core, or test DEFCON..."
                    className="flex-1 w-full bg-black/80 border border-red-900/50 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 font-mono focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
                />
                <div className="flex items-center gap-1.5 w-full sm:w-auto">
                    <button
                        type="button"
                        onClick={() => {
                            setQuickCommand('HELP');
                        }}
                        className="px-2.5 py-2 bg-red-950/50 hover:bg-red-900/50 border border-red-900/50 text-red-400 text-xs font-mono rounded"
                    >
                        HELP
                    </button>
                    <button
                        type="button"
                        onClick={() => {
                            setQuickCommand('SYSTEM DIAGNOSTIC');
                        }}
                        className="px-2.5 py-2 bg-red-950/50 hover:bg-red-900/50 border border-red-900/50 text-red-400 text-xs font-mono rounded"
                    >
                        DIAG
                    </button>
                    <button
                        type="submit"
                        className="px-4 py-2 bg-red-600 hover:bg-red-500 text-black font-black text-xs font-mono uppercase tracking-widest rounded shadow-[0_0_12px_rgba(255,0,0,0.5)] transition-all active:scale-95"
                    >
                        TRANSMIT
                    </button>
                </div>
            </form>

            <style>{`
                @keyframes spin-slow { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
                .animate-spin-slow { animation: spin-slow 45s linear infinite; }
            `}</style>
        </div>
    );
};

export default Dashboard;
