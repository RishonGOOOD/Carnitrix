import React, { useState } from 'react';
import { TrendingUp, Send, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

const EconomicForecasterPanel: React.FC = () => {
    const { state } = useAppContext();
    const [query, setQuery] = useState('NASDAQ:GOOGL');
    const [forecast, setForecast] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleForecast = async () => {
        if (!query.trim() || !state.activeProfile) return;
        setIsLoading(true);
        setForecast(null);
        try {
            const prompt = `Provide a detailed market analysis and future forecast for "${query}". Use real-time data if possible. Include key metrics, recent news, and a short-term outlook (bullish, bearish, or neutral).`;
            const res = await getAIResponse(prompt, Mode.EconomicForecaster, { ...state.activeProfile.aiSettings, useSearchGrounding: true });
            setForecast(res.text);
        } catch (e) {
            setForecast('Failed to retrieve market data.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <TrendingUp size={14}/> ECONOMIC FORECASTER
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="w-full lg:w-1/3 border-b lg:border-b-0 lg:border-r border-[var(--color-panel-header-border)] flex flex-col p-4 gap-4">
                    <p className="text-xs text-gray-400">Enter a stock ticker (e.g., NASDAQ:TSLA) or an economic sector (e.g., renewable energy sector) for analysis.</p>
                    <input
                        type="text"
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        className="w-full hud-input text-sm"
                    />
                    <button onClick={handleForecast} disabled={isLoading || !query.trim()} className="w-full hud-button flex items-center justify-center gap-2">
                        {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                        GET FORECAST
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 bg-black/20">
                    <h3 className="text-sm font-bold text-[var(--color-primary)] mb-2">MARKET ANALYSIS</h3>
                    {isLoading && <Loader2 className="animate-spin"/>}
                    {forecast ? (
                        <pre className="whitespace-pre-wrap font-mono text-sm text-gray-300">{forecast}</pre>
                    ) : (
                        <p className="text-sm text-gray-500">Awaiting query...</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EconomicForecasterPanel;
