import React, { useState, useEffect, useRef } from 'react';
import { Hourglass, AlertTriangle } from 'lucide-react';

const TemporalAnomalyDetectorPanel: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [anomalies, setAnomalies] = useState<{ time: string; signature: string }[]>([]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        let time = 0;

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        const draw = () => {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.lineWidth = 2;
            
            // Base timeline wave
            ctx.strokeStyle = `rgba(255, 0, 60, 0.5)`;
            ctx.beginPath();
            ctx.moveTo(0, canvas.height / 2);
            for (let x = 0; x < canvas.width; x++) {
                const y = canvas.height / 2 + Math.sin(x * 0.02 + time) * 20 * (1 + Math.sin(time * 0.5) * 0.3);
                ctx.lineTo(x, y);
            }
            ctx.stroke();

            // Anomaly detection and rendering
            if (Math.random() < 0.01) { // Chance of anomaly
                const signature = `SIG-${(Math.random() * 1000).toFixed(0)}`;
                setAnomalies(prev => [{ time: new Date().toLocaleTimeString(), signature }, ...prev.slice(0, 4)]);
                
                // Visual glitch
                for(let i = 0; i < 5; i++) {
                    ctx.strokeStyle = `rgba(0, 255, 255, ${Math.random() * 0.8})`;
                    ctx.lineWidth = Math.random() * 3;
                    const glitchX = Math.random() * canvas.width;
                    const glitchY = Math.random() * canvas.height;
                    const glitchHeight = Math.random() * 50;
                    ctx.beginPath();
                    ctx.moveTo(glitchX, glitchY - glitchHeight);
                    ctx.lineTo(glitchX, glitchY + glitchHeight);
                    ctx.stroke();
                }
            }

            time += 0.05;
            animationFrameId = requestAnimationFrame(draw);
        };
        draw();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, []);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Hourglass size={14}/> TEMPORAL ANOMALY DETECTOR
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="flex-1 relative bg-black">
                    <canvas ref={canvasRef} className="w-full h-full" />
                    <div className="absolute top-2 left-2 text-xs font-mono text-green-400 bg-black/50 p-1 rounded animate-pulse">
                        STATUS: SCANNING TIMELINE
                    </div>
                </div>
                <div className="w-full lg:w-1/3 border-t lg:border-t-0 lg:border-l border-[var(--color-panel-header-border)] flex flex-col">
                    <div className="hud-panel-header">
                        <AlertTriangle size={14} /> ANOMALY LOG
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 space-y-2 bg-black/20">
                        {anomalies.length === 0 && <p className="text-xs text-gray-500 p-2">No anomalies detected.</p>}
                        {anomalies.map((anomaly, i) => (
                            <div key={i} className="bg-yellow-900/20 border border-yellow-500/30 rounded p-2 font-mono text-xs animate-enter">
                                <p className="text-yellow-400 font-bold">Time: {anomaly.time}</p>
                                <p className="text-gray-300">Signature: {anomaly.signature}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TemporalAnomalyDetectorPanel;
