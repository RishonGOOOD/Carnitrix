
import React, { useState, useEffect } from 'react';
import { Box, X, Package, ShieldCheck, Trash2, Plus, Search, Zap, Copy } from 'lucide-react';
import { useAppContext } from '../context';
import { NexusLink } from '../types';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { launchAndroidApp, requestAppSelection } from '../utils/nativeBridge';

const AppLauncherPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const links = state.activeProfile?.nexusLinks || [];
    const [isAdding, setIsAdding] = useState(false);
    const [search, setSearch] = useState('');
    const [newName, setNewName] = useState('');
    const [newPackage, setNewPackage] = useState('');

    const handleAddLink = (e: React.FormEvent) => {
        e.preventDefault();
        const pkg = newPackage.trim().toLowerCase();
        if (!newName.trim() || !pkg) return;

        const newLink: NexusLink = {
            id: `link-${Date.now()}`,
            name: newName.trim().toUpperCase(),
            packageName: pkg,
            createdAt: Date.now()
        };

        dispatch({ type: 'UPDATE_PROFILE', payload: { nexusLinks: [...links, newLink] }});
        setNewName(''); setNewPackage(''); setIsAdding(false);
        playSound('success');
    };

    const handleLaunch = (link: NexusLink) => {
        dispatch({ type: 'ADD_LOG', payload: { source: 'NEXUS', message: `Tunneling: ${link.packageName}`, level: 'success' }});
        launchAndroidApp(link.packageName);
    };

    const deleteLink = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        dispatch({ type: 'UPDATE_PROFILE', payload: { nexusLinks: links.filter(l => l.id !== id) }});
        playSound('error');
    };

    const filtered = links.filter(l => l.name.toLowerCase().includes(search.toLowerCase()));

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani] relative animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex-shrink-0 bg-black/60 border-b border-red-600/30 p-3 rounded-xl flex flex-col lg:flex-row justify-between items-center gap-3">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-red-600/10 border border-red-600 rounded flex items-center justify-center text-red-500">
                        <Box size={20} className="animate-pulse" />
                    </div>
                    <div>
                        <h2 className="text-sm font-black text-white uppercase tracking-widest leading-none">Nexus Link</h2>
                        <div className="text-[7px] font-mono text-gray-500 uppercase tracking-widest mt-1">
                             Hardware Bridge // Active: {links.length}
                        </div>
                    </div>
                </div>
                <div className="flex gap-2 w-full lg:w-auto">
                    <input 
                        value={search} 
                        onChange={e => setSearch(e.target.value)} 
                        placeholder="FILTER_NODES..." 
                        className="flex-1 lg:w-36 bg-black/60 border border-gray-800 rounded px-3 py-1 text-[9px] text-white outline-none focus:border-red-600" 
                    />
                    <button onClick={() => setIsAdding(true)} className="px-3 py-1 bg-red-600 text-black font-black text-[9px] rounded uppercase tracking-widest hover:bg-white active:scale-95 transition-all">
                        <Plus size={10} className="inline mr-1"/> NEW_ID
                    </button>
                </div>
            </div>

            <div className="flex-1 bg-black/30 border border-white/5 rounded-2xl overflow-y-auto p-3 scrollbar-carnix">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-20">
                    {filtered.map((link, i) => (
                        <div key={link.id} className="relative group animate-in zoom-in duration-300" style={{ animationDelay: `${i * 50}ms` }}>
                            <button 
                                onClick={() => handleLaunch(link)}
                                className="w-full p-6 bg-black/60 border border-white/5 rounded-2xl flex flex-col items-center justify-center gap-3 transition-all hover:scale-105 active:scale-95 hover:border-red-600/50 shadow-2xl relative overflow-hidden"
                            >
                                <div className="absolute inset-0 bg-red-600/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-white/5 border border-white/10 group-hover:bg-red-600 transition-all group-hover:shadow-[0_0_20px_red]">
                                    <Package size={24} className="text-red-600 group-hover:text-black transition-colors" />
                                </div>
                                <div className="text-center z-10">
                                    <div className="text-[10px] font-black text-white uppercase truncate px-1 tracking-widest">{link.name}</div>
                                    <div className="text-[7px] font-mono text-gray-600 truncate px-1 mt-1">{link.packageName}</div>
                                </div>
                                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Zap size={10} className="text-red-500 animate-pulse" />
                                </div>
                            </button>
                            <button onClick={(e) => deleteLink(e, link.id)} className="absolute -top-1 -right-1 p-1.5 bg-red-900 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white text-white hover:text-black shadow-lg">
                                <X size={10}/>
                            </button>
                        </div>
                    ))}
                </div>
            </div>

            {isAdding && (
                <div className="absolute inset-0 z-50 bg-black/95 backdrop-blur-xl p-4 flex items-center justify-center animate-in zoom-in duration-300">
                    <form onSubmit={handleAddLink} className="w-full max-w-sm border border-red-600/50 p-6 bg-black rounded-2xl space-y-4 shadow-[0_0_50px_rgba(255,0,0,0.2)]">
                        <div className="flex justify-between items-center border-b border-white/10 pb-2">
                            <h3 className="text-xs font-black text-white uppercase tracking-widest">Construct Nexus Link</h3>
                            <button type="button" onClick={() => setIsAdding(false)} className="text-gray-500 hover:text-white"><X size={18}/></button>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <label className="text-[8px] text-gray-500 font-black uppercase mb-1">Display Label</label>
                                <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="e.g. WHATSAPP" className="w-full bg-black border border-gray-800 p-2 text-xs text-white rounded outline-none focus:border-red-600" />
                            </div>
                            <div>
                                <label className="text-[8px] text-gray-500 font-black uppercase mb-1">Android Package Name</label>
                                <div className="flex gap-2">
                                    <input value={newPackage} onChange={e => setNewPackage(e.target.value)} placeholder="com.example.app" className="flex-1 bg-black border border-gray-800 p-2 text-xs text-white rounded outline-none focus:border-red-600 font-mono" />
                                    <button type="button" onClick={() => requestAppSelection()} className="px-3 bg-white/5 border border-white/10 text-cyan-400 rounded hover:bg-white/10">
                                        <Search size={14}/>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <button type="submit" className="w-full py-3 bg-red-600 text-black font-black text-[10px] uppercase tracking-widest hover:bg-white rounded transition-all">
                            REGISTER_NODE
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};

export default AppLauncherPanel;
