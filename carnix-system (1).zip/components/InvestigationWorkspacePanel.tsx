import React, { useState } from 'react';
import { InvestigationService } from '../services/investigationService';
import { InvestigationCase, OsintResult, SecurityFinding } from '../types';
import { 
  FolderKanban, Plus, Clock, Target, ShieldAlert, 
  FileText, CheckCircle2, User, RefreshCw, Send, AlertTriangle
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

interface InvestigationWorkspacePanelProps {
  onNavigateToReport?: () => void;
  onRunTargetRecon?: (target: string) => void;
}

export const InvestigationWorkspacePanel: React.FC<InvestigationWorkspacePanelProps> = ({
  onNavigateToReport,
  onRunTargetRecon
}) => {
  const [cases, setCases] = useState<InvestigationCase[]>(InvestigationService.getCases());
  const [activeCase, setActiveCase] = useState<InvestigationCase | undefined>(InvestigationService.getActiveCase());
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'TIMELINE' | 'FINDINGS' | 'EVIDENCE' | 'NOTES'>('OVERVIEW');
  
  // New Case Modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newScope, setNewScope] = useState('');
  const [newTargets, setNewTargets] = useState('');

  // Add Target State
  const [targetInput, setTargetInput] = useState('');
  const [noteText, setNoteText] = useState(activeCase?.notes || '');

  const refreshCase = () => {
    setCases(InvestigationService.getCases());
    setActiveCase(InvestigationService.getActiveCase());
  };

  const handleSelectCase = (id: string) => {
    InvestigationService.setActiveCaseId(id);
    const c = InvestigationService.getActiveCase();
    setActiveCase(c);
    setNoteText(c?.notes || '');
    playSound('click');
    triggerHaptic('light');
  };

  const handleCreateCase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    playSound('access');
    const targets = newTargets.split(',').map(t => t.trim()).filter(Boolean);
    const created = InvestigationService.createNewCase(newTitle.trim(), newScope.trim(), targets);
    setCases(InvestigationService.getCases());
    setActiveCase(created);
    setShowCreateModal(false);
    setNewTitle('');
    setNewScope('');
    setNewTargets('');
  };

  const handleAddTarget = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetInput.trim() || !activeCase) return;
    const cleaned = targetInput.trim();
    InvestigationService.updateActiveCase(c => ({
      ...c,
      targets: Array.from(new Set([...c.targets, cleaned])),
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: Date.now(),
          dateStr: new Date().toLocaleString(),
          title: `Target Added: ${cleaned}`,
          description: `Analyst added ${cleaned} to investigation perimeter.`,
          type: 'NOTE',
          confidence: 'CONFIRMED',
          source: 'Analyst'
        },
        ...c.timeline
      ]
    }));
    setTargetInput('');
    refreshCase();
    playSound('success');
  };

  const handleSaveNotes = () => {
    InvestigationService.updateActiveCase(c => ({
      ...c,
      notes: noteText
    }));
    playSound('success');
    refreshCase();
  };

  if (!activeCase) {
    return <div className="p-10 text-center text-gray-500 font-mono">No active investigation case.</div>;
  }

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-red-950/20 border border-red-900/30 rounded-xl">
        <div className="flex items-center gap-3">
          <span className="p-2 bg-red-600/20 border border-red-500 rounded-lg text-red-400">
            <FolderKanban size={20} />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black font-orbitron text-white tracking-wider">
                {activeCase.title}
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-red-950/80 text-red-400 border border-red-800">
                {activeCase.status}
              </span>
            </div>
            <p className="text-xs text-gray-400 font-mono mt-0.5">
              Case ID: <span className="text-cyan-400">{activeCase.id}</span> | Lead: <span className="text-gray-300">{activeCase.leadAnalyst}</span>
            </p>
          </div>
        </div>

        {/* Case Switcher & Actions */}
        <div className="flex items-center gap-2">
          <select
            value={activeCase.id}
            onChange={(e) => handleSelectCase(e.target.value)}
            className="py-1.5 px-3 bg-black border border-red-900/40 rounded-lg text-xs font-mono text-gray-300 focus:outline-none"
          >
            {cases.map(c => (
              <option key={c.id} value={c.id}>{c.title}</option>
            ))}
          </select>

          <button
            onClick={() => setShowCreateModal(true)}
            className="flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded transition-all shadow-[0_0_15px_rgba(255,0,0,0.4)]"
          >
            <Plus size={14} /> NEW CASE
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex gap-1 bg-black/60 p-1 rounded-lg border border-red-900/30 font-mono text-xs overflow-x-auto">
        {(['OVERVIEW', 'TIMELINE', 'FINDINGS', 'EVIDENCE', 'NOTES'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              playSound('click');
            }}
            className={`px-3 py-1.5 rounded transition-all font-bold whitespace-nowrap ${
              activeTab === tab 
                ? 'bg-red-600 text-black shadow-[0_0_10px_rgba(255,0,0,0.5)]' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono">
            <div className="p-3 bg-black/60 border border-white/5 rounded-xl">
              <div className="text-gray-400 text-[10px]">ACTIVE TARGETS</div>
              <div className="text-2xl font-black text-cyan-400 font-orbitron">{activeCase.targets.length}</div>
            </div>
            <div className="p-3 bg-black/60 border border-white/5 rounded-xl">
              <div className="text-gray-400 text-[10px]">EVIDENCE RECORDS</div>
              <div className="text-2xl font-black text-emerald-400 font-orbitron">{activeCase.evidence.length}</div>
            </div>
            <div className="p-3 bg-black/60 border border-white/5 rounded-xl">
              <div className="text-gray-400 text-[10px]">SECURITY FINDINGS</div>
              <div className="text-2xl font-black text-amber-400 font-orbitron">{activeCase.findings.length}</div>
            </div>
            <div className="p-3 bg-black/60 border border-white/5 rounded-xl">
              <div className="text-gray-400 text-[10px]">TIMELINE EVENTS</div>
              <div className="text-2xl font-black text-white font-orbitron">{activeCase.timeline.length}</div>
            </div>
          </div>

          {/* Scope and Targets */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Scope Box */}
            <div className="p-4 bg-black/60 border border-red-900/30 rounded-xl font-mono text-xs space-y-2">
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <Target size={14} className="text-red-500" /> AUTHORIZED INVESTIGATION SCOPE
              </div>
              <p className="text-gray-300 leading-relaxed bg-black/40 p-3 rounded border border-white/5">
                {activeCase.scope}
              </p>
            </div>

            {/* Target Management Box */}
            <div className="p-4 bg-black/60 border border-red-900/30 rounded-xl font-mono text-xs space-y-3">
              <div className="text-sm font-bold text-white flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Target size={14} className="text-cyan-400" /> PERIMETER TARGETS ({activeCase.targets.length})
                </span>
              </div>

              <form onSubmit={handleAddTarget} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add domain, IP, or username to case..."
                  value={targetInput}
                  onChange={(e) => setTargetInput(e.target.value)}
                  className="flex-1 p-2 bg-black border border-red-900/40 rounded text-white focus:outline-none focus:border-red-500 text-xs"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-bold uppercase rounded"
                >
                  ADD
                </button>
              </form>

              <div className="flex flex-wrap gap-2 pt-1">
                {activeCase.targets.map(t => (
                  <div key={t} className="flex items-center gap-2 px-2.5 py-1 bg-red-950/40 border border-red-900/40 rounded text-xs font-mono text-white">
                    <span>{t}</span>
                    {onRunTargetRecon && (
                      <button
                        onClick={() => onRunTargetRecon(t)}
                        title="Run Universal Reconnaissance"
                        className="text-cyan-400 hover:text-cyan-300"
                      >
                        <RefreshCw size={11} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TIMELINE */}
      {activeTab === 'TIMELINE' && (
        <div className="p-4 bg-black/60 border border-red-900/30 rounded-xl font-mono text-xs space-y-3">
          <div className="text-sm font-bold text-white flex items-center gap-2">
            <Clock size={14} className="text-red-500" /> CHRONOLOGICAL INVESTIGATION TIMELINE
          </div>
          <div className="space-y-2 border-l-2 border-red-900/60 pl-4 ml-2">
            {activeCase.timeline.map(item => (
              <div key={item.id} className="relative space-y-1 pb-2">
                <div className="absolute -left-[23px] top-1 w-2.5 h-2.5 rounded-full bg-red-600 ring-4 ring-black" />
                <div className="flex justify-between items-center text-[11px]">
                  <span className="font-bold text-cyan-400">{item.title}</span>
                  <span className="text-gray-500">{item.dateStr}</span>
                </div>
                <p className="text-gray-300 text-[11px]">{item.description}</p>
                <div className="text-[10px] text-gray-500">Source: {item.source} | Confidence: {item.confidence}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: FINDINGS */}
      {activeTab === 'FINDINGS' && (
        <div className="space-y-3 font-mono text-xs">
          <div className="text-sm font-bold text-white">CASE FINDINGS & VULNERABILITIES ({activeCase.findings.length})</div>
          {activeCase.findings.length === 0 ? (
            <div className="p-8 text-center text-gray-500 bg-black/40 rounded-xl border border-white/5">
              No defensive vulnerabilities logged yet for this case. Run a defensive security audit from the Security Engine to populate findings.
            </div>
          ) : (
            activeCase.findings.map(f => (
              <div key={f.id} className="p-3 bg-red-950/10 border border-red-900/30 rounded-lg space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white">{f.title}</span>
                  <span className="text-red-400 font-bold">{f.severity}</span>
                </div>
                <div className="text-gray-400">{f.description}</div>
                <div className="text-emerald-400">Remediation: {f.remediation}</div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 4: EVIDENCE */}
      {activeTab === 'EVIDENCE' && (
        <div className="space-y-3 font-mono text-xs">
          <div className="text-sm font-bold text-white">COLLECTED OSINT & TELEMETRY EVIDENCE ({activeCase.evidence.length})</div>
          {activeCase.evidence.length === 0 ? (
            <div className="p-8 text-center text-gray-500 bg-black/40 rounded-xl border border-white/5">
              No evidence records saved yet. Run OSINT searches in the Deep OSINT AI or Omni Search to link evidence.
            </div>
          ) : (
            activeCase.evidence.map(e => (
              <div key={e.id} className="p-3 bg-black/60 border border-red-900/30 rounded-lg space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-cyan-400">{e.category}: {e.query}</span>
                  <span className="text-emerald-400 font-bold">{e.confidence}</span>
                </div>
                <p className="text-gray-300">{e.evidence}</p>
                <div className="text-[10px] text-gray-500">Source: {e.source} | Method: {e.processingMethod}</div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 5: NOTES */}
      {activeTab === 'NOTES' && (
        <div className="space-y-3 font-mono text-xs">
          <div className="flex justify-between items-center">
            <span className="text-sm font-bold text-white">ANALYST SCRATCHPAD & INVESTIGATION NOTES</span>
            <button
              onClick={handleSaveNotes}
              className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black uppercase rounded"
            >
              SAVE NOTES
            </button>
          </div>
          <textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            rows={12}
            placeholder="Record analyst observations, threat actor hypotheses, timeline notes..."
            className="w-full p-4 bg-black/80 border border-red-900/40 rounded-xl text-gray-200 focus:outline-none focus:border-red-500 font-mono"
          />
        </div>
      )}

      {/* Create Case Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0a0003] border border-red-600/60 rounded-xl p-5 space-y-4 font-mono">
            <div className="flex justify-between items-center text-white border-b border-red-900/40 pb-2">
              <span className="font-bold text-sm tracking-wider text-red-500 flex items-center gap-2">
                <Plus size={16} /> INITIALIZE INVESTIGATION CASE
              </span>
              <button onClick={() => setShowCreateModal(false)} className="text-gray-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateCase} className="space-y-3 text-xs">
              <div>
                <label className="block text-gray-400 mb-1">Case Title:</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Operation Titan Perimeter Audit"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-white focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-400 mb-1">Rules of Engagement / Scope:</label>
                <textarea
                  required
                  rows={3}
                  placeholder="Authorized public passive OSINT and defensive DNS/TLS auditing."
                  value={newScope}
                  onChange={(e) => setNewScope(e.target.value)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-white focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-gray-400 mb-1">Initial Targets (comma-separated):</label>
                <input
                  type="text"
                  placeholder="target.org, 198.51.100.1, api.target.org"
                  value={newTargets}
                  onChange={(e) => setNewTargets(e.target.value)}
                  className="w-full p-2 bg-black border border-red-900/40 rounded text-white focus:border-red-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 bg-gray-800 text-gray-400 rounded hover:text-white"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black uppercase tracking-wider rounded"
                >
                  CREATE CASE
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default InvestigationWorkspacePanel;
