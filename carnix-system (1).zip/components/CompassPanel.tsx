
import React from 'react';
import Compass from './Compass';
import { MapPin, Globe, LocateFixed } from 'lucide-react';
import { Address } from '../types';

interface CompassPanelProps {
    geolocation?: { latitude: number; longitude: number; altitude?: number; };
    address?: Address;
}

const CompassPanel: React.FC<CompassPanelProps> = ({ geolocation, address }) => {
    return (
        <div className="w-full h-full flex flex-col md:flex-row items-center justify-center relative bg-[radial-gradient(circle_at_center,var(--color-primary)_0%,transparent_70%)] bg-opacity-5 p-4 gap-4">
            {/* Info Sidebar (Top on portrait, Left on landscape) */}
            <div className="w-full md:w-64 flex flex-row md:flex-col justify-between md:justify-start gap-4 flex-shrink-0 z-10">
                 <div className="flex-1 bg-black/40 p-3 rounded border border-[var(--color-panel-border)]">
                    <h3 className="text-xs font-bold text-[var(--color-primary)] flex items-center gap-2 border-b border-white/10 pb-2 mb-2">
                        <MapPin size={14} /> GPS TELEMETRY
                    </h3>
                    <div className="font-mono text-xs space-y-2 text-[var(--color-text-muted)]">
                        <div className="flex justify-between border-b border-white/5 pb-1"><span>LAT</span> <span className="text-white">{geolocation?.latitude.toFixed(6) ?? "---"}</span></div>
                        <div className="flex justify-between border-b border-white/5 pb-1"><span>LON</span> <span className="text-white">{geolocation?.longitude.toFixed(6) ?? "---"}</span></div>
                        <div className="flex justify-between"><span>ALT</span> <span className="text-white">{geolocation?.altitude ? `${Math.round(geolocation.altitude)}m` : "---"}</span></div>
                    </div>
                </div>

                <div className="flex-1 bg-black/40 p-3 rounded border border-[var(--color-panel-border)]">
                    <h3 className="text-xs font-bold text-[var(--color-primary)] flex items-center gap-2 border-b border-white/10 pb-2 mb-2">
                        <Globe size={14} /> SECTOR
                    </h3>
                    <div className="font-mono text-xs space-y-1 text-[var(--color-text-muted)]">
                        <div className="text-white font-bold text-sm truncate">{address?.district || address?.city || "SEARCHING..."}</div>
                        <div className="text-[10px] uppercase tracking-widest">{address?.country || "UNKNOWN REGION"}</div>
                    </div>
                </div>
            </div>

            {/* Compass Center */}
            <div className="flex-1 flex items-center justify-center relative w-full h-full max-h-[80vh]">
                <div className="absolute top-0 right-0 bg-black/40 p-2 rounded border border-[var(--color-panel-border)] text-right hidden md:block">
                    <div className="text-[10px] text-[var(--color-text-muted)] flex items-center gap-2 justify-end">
                        <LocateFixed size={12} className={geolocation ? "text-green-500" : "text-red-500"} />
                        {geolocation ? "SIGNAL LOCKED" : "SEARCHING"}
                    </div>
                    <div className="flex gap-0.5 justify-end mt-1">
                        <div className={`w-1 h-2 ${geolocation ? 'bg-[var(--color-primary)]' : 'bg-gray-700'}`}></div>
                        <div className={`w-1 h-3 ${geolocation ? 'bg-[var(--color-primary)]' : 'bg-gray-700'}`}></div>
                        <div className={`w-1 h-4 ${geolocation ? 'bg-[var(--color-primary)]' : 'bg-gray-700'}`}></div>
                        <div className={`w-1 h-5 ${geolocation ? 'bg-[var(--color-primary)]/30' : 'bg-gray-700'}`}></div>
                    </div>
                 </div>
                
                <div className="w-full h-full flex items-center justify-center scale-90 md:scale-100">
                    <Compass fullSize={true} />
                </div>
            </div>
        </div>
    );
};

export default CompassPanel;
