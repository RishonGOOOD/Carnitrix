
import React from 'react';
import { ShieldAlert, Globe, Activity, Terminal } from 'lucide-react';

const IntelPanel: React.FC = () => (
    <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
        <div className="bg-black/60 border border-white/10 p-3 rounded-lg flex justify-between items-center">
            <div className="flex items-center gap-3">
                <Globe size={20} className="text-cyan-400 animate-pulse" />
                <h2 className="text-sm font-black text-white uppercase italic">Global Intelligence</h2>
            </div>
        </div>
        <div className="flex-1 grid grid-cols-12 gap-2 overflow-hidden">
            <div className="col-span-12 lg:col-span-8 bg-black/40 border border-white/5 rounded-lg p-4 relative overflow-hidden">
                <div className="absolute inset-0 opacity-5 grayscale bg-[url('https://upload.wikimedia.org/wikipedia/commons/8/88/World_map_blank_without_borders.svg')] bg-center bg-no-repeat bg-contain" />
                <div className="relative z-10 space-y-4">
                    <div className="p-2 border-l-2 border-red-600 bg-red-900/10 rounded-r">
                        <div className="text-[10px] font-black text-red-500">HOTSPOT_ALPHA</div>
                        <p className="text-xs text-white">Unusual network surge detected in Sector-7. Tracking packet trails.</p>
                    </div>
                    <div className="p-2 border-l-2 border-yellow-600 bg-yellow-900/10 rounded-r">
                        <div className="text-[10px] font-black text-yellow-500">DATA_LEAK_WARNING</div>
                        <p className="text-xs text-white">Credential dump on DarkMesh-04. Recommend rotation of all master keys.</p>
                    </div>
                </div>
            </div>
            <div className="col-span-12 lg:col-span-4 bg-black/60 border border-white/10 rounded-lg p-3 flex flex-col gap-3">
                <div className="text-[9px] font-black text-gray-500 uppercase flex items-center gap-2"><Activity size={12}/> Threat Analysis</div>
                <div className="flex-1 space-y-3">
                    {['Netsec', 'Crypto', 'Geopol', 'Physics'].map(t => (
                        <div key={t} className="space-y-1">
                            <div className="flex justify-between text-[8px] font-bold text-gray-400 uppercase"><span>{t}</span> <span>{Math.floor(Math.random()*40)}%</span></div>
                            <div className="h-1 bg-gray-800 rounded-full overflow-hidden"><div className="h-full bg-red-600" style={{ width: `${Math.random()*100}%` }}></div></div>
                        </div>
                    ))}
                </div>
                <div className="p-2 bg-white/5 border border-white/5 rounded text-[8px] font-mono text-gray-600">
                    ID: 0xFD42 // TRACE: OK
                </div>
            </div>
        </div>
    </div>
);

export default IntelPanel;
