
import React, { useState, useEffect, useRef } from 'react';
import { Contact, Message } from '../types';
import { Shield, User, Send, Plus, Trash2, Edit, Save, X, Lock, MessageSquare } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const SecureCommsPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const contacts = state.activeProfile?.contacts || [];

    const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
    const [input, setInput] = useState('');
    const [isEditing, setIsEditing] = useState<Contact | null>(null);
    const chatEndRef = useRef<HTMLDivElement>(null);

    const selectedContact = contacts.find(c => c.id === selectedContactId);

    const onUpdateContacts = (newContacts: Contact[]) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { contacts: newContacts }});
    };

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || !selectedContact) return;
        
        const userMessage: Message = { id: Date.now(), sender: 'user', text: input };
        
        const updatedContact = { 
            ...selectedContact, 
            history: [...(selectedContact.history || []), userMessage] 
        };
        
        onUpdateContacts(contacts.map(c => c.id === selectedContact.id ? updatedContact : c));
        setInput('');
        playSound('success');

        // Simulate secure reply
        setTimeout(() => {
            const replyText = `SECURE TRANSMISSION RECEIVED. [${Math.random().toString(36).substring(7).toUpperCase()}]`;
            const replyMessage: Message = { id: Date.now() + 1, sender: 'carnix', text: replyText };
            
            const replyContact = { 
                ...selectedContact, 
                history: [...(selectedContact.history || []), userMessage, replyMessage] 
            };
            onUpdateContacts(contacts.map(c => c.id === selectedContact.id ? replyContact : c));
            playSound('alert');
        }, 1500);
    };

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [selectedContact?.history]);

    const handleSaveContact = (e: React.FormEvent) => {
        e.preventDefault();
        if (!isEditing) return;
        
        const existingIndex = contacts.findIndex(c => c.id === isEditing.id);
        if (existingIndex >= 0) {
            const newContacts = [...contacts];
            newContacts[existingIndex] = isEditing;
            onUpdateContacts(newContacts);
        } else {
            onUpdateContacts([...contacts, isEditing]);
        }
        setIsEditing(null);
        playSound('success');
    };
    
    const handleAddNewContact = () => {
        const newContact: Contact = { id: `c-${Date.now()}`, name: 'New Contact', number: '', isSecure: true, history: [] };
        setIsEditing(newContact);
    };

    const handleDeleteContact = (id: string) => {
        if(confirm('Delete this contact and all history?')) {
            onUpdateContacts(contacts.filter(c => c.id !== id));
            if (selectedContactId === id) setSelectedContactId(null);
            playSound('error');
        }
    };

    return (
        <div className="w-full h-full flex gap-4 p-1">
            {/* Contacts List */}
            <div className="w-1/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                <div className="p-3 border-b border-gray-700 flex justify-between items-center bg-white/5">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2"><User size={16}/> CONTACTS</h3>
                    <button onClick={handleAddNewContact} className="p-1 text-[var(--color-primary)] hover:bg-white/10 rounded"><Plus size={16}/></button>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {contacts.map(contact => (
                        <div key={contact.id} onClick={() => setSelectedContactId(contact.id)} className={`p-3 border-b border-gray-800 cursor-pointer flex justify-between items-center group transition-colors ${selectedContactId === contact.id ? 'bg-[var(--color-primary)]/10 border-l-2 border-l-[var(--color-primary)]' : 'hover:bg-white/5 border-l-2 border-l-transparent'}`}>
                            <div>
                                <p className={`font-bold text-sm ${selectedContactId === contact.id ? 'text-[var(--color-primary)]' : 'text-white'}`}>{contact.name}</p>
                                <p className="text-[10px] text-gray-400 flex items-center gap-1 font-mono">
                                    <Shield size={10} className={contact.isSecure ? 'text-green-500' : 'text-gray-600'}/>
                                    {contact.isSecure ? 'ENCRYPTED' : 'UNSECURED'}
                                </p>
                            </div>
                            <div className="flex opacity-0 group-hover:opacity-100 gap-1 transition-opacity">
                                <button onClick={(e) => {e.stopPropagation(); setIsEditing(contact);}} className="p-1 hover:text-[var(--color-primary)]"><Edit size={12}/></button>
                                <button onClick={(e) => {e.stopPropagation(); handleDeleteContact(contact.id);}} className="p-1 hover:text-red-500"><Trash2 size={12}/></button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Chat Area / Edit Form */}
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden relative">
                {isEditing ? (
                    <form onSubmit={handleSaveContact} className="p-6 space-y-4 max-w-md mx-auto mt-10 bg-black/50 border border-gray-700 rounded-lg">
                        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2"><Edit size={18}/> {contacts.find(c=>c.id===isEditing.id) ? 'EDIT CONTACT' : 'NEW CONTACT'}</h3>
                        <div>
                            <label className="text-xs text-gray-400 block mb-1">CODENAME</label>
                            <input type="text" value={isEditing.name} onChange={e => setIsEditing({...isEditing, name: e.target.value})} className="w-full bg-black border border-gray-600 rounded p-2 text-sm text-white focus:border-[var(--color-primary)] outline-none" required />
                        </div>
                        <div>
                            <label className="text-xs text-gray-400 block mb-1">SECURE FREQUENCY / ID</label>
                            <input type="text" value={isEditing.number} onChange={e => setIsEditing({...isEditing, number: e.target.value})} className="w-full bg-black border border-gray-600 rounded p-2 text-sm text-white focus:border-[var(--color-primary)] outline-none" />
                        </div>
                        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setIsEditing({...isEditing, isSecure: !isEditing.isSecure})}>
                            <div className={`w-4 h-4 border rounded ${isEditing.isSecure ? 'bg-green-500 border-green-500' : 'border-gray-500'}`}></div>
                            <span className="text-xs text-gray-300">ENABLE END-TO-END ENCRYPTION</span>
                        </div>
                        <div className="flex gap-2 pt-2">
                            <button type="submit" className="flex-1 p-2 bg-green-700 text-white rounded text-xs font-bold flex items-center justify-center gap-2"><Save size={14}/> SAVE</button>
                            <button type="button" onClick={() => setIsEditing(null)} className="flex-1 p-2 bg-gray-700 text-white rounded text-xs font-bold flex items-center justify-center gap-2"><X size={14}/> CANCEL</button>
                        </div>
                    </form>
                ) : selectedContact ? (
                     <>
                        <div className="p-3 border-b border-gray-700 flex items-center justify-between bg-[var(--color-primary)]/5">
                            <div className="flex items-center gap-2">
                                <div className="p-1.5 bg-[var(--color-primary)]/20 rounded-full text-[var(--color-primary)]">
                                    <Lock size={14}/>
                                </div>
                                <div>
                                    <h3 className="text-sm font-bold text-white">{selectedContact.name}</h3>
                                    <span className="text-[10px] text-green-400 font-mono tracking-wider">CHANNEL SECURE // AES-256</span>
                                </div>
                            </div>
                        </div>
                        
                        <div className="flex-1 p-4 space-y-4 overflow-y-auto bg-black/20">
                            {(!selectedContact.history || selectedContact.history.length === 0) && (
                                <div className="text-center text-gray-600 mt-10 text-xs italic">
                                    Start a secure transmission...
                                </div>
                            )}
                            {selectedContact.history?.map((msg, i) => (
                                 <div key={i} className={`flex items-start gap-3 ${msg.sender === 'user' ? 'justify-end' : ''} animate-enter`}>
                                     {msg.sender === 'carnix' && <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center shrink-0 border border-gray-600"><User size={14} className="text-gray-400"/></div>}
                                     <div className={`p-3 rounded-lg max-w-[80%] text-sm ${msg.sender === 'user' ? 'bg-[var(--color-primary)] text-black font-bold' : 'bg-gray-800 text-gray-200 border border-gray-700'}`}>
                                         {msg.text}
                                     </div>
                                 </div>
                            ))}
                            <div ref={chatEndRef} />
                        </div>
                        
                        <div className="p-3 border-t border-gray-700 bg-black/40">
                             <form onSubmit={handleSend} className="flex items-center gap-3">
                                <input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="Type encrypted message..."
                                    className="flex-1 bg-black/50 border border-gray-600 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-[var(--color-primary)] text-white font-mono"
                                />
                                <button type="submit" className="p-2.5 bg-[var(--color-primary)] text-black rounded-full hover:bg-white transition-colors disabled:opacity-50" disabled={!input.trim()}>
                                    <Send size={16} />
                                </button>
                            </form>
                        </div>
                     </>
                ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-gray-500 gap-2">
                        <MessageSquare size={32} className="opacity-20"/>
                        <p className="text-xs">SELECT A CONTACT TO OPEN SECURE CHANNEL</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default SecureCommsPanel;
