
import React, { useState } from 'react';
import { HardDrive, FolderOpen, FileText, FileImage, FileVideo, Shield, Loader2, Search } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const StoragePanel: React.FC = () => {
    const [mounted, setMounted] = useState(false);
    const [scanning, setScanning] = useState(false);

    const mount = () => {
        setMounted(true);
        playSound('access');
    };

    const scan = () => {
        setScanning(true);
        playSound('scan');
        setTimeout(() => {
            setScanning(false);
            playSound('success');
        }, 2000);
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-white/10 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <HardDrive size={20} className="text-cyan-400" />
                    <h2 className="text-sm font-black text-white uppercase italic">Local Databanks</h2>
                </div>
                <div className="flex gap-2">
                    <button onClick={scan} disabled={!mounted || scanning} className="text-[9px] font-black text-gray-400 border border-gray-800 px-3 py-1 rounded hover:border-cyan-500 disabled:opacity-20">
                        {scanning ? <Loader2 size={10} className="animate-spin inline mr-1"/> : <Shield size={10} className="inline mr-1"/>} INTEGRITY_SCAN
                    </button>
                    {!mounted && <button onClick={mount} className="text-[9px] font-black bg-red-600 text-black px-3 py-1 rounded">MOUNT DRIVE</button>}
                </div>
            </div>

            <div className="flex-1 flex gap-2 overflow-hidden">
                <div className="flex-1 bg-black/30 border border-white/10 rounded-lg flex flex-col overflow-hidden">
                    {!mounted ? (
                        <div className="h-full flex flex-col items-center justify-center opacity-10">
                            <FolderOpen size={48} />
                            <p className="text-xs font-black uppercase mt-4">Node Disconnected</p>
                        </div>
                    ) : (
                        <>
                            <div className="p-2 border-b border-white/5 flex gap-2">
                                <div className="flex-1 relative">
                                    <Search size={10} className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-600" />
                                    <input className="w-full bg-black/40 border border-gray-800 rounded px-6 py-1 text-[9px] text-white" placeholder="QUERY_STORAGE..." />
                                </div>
                            </div>
                            <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-tactical">
                                {['SYSTEM_CORE_LOG', 'USER_INTEL_ARCHIVE', 'MEDIA_CACHE', 'TEMP_SYMLINKS'].map(f => (
                                    <div key={f} className="p-2 bg-white/5 border border-white/5 rounded text-[10px] flex justify-between items-center group cursor-pointer hover:border-cyan-500/50">
                                        <div className="flex items-center gap-2 text-gray-300"><FileText size={12}/> {f}</div>
                                        <span className="text-gray-600 font-mono text-[8px]">0xAF32</span>
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                </div>

                <div className="w-64 hidden lg:flex bg-black/60 border border-white/10 rounded-lg flex-col p-4 gap-6">
                    <h3 className="text-[9px] font-black text-gray-500 uppercase tracking-widest border-b border-white/5 pb-2">Analysis Report</h3>
                    <div className="space-y-4">
                        <div className="space-y-1">
                             <div className="flex justify-between text-[8px] font-black text-gray-500"><span>AVAILABILITY</span> <span>88%</span></div>
                             <div className="h-0.5 bg-gray-800 rounded-full"><div className="h-full bg-cyan-500 w-[88%]"></div></div>
                        </div>
                        <div className="space-y-1">
                             <div className="flex justify-between text-[8px] font-black text-gray-500"><span>FRAGMENTATION</span> <span>2%</span></div>
                             <div className="h-0.5 bg-gray-800 rounded-full"><div className="h-full bg-red-600 w-[2%]"></div></div>
                        </div>
                    </div>
                    <div className="mt-auto p-2 bg-red-900/10 border border-red-900/30 rounded text-[8px] text-red-500 italic">
                        Encryption protocol active. Unauthorized access will trigger immediate node incineration.
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StoragePanel;
