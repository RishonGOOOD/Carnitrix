
import React, { useState } from 'react';
import { Cpu, Zap, Info, Layers, Edit2 } from 'lucide-react';

const HardwarePinArchitect: React.FC = () => {
    const [selectedPin, setSelectedPin] = useState<any>(null);
    
    const pins = [
        { id: 1, label: '3V3', type: 'POWER', color: 'text-red-500' },
        { id: 2, label: 'EN', type: 'CONTROL', color: 'text-white' },
        { id: 3, label: 'GPIO36', type: 'ADC', color: 'text-yellow-500' },
        { id: 4, label: 'GPIO39', type: 'ADC', color: 'text-yellow-500' },
        { id: 5, label: 'GPIO34', type: 'INPUT', color: 'text-green-500' },
        { id: 6, label: 'GPIO35', type: 'INPUT', color: 'text-green-500' },
        { id: 7, label: 'GPIO32', type: 'PWM', color: 'text-blue-500' },
        { id: 8, label: 'GPIO33', type: 'PWM', color: 'text-blue-500' },
    ];

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/40 border border-white/5 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Layers size={24} className="text-purple-400" />
                    <div>
                        <h2 className="text-lg font-black tracking-widest text-white uppercase italic">Pin Architect</h2>
                        <p className="text-[9px] font-mono text-gray-500 uppercase">Board Configurator // ESP32-WROOM-32D</p>
                    </div>
                </div>
            </div>

            <div className="flex-1 flex gap-4 overflow-hidden">
                <div className="flex-1 bg-black/40 border border-white/5 rounded p-8 flex items-center justify-center">
                    <div className="w-64 h-96 border-4 border-gray-800 bg-[#121212] relative rounded shadow-2xl">
                         <div className="absolute top-4 left-1/2 -translate-x-1/2 w-20 h-20 bg-gray-900 border border-white/5 flex items-center justify-center text-gray-700 font-black text-xs">MCU</div>
                         
                         {/* Pins visualization */}
                         <div className="absolute top-24 left-0 w-full px-4 space-y-2">
                             {pins.map(pin => (
                                 <div 
                                    key={pin.id} 
                                    onClick={() => setSelectedPin(pin)}
                                    className={`flex items-center gap-2 cursor-pointer group transition-all ${selectedPin?.id === pin.id ? 'scale-105' : ''}`}
                                 >
                                     <div className={`w-3 h-1 ${pin.type === 'POWER' ? 'bg-red-500' : 'bg-gray-600'}`}></div>
                                     <div className={`text-[10px] font-mono ${pin.color} group-hover:text-white transition-colors`}>{pin.label}</div>
                                     {selectedPin?.id === pin.id && <Zap size={8} className="text-yellow-400 animate-pulse"/>}
                                 </div>
                             ))}
                         </div>
                    </div>
                </div>

                <div className="w-80 bg-black/60 border border-white/10 rounded p-4 flex flex-col gap-4">
                    <div className="hud-panel-header !bg-transparent !p-0 border-b border-white/10 pb-2">
                        <Info size={14}/> PIN_METADATA
                    </div>
                    {selectedPin ? (
                        <div className="space-y-4 animate-enter">
                            <div>
                                <h3 className="text-xl font-black text-white">{selectedPin.label}</h3>
                                <p className="text-[10px] text-gray-500 uppercase tracking-widest">Type: {selectedPin.type}</p>
                            </div>
                            <div className="bg-white/5 p-3 rounded border border-white/10 text-xs text-gray-400 leading-relaxed italic">
                                "{selectedPin.label} is currently assigned to {selectedPin.type} processing. Ensure impedance matching for high-frequency signal integrity."
                            </div>
                            <button className="w-full py-2 bg-purple-600/20 border border-purple-500 text-purple-400 font-bold text-[10px] uppercase">Assign Peripheral</button>
                        </div>
                    ) : (
                        <div className="flex-1 flex items-center justify-center opacity-20 italic text-xs">
                            Select a pin node to view architecture details.
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default HardwarePinArchitect;
