
import React, { useState } from 'react';
import { Zap, Send, Loader2, Code, Layout, ImageIcon } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const ForgePanel: React.FC = () => {
    const [p, setP] = useState('');
    const [gen, setGen] = useState(false);

    const start = () => {
        if (!p.trim()) return;
        setGen(true);
        playSound('process');
        setTimeout(() => {
            setGen(false);
            playSound('success');
        }, 2000);
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="bg-black/60 border border-red-600/30 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Zap size={20} className="text-red-600 animate-pulse" />
                    <h2 className="text-sm font-black text-white uppercase italic">AI Forge Node</h2>
                </div>
            </div>
            <div className="flex-1 flex flex-col lg:flex-row gap-2 overflow-hidden">
                <div className="w-full lg:w-1/2 flex flex-col gap-2">
                    <div className="flex-1 bg-black/40 border border-white/10 rounded-lg p-4 flex flex-col gap-4">
                        <textarea 
                            value={p} onChange={e => setP(e.target.value)} 
                            className="flex-1 w-full bg-black/40 border border-gray-800 p-3 text-xs text-white outline-none focus:border-red-600 resize-none"
                            placeholder="Describe creation parameters..."
                        />
                        <div className="grid grid-cols-2 gap-2">
                            <button onClick={start} disabled={gen} className="p-3 bg-red-600 text-black font-black text-xs uppercase rounded flex items-center justify-center gap-2">
                                {gen ? <Loader2 size={14} className="animate-spin"/> : <Zap size={14}/>} GENERATE
                            </button>
                            <button className="p-3 border border-gray-800 text-gray-500 text-xs font-black uppercase rounded">Cancel</button>
                        </div>
                    </div>
                </div>
                <div className="flex-1 bg-black/60 border border-white/5 rounded-lg flex items-center justify-center text-gray-800 p-8">
                     {gen ? (
                        <div className="text-center space-y-2">
                            <Loader2 size={48} className="animate-spin text-red-600 mx-auto" />
                            <p className="text-[10px] font-black uppercase tracking-[0.4em]">Synthesizing Reality...</p>
                        </div>
                     ) : (
                        <div className="text-center opacity-10">
                            <Layout size={64} className="mx-auto mb-4" />
                            <p className="text-xs font-black uppercase">Output_Buffer_Empty</p>
                        </div>
                     )}
                </div>
            </div>
        </div>
    );
};

export default ForgePanel;
