
import React, { useEffect, useRef } from 'react';
import { Atom, ShieldCheck, Zap } from 'lucide-react';

const QuantumCommPanel: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        const particles: any[] = [];
        const particleCount = 50;

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                size: Math.random() * 2 + 1,
            });
        }

        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
                if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

                ctx.fillStyle = `rgba(0, 216, 255, 0.8)`;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });

            for (let i = 0; i < particleCount; i++) {
                for (let j = i; j < particleCount; j++) {
                    const dist = Math.hypot(particles[i].x - particles[j].x, particles[i].y - particles[j].y);
                    if (dist < 100) {
                        ctx.strokeStyle = `rgba(255, 0, 0, ${1 - dist / 100})`;
                        ctx.lineWidth = 0.5;
                        ctx.beginPath();
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.stroke();
                    }
                }
            }

            animationFrameId = requestAnimationFrame(animate);
        };
        animate();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, []);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Atom size={16} className="animate-spin-slow"/> QUANTUM COMMUNICATIONS
                </h2>
                <span className="text-xs font-mono text-green-400 flex items-center gap-2 animate-pulse">
                    <ShieldCheck size={12}/> CHANNEL SECURE
                </span>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md relative overflow-hidden">
                <canvas ref={canvasRef} className="w-full h-full" />
                <div className="absolute top-4 left-4 font-mono text-xs text-white bg-black/50 p-2 rounded">
                    <p>STATUS: Q-ENTANGLEMENT STABLE</p>
                    <p>DATA RATE: 1.25 Tbps (Simulated)</p>
                    <p>LATENCY: &lt; 0.01 ps (Simulated)</p>
                </div>
            </div>
        </div>
    );
};

export default QuantumCommPanel;
