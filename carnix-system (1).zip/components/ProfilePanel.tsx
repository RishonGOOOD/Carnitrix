
import React, { useState, useRef } from 'react';
import { User, Save, Upload, LogOut, Trash2, Loader2, Zap } from 'lucide-react';
import { useAppContext } from '../context';
import { Profile } from '../types';
import { playSound } from '../utils/soundEffects';

const ProfilePanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;

    const [name, setName] = useState(activeProfile?.name || '');
    const [bio, setBio] = useState(activeProfile?.bio || '');
    const [profilePicture, setProfilePicture] = useState(activeProfile?.profilePicture);
    const [isSaving, setIsSaving] = useState(false);

    const handleSave = () => {
        if (!name.trim()) {
            playSound('error');
            return;
        }
        setIsSaving(true);
        playSound('process');
        
        setTimeout(() => {
            const updatedData = { name: name.toUpperCase(), bio, profilePicture };
            dispatch({ type: 'UPDATE_PROFILE', payload: updatedData });
            
            const saved = localStorage.getItem('carnix_profiles');
            if (saved && activeProfile) {
                const profiles = JSON.parse(saved).map((p: Profile) => 
                    p.id === activeProfile.id ? { ...p, ...updatedData } : p
                );
                localStorage.setItem('carnix_profiles', JSON.stringify(profiles));
            }
            
            setIsSaving(false);
            playSound('success');
        }, 1000);
    };

    const handleLogout = () => {
        playSound('switch');
        dispatch({ type: 'LOGOUT' });
    };

    const handlePurge = () => {
        if (confirm("IDENTITY DESTRUCTION: Erase all data and credentials for this node? This cannot be undone.")) {
            playSound('error');
            const saved = localStorage.getItem('carnix_profiles');
            if (saved && activeProfile) {
                const profiles = JSON.parse(saved).filter((p: Profile) => p.id !== activeProfile.id);
                localStorage.setItem('carnix_profiles', JSON.stringify(profiles));
            }
            dispatch({ type: 'LOGOUT' });
        }
    };

    return (
        <div className="w-full h-full p-2 md:p-6 overflow-y-auto scrollbar-carnix">
            <div className="max-w-3xl mx-auto space-y-6 stagger-in">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-3 bg-[var(--color-primary)]/10 rounded border border-[var(--color-primary)]/30 shadow-[0_0_10px_var(--color-primary)]">
                        <User size={24} className="text-[var(--color-primary)]" />
                    </div>
                    <div>
                        <h1 className="text-xl font-black text-white uppercase tracking-tighter">Identity Management</h1>
                        <p className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">Operator Node: {activeProfile?.id.slice(-8)}</p>
                    </div>
                </div>

                <div className="jarvis-panel p-6 bg-black/60 relative">
                    <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
                        <div className="relative group shrink-0">
                            <div className="w-32 h-32 rounded-lg border-2 border-[var(--color-primary)]/50 overflow-hidden bg-black/50 shadow-[0_0_20px_rgba(255,0,60,0.2)] flex items-center justify-center">
                                {profilePicture ? (
                                    <img src={profilePicture} className="w-full h-full object-cover" alt="Profile" />
                                ) : (
                                    <User size={64} className="text-gray-800" />
                                )}
                                {isSaving && (
                                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center z-10">
                                        <Loader2 size={32} className="animate-spin text-[var(--color-primary)]" />
                                    </div>
                                )}
                            </div>
                            <button 
                                onClick={() => document.getElementById('pic-upload')?.click()}
                                className="absolute -bottom-2 -right-2 bg-[var(--color-primary)] p-2 rounded-full text-black hover:bg-white transition-all shadow-lg z-20"
                                title="Update ID Photo"
                            >
                                <Upload size={16} />
                            </button>
                            <input id="pic-upload" type="file" className="hidden" accept="image/*" onChange={e => {
                                const file = e.target.files?.[0];
                                if(file) {
                                    const reader = new FileReader();
                                    reader.onload = r => setProfilePicture(r.target?.result as string);
                                    reader.readAsDataURL(file);
                                }
                            }} />
                        </div>

                        <div className="flex-1 w-full space-y-4">
                            <div>
                                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-1">Callsign / Handle</label>
                                <input 
                                    value={name} 
                                    onChange={e => setName(e.target.value)} 
                                    className="w-full !bg-black/40 !border-white/10 !p-3 !text-lg !font-black !text-white focus:!border-[var(--color-primary)] outline-none uppercase font-mono transition-all" 
                                    placeholder="ENTER CALLSIGN..."
                                />
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-1">Operator Bio / Status Report</label>
                                <textarea 
                                    value={bio} 
                                    onChange={e => setBio(e.target.value)} 
                                    className="w-full !bg-black/40 !border-white/10 !p-3 !text-xs !text-gray-300 h-24 !resize-none focus:!border-[var(--color-primary)] outline-none leading-relaxed" 
                                    placeholder="State your purpose..."
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <button 
                        onClick={handleSave} 
                        disabled={isSaving}
                        className="hud-button py-4 flex items-center justify-center gap-2 bg-[var(--color-primary)] text-black font-black disabled:opacity-50"
                    >
                        {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                        COMMIT CORE UPDATES
                    </button>
                    <div className="flex gap-4">
                        <button 
                            onClick={handleLogout} 
                            className="flex-1 hud-button !bg-gray-900/40 !border-gray-700 !text-gray-400 py-4 flex items-center justify-center gap-2"
                        >
                            <LogOut size={18} /> LOGOUT
                        </button>
                        <button 
                            onClick={handlePurge} 
                            className="flex-1 hud-button !bg-red-900/40 !border-red-600 !text-red-500 py-4 flex items-center justify-center gap-2"
                        >
                            <Trash2 size={18} /> PURGE
                        </button>
                    </div>
                </div>

                <div className="bg-blue-900/10 border border-blue-900/30 p-4 rounded text-[10px] text-blue-400 font-mono flex items-start gap-3">
                    <Zap size={16} className="shrink-0 mt-0.5" />
                    <div>
                        <p className="font-black uppercase mb-1">Synchronized Network</p>
                        <p className="opacity-70 leading-relaxed uppercase">Your node identification is mirrored across the AI Station network. Updates are propagated immediately to all active clusters.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProfilePanel;
