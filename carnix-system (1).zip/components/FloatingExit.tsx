import React from 'react';

// FloatingExit is deprecated in favor of unified docked TopBar & Sidebar navigation to eliminate UI overlap
const FloatingExit: React.FC = () => {
    return null;
};

export default FloatingExit;
