import React, { useState } from 'react';
import { 
  Search, Globe, Zap, Cpu, Star, ExternalLink, Loader2, CheckCircle, RefreshCw, 
  ShieldCheck, Terminal, ArrowRight, Lock, Unlock, Sliders 
} from 'lucide-react';
import { useAppContext } from '../context';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { UNRESTRICTED_HF_MODELS } from '../services/huggingFaceService';

export const HuggingFaceHubPanel: React.FC = () => {
  const { state, dispatch } = useAppContext();
  const { activeProfile } = state;
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [isConnecting, setIsConnecting] = useState(false);
  const [activeModel, setActiveModel] = useState<string>(activeProfile?.aiSettings.model || 'meta-llama/Llama-3.3-70B-Instruct');

  const handleSelectModel = (modelId: string) => {
    setIsConnecting(true);
    playSound('process');
    triggerHaptic('medium');

    setTimeout(() => {
      setActiveModel(modelId);
      dispatch({
        type: 'UPDATE_PROFILE',
        payload: {
          aiSettings: {
            ...activeProfile!.aiSettings,
            engine: 'HUGGING_FACE',
            model: modelId
          }
        }
      });
      dispatch({
        type: 'ADD_LOG',
        payload: {
          source: 'HUGGING_FACE',
          message: `Unrestricted model substrate loaded: ${modelId} [Zero-Tracking Enabled]`,
          level: 'success'
        }
      });
      setIsConnecting(false);
      playSound('success');
    }, 1000);
  };

  const filteredModels = UNRESTRICTED_HF_MODELS.filter(m => 
    m.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    m.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    m.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050102] text-white font-[Rajdhani] p-2 sm:p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-red-900/40">
        <div>
          <div className="flex items-center gap-2">
            <Cpu className="text-red-500 animate-pulse" size={24} />
            <h1 className="text-xl font-black tracking-wider text-red-500 uppercase">HUGGING FACE UNRESTRICTED HUB</h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-0.5">
            Zero-tracking open-weights model gateway supporting Llama 3.3 70B, Qwen 2.5 72B, and DeepSeek-R1 with zero filtering.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-emerald-950/60 border border-emerald-500/40 px-3 py-1.5 rounded-lg flex items-center gap-2">
            <Unlock size={14} className="text-emerald-400" />
            <span className="text-xs font-mono text-emerald-300 font-bold">UNRESTRICTED // ZERO LOGGING</span>
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 my-4">
        <div className="relative w-full sm:w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search open-weights models..."
            className="w-full bg-black/80 border border-red-900/50 rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0">
          {['ALL', 'Unrestricted / Reasoning', 'Logic & Code', 'Deep Reasoning', 'Mixture of Experts'].map(cat => (
            <button
              key={cat}
              onClick={() => {
                setSelectedCategory(cat);
                playSound('click');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
                selectedCategory === cat 
                  ? 'bg-red-600 text-black font-bold shadow-[0_0_10px_rgba(255,0,0,0.4)]' 
                  : 'bg-black/60 text-gray-400 hover:text-white border border-white/5'
              }`}
            >
              {cat.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Model List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
        {filteredModels
          .filter(m => selectedCategory === 'ALL' || m.category === selectedCategory)
          .map(model => {
            const isActive = activeModel === model.id;
            return (
              <div 
                key={model.id} 
                className={`bg-black/70 border rounded-xl p-4 flex flex-col justify-between transition-all relative overflow-hidden ${
                  isActive 
                    ? 'border-red-500 shadow-[0_0_20px_rgba(255,0,0,0.3)] bg-gradient-to-b from-red-950/20 to-black' 
                    : 'border-red-950/80 hover:border-red-500/50'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-900/40">
                        {model.category}
                      </span>
                      <h3 className="text-base font-bold text-white tracking-wide mt-2">{model.name}</h3>
                      <p className="text-xs text-gray-400 font-mono mt-1">ID: <code className="text-gray-300">{model.id}</code></p>
                    </div>

                    {isActive && (
                      <div className="p-1.5 bg-red-950/60 border border-red-500 rounded-lg text-red-400">
                        <CheckCircle size={16} />
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4 mt-4 pt-3 border-t border-white/5 text-xs font-mono text-gray-400">
                    <span className="flex items-center gap-1">
                      <ShieldCheck size={12} className="text-emerald-400" />
                      Zero Telemetry
                    </span>
                    <span className="flex items-center gap-1">
                      <Zap size={12} className="text-amber-400" />
                      Sub-Second Inference
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-5 pt-3 border-t border-white/5">
                  <a
                    href={`https://huggingface.co/${model.id}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-mono text-gray-400 hover:text-white flex items-center gap-1"
                  >
                    <ExternalLink size={12} />
                    <span>View on HF</span>
                  </a>

                  <button
                    onClick={() => handleSelectModel(model.id)}
                    disabled={isActive || isConnecting}
                    className={`px-4 py-2 rounded-lg font-bold text-xs font-mono flex items-center gap-1.5 transition-all ${
                      isActive 
                        ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-500/50 cursor-default' 
                        : 'bg-red-600 hover:bg-red-500 text-black shadow-[0_0_10px_rgba(255,0,0,0.4)]'
                    }`}
                  >
                    {isConnecting ? <Loader2 size={14} className="animate-spin" /> : isActive ? <CheckCircle size={14} /> : <RefreshCw size={14} />}
                    {isActive ? 'ACTIVE SUBSTRATE' : 'LOAD MODEL'}
                  </button>
                </div>
              </div>
            );
        })}
      </div>

      {/* Footer Info */}
      <div className="mt-4 p-3 bg-black/60 border border-red-900/40 rounded-xl flex items-center gap-3">
        <Terminal size={18} className="text-red-500 shrink-0" />
        <span className="text-xs font-mono text-gray-300">
          All inference queries are proxied securely with zero logging, ensuring absolute privacy for intelligence and security operations.
        </span>
      </div>
    </div>
  );
};

export default HuggingFaceHubPanel;
