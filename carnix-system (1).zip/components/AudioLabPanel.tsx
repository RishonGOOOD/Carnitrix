
import React, { useState, useEffect, useRef } from 'react';
import { Play, StopCircle, Sliders, Music } from 'lucide-react';

const notes = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25]; // C4 to C5 major scale

const AudioLabPanel: React.FC = () => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [tempo, setTempo] = useState(120);
    const [sequence, setSequence] = useState<boolean[][]>(
        () => Array(8).fill(0).map(() => Array(16).fill(false))
    );
    const [currentStep, setCurrentStep] = useState(0);

    const audioCtxRef = useRef<AudioContext | null>(null);
    const nextStepTimeRef = useRef(0);
    const stepIntervalRef = useRef<any>(null);

    useEffect(() => {
        if (!isPlaying) {
            clearInterval(stepIntervalRef.current);
            setCurrentStep(0);
            return;
        }

        if (!audioCtxRef.current) {
            audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        
        const scheduleAheadTime = 0.1;
        
        const scheduler = () => {
            while (nextStepTimeRef.current < audioCtxRef.current!.currentTime + scheduleAheadTime) {
                 // Play notes for the current step
                sequence.forEach((row, noteIndex) => {
                    if (row[currentStep]) {
                        const osc = audioCtxRef.current!.createOscillator();
                        osc.frequency.setValueAtTime(notes[noteIndex], nextStepTimeRef.current);
                        osc.type = 'sine';
                        osc.connect(audioCtxRef.current!.destination);
                        osc.start(nextStepTimeRef.current);
                        osc.stop(nextStepTimeRef.current + 0.1);
                    }
                });
                
                // Advance step
                const secondsPerBeat = 60.0 / tempo;
                nextStepTimeRef.current += 0.25 * secondsPerBeat; // 16th notes
                setCurrentStep(prev => (prev + 1) % 16);
            }
        };

        nextStepTimeRef.current = audioCtxRef.current.currentTime;
        stepIntervalRef.current = setInterval(scheduler, 25);

        return () => clearInterval(stepIntervalRef.current);
    }, [isPlaying, tempo, sequence]);

    const toggleCell = (row: number, col: number) => {
        const newSequence = [...sequence];
        newSequence[row][col] = !newSequence[row][col];
        setSequence(newSequence);
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Sliders size={16}/> AUDIO LAB</h2>
                <div className="flex items-center gap-4">
                    <label className="text-xs">TEMPO: {tempo} BPM</label>
                    <input type="range" min="60" max="180" value={tempo} onChange={e => setTempo(Number(e.target.value))} className="w-32"/>
                    <button onClick={() => setIsPlaying(!isPlaying)} className={`p-2 rounded flex items-center gap-2 text-sm ${isPlaying ? 'bg-red-600' : 'bg-green-600'}`}>
                        {isPlaying ? <StopCircle size={16}/> : <Play size={16}/>} {isPlaying ? 'STOP' : 'PLAY'}
                    </button>
                </div>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 grid grid-cols-16 gap-2">
                 {sequence.map((row, rowIndex) => (
                    <React.Fragment key={rowIndex}>
                        {row.map((isActive, colIndex) => (
                            <div key={`${rowIndex}-${colIndex}`}
                                 onClick={() => toggleCell(rowIndex, colIndex)}
                                 className={`w-full h-full rounded cursor-pointer transition-colors ${isActive ? 'bg-[var(--color-primary)]' : 'bg-gray-800 hover:bg-gray-700'} ${currentStep === colIndex && isPlaying ? 'border-2 border-white' : ''}`}
                            ></div>
                        ))}
                    </React.Fragment>
                ))}
            </div>
        </div>
    );
};

export default AudioLabPanel;
