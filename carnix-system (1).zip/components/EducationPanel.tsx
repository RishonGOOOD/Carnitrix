
import React, { useState, useRef, useEffect } from 'react';
import { Mode } from '../types';
import { Bot, Cpu, Calculator, Zap, RotateCw, Play, Square, Code, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { playSound } from '../utils/soundEffects';

interface EducationPanelProps {
    initialTab?: 'ROBOTICS' | 'ELECTRONICS' | 'MATH' | 'CODE';
}

const RoboticsSim: React.FC = () => {
    const [servos, setServos] = useState([90, 90, 90, 90]); // Base, Shoulder, Elbow, Claw
    const [activeServo, setActiveServo] = useState(0);

    const updateServo = (val: number) => {
        const newServos = [...servos];
        newServos[activeServo] = val;
        setServos(newServos);
    };

    // Simple 2D kinematic visualization
    const canvasRef = useRef<HTMLCanvasElement>(null);
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const w = canvas.width = canvas.offsetWidth;
        const h = canvas.height = canvas.offsetHeight;
        const baseX = w / 2;
        const baseY = h - 20;

        ctx.clearRect(0, 0, w, h);
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        // Segments length
        const L1 = 60;
        const L2 = 50;
        const L3 = 30;

        // Angles to Radians (Simulated relative logic)
        const a1 = (servos[0] - 90) * (Math.PI / 180); // Base rotation (just x-shift simulation)
        const a2 = (servos[1]) * (Math.PI / 180); // Shoulder
        const a3 = (servos[2] - 90) * (Math.PI / 180); // Elbow relative

        // Draw Base
        ctx.fillStyle = '#333';
        ctx.fillRect(baseX - 20, h - 20, 40, 20);

        // Calculate Joints
        const x1 = baseX;
        const y1 = baseY;

        const x2 = x1 + Math.cos(a1) * 10; // Faux 3D base rotation effect
        const y2 = y1 - 20;

        const x3 = x2 + Math.cos(a2 - Math.PI/2) * L1;
        const y3 = y2 + Math.sin(a2 - Math.PI/2) * L1;

        const x4 = x3 + Math.cos(a2 + a3 - Math.PI/2) * L2;
        const y4 = y3 + Math.sin(a2 + a3 - Math.PI/2) * L2;

        // Draw Arm
        ctx.beginPath();
        ctx.moveTo(x2, y2);
        ctx.lineTo(x3, y3);
        ctx.lineTo(x4, y4);
        ctx.stroke();

        // Draw Joints
        ctx.fillStyle = '#ff003c';
        [
            {x:x2,y:y2}, {x:x3,y:y3}, {x:x4,y:y4}
        ].forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, 4, 0, Math.PI*2);
            ctx.fill();
        });

    }, [servos]);

    return (
        <div className="flex flex-col h-full gap-4">
            <div className="flex-1 bg-black/40 border border-white/10 rounded-lg relative overflow-hidden">
                <canvas ref={canvasRef} className="w-full h-full" />
                <div className="absolute top-2 left-2 text-[10px] font-mono text-cyan-400">KINEMATIC SIMULATION</div>
            </div>
            <div className="h-40 bg-black/60 border border-white/10 rounded-lg p-4 flex flex-col gap-2">
                <div className="flex gap-2 mb-2">
                    {['BASE', 'SHOULDER', 'ELBOW', 'CLAW'].map((label, i) => (
                        <button 
                            key={i} 
                            onClick={() => setActiveServo(i)} 
                            className={`flex-1 text-[9px] font-bold py-1 border rounded transition-all ${activeServo === i ? 'bg-cyan-600 text-black border-cyan-600' : 'border-gray-700 text-gray-500 hover:text-white'}`}
                        >
                            {label}
                        </button>
                    ))}
                </div>
                <div className="flex items-center gap-4">
                    <span className="text-xs font-mono w-12 text-right">{servos[activeServo]}°</span>
                    <input 
                        type="range" 
                        min="0" max="180" 
                        value={servos[activeServo]} 
                        onChange={e => updateServo(Number(e.target.value))} 
                        className="flex-1 accent-cyan-500 h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer"
                    />
                </div>
                <div className="flex gap-2 mt-auto">
                    <button onClick={() => setServos([90,90,90,90])} className="flex-1 py-2 bg-gray-800 rounded text-[10px] font-bold hover:bg-gray-700">RESET POSE</button>
                    <button className="flex-1 py-2 bg-cyan-900/30 text-cyan-400 border border-cyan-700 rounded text-[10px] font-bold hover:bg-cyan-900/50">EXPORT SEQUENCE</button>
                </div>
            </div>
        </div>
    );
};

const ElectronicsSim: React.FC = () => {
    return (
        <div className="flex flex-col h-full items-center justify-center text-gray-500 gap-4">
            <Cpu size={64} className="opacity-20"/>
            <div className="text-center">
                <h3 className="text-lg font-bold text-white mb-2">CIRCUIT VIRTUALIZATION</h3>
                <p className="text-xs max-w-md mx-auto">
                    Breadboard simulation matrix initialized. Component library loading...
                </p>
            </div>
            <div className="grid grid-cols-4 gap-2 mt-4">
                {['LED', 'RESISTOR', 'CAPACITOR', 'IC_555'].map(c => (
                    <div key={c} className="p-3 border border-gray-800 bg-black/40 rounded text-[10px] font-mono hover:border-green-500 cursor-pointer transition-colors">
                        {c}
                    </div>
                ))}
            </div>
        </div>
    );
};

const MathSolver: React.FC = () => {
    const { state } = useAppContext();
    const [input, setInput] = useState('');
    const [solution, setSolution] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const solve = async () => {
        if (!input.trim() || !state.activeProfile) return;
        setLoading(true);
        setSolution(null);
        playSound('process');
        try {
            const prompt = `Solve this math problem step-by-step. Use LaTeX formatting for equations if needed. Problem: ${input}`;
            const res = await getAIResponse(prompt, Mode.MathSolver, state.activeProfile.aiSettings);
            setSolution(res.text);
            playSound('success');
        } catch (e) {
            setSolution('Calculation matrix offline.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-full gap-4">
            <div className="flex gap-2">
                <input 
                    value={input} 
                    onChange={e => setInput(e.target.value)} 
                    placeholder="Enter equation or problem (e.g. Integral of x^2)..." 
                    className="flex-1 bg-black/40 border border-gray-700 rounded p-3 text-sm text-white font-mono focus:border-[var(--color-primary)] outline-none"
                    onKeyDown={e => e.key === 'Enter' && solve()}
                />
                <button onClick={solve} disabled={loading} className="px-6 bg-[var(--color-primary)] text-black font-bold rounded flex items-center justify-center">
                    {loading ? <Loader2 className="animate-spin"/> : <Calculator size={20}/>}
                </button>
            </div>
            <div className="flex-1 bg-black/30 border border-white/10 rounded-lg p-4 overflow-y-auto font-mono text-sm text-gray-300 whitespace-pre-wrap">
                {solution || <span className="text-gray-600 italic">// Solution output buffer...</span>}
            </div>
        </div>
    );
};

const EducationPanel: React.FC<EducationPanelProps> = ({ initialTab = 'ROBOTICS' }) => {
    const [tab, setTab] = useState(initialTab);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <div className="flex gap-2">
                    <button onClick={() => setTab('ROBOTICS')} className={`px-4 py-2 rounded text-xs font-black flex items-center gap-2 transition-all ${tab === 'ROBOTICS' ? 'bg-cyan-600 text-black' : 'text-gray-500 hover:text-white'}`}>
                        <Bot size={14}/> ROBOTICS
                    </button>
                    <button onClick={() => setTab('ELECTRONICS')} className={`px-4 py-2 rounded text-xs font-black flex items-center gap-2 transition-all ${tab === 'ELECTRONICS' ? 'bg-green-600 text-black' : 'text-gray-500 hover:text-white'}`}>
                        <Zap size={14}/> ELECTRONICS
                    </button>
                    <button onClick={() => setTab('MATH')} className={`px-4 py-2 rounded text-xs font-black flex items-center gap-2 transition-all ${tab === 'MATH' ? 'bg-purple-600 text-black' : 'text-gray-500 hover:text-white'}`}>
                        <Calculator size={14}/> QUANTUM MATH
                    </button>
                </div>
            </div>
            <div className="flex-1 bg-black/20 border border-[var(--color-panel-border)] rounded-md p-4 overflow-hidden relative">
                {tab === 'ROBOTICS' && <RoboticsSim />}
                {tab === 'ELECTRONICS' && <ElectronicsSim />}
                {tab === 'MATH' && <MathSolver />}
            </div>
        </div>
    );
};

export default EducationPanel;
