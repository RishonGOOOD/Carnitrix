
import React, { useState } from 'react';
import { Globe, ShieldAlert, Wifi, CloudLightning, Newspaper } from 'lucide-react';

type MapOverlay = 'GEO_POLITICAL' | 'CYBER_THREAT' | 'WEATHER' | 'NEWS';

const WorldStatusPanel: React.FC = () => {
    const [activeOverlay, setActiveOverlay] = useState<MapOverlay>('GEO_POLITICAL');

    const renderOverlayData = () => {
        switch(activeOverlay) {
            case 'GEO_POLITICAL': return <p className="text-xs">Displaying geopolitical hotspots and conflict zones. Areas in red indicate high tension.</p>;
            case 'CYBER_THREAT': return <p className="text-xs">Showing major DDoS attacks and network intrusion attempts in real-time.</p>;
            case 'WEATHER': return <p className="text-xs">Tracking significant weather events: hurricanes, typhoons, and major storm fronts.</p>;
            case 'NEWS': return <p className="text-xs">Aggregating breaking news headlines from major global sources, plotted by location.</p>;
            default: return null;
        }
    };
    
    const renderMapContent = () => {
        const points = Array.from({length: 15});
        let colorClass = 'bg-red-500';
        if (activeOverlay === 'CYBER_THREAT') colorClass = 'bg-blue-500';
        if (activeOverlay === 'WEATHER') colorClass = 'bg-green-500';
        if (activeOverlay === 'NEWS') colorClass = 'bg-yellow-500';

        return points.map((_, i) => (
            <div key={i} className={`absolute w-2 h-2 rounded-full ${colorClass} animate-pulse`}
                 style={{ 
                     top: `${10 + Math.random() * 80}%`, 
                     left: `${10 + Math.random() * 80}%`,
                     animationDelay: `${Math.random() * 2}s`
                 }}>
            </div>
        ));
    };

    const OverlayButton: React.FC<{type: MapOverlay, label: string, icon: React.ReactNode}> = ({ type, label, icon }) => (
        <button 
            onClick={() => setActiveOverlay(type)}
            className={`flex-1 flex items-center justify-center gap-2 p-3 text-xs font-bold rounded-md transition-colors ${activeOverlay === type ? 'bg-[var(--color-primary)] text-black' : 'bg-black/40 text-gray-400 hover:bg-white/10'}`}
        >
            {icon}
            <span>{label}</span>
        </button>
    );

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2">
                <div className="flex gap-2">
                    <OverlayButton type="GEO_POLITICAL" label="GEO-POLITICAL" icon={<ShieldAlert size={14}/>} />
                    <OverlayButton type="CYBER_THREAT" label="CYBER THREAT" icon={<Wifi size={14}/>} />
                    <OverlayButton type="WEATHER" label="WEATHER" icon={<CloudLightning size={14}/>} />
                    <OverlayButton type="NEWS" label="NEWS" icon={<Newspaper size={14}/>} />
                </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-4 overflow-hidden">
                <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <div className="p-2 border-b border-gray-700 text-xs font-bold text-[var(--color-primary)] flex items-center gap-2">
                        <Globe size={14}/> GLOBAL THREAT MAP
                    </div>
                    <div className="flex-1 bg-black relative overflow-hidden">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/8/88/World_map_blank_without_borders.svg" alt="World Map" className="w-full h-full object-contain opacity-10 grayscale" />
                        {renderMapContent()}
                    </div>
                </div>
                <div className="w-full md:w-1/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <div className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400">
                        OVERLAY ANALYSIS
                    </div>
                    <div className="p-4 text-gray-300">
                        {renderOverlayData()}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WorldStatusPanel;
