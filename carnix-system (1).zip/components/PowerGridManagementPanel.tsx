import React, { useState } from 'react';
import { Zap, Activity } from 'lucide-react';

const PowerGridManagementPanel: React.FC = () => {
    const [load, setLoad] = useState(75);
    const [status, setStatus] = useState('STABLE');

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Zap size={14}/> POWER GRID MANAGEMENT
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="w-full lg:w-1/3 border-b lg:border-b-0 lg:border-r border-[var(--color-panel-header-border)] flex flex-col p-4 gap-4 justify-center">
                     <div className="text-center">
                        <p className="text-sm font-bold text-gray-400">TOTAL GRID LOAD</p>
                        <p className="font-mono text-6xl font-bold text-white mt-2">{load}%</p>
                        <p className={`mt-2 font-bold text-lg ${load > 90 ? 'text-red-500' : 'text-green-500'}`}>
                            {load > 90 ? 'OVERLOAD WARNING' : 'NOMINAL'}
                        </p>
                    </div>
                    <div className="mt-4 space-y-2">
                        <button onClick={() => setLoad(l => Math.min(100, l+5))} className="w-full hud-button">REROUTE TO SECTOR A (+5%)</button>
                        <button onClick={() => setLoad(l => Math.max(0, l-5))} className="w-full hud-button">DIVERT FROM SECTOR B (-5%)</button>
                    </div>
                </div>
                <div className="flex-1 p-4 bg-black/20 flex items-center justify-center">
                    <svg viewBox="0 0 200 150" className="w-full h-full max-w-lg">
                        <defs>
                            <linearGradient id="flowGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                <stop offset="0%" stopColor="var(--color-primary)" stopOpacity="0">
                                    <animate attributeName="stop-opacity" values="0;1;0" dur="2s" repeatCount="indefinite" />
                                </stop>
                                <stop offset="100%" stopColor="var(--color-primary)" />
                            </linearGradient>
                        </defs>
                        {/* Lines */}
                        <path d="M 10 75 H 50" stroke="#374151" strokeWidth="2"/>
                        <path d="M 50 75 L 80 40" stroke="#374151" strokeWidth="2"/>
                        <path d="M 50 75 L 80 110" stroke="#374151" strokeWidth="2"/>
                        <path d="M 80 40 H 120" stroke="#374151" strokeWidth="2"/>
                        <path d="M 80 110 H 120" stroke="#374151" strokeWidth="2"/>
                        <path d="M 120 40 L 150 75" stroke="#374151" strokeWidth="2"/>
                        <path d="M 120 110 L 150 75" stroke="#374151" strokeWidth="2"/>
                        <path d="M 150 75 H 190" stroke="#374151" strokeWidth="2"/>
                        
                        {/* Animated Flow */}
                        <circle cx="0" cy="0" r="2" fill="url(#flowGradient)">
                            <animateMotion dur="3s" repeatCount="indefinite" path="M 10 75 H 50 L 80 40 H 120 L 150 75 H 190" />
                        </circle>
                         <circle cx="0" cy="0" r="2" fill="url(#flowGradient)">
                            <animateMotion dur="3.5s" repeatCount="indefinite" path="M 10 75 H 50 L 80 110 H 120 L 150 75 H 190" />
                        </circle>

                        {/* Nodes */}
                        <circle cx="10" cy="75" r="5" fill="var(--color-primary)" />
                        <circle cx="50" cy="75" r="5" fill="#4b5563" />
                        <circle cx="80" cy="40" r="5" fill="#4b5563" />
                        <circle cx="80" cy="110" r="5" fill="#4b5563" />
                        <circle cx="120" cy="40" r="5" fill="#4b5563" />
                        <circle cx="120" cy="110" r="5" fill="#4b5563" />
                        <circle cx="150" cy="75" r="5" fill="#4b5563" />
                        <circle cx="190" cy="75" r="5" fill="var(--color-primary)" />
                    </svg>
                </div>
            </div>
        </div>
    );
};

export default PowerGridManagementPanel;
