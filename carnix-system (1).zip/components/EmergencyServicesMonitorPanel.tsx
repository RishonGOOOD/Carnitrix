import React, { useState, useEffect } from 'react';
import { Siren, MapPin, Activity } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

interface DispatchLog {
    time: string;
    unit: string;
    event: string;
    location: string;
    priority: 'High' | 'Medium' | 'Low';
}

const EmergencyServicesMonitorPanel: React.FC = () => {
    const { state } = useAppContext();
    const { address } = state;
    const [log, setLog] = useState<DispatchLog[]>([]);
    const [isGenerating, setIsGenerating] = useState(false);

    const generateLogs = async () => {
        if (!state.activeProfile || !address) return;
        setIsGenerating(true);
        try {
            const prompt = `Generate a list of 5 fictional but realistic emergency service dispatch logs for the ${address.city || address.country} area. Include a mix of police, fire, and medical events with varied priorities. Format as a JSON array of objects, each with 'time', 'unit', 'event', 'location', and 'priority' keys.`;
             const res = await getAIResponse(prompt, Mode.EmergencyServicesMonitor, state.activeProfile.aiSettings);
             
             // Basic parsing of JSON from text response
             const jsonMatch = res.text.match(/\[[\s\S]*\]/);
             if (jsonMatch) {
                 const parsedLogs = JSON.parse(jsonMatch[0]);
                 setLog(parsedLogs);
             } else {
                throw new Error("AI did not return a valid JSON array.");
             }

        } catch (e) {
            console.error(e);
            // Fallback to simpler generation if JSON fails
            setLog([{ time: new Date().toLocaleTimeString(), unit: 'SYS', event: 'Failed to parse dispatch data.', location: 'Control', priority: 'Medium' }]);
        } finally {
            setIsGenerating(false);
        }
    };

    useEffect(() => {
        generateLogs();
        const interval = setInterval(generateLogs, 30000); // Refresh every 30 seconds
        return () => clearInterval(interval);
    }, [address]);

    const priorityColor = (priority: string) => {
        switch(priority) {
            case 'High': return 'border-red-500 bg-red-900/20 text-red-400';
            case 'Medium': return 'border-yellow-500 bg-yellow-900/20 text-yellow-400';
            default: return 'border-blue-500 bg-blue-900/20 text-blue-400';
        }
    }

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Siren size={14}/> EMERGENCY SERVICES MONITOR
                </h2>
                <div className="ml-auto text-xs font-mono text-gray-400 flex items-center gap-2">
                    <MapPin size={12}/> SECTOR: {address?.city || address?.country || 'UNKNOWN'}
                </div>
            </div>
            <div className="flex-1 hud-panel flex flex-col overflow-hidden">
                <div className="hud-panel-header grid grid-cols-4 text-xs">
                    <span>TIME</span>
                    <span>EVENT</span>
                    <span>LOCATION</span>
                    <span className="text-center">PRIORITY</span>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-2 bg-black/20">
                    {log.map((entry, i) => (
                        <div key={i} className={`grid grid-cols-4 gap-4 p-2 border-l-4 rounded items-center font-mono text-sm animate-enter ${priorityColor(entry.priority)}`}>
                            <span className="text-gray-400 text-xs">{entry.time}</span>
                            <span className="text-white font-bold truncate">{entry.event}</span>
                            <span className="text-gray-300 truncate">{entry.location}</span>
                            <span className="text-center font-bold">{entry.priority.toUpperCase()}</span>
                        </div>
                    ))}
                    {isGenerating && <Activity className="animate-spin text-gray-500 mx-auto my-4"/>}
                </div>
            </div>
        </div>
    );
};

export default EmergencyServicesMonitorPanel;
