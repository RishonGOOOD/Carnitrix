


import React, { useState } from 'react';
import { BookOpen, Plus, Save, Trash2, Calendar } from 'lucide-react';
import { useAppContext } from '../context';
import { JournalEntry } from '../types';
import { playSound } from '../utils/soundEffects';

const JournalPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const journal = state.activeProfile?.journal || [];

    const [isWriting, setIsWriting] = useState(false);
    const [currentEntry, setCurrentEntry] = useState('');
    const today = new Date().toISOString().split('T')[0];

    const onUpdateJournal = (newJournal: JournalEntry[]) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { journal: newJournal } });
    };

    const handleSave = () => {
        if (!currentEntry.trim()) return;

        const existingEntryIndex = journal.findIndex(e => e.date === today);
        let newJournal: JournalEntry[];

        if (existingEntryIndex > -1) {
            // Update today's entry
            newJournal = [...journal];
            newJournal[existingEntryIndex] = { ...newJournal[existingEntryIndex], content: currentEntry };
        } else {
            // Add a new entry for today
            const newEntry: JournalEntry = { id: `j-${Date.now()}`, date: today, content: currentEntry };
            newJournal = [newEntry, ...journal];
        }
        
        onUpdateJournal(newJournal.sort((a,b) => b.date.localeCompare(a.date)));
        setIsWriting(false);
        playSound('success');
    };
    
    const handleDelete = (id: string) => {
        if (confirm("Delete this log entry permanently?")) {
            onUpdateJournal(journal.filter(e => e.id !== id));
            playSound('error');
        }
    };

    const startNewEntry = () => {
        const todaysEntry = journal.find(e => e.date === today);
        setCurrentEntry(todaysEntry?.content || '');
        setIsWriting(true);
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><BookOpen size={16}/> CAPTAIN'S LOG</h2>
                {isWriting ? (
                    <button onClick={handleSave} className="px-3 py-1 bg-green-700 text-white rounded text-xs flex items-center gap-1">
                        <Save size={12} /> SAVE ENTRY
                    </button>
                ) : (
                    <button onClick={startNewEntry} className="px-3 py-1 bg-[var(--color-primary)]/20 text-[var(--color-primary)] rounded text-xs flex items-center gap-1">
                        <Plus size={12} /> {journal.find(e => e.date === today) ? 'EDIT' : 'NEW'} TODAY'S ENTRY
                    </button>
                )}
            </div>
            
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md overflow-y-auto p-4">
                {isWriting ? (
                     <div className="h-full flex flex-col">
                        <h3 className="font-bold text-lg text-white">Log Entry: {today}</h3>
                        <textarea
                            value={currentEntry}
                            onChange={e => setCurrentEntry(e.target.value)}
                            className="flex-1 w-full bg-black/50 border border-gray-700 rounded p-2 text-sm resize-none focus:outline-none focus:border-[var(--color-primary)] my-2"
                            placeholder="Begin writing..."
                        />
                     </div>
                ) : (
                    <div className="space-y-6">
                        {journal.map(entry => (
                            <div key={entry.id} className="border-b border-gray-800 pb-4 group">
                                <div className="flex justify-between items-center mb-2">
                                    <h3 className="font-bold text-lg text-[var(--color-primary)] flex items-center gap-2">
                                        <Calendar size={14}/> {entry.date}
                                    </h3>
                                    <button onClick={() => handleDelete(entry.id)} className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Trash2 size={16}/>
                                    </button>
                                </div>
                                <p className="text-sm text-gray-300 whitespace-pre-wrap font-mono">{entry.content}</p>
                            </div>
                        ))}
                    </div>
                )}
                 {journal.length === 0 && !isWriting && (
                    <div className="text-center text-gray-500 mt-10">
                        No log entries found.
                    </div>
                )}
            </div>
        </div>
    );
};

export default JournalPanel;