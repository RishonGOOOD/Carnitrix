
import React, { useState, useEffect, useRef } from 'react';
import { Cpu, Terminal, Power, Zap, Code, RefreshCw, Wifi, Plus, Trash2, Save, Download, Wrench, FileCode, Loader2, Usb, XCircle } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';
import { useAppContext } from '../context';

interface IoTButton {
    id: string;
    label: string;
    command: string;
    color: string;
    icon: string;
}

interface IoTProject {
    name: string;
    board: string;
    buttons: IoTButton[];
    firmware: string;
    endpoint: string; 
}

const MicrocontrollerPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;

    // Project State
    const [project, setProject] = useState<IoTProject>(() => {
        const saved = localStorage.getItem('carnix_mcu_project');
        return saved ? JSON.parse(saved) : {
            name: 'CARNIX_MCU_01',
            board: 'Arduino UNO',
            buttons: [
                { id: '1', label: 'LED_ON', command: 'ON', color: 'bg-green-600', icon: 'zap' },
                { id: '2', label: 'LED_OFF', command: 'OFF', color: 'bg-red-600', icon: 'power' }
            ],
            firmware: '',
            endpoint: 'http://192.168.4.1'
        };
    });

    // Hardware State
    const portRef = useRef<any>(null);
    const writerRef = useRef<any>(null);
    const [isConnected, setIsConnected] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const [termOutput, setTermOutput] = useState<string[]>(['[SYSTEM] Interface Ready.', '[SYSTEM] Select physical link or wireless relay...']);
    const [activeTab, setActiveTab] = useState<'CONTROLS' | 'FIRMWARE' | 'CONFIG'>('CONTROLS');
    const [isGenerating, setIsGenerating] = useState(false);

    // Form Input
    const [newBtnLabel, setNewBtnLabel] = useState('');
    const [newBtnCmd, setNewBtnCmd] = useState('');

    const log = (msg: string) => setTermOutput(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`].slice(-40));

    useEffect(() => {
        localStorage.setItem('carnix_mcu_project', JSON.stringify(project));
    }, [project]);

    const connectUSB = async () => {
        if (!('serial' in navigator)) {
            log('[ERR] Web Serial API not detected.');
            return;
        }
        if (isConnected) {
            try {
                if (writerRef.current) await writerRef.current.releaseLock();
                if (portRef.current) await portRef.current.close();
                setIsConnected(false);
                log('[SYS] Serial Link Terminated.');
            } catch (e: any) { log(`[ERR] Disconnect failed: ${e.message}`); }
            return;
        }
        setIsConnecting(true);
        try {
            const p = await (navigator as any).serial.requestPort();
            await p.open({ baudRate: 115200 });
            portRef.current = p;
            const textEncoder = new TextEncoderStream();
            const writableStreamClosed = textEncoder.readable.pipeTo(p.writable);
            writerRef.current = textEncoder.writable.getWriter();
            setIsConnected(true);
            log('[OK] Physical Link Established // 115200 Baud');
            playSound('access');
        } catch (e: any) {
            log(`[FAULT] Link Aborted: ${e.message}`);
        } finally { setIsConnecting(false); }
    };

    const executeCommand = async (cmd: string) => {
        log(`[TX] ${cmd}`);
        playSound('click');
        if (writerRef.current && isConnected) {
            try { await writerRef.current.write(cmd + "\n"); triggerHaptic('light'); }
            catch (e) { log('[ERR] Serial Write Failure.'); }
        } else if (project.endpoint && !isConnected) {
            try {
                fetch(`${project.endpoint}/${cmd.toLowerCase()}`, { mode: 'no-cors' })
                    .then(() => log(`[WiFi] Sent to ${project.endpoint}`))
                    .catch(() => log('[ERR] Wireless relay timeout.'));
            } catch (e) { log('[ERR] Network Request Failed.'); }
        } else {
            log('[WARN] No active interface.');
        }
    };

    const addBtn = () => {
        if (!newBtnLabel || !newBtnCmd) return;
        const btn: IoTButton = {
            id: Date.now().toString(),
            label: newBtnLabel.toUpperCase(),
            command: newBtnCmd,
            color: 'bg-blue-900/30 border-blue-500',
            icon: 'cpu'
        };
        setProject(p => ({ ...p, buttons: [...p.buttons, btn] }));
        setNewBtnLabel(''); setNewBtnCmd('');
        playSound('success');
    };

    const deleteBtn = (id: string) => {
        setProject(p => ({ ...p, buttons: p.buttons.filter(b => b.id !== id) }));
        playSound('error');
    };

    const generateCode = async () => {
        if (!activeProfile) return;
        setIsGenerating(true);
        playSound('process');
        
        try {
            const prompt = `Generate Arduino C++ code for a microcontroller project. 
            Board: ${project.board}. 
            Functionality: It should listen for Serial/HTTP commands and control GPIO pins.
            Commands to handle: ${project.buttons.map(b => `"${b.command}" (Button: ${b.label})`).join(', ')}.
            Include setup() and loop() with Serial.begin(115200). 
            If board is ESP32/ESP8266, include WiFi setup (SSID: "CARNIX_NODE", Pass: "password") and a WebServer.
            Return ONLY the raw code.`;

            const res = await getAIResponse(prompt, Mode.Microcontroller, activeProfile.aiSettings);
            const code = res.text.replace(/```cpp|```c|```/g, '').trim();
            
            setProject(p => ({ ...p, firmware: code }));
            playSound('success');
        } catch (e: any) {
            log(`[ERR] Auto-code gen failed: ${e.message}`);
        } finally {
            setIsGenerating(false);
        }
    };

    const exportIno = () => {
        if (!project.firmware) {
            log('[WARN] No firmware to export.');
            return;
        }
        const blob = new Blob([project.firmware], { type: 'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `${project.name.replace(/\s+/g, '_')}.ino`;
        a.click();
        URL.revokeObjectURL(a.href);
        playSound('success');
        log('[SYS] Firmware exported to device.');
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani] animate-enter">
            {/* HUD HEADER */}
            <div className="flex-shrink-0 bg-black/60 border border-red-600/30 p-3 rounded-lg flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-red-600/10 border border-red-600 rounded-lg flex items-center justify-center text-red-500 shadow-[0_0_20px_rgba(255,0,60,0.3)]">
                        <Cpu size={20} className={isConnected ? 'animate-pulse' : ''} />
                    </div>
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic tracking-tighter">IoT Architect Hub</h2>
                        <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                             <Wrench size={10} /> Board: {project.board} // Interface: {isConnected ? <span className="text-green-500">ONLINE</span> : <span className="text-red-500">OFFLINE</span>}
                        </div>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button onClick={connectUSB} disabled={isConnecting} className={`hud-button !py-2 !px-4 text-[10px] flex items-center gap-2 ${isConnected ? '!bg-red-600/20 !border-red-500 !text-red-500' : '!bg-green-600/20 !border-green-500 !text-green-500'}`}>
                        {isConnecting ? <RefreshCw className="animate-spin" size={14}/> : isConnected ? <XCircle size={14}/> : <Usb size={14}/>}
                        {isConnected ? 'DISCONNECT' : 'CONNECT SERIAL'}
                    </button>
                    <div className="flex bg-black rounded border border-gray-800 p-0.5">
                        {(['CONTROLS', 'FIRMWARE', 'CONFIG'] as const).map(t => (
                            <button key={t} onClick={() => setActiveTab(t)} className={`px-4 py-1 text-[10px] font-black rounded transition-all ${activeTab === t ? 'bg-red-600 text-black' : 'text-gray-500 hover:text-white'}`}>
                                {t}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row gap-2 overflow-hidden">
                {/* WORKSPACE */}
                <div className="flex-1 bg-black/40 border border-white/5 rounded-lg overflow-hidden flex flex-col">
                    {activeTab === 'CONTROLS' && (
                        <div className="flex-1 p-4 overflow-y-auto scrollbar-carnix flex flex-col">
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 mb-4">
                                {project.buttons.map(btn => (
                                    <div key={btn.id} className="relative group">
                                        <button 
                                            onClick={() => executeCommand(btn.command)}
                                            className={`w-full h-24 border rounded-xl flex flex-col items-center justify-center gap-2 transition-all hover:scale-105 active:scale-95 ${btn.color} border-white/10 group-hover:border-red-600 shadow-lg`}
                                        >
                                            {btn.icon === 'power' ? <Power size={24}/> : btn.icon === 'zap' ? <Zap size={24}/> : <Terminal size={24}/>}
                                            <div className="flex flex-col items-center">
                                                <span className="text-[10px] font-black tracking-[0.2em]">{btn.label}</span>
                                                <span className="text-[8px] font-mono text-gray-400 opacity-60">TX: {btn.command}</span>
                                            </div>
                                        </button>
                                        <button onClick={() => deleteBtn(btn.id)} className="absolute top-1 right-1 p-1.5 bg-black/80 rounded-full text-red-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white">
                                            <Trash2 size={10}/>
                                        </button>
                                    </div>
                                ))}
                                
                                {/* Add New Button Card */}
                                <div className="h-24 border-2 border-dashed border-gray-800 rounded-xl flex flex-col items-center justify-center p-2 gap-2 bg-black/20 hover:border-gray-600 transition-colors">
                                    <div className="w-full flex gap-1">
                                        <input value={newBtnLabel} onChange={e => setNewBtnLabel(e.target.value)} placeholder="LABEL" className="flex-1 bg-black border border-gray-700 text-[9px] p-1 rounded text-white text-center uppercase" />
                                        <input value={newBtnCmd} onChange={e => setNewBtnCmd(e.target.value)} placeholder="CMD" className="flex-1 bg-black border border-gray-700 text-[9px] p-1 rounded text-white text-center" />
                                    </div>
                                    <button onClick={addBtn} className="w-full py-1 bg-white/5 border border-white/10 text-[9px] font-black uppercase hover:bg-green-600 hover:text-black transition-all rounded flex items-center justify-center gap-1">
                                        <Plus size={10}/> ADD CONTROL
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'FIRMWARE' && (
                        <div className="flex-1 flex flex-col p-4 gap-4 overflow-hidden">
                            <div className="flex justify-between items-center bg-black/40 p-3 border border-white/5 rounded">
                                <div className="flex items-center gap-2">
                                    <FileCode size={18} className="text-red-500" />
                                    <h3 className="text-xs font-black text-gray-300 uppercase tracking-widest">AI Firmware Forge</h3>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={generateCode} disabled={isGenerating} className="text-[10px] bg-red-600 text-black font-black px-4 py-1.5 rounded flex items-center gap-2">
                                        {isGenerating ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />} AI GENERATE
                                    </button>
                                    <button onClick={exportIno} disabled={!project.firmware} className="text-[10px] bg-cyan-600 text-black font-black px-4 py-1.5 rounded flex items-center gap-2 disabled:opacity-50">
                                        <Download size={12} /> EXPORT .INO
                                    </button>
                                </div>
                            </div>
                            <div className="flex-1 relative">
                                <textarea 
                                    className="absolute inset-0 w-full h-full bg-black/80 p-4 border border-white/5 rounded font-mono text-[11px] text-green-500/80 resize-none outline-none focus:border-green-500"
                                    value={project.firmware || '// Use AI Generate to create code based on your buttons...'}
                                    readOnly
                                />
                            </div>
                        </div>
                    )}

                    {activeTab === 'CONFIG' && (
                        <div className="flex-1 p-8 space-y-8 overflow-y-auto">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Architect Designation</label>
                                    <input value={project.name} onChange={e => setProject({...project, name: e.target.value})} className="w-full bg-black/60 border border-gray-800 p-3 text-white font-mono text-sm outline-none focus:border-red-600 rounded" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Logic Core Model</label>
                                    <select value={project.board} onChange={e => setProject({...project, board: e.target.value})} className="w-full bg-black/60 border border-gray-800 p-3 text-white text-sm outline-none focus:border-red-600 rounded">
                                        <option>Arduino UNO / Nano</option>
                                        <option>ESP32 DevKit V1</option>
                                        <option>NodeMCU ESP8266</option>
                                        <option>Raspberry Pi Pico</option>
                                    </select>
                                </div>
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Wireless Beacon Endpoint (Optional)</label>
                                <input value={project.endpoint} onChange={e => setProject({...project, endpoint: e.target.value})} className="w-full bg-black/60 border border-gray-800 p-3 text-white font-mono text-sm outline-none focus:border-red-600 rounded" placeholder="http://192.168.4.1" />
                            </div>
                            <div className="pt-4 border-t border-white/5 flex gap-4">
                                <button onClick={() => { setProject({...project, buttons: []}); playSound('error'); }} className="hud-button !bg-red-900/20 !border-red-600 !text-red-500 flex items-center justify-center gap-2 py-3 px-6"><Trash2 size={16}/> WIPE UI</button>
                                <button onClick={() => { localStorage.setItem('carnix_mcu_project', JSON.stringify(project)); playSound('success'); }} className="flex-1 hud-button flex items-center justify-center gap-2 py-3"><Save size={16}/> COMMIT ARCHITECTURE</button>
                            </div>
                        </div>
                    )}
                </div>

                {/* LOGS */}
                <div className="w-full lg:w-80 bg-black border border-white/5 flex flex-col rounded-lg overflow-hidden">
                    <div className="p-3 border-b border-white/10 bg-white/5 flex justify-between items-center">
                         <div className="flex items-center gap-2">
                            <Terminal size={14} className="text-red-500" />
                            <span className="text-[10px] font-black text-gray-400 tracking-widest uppercase">Serial Monitor</span>
                         </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 font-mono text-[9px] space-y-1.5 bg-[#030101] scrollbar-carnix">
                         {termOutput.map((line, i) => (
                             <div key={i} className={`break-words ${line.includes('[ERR]') ? 'text-red-500' : line.includes('[TX]') ? 'text-cyan-400' : 'text-gray-500'}`}>
                                 {line}
                             </div>
                         ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MicrocontrollerPanel;
