import React, { useState, useEffect, useRef } from 'react';
import { TerminalSandbox, TerminalExecutionResult, TerminalAuditEntry, SandboxTelemetry } from '../services/terminalSandbox';
import { 
  Terminal as TerminalIcon, ShieldCheck, Play, Trash2, Clock, 
  Cpu, HardDrive, ListFilter, AlertTriangle, CheckCircle2, Lock, Sparkles
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const SecureTerminalPanel: React.FC = () => {
  const [commandInput, setCommandInput] = useState('');
  const [history, setHistory] = useState<TerminalExecutionResult[]>([]);
  const [telemetry, setTelemetry] = useState<SandboxTelemetry>(TerminalSandbox.getTelemetry());
  const [activeTab, setActiveTab] = useState<'CONSOLE' | 'AUDIT_LOG' | 'SECURITY_POLICY'>('CONSOLE');
  const [auditLogs, setAuditLogs] = useState<TerminalAuditEntry[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial banner
    handleExecute('help');
    const interval = setInterval(() => {
      setTelemetry(TerminalSandbox.getTelemetry());
      setAuditLogs(TerminalSandbox.getAuditLogs());
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleExecute = async (cmdToRun?: string) => {
    const cmd = (cmdToRun !== undefined ? cmdToRun : commandInput).trim();
    if (!cmd) return;

    if (cmd.toLowerCase() === 'clear') {
      setHistory([]);
      setCommandInput('');
      playSound('click');
      return;
    }

    setIsExecuting(true);
    playSound('type');
    triggerHaptic('light');

    const result = await TerminalSandbox.execute(cmd);
    setHistory(prev => [...prev, result]);
    setTelemetry(TerminalSandbox.getTelemetry());
    setAuditLogs(TerminalSandbox.getAuditLogs());
    setIsExecuting(false);
    setCommandInput('');

    if (result.exitCode === 0) {
      playSound('success');
    } else {
      playSound('alert');
    }
  };

  const sampleCommands = [
    'ls -la /cases',
    'cat /cases/active_investigation.json | jq .',
    'grep -i "185." sample_ioc.txt',
    'sha256sum /home/analyst/sample_ioc.txt',
    'curl https://crt.sh/?q=apex-defense.org',
    'python -c "import hashlib; print(hashlib.sha256(b\'carnix\').hexdigest())"',
    'node -e "console.log(Buffer.from(\'CARNIX_SANDBOX\').toString(\'base64\'))"',
    'curl http://169.254.169.254/latest/meta-data/' // Demonstrates SSRF violation blocking
  ];

  return (
    <div className="w-full h-full flex flex-col gap-3 font-[Rajdhani] bg-[#050002]/95 text-white overflow-hidden p-2 sm:p-4">
      {/* Header Bar with Telemetry Gauges */}
      <div className="flex flex-wrap items-center justify-between p-3 bg-black/80 border border-red-900/30 rounded-xl gap-2 shadow-inner">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-red-950/80 border border-red-600/40 rounded-lg">
            <TerminalIcon size={18} className="text-red-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black font-orbitron text-white">CARNIX SECURE TERMINAL</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800 flex items-center gap-1">
                <Lock size={10} /> ISOLATED CONTAINER SANDBOX
              </span>
            </div>
            <div className="text-[11px] font-mono text-gray-400">
              Host credentials, SSH keys, and OS roots are inaccessible. Strict SSRF policy enforced.
            </div>
          </div>
        </div>

        {/* Resource Telemetry */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-black/60 rounded border border-white/5">
            <Cpu size={14} className="text-cyan-400" />
            <span className="text-gray-400">CPU:</span>
            <span className="font-bold text-white">{telemetry.cpuUsagePercent}%</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-black/60 rounded border border-white/5">
            <HardDrive size={14} className="text-yellow-400" />
            <span className="text-gray-400">MEM:</span>
            <span className="font-bold text-white">{telemetry.memoryUsageMb}MB / {telemetry.maxMemoryMb}MB</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-black/60 rounded border border-white/5">
            <Clock size={14} className="text-emerald-400" />
            <span className="text-gray-400">UPTIME:</span>
            <span className="font-bold text-white">{telemetry.sessionUptimeSeconds}s</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-red-900/30 pb-2">
        <button
          onClick={() => { setActiveTab('CONSOLE'); playSound('click'); }}
          className={`px-4 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'CONSOLE' ? 'bg-red-600 text-black shadow-[0_0_10px_rgba(255,0,0,0.5)]' : 'bg-black/40 text-gray-400 hover:text-white'
          }`}
        >
          $ TERMINAL CONSOLE
        </button>
        <button
          onClick={() => { setActiveTab('AUDIT_LOG'); playSound('click'); }}
          className={`px-4 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'AUDIT_LOG' ? 'bg-red-600 text-black shadow-[0_0_10px_rgba(255,0,0,0.5)]' : 'bg-black/40 text-gray-400 hover:text-white'
          }`}
        >
          AUDIT LOGS ({auditLogs.length})
        </button>
        <button
          onClick={() => { setActiveTab('SECURITY_POLICY'); playSound('click'); }}
          className={`px-4 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
            activeTab === 'SECURITY_POLICY' ? 'bg-red-600 text-black shadow-[0_0_10px_rgba(255,0,0,0.5)]' : 'bg-black/40 text-gray-400 hover:text-white'
          }`}
        >
          SECURITY & SSRF POLICY
        </button>
      </div>

      {/* Main Content Area */}
      {activeTab === 'CONSOLE' && (
        <div className="flex-1 flex flex-col bg-black/95 border border-red-900/30 rounded-xl overflow-hidden shadow-2xl">
          {/* Scrollable output window */}
          <div className="flex-1 overflow-y-auto scrollbar-carnix p-4 space-y-3 font-mono text-xs">
            {history.map((h, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex items-center gap-2 text-gray-400">
                  <span className="text-red-500 font-bold">analyst@carnix-sandbox:{TerminalSandbox.getCurrentDirectory()}$</span>
                  <span className="text-white font-bold">{h.command}</span>
                  <span className="text-[10px] text-gray-600 ml-auto">
                    {h.executionTimeMs}ms • exit: {h.exitCode}
                  </span>
                </div>
                {h.stdout && (
                  <pre className="p-2.5 bg-black/60 rounded border border-white/5 text-emerald-400 whitespace-pre-wrap leading-relaxed">
                    {h.stdout}
                  </pre>
                )}
                {h.stderr && (
                  <pre className="p-2.5 bg-red-950/30 rounded border border-red-900/40 text-red-400 whitespace-pre-wrap leading-relaxed">
                    {h.stderr}
                  </pre>
                )}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          {/* Quick Command Pills */}
          <div className="px-3 py-2 bg-black/60 border-t border-white/5 flex flex-wrap items-center gap-1.5 text-[11px] font-mono">
            <span className="text-gray-500 text-[10px]">SAFE UTILITIES:</span>
            {sampleCommands.map((cmd, i) => (
              <button
                key={i}
                onClick={() => handleExecute(cmd)}
                className="px-2 py-0.5 rounded bg-black/80 hover:bg-red-950/40 border border-white/10 hover:border-red-900/60 text-gray-300 hover:text-white transition-all text-[10px]"
              >
                {cmd.length > 28 ? cmd.slice(0, 28) + '...' : cmd}
              </button>
            ))}
          </div>

          {/* Command Prompt Input */}
          <form
            onSubmit={(e) => { e.preventDefault(); handleExecute(); }}
            className="flex items-center gap-2 p-3 bg-black/90 border-t border-red-900/40"
          >
            <span className="text-red-500 font-mono font-bold text-xs">analyst@carnix$</span>
            <input
              type="text"
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              placeholder="e.g. python -c '...', jq ., grep, ls, sha256sum, curl https://crt.sh/..."
              disabled={isExecuting}
              className="flex-1 bg-transparent border-none text-xs font-mono text-white placeholder-gray-600 focus:outline-none"
              autoFocus
            />
            <button
              type="submit"
              disabled={isExecuting || !commandInput.trim()}
              className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase rounded transition-all disabled:opacity-40 flex items-center gap-1"
            >
              <Play size={12} /> RUN
            </button>
          </form>
        </div>
      )}

      {activeTab === 'AUDIT_LOG' && (
        <div className="flex-1 overflow-y-auto scrollbar-carnix bg-black/90 border border-red-900/30 rounded-xl p-4 font-mono text-xs space-y-2">
          <div className="flex justify-between items-center text-gray-400 font-bold pb-2 border-b border-white/10">
            <span>IMMUTABLE COMMAND AUDIT TRAIL</span>
            <span>TOTAL EXECUTIONS: {auditLogs.length}</span>
          </div>
          {auditLogs.map((log, i) => (
            <div key={i} className="p-2.5 bg-black/60 rounded border border-white/5 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="text-white font-bold">{log.command}</div>
                <div className="text-[10px] text-gray-500">
                  User: {log.user} | Session: {log.sessionId} | Time: {new Date(log.timestamp).toLocaleTimeString()}
                </div>
              </div>
              <div className="text-right">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  log.exitCode === 0 ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'
                }`}>
                  EXIT {log.exitCode}
                </span>
                <div className="text-[10px] text-gray-500 mt-1">{log.durationMs}ms</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'SECURITY_POLICY' && (
        <div className="flex-1 overflow-y-auto scrollbar-carnix bg-black/90 border border-red-900/30 rounded-xl p-5 font-mono text-xs space-y-4">
          <h3 className="text-sm font-bold text-white uppercase flex items-center gap-2 font-orbitron">
            <ShieldCheck size={16} className="text-red-500" /> CARNIX SECURE TERMINAL ENFORCEMENT SPECIFICATION
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-lg space-y-2">
              <div className="text-red-400 font-bold">1. File System Sandboxing</div>
              <p className="text-gray-300 text-[11px] leading-relaxed">
                The terminal operates strictly within an ephemeral, in-memory virtual file system (VFS). All file creation, editing, and deletion operations affect only virtual nodes and never write to the host container.
              </p>
            </div>
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-lg space-y-2">
              <div className="text-red-400 font-bold">2. Server-Side Request Forgery (SSRF) Defense</div>
              <p className="text-gray-300 text-[11px] leading-relaxed">
                Outbound network invocations via `curl` enforce strict IP denylists (blocking RFC 1918 private subnets 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, loopback 127.0.0.1, and Cloud Metadata 169.254.169.254).
              </p>
            </div>
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-lg space-y-2">
              <div className="text-red-400 font-bold">3. Resource Quotas & Process Throttling</div>
              <p className="text-gray-300 text-[11px] leading-relaxed">
                CPU usage is capped at 1.0 vCPU, memory ceiling is constrained to 512MB RAM, and execution threads are limited to a maximum of 10 concurrent tasks with an automatic 15-second command timeout.
              </p>
            </div>
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-lg space-y-2">
              <div className="text-red-400 font-bold">4. Immutable Audit Ledger</div>
              <p className="text-gray-300 text-[11px] leading-relaxed">
                Every keystroke, command invocation, execution time, and process return code is recorded chronologically into the tamper-resistant session audit trail.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecureTerminalPanel;
