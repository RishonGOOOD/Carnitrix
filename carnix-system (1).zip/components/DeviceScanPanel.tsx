
import React, { useState, useEffect } from 'react';
import { Wifi, Bluetooth, Usb, Radio, Loader2, ScanLine } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const WifiBtScanner: React.FC = () => {
    const [btDevices, setBtDevices] = useState<any[]>([]);
    const [isScanningBt, setIsScanningBt] = useState(false);
    const [btError, setBtError] = useState<string | null>(null);

     const handleBtScan = async () => {
        // FIX: Cast navigator to any for bluetooth check
        if (!(navigator as any).bluetooth) {
            setBtError("Web Bluetooth API is not available on this browser. Try Chrome/Edge.");
            return;
        }
        setIsScanningBt(true);
        setBtError(null);
        setBtDevices([]);
        playSound('scan');
        try {
            const device = await (navigator as any).bluetooth.requestDevice({ acceptAllDevices: true });
            setBtDevices(prev => [...prev, { id: device.id, name: device.name || 'Unnamed Device' }]);
        } catch (error: any) {
            if (error.name !== 'NotFoundError') setBtError(`Error: ${error.message}`);
        } finally {
            setIsScanningBt(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
             <div className="flex-1 flex flex-col bg-black/30 border border-gray-800 rounded-lg">
                <div className="p-3 border-b border-gray-700 flex justify-between items-center">
                    <h3 className="text-sm font-bold text-blue-400 flex items-center gap-2"><Bluetooth size={16}/> BLUETOOTH LE SCANNER</h3>
                    <button onClick={handleBtScan} disabled={isScanningBt} className="px-3 py-1 bg-blue-900/40 text-blue-300 border border-blue-700 rounded text-xs">SCAN</button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-2">
                    {btError && <div className="text-red-500 text-sm">{btError}</div>}
                    {btDevices.length === 0 && !btError && !isScanningBt && <div className="text-gray-500 text-xs italic">No devices scanned yet. Click SCAN to pair.</div>}
                    {btDevices.map(d => <div key={d.id} className="p-3 bg-black/40 border border-gray-700 rounded text-sm text-white font-mono flex justify-between"><span>{d.name}</span> <span className="text-gray-500">{d.id}</span></div>)}
                </div>
            </div>
        </div>
    );
};

const SerialUsbScanner: React.FC = () => {
    const [ports, setPorts] = useState<any[]>([]);
    const [isScanning, setIsScanning] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const scanSerialPorts = async () => {
        if (!('serial' in navigator)) {
            setError("Web Serial API not supported in this browser.");
            return;
        }
        setIsScanning(true);
        setError(null);
        try {
            const availablePorts = await (navigator as any).serial.getPorts();
            setPorts(availablePorts);
        } catch (e: any) {
            setError(e.message);
        }
        setIsScanning(false);
    };
    
    const requestSerialPort = async () => {
         if (!('serial' in navigator)) return;
         try {
            const port = await (navigator as any).serial.requestPort();
            scanSerialPorts(); // Rescan to include the new port
         } catch (e: any) {
            if (e.name !== 'NotFoundError') setError("Failed to connect to port.");
         }
    };

    useEffect(() => {
        scanSerialPorts();
    }, []);

    return (
         <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="p-4 bg-black/30 border border-gray-800 rounded-lg">
                <h3 className="text-sm font-bold text-white mb-2">Serial / USB Ports</h3>
                <p className="text-xs text-gray-400 mb-4">Scan for connected serial devices like microcontrollers (Arduino, etc.). If no devices appear, you may need to grant access first.</p>
                <div className="flex gap-2">
                    <button onClick={scanSerialPorts} className="flex-1 p-2 bg-gray-700 rounded text-xs">REFRESH LIST</button>
                    <button onClick={requestSerialPort} className="flex-1 p-2 bg-blue-700 rounded text-xs">REQUEST NEW DEVICE</button>
                </div>
            </div>
            <div className="flex-1 p-2 bg-black/20 border border-gray-800 rounded-lg overflow-y-auto">
                 {error && <div className="text-red-500 text-sm p-2">{error}</div>}
                 {ports.map((port, i) => {
                     const info = port.getInfo();
                     return (
                        <div key={i} className="p-3 bg-black/40 border border-gray-700 rounded mb-2 text-sm font-mono">
                           <p>Device Found</p>
                           <p className="text-xs text-gray-400">Vendor ID: {info.usbVendorId || 'N/A'}</p>
                           <p className="text-xs text-gray-400">Product ID: {info.usbProductId || 'N/A'}</p>
                        </div>
                     )
                 })}
                 {ports.length === 0 && !error && <div className="text-gray-500 text-center p-4">No connected serial devices detected.</div>}
            </div>
        </div>
    );
};


type ActiveTab = 'BT' | 'SERIAL';

const DeviceScanPanel: React.FC = () => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('BT');

    return (
        <div className="w-full h-full flex flex-col text-sm bg-transparent gap-2">
            <div className="flex items-center gap-2 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-1">
                 <button 
                    onClick={() => setActiveTab('BT')} 
                    className={`flex-1 p-2 rounded flex items-center justify-center gap-2 text-xs font-bold transition-colors ${activeTab === 'BT' ? 'bg-[var(--color-primary)] text-black' : 'bg-black/50 hover:bg-white/10'}`}
                >
                    <Bluetooth size={14}/> BLUETOOTH
                </button>
                 <button 
                    onClick={() => setActiveTab('SERIAL')} 
                    className={`flex-1 p-2 rounded flex items-center justify-center gap-2 text-xs font-bold transition-colors ${activeTab === 'SERIAL' ? 'bg-[var(--color-primary)] text-black' : 'bg-black/50 hover:bg-white/10'}`}
                >
                    <Usb size={14}/> SERIAL & USB
                </button>
            </div>
            <div className="flex-1 overflow-hidden">
                {activeTab === 'BT' && <WifiBtScanner />}
                {activeTab === 'SERIAL' && <SerialUsbScanner />}
            </div>
        </div>
    );
};

export default DeviceScanPanel;
