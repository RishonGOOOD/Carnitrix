
import React, { useState, useEffect, useRef } from 'react';
import { Mic, BrainCircuit, X, GripHorizontal, Ghost } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { playSound } from '../utils/soundEffects';
import { speak } from '../utils/textToSpeech';

const FloatingAssistant: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile, mode, isStealthMode } = state;
    
    // State
    const [isListening, setIsListening] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const [transcript, setTranscript] = useState('');
    const [position, setPosition] = useState({ x: window.innerWidth - 80, y: window.innerHeight - 150 });
    const [isDragging, setIsDragging] = useState(false);
    const [opacity, setOpacity] = useState(0.3);

    const recognitionRef = useRef<any>(null);
    const dragOffset = useRef({ x: 0, y: 0 });
    const assistantRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const maxX = window.innerWidth - 60;
        const maxY = window.innerHeight - 60;
        setPosition(prev => ({
            x: Math.min(prev.x, maxX),
            y: Math.min(prev.y, maxY)
        }));
    }, []);

    useEffect(() => {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
            recognitionRef.current = new SpeechRecognition();
            recognitionRef.current.continuous = false;
            recognitionRef.current.interimResults = false;
            recognitionRef.current.lang = 'en-US';

            recognitionRef.current.onstart = () => {
                setIsListening(true);
                setOpacity(1);
                playSound('scan');
            };

            recognitionRef.current.onend = () => {
                setIsListening(false);
                if (!expanded && !isDragging) setOpacity(isStealthMode ? 0.05 : 0.3);
            };

            recognitionRef.current.onresult = async (event: any) => {
                const text = event.results[0][0].transcript;
                setTranscript(text);
                handleCommand(text);
            };
        }
    }, [expanded, isDragging, isStealthMode]);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (isDragging) {
                const newX = e.clientX - dragOffset.current.x;
                const newY = e.clientY - dragOffset.current.y;
                const maxX = window.innerWidth - (assistantRef.current?.offsetWidth || 60);
                const maxY = window.innerHeight - (assistantRef.current?.offsetHeight || 60);
                setPosition({ x: Math.max(0, Math.min(newX, maxX)), y: Math.max(0, Math.min(newY, maxY)) });
            }
        };
        const handleMouseUp = () => {
            setIsDragging(false);
            if (!expanded && !isListening) setOpacity(isStealthMode ? 0.05 : 0.3);
        };
        if (isDragging) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
            setOpacity(0.8);
        }
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, expanded, isListening, isStealthMode]);

    const startDrag = (e: React.MouseEvent) => {
        if ((e.target as HTMLElement).tagName === 'BUTTON') return;
        setIsDragging(true);
        dragOffset.current = { x: e.clientX - position.x, y: e.clientY - position.y };
    };

    const toggleListen = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (isListening) {
            recognitionRef.current?.stop();
        } else {
            setExpanded(true);
            setOpacity(1);
            recognitionRef.current?.start();
        }
    };

    const handleCommand = async (text: string) => {
        if (!activeProfile) return;
        setIsProcessing(true);
        playSound('process');
        try {
            dispatch({ type: 'ADD_MESSAGE', payload: { id: Date.now(), sender: 'user', text } });
            const response = await getAIResponse(text, mode, activeProfile.aiSettings);
            dispatch({ type: 'ADD_MESSAGE', payload: { id: Date.now() + 1, sender: 'carnix', text: response.text, urls: response.urls } });
            speak(response.text, activeProfile, isStealthMode);
            playSound('success');
        } catch (e) {
            playSound('error');
        } finally {
            setIsProcessing(false);
            setTimeout(() => setTranscript(''), 3000);
        }
    };

    if (!activeProfile) return null;

    return (
        <div 
            ref={assistantRef}
            className={`fixed z-[9999] font-[Rajdhani] transition-all duration-500 ${isStealthMode ? 'animate-flicker' : ''}`}
            style={{ 
                left: position.x, 
                top: position.y,
                opacity: expanded || isListening ? 1 : (isStealthMode ? 0.1 : opacity),
                cursor: isDragging ? 'grabbing' : 'grab'
            }}
            onMouseDown={startDrag}
            onMouseEnter={() => setOpacity(1)}
            onMouseLeave={() => !expanded && !isListening && !isDragging && setOpacity(isStealthMode ? 0.05 : 0.3)}
        >
            <div className={`
                flex flex-col items-end transition-all duration-300 ease-out bg-black/90 border border-[var(--color-primary)] rounded-xl shadow-[0_0_20px_rgba(255,0,60,0.3)] backdrop-blur-md overflow-hidden
                ${expanded ? 'w-64 p-3' : 'w-12 h-12 p-0 rounded-full border-2'}
                ${isStealthMode ? 'border-gray-800' : ''}
            `}>
                {!expanded && (
                    <div className="w-full h-full flex items-center justify-center" onClick={() => { setExpanded(true); playSound('click'); }}>
                        <div className={`absolute inset-0 rounded-full border border-dashed border-[var(--color-primary)]/50 ${isListening || isProcessing ? 'animate-spin' : ''}`}></div>
                        {isStealthMode ? <Ghost size={20} className="text-gray-700" /> : <BrainCircuit size={20} className="text-[var(--color-primary)]" />}
                    </div>
                )}

                {expanded && (
                    <div className="w-full flex flex-col gap-2">
                        <div className="flex justify-between items-center border-b border-white/10 pb-2 mb-1 cursor-grab active:cursor-grabbing">
                            <div className="flex items-center gap-2">
                                <GripHorizontal size={14} className="text-gray-500" />
                                <span className={`text-[10px] font-black uppercase tracking-widest ${isStealthMode ? 'text-gray-600' : 'text-white'}`}>
                                    {isStealthMode ? 'GHOST_NODE' : 'AI_NODE'}
                                </span>
                            </div>
                            <button onClick={(e) => { e.stopPropagation(); setExpanded(false); setOpacity(isStealthMode ? 0.05 : 0.3); }} className="text-gray-500 hover:text-white p-1">
                                <X size={14}/>
                            </button>
                        </div>
                        <div className="min-h-[40px] text-xs font-mono text-gray-300 p-2 bg-white/5 rounded border border-white/5">
                            {isListening ? (
                                <span className="text-[var(--color-primary)] animate-pulse font-bold">LISTENING...</span>
                            ) : isProcessing ? (
                                <span className="text-blue-400 animate-pulse font-bold">PROCESSING...</span>
                            ) : transcript ? (
                                `"${transcript}"`
                            ) : (
                                isStealthMode ? "Stealth Active." : "System Ready."
                            )}
                        </div>
                        <div className="flex justify-between items-center pt-2">
                            <button 
                                onClick={toggleListen}
                                className={`w-10 h-10 rounded-full flex items-center justify-center border transition-all ${isListening ? 'bg-red-600 border-red-500 text-white animate-pulse' : 'bg-black border-gray-600 text-[var(--color-primary)] hover:border-[var(--color-primary)]'}`}
                            >
                                <Mic size={18} />
                            </button>
                            <span className="text-[8px] text-gray-500 font-black uppercase tracking-[0.2em]">{isListening ? 'VOX_ACTIVE' : 'VOX_IDLE'}</span>
                        </div>
                    </div>
                )}
            </div>
            <style>{`
                @keyframes assistant-flicker {
                    0%, 100% { opacity: 0.1; }
                    50% { opacity: 0.05; }
                    55% { opacity: 0.2; }
                    60% { opacity: 0.1; }
                }
                .animate-flicker { animation: assistant-flicker 5s infinite; }
            `}</style>
        </div>
    );
};

export default FloatingAssistant;
