
import React, { useState } from 'react';
import { Music, Radio, Disc, Play } from 'lucide-react';
import MediaPanel from './MediaPanel';
import RadioPanel from './RadioPanel';

const MediaCenterPanel: React.FC = () => {
    const [tab, setTab] = useState<'LOCAL' | 'STREAM'>('LOCAL');

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/60 border border-white/10 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Disc size={20} className="text-pink-500 animate-spin-slow" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic tracking-tighter">Signal Relay Center</h2>
                    </div>
                </div>
                <div className="flex bg-black rounded border border-gray-800 p-0.5">
                    <button onClick={() => setTab('LOCAL')} className={`px-4 py-1.5 text-[10px] font-black rounded flex items-center gap-2 ${tab === 'LOCAL' ? 'bg-pink-600 text-black' : 'text-gray-500 hover:text-white'}`}><Music size={12}/> DATABANK</button>
                    <button onClick={() => setTab('STREAM')} className={`px-4 py-1.5 text-[10px] font-black rounded flex items-center gap-2 ${tab === 'STREAM' ? 'bg-pink-600 text-black' : 'text-gray-500 hover:text-white'}`}><Radio size={12}/> LIVE FEED</button>
                </div>
            </div>
            
            <div className="flex-1 bg-black/20 border border-white/5 rounded-lg overflow-hidden relative">
                {tab === 'LOCAL' ? <MediaPanel /> : <RadioPanel />}
            </div>
        </div>
    );
};

export default MediaCenterPanel;
