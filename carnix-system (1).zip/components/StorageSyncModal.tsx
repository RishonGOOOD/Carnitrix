import React, { useState, useEffect } from 'react';
import { 
    Cloud, HardDrive, RefreshCw, Download, Upload, CheckCircle2, 
    AlertCircle, Wifi, WifiOff, Database, ShieldCheck, X
} from 'lucide-react';
import { useAppContext } from '../context';
import { storageSync } from '../services/storageSyncService';
import { playSound } from '../utils/soundEffects';

interface StorageSyncModalProps {
    isOpen: boolean;
    onClose: () => void;
}

export const StorageSyncModal: React.FC<StorageSyncModalProps> = ({ isOpen, onClose }) => {
    const { state, dispatch } = useAppContext();
    const { isOnline, activeProfile } = state;
    const [isSyncing, setIsSyncing] = useState(false);
    const [syncMessage, setSyncMessage] = useState<string | null>(null);
    const [pendingCount, setPendingCount] = useState(0);
    const [lastSyncTime, setLastSyncTime] = useState<string>('Never');

    useEffect(() => {
        if (isOpen) {
            const queue = storageSync.getPendingQueue();
            setPendingCount(queue.length);
            const time = storageSync.getLastSyncTime();
            setLastSyncTime(time ? new Date(time).toLocaleTimeString() : 'Never');
        }
    }, [isOpen]);

    if (!isOpen) return null;

    const handleManualSync = async () => {
        if (!isOnline) {
            setSyncMessage('OFFLINE: Cannot establish cloud uplink. Local mode maintained.');
            playSound('error');
            return;
        }

        setIsSyncing(true);
        setSyncMessage('Synchronizing with Cloud Databanks...');
        playSound('process');

        try {
            await storageSync.syncPendingQueue();
            if (activeProfile) {
                await storageSync.syncProfileToCloud(activeProfile);
            }
            setPendingCount(0);
            const time = storageSync.getLastSyncTime();
            setLastSyncTime(time ? new Date(time).toLocaleTimeString() : 'Just now');
            setSyncMessage('Quantum Cloud Databanks fully synchronized.');
            playSound('success');
            dispatch({
                type: 'ADD_LOG',
                payload: {
                    id: `log-${Date.now()}`,
                    timestamp: Date.now(),
                    level: 'INFO',
                    message: 'Manual Cloud Databank synchronization succeeded.',
                    source: 'STORAGE_SYNC'
                }
            });
        } catch {
            setSyncMessage('Sync timeout. Buffered to local pending queue.');
            playSound('error');
        } finally {
            setIsSyncing(false);
            setTimeout(() => setSyncMessage(null), 4000);
        }
    };

    const handleExportBackup = () => {
        if (!activeProfile) return;
        playSound('click');
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(activeProfile, null, 2));
        const downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute("href", dataStr);
        downloadAnchor.setAttribute("download", `carnix_databank_backup_${Date.now()}.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
        setSyncMessage('Encrypted JSON Databank backup downloaded.');
        setTimeout(() => setSyncMessage(null), 3000);
    };

    const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const parsed = JSON.parse(event.target?.result as string);
                if (parsed && typeof parsed === 'object') {
                    dispatch({ type: 'SET_PROFILE', payload: parsed });
                    storageSync.saveLocalProfile(parsed);
                    playSound('success');
                    setSyncMessage('Databank restored from backup successfully.');
                    setTimeout(() => setSyncMessage(null), 3000);
                }
            } catch {
                setSyncMessage('Failed to parse backup file: Invalid format.');
                playSound('error');
            }
        };
        reader.readAsText(file);
    };

    const chatsCount = activeProfile?.chats?.length || 0;
    const notesCount = activeProfile?.notes?.length || 0;
    const tasksCount = activeProfile?.tasks?.length || 0;
    const eventsCount = activeProfile?.events?.length || 0;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <div className="w-full max-w-lg bg-black border-2 border-red-600/40 rounded-3xl p-6 shadow-[0_0_50px_rgba(255,0,0,0.2)] font-[Rajdhani] relative overflow-hidden">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-red-900/30 pb-4 mb-5">
                    <div className="flex items-center gap-3">
                        <div className={`p-2.5 rounded-xl ${isOnline ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'}`}>
                            <Database size={22} />
                        </div>
                        <div>
                            <h2 className="text-lg font-black text-white tracking-widest uppercase italic">
                                HYBRID STORAGE & CLOUD SYNC
                            </h2>
                            <p className="text-[11px] font-mono text-gray-400 tracking-wider">
                                ADAPTIVE CLOUD + LOCAL AUTONOMOUS VAULT
                            </p>
                        </div>
                    </div>
                    <button 
                        onClick={onClose}
                        className="p-2 text-gray-400 hover:text-white rounded-xl hover:bg-white/10 transition-all active:scale-95"
                    >
                        <X size={20} />
                    </button>
                </div>

                {/* Uplink status banner */}
                <div className={`p-4 rounded-2xl border mb-5 flex items-center justify-between ${
                    isOnline 
                        ? 'bg-cyan-950/30 border-cyan-500/40 text-cyan-300' 
                        : 'bg-amber-950/30 border-amber-500/40 text-amber-300'
                }`}>
                    <div className="flex items-center gap-3">
                        {isOnline ? <Wifi size={20} className="text-cyan-400 animate-pulse" /> : <WifiOff size={20} className="text-amber-400" />}
                        <div>
                            <div className="text-xs font-bold uppercase tracking-wider font-mono">
                                {isOnline ? 'QUANTUM CLOUD UPLINK ACTIVE' : 'NETWORK SEVERED — LOCAL STORAGE ACTIVE'}
                            </div>
                            <div className="text-[10px] text-gray-400 font-mono">
                                {isOnline 
                                    ? 'Data synchronizes to Cloud Vault in real-time.' 
                                    : 'All modifications preserved in local encrypted device vault.'}
                            </div>
                        </div>
                    </div>
                    <div className="text-right font-mono text-[10px]">
                        <div className="text-gray-400">QUEUED</div>
                        <div className="text-sm font-bold text-white">{pendingCount} ITEMS</div>
                    </div>
                </div>

                {/* Storage Telemetry Stats */}
                <div className="grid grid-cols-2 gap-3 mb-5">
                    <div className="p-3 bg-white/5 border border-white/10 rounded-2xl">
                        <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                            <Cloud size={14} className="text-cyan-400" />
                            <span>CLOUD STATUS</span>
                        </div>
                        <div className="text-sm font-black text-white font-mono">
                            {isOnline ? 'SYNCED / SECURE' : 'OFFLINE BUFFER'}
                        </div>
                        <div className="text-[10px] text-gray-500 font-mono mt-0.5">
                            Last Sync: {lastSyncTime}
                        </div>
                    </div>

                    <div className="p-3 bg-white/5 border border-white/10 rounded-2xl">
                        <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
                            <HardDrive size={14} className="text-red-400" />
                            <span>LOCAL VAULT</span>
                        </div>
                        <div className="text-sm font-black text-white font-mono">
                            {chatsCount + notesCount + tasksCount + eventsCount} TOTAL RECORDS
                        </div>
                        <div className="text-[10px] text-gray-500 font-mono mt-0.5">
                            {chatsCount} Chats · {notesCount} Notes · {tasksCount} Tasks
                        </div>
                    </div>
                </div>

                {/* Status message */}
                {syncMessage && (
                    <div className="mb-4 p-3 bg-red-950/40 border border-red-500/40 rounded-xl text-xs font-mono text-red-300 flex items-center gap-2">
                        <CheckCircle2 size={16} className="text-red-400 shrink-0" />
                        <span>{syncMessage}</span>
                    </div>
                )}

                {/* Actions */}
                <div className="space-y-2">
                    <button
                        onClick={handleManualSync}
                        disabled={isSyncing || !isOnline}
                        className="w-full py-3 px-4 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-black font-black uppercase text-xs tracking-widest rounded-2xl flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(255,0,0,0.3)] transition-all disabled:opacity-40 active:scale-98"
                    >
                        <RefreshCw size={16} className={isSyncing ? "animate-spin" : ""} />
                        <span>{isSyncing ? 'SYNCHRONIZING...' : 'FORCE CLOUD SYNC NOW'}</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                        <button
                            onClick={handleExportBackup}
                            className="py-2.5 px-3 bg-white/5 hover:bg-white/10 border border-white/15 text-gray-300 hover:text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95"
                        >
                            <Download size={14} />
                            <span>EXPORT BACKUP</span>
                        </button>

                        <label className="py-2.5 px-3 bg-white/5 hover:bg-white/10 border border-white/15 text-gray-300 hover:text-white rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer">
                            <Upload size={14} />
                            <span>IMPORT BACKUP</span>
                            <input 
                                type="file" 
                                accept=".json" 
                                onChange={handleImportBackup} 
                                className="hidden" 
                            />
                        </label>
                    </div>
                </div>

                {/* Security seal */}
                <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-gray-500">
                    <span className="flex items-center gap-1">
                        <ShieldCheck size={12} className="text-emerald-400" />
                        AES-256 VAULT ENCRYPTION
                    </span>
                    <span>CARNIX STORAGE v7.4</span>
                </div>
            </div>
        </div>
    );
};
