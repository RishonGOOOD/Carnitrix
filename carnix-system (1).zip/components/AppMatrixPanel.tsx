
import React, { useState } from 'react';
import { 
    LayoutDashboard, MessageSquare, Settings, User, 
    HardDrive, FileText, Globe, Bitcoin, 
    Eye, Camera, Satellite, Map, CloudRain, 
    Activity, Terminal,
    Lock, Radio, Smartphone, 
    ShieldAlert, Shield,
    Code, Music, Grid,
    Brain, Layers
} from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { useAppContext } from '../context';
import { Mode } from '../types';

const UNIQUE_APPS = [
    // --- CORE ---
    { mode: Mode.Home, label: 'DASHBOARD', cat: 'CORE', icon: LayoutDashboard },
    { mode: Mode.Chat, label: 'NEURAL LINK', cat: 'CORE', icon: MessageSquare },
    { mode: Mode.Settings, label: 'SYSTEM CONFIG', cat: 'CORE', icon: Settings },
    { mode: Mode.ProfileManager, label: 'IDENTITY NODE', cat: 'CORE', icon: User },
    { mode: Mode.Journal, label: 'CAPTAIN LOG', cat: 'CORE', icon: FileText },
    { mode: Mode.Tasks, label: 'DIRECTIVES', cat: 'CORE', icon: Activity },

    // --- DATA ---
    { mode: Mode.Files, label: 'DATA BANKS', cat: 'DATA', icon: HardDrive },
    { mode: Mode.Notes, label: 'INTEL DB', cat: 'DATA', icon: HardDrive }, // Using HardDrive as Database fallback
    { mode: Mode.Browser, label: 'WEB UPLINK', cat: 'DATA', icon: Globe },
    { mode: Mode.Crypto, label: 'MARKET', cat: 'DATA', icon: Bitcoin },
    { mode: Mode.MemoryVault, label: 'MEMORY VAULT', cat: 'DATA', icon: Brain },

    // --- VISION ---
    { mode: Mode.Vision, label: 'VISION HUB', cat: 'VISION', icon: Eye },
    { mode: Mode.Camera, label: 'OPTICAL FEED', cat: 'VISION', icon: Camera },
    { mode: Mode.Satellite, label: 'ORBITAL VIEW', cat: 'VISION', icon: Satellite },
    { mode: Mode.Location, label: 'GEO SPATIAL', cat: 'VISION', icon: Map },
    { mode: Mode.WeatherRadar, label: 'ATMOSPHERICS', cat: 'VISION', icon: CloudRain },

    // --- SYS ---
    { mode: Mode.Hardware, label: 'HARDWARE', cat: 'SYS', icon: Grid },
    { mode: Mode.Diagnostics, label: 'DIAGNOSTICS', cat: 'SYS', icon: Activity },
    { mode: Mode.Terminal, label: 'CONSOLE', cat: 'SYS', icon: Terminal },

    // --- COMM ---
    { mode: Mode.SecureComms, label: 'SECURE COMMS', cat: 'COMM', icon: Lock },
    { mode: Mode.Radio, label: 'FREQ TUNER', cat: 'COMM', icon: Radio },
    { mode: Mode.AudioVoice, label: 'VOICE LINK', cat: 'COMM', icon: Smartphone },

    // --- TOOLS ---
    { mode: Mode.CodeAssistant, label: 'CODE GEN', cat: 'TOOLS', icon: Code },
    { mode: Mode.AudioLab, label: 'AUDIO LAB', cat: 'TOOLS', icon: Music },
    { mode: Mode.ThreatIntel, label: 'THREAT INTEL', cat: 'TOOLS', icon: ShieldAlert },
    { mode: Mode.EthicalHacking, label: 'HACKING LAB', cat: 'TOOLS', icon: Shield },
];

const AppMatrixPanel: React.FC = () => {
    const { dispatch } = useAppContext();
    const [activeCategory, setActiveCategory] = useState('ALL');

    const handleAppClick = (mode: Mode) => {
        playSound('click');
        dispatch({ type: 'SET_MODE', payload: mode });
    };

    const displayedApps = activeCategory === 'ALL' 
        ? UNIQUE_APPS 
        : UNIQUE_APPS.filter(app => app.cat === activeCategory);

    const BottomNavButton = ({ cat, icon: Icon }: { cat: string, icon: any }) => (
        <button 
            onClick={() => setActiveCategory(cat)}
            className={`flex flex-col items-center justify-center p-2 rounded transition-all ${activeCategory === cat ? 'text-[var(--color-primary)]' : 'text-gray-600 hover:text-white'}`}
        >
            <Icon size={18} />
            <span className="text-[8px] font-black mt-1">{cat}</span>
        </button>
    );

    return (
        <div className="w-full h-full flex flex-col bg-black font-[Rajdhani] relative overflow-hidden">
            <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(0,255,0,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,0,0.05)_1px,transparent_1px)]" style={{backgroundSize: '20px 20px'}}></div>

            <div className="flex-shrink-0 p-4 border-b border-white/10 flex justify-between items-center bg-black/80 backdrop-blur z-10">
                <div className="flex items-center gap-3">
                    <Layers size={24} className="text-[var(--color-primary)]" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase tracking-widest leading-none">APP MATRIX</h2>
                        <div className="text-[9px] font-mono text-gray-500 uppercase tracking-[0.2em] mt-1">
                            ACTIVE NODES: {UNIQUE_APPS.length}
                        </div>
                    </div>
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 relative z-0 scrollbar-hide">
                <div className="border border-red-500/30 rounded-xl p-1 min-h-full relative bg-red-900/5">
                    <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 pb-20">
                        {displayedApps.map((app) => (
                            <button
                                key={app.mode}
                                onClick={() => handleAppClick(app.mode)}
                                className="aspect-square bg-black/60 border border-white/5 hover:border-[var(--color-primary)] hover:bg-[var(--color-primary)]/10 rounded-lg flex flex-col items-center justify-center gap-2 transition-all group relative overflow-hidden"
                            >
                                <div className="text-gray-400 group-hover:text-white transition-colors">
                                    <app.icon size={24} />
                                </div>
                                <span className="text-[9px] font-bold text-gray-500 group-hover:text-[var(--color-primary)] text-center px-1 leading-tight uppercase">
                                    {app.label}
                                </span>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            <div className="flex-shrink-0 bg-black/90 border-t border-white/10 p-2 flex justify-around items-center z-20 backdrop-blur-md">
                <BottomNavButton cat="ALL" icon={Grid} />
                <BottomNavButton cat="CORE" icon={Activity} />
                <BottomNavButton cat="DATA" icon={HardDrive} />
                <BottomNavButton cat="COMM" icon={MessageSquare} />
                <BottomNavButton cat="VISION" icon={Eye} />
                <BottomNavButton cat="SYS" icon={Activity} />
            </div>
        </div>
    );
};

export default AppMatrixPanel;
