
import React from 'react';
import { Activity, ShieldCheck, Database, Wrench, HardDrive, Cpu } from 'lucide-react';

const SystemPanel: React.FC = () => (
    <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
        <div className="bg-black/40 border border-white/10 p-3 rounded-lg flex justify-between items-center">
            <div className="flex items-center gap-3">
                <Activity size={20} className="text-red-600" />
                <h2 className="text-sm font-black text-white uppercase italic">Core Vitals</h2>
            </div>
        </div>
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
                { l: 'Encryption', i: ShieldCheck, v: 'AES-256-QM', s: 'OPTIMAL', c: 'text-green-500' },
                { l: 'Neural Sync', i: Activity, v: '98.4%', s: 'LOCKED', c: 'text-cyan-500' },
                { l: 'Storage', i: HardDrive, v: '12.8 / 40 TB', s: 'MOUNTED', c: 'text-white' },
                { l: 'Data Mesh', i: Database, v: '1,402 Nodes', s: 'ACTIVE', c: 'text-green-500' },
                { l: 'Processor', i: Cpu, v: 'Quantum-X7', s: 'COLD', c: 'text-blue-400' },
                { l: 'Maintenance', i: Wrench, v: 'T-Minus 4h', s: 'IDLE', c: 'text-yellow-500' }
            ].map((stat, i) => (
                <div key={i} className="jarvis-panel p-4 bg-black/60 border-l-2 border-red-600 space-y-3">
                    <div className="flex items-center gap-2">
                        <stat.i size={16} className="text-red-600" />
                        <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">{stat.l}</span>
                    </div>
                    <div className="text-xl font-black text-white font-mono">{stat.v}</div>
                    <div className={`text-[8px] font-bold uppercase tracking-widest ${stat.c}`}>{stat.s}</div>
                </div>
            ))}
        </div>
    </div>
);

export default SystemPanel;
