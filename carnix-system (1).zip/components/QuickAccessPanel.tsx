
import React, { useState } from 'react';
import { 
    LayoutDashboard, MessageSquare, Eye, Cpu, Newspaper, 
    Map, Bitcoin, Lock, Zap, LogOut, ArrowLeft, ArrowRight 
} from 'lucide-react';
import { Mode } from '../types';
import { useAppContext } from '../context';
import { playSound, triggerHaptic } from '../utils/soundEffects';

const QuickAccessPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const [rotation, setRotation] = useState(0);
    const [selectedIndex, setSelectedIndex] = useState(0);
    
    const dialItems = [
        { id: Mode.Home, icon: <LayoutDashboard />, label: 'HUD CORE', color: '#ff003c' },
        { id: Mode.Chat, icon: <MessageSquare />, label: 'NEURAL LINK', color: '#00ccff' },
        { id: Mode.Camera, icon: <Eye />, label: 'OPTIC FEED', color: '#00ffaa' },
        { id: Mode.Microcontroller, icon: <Cpu />, label: 'MCU BRIDGE', color: '#ffaa00' },
        { id: Mode.News, icon: <Newspaper />, label: 'WORLD FEED', color: '#ffffff' },
        { id: Mode.Location, icon: <Map />, label: 'GEO LOCK', color: '#55ff00' },
        { id: Mode.Crypto, icon: <Bitcoin />, label: 'MARKET', color: '#facc15' },
        { id: Mode.SecureComms, icon: <Lock />, label: 'ENCRYPTION', color: '#8b5cf6' },
    ];

    const angleStep = 360 / dialItems.length;

    const rotate = (dir: number) => {
        const nextRot = rotation + (dir * angleStep);
        setRotation(nextRot);
        
        let nextIdx = selectedIndex - dir;
        if (nextIdx < 0) nextIdx = dialItems.length - 1;
        if (nextIdx >= dialItems.length) nextIdx = 0;
        setSelectedIndex(nextIdx);
        
        playSound('click');
        triggerHaptic('light');
    };

    const activate = () => {
        playSound('access');
        triggerHaptic('heavy');
        dispatch({ type: 'SET_MODE', payload: dialItems[selectedIndex].id });
    };

    return (
        <div className="fixed inset-0 bg-black flex flex-col items-center justify-center overflow-hidden font-[Rajdhani] select-none touch-none">
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,var(--color-primary)_0%,transparent_70%)] animate-pulse"></div>
            
            <div className="absolute top-10 flex flex-col items-center gap-2 animate-enter z-20">
                <div className="text-[10px] font-black tracking-[0.5em] text-gray-500 uppercase">OMNITRIX_ACTIVE // PROTOCOL_V5</div>
                <h1 className="text-4xl font-black text-white italic tracking-tighter shadow-red-500 text-center">
                    {dialItems[selectedIndex].label}
                </h1>
            </div>

            <div className="relative w-full h-full flex items-center justify-center">
                <div style={{ perspective: '1200px', width: '100%', height: '100%', position: 'absolute', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <div 
                        className="relative transition-transform duration-500 cubic-bezier(0.23, 1, 0.32, 1)"
                        style={{ transform: `rotateY(${rotation}deg)`, transformStyle: 'preserve-3d', width: '0px', height: '0px' }}
                    >
                        {dialItems.map((item, i) => (
                            <div
                                key={i}
                                className="absolute left-0 top-0 flex items-center justify-center"
                                style={{
                                    transform: `rotateY(${i * angleStep}deg) translateZ(280px)`,
                                    backfaceVisibility: 'hidden'
                                }}
                            >
                                <div 
                                    className={`w-20 h-20 -ml-10 -mt-10 rounded-2xl flex items-center justify-center border-2 transition-all duration-300 ${selectedIndex === i ? 'bg-white text-black scale-125 shadow-[0_0_30px_white]' : 'bg-black/80 text-gray-500 border-white/10 opacity-30'}`}
                                    style={{ borderColor: selectedIndex === i ? item.color : '' }}
                                >
                                    {React.cloneElement(item.icon as React.ReactElement, { size: 40 })}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <button 
                    onClick={activate}
                    className="relative z-50 w-32 h-32 rounded-full border-4 border-white bg-black flex flex-col items-center justify-center group active:scale-95 transition-transform shadow-[0_0_50px_rgba(255,255,255,0.2)] hover:border-[var(--color-primary)]"
                >
                    <Zap size={48} className="text-white group-hover:text-[var(--color-primary)] group-hover:animate-pulse" />
                    <span className="text-[10px] font-black mt-2 tracking-widest text-white group-hover:text-[var(--color-primary)]">ENGAGE</span>
                </button>
            </div>

            <div className="absolute bottom-16 flex items-center gap-8 z-20">
                <button onClick={() => rotate(1)} className="p-4 bg-white/5 border border-white/10 rounded-full hover:bg-white/10 text-white transition-all active:scale-90">
                    <ArrowLeft size={24} />
                </button>
                <button onClick={() => dispatch({ type: 'LOGOUT' })} className="px-8 py-3 bg-red-900/20 border border-red-500 text-red-500 rounded-full text-xs font-black tracking-widest hover:bg-red-600 hover:text-white transition-all flex items-center gap-2">
                    <LogOut size={16} /> TERMINATE
                </button>
                <button onClick={() => rotate(-1)} className="p-4 bg-white/5 border border-white/10 rounded-full hover:bg-white/10 text-white transition-all active:scale-90">
                    <ArrowRight size={24} />
                </button>
            </div>
        </div>
    );
};

export default QuickAccessPanel;
