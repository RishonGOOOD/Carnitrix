import React, { useState, useEffect, useRef } from 'react';
import { Message, Mode } from '../types';
import { Send, Users, Shield, Bot, User, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { playSound } from '../utils/soundEffects';

const GroupChatPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const [input, setInput] = useState('');
    const [isThinking, setIsThinking] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const history = activeProfile?.groupChatHistory || [];

    const onUpdateHistory = (newHistory: Message[]) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { groupChatHistory: newHistory } });
    };

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [history, isThinking]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || !activeProfile) return;

        const userMsg: Message = { id: Date.now(), sender: activeProfile.name, text: input };
        const newHistory = [...history, userMsg];
        onUpdateHistory(newHistory);
        setInput('');
        playSound('click');

        setIsThinking(true);
        
        try {
            // Simulate a group response from Carnix and maybe another "entity"
            const carnixResponse = await getAIResponse(
                `A group chat message was sent: "${input}". Respond as CARNIX.`,
                Mode.GroupChat,
                activeProfile.aiSettings,
                state.geolocation,
                newHistory
            );

            const carnixMsg: Message = { 
                id: Date.now() + 1, 
                sender: 'carnix', 
                text: carnixResponse.text 
            };

            // Occasionally add a second respondent
            if (Math.random() > 0.5) {
                setTimeout(async () => {
                    const shadowResponse = await getAIResponse(
                        `You are 'SHADOW-OPS', a silent observer in this tactical chat. Briefly comment on the user's message: "${input}"`,
                        Mode.GroupChat,
                        { ...activeProfile.aiSettings, personality: 'Dark Sci-Fi' },
                        state.geolocation,
                        [...newHistory, carnixMsg]
                    );
                    onUpdateHistory([...newHistory, carnixMsg, { 
                        id: Date.now() + 2, 
                        sender: 'system', 
                        text: shadowResponse.text 
                    }]);
                    playSound('alert');
                }, 1000);
                onUpdateHistory([...newHistory, carnixMsg]);
            } else {
                onUpdateHistory([...newHistory, carnixMsg]);
            }
            playSound('success');
        } catch (e) {
            onUpdateHistory([...newHistory, { id: Date.now() + 1, sender: 'system', text: 'Uplink synchronization failure.' }]);
        } finally {
            setIsThinking(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col bg-black/20 p-2">
            <div className="flex-shrink-0 bg-black/40 border border-[var(--color-panel-border)] rounded-t-lg p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <Users size={20} className="text-[var(--color-primary)]" />
                    <div>
                        <h2 className="text-sm font-black tracking-widest text-white">TACTICAL GROUP UPLINK</h2>
                        <div className="text-[9px] font-mono text-gray-500">ENCRYPTED // MULTI-USER NODE</div>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                    <span className="text-[10px] font-mono text-green-500">SECURE</span>
                </div>
            </div>

            <div className="flex-1 bg-black/30 border-x border-[var(--color-panel-border)] overflow-y-auto p-4 space-y-4 scrollbar-thin">
                {history.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full opacity-30">
                        <Shield size={48} className="mb-2"/>
                        <p className="text-xs font-mono">CHANNEL INITIALIZED. AWAITING DATA.</p>
                    </div>
                )}
                {history.map((msg) => (
                    <div key={msg.id} className={`flex flex-col ${msg.sender === activeProfile?.name ? 'items-end' : 'items-start'} animate-enter`}>
                        <span className="text-[9px] font-bold text-gray-500 mb-1 uppercase tracking-tighter">{msg.sender}</span>
                        <div className={`max-w-[85%] p-3 rounded-md text-xs border ${
                            msg.sender === activeProfile?.name ? 'bg-[var(--color-primary)]/10 border-[var(--color-primary)]/30 text-white' : 
                            msg.sender === 'carnix' ? 'bg-blue-900/20 border-blue-500/30 text-blue-100' :
                            'bg-gray-800/40 border-gray-700 text-gray-300'
                        }`}>
                            <p className="whitespace-pre-wrap">{msg.text}</p>
                        </div>
                    </div>
                ))}
                {isThinking && (
                    <div className="flex gap-2 items-center text-gray-500 animate-pulse">
                        <Loader2 size={12} className="animate-spin" />
                        <span className="text-[10px] font-mono">SYNCING...</span>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            <div className="p-3 bg-black/40 border border-[var(--color-panel-border)] rounded-b-lg">
                <form onSubmit={handleSend} className="flex gap-2">
                    <input 
                        type="text" 
                        value={input} 
                        onChange={e => setInput(e.target.value)} 
                        placeholder="Broadcast to group..."
                        className="flex-1 bg-black/60 border border-gray-700 rounded-md px-4 py-2 text-xs focus:border-[var(--color-primary)] outline-none text-white font-mono"
                    />
                    <button type="submit" disabled={!input.trim() || isThinking} className="p-2 bg-[var(--color-primary)] text-black rounded-md hover:bg-white transition-all disabled:opacity-50">
                        <Send size={18} />
                    </button>
                </form>
            </div>
        </div>
    );
};

export default GroupChatPanel;