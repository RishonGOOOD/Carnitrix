import React, { useState } from 'react';
import { FlaskConical, Send, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

const ChemicalAnalysisPanel: React.FC = () => {
    const { state } = useAppContext();
    const [query, setQuery] = useState('H2O');
    const [analysis, setAnalysis] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleAnalyze = async () => {
        if (!query.trim() || !state.activeProfile) return;
        setIsLoading(true);
        setAnalysis(null);
        try {
            const prompt = `Provide a detailed chemical analysis of "${query}". Include its formula, molar mass, properties, and common uses.`;
            const res = await getAIResponse(prompt, Mode.ChemicalAnalysis, state.activeProfile.aiSettings);
            setAnalysis(res.text);
        } catch (e) {
            setAnalysis('Failed to analyze compound.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <FlaskConical size={14}/> CHEMICAL ANALYSIS
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="w-full lg:w-1/3 border-b lg:border-b-0 lg:border-r border-[var(--color-panel-header-border)] flex flex-col p-4 gap-4">
                    <p className="text-xs text-gray-400">Enter a chemical formula, common name, or IUPAC name to analyze.</p>
                    <input
                        type="text"
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        placeholder="e.g., C6H12O6 or Glucose"
                        className="w-full hud-input text-sm"
                    />
                    <button onClick={handleAnalyze} disabled={isLoading || !query.trim()} className="w-full hud-button flex items-center justify-center gap-2">
                        {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                        ANALYZE
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 bg-black/20">
                    <h3 className="text-sm font-bold text-[var(--color-primary)] mb-2">ANALYSIS REPORT</h3>
                     {isLoading && <Loader2 className="animate-spin"/>}
                    {analysis ? (
                        <pre className="whitespace-pre-wrap font-mono text-sm text-gray-300">{analysis}</pre>
                    ) : (
                        <p className="text-sm text-gray-500">Awaiting query...</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChemicalAnalysisPanel;
