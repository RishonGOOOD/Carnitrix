import React from 'react';
import { Accessibility, Activity } from 'lucide-react';

const CyberneticsPanel: React.FC = () => {
    const implants = [
        { name: 'Kiroshi Optics Mk.III', type: 'Optical', status: 'Optimal' },
        { name: 'Gorilla Arms', type: 'Limbic', status: 'Optimal' },
        { name: 'Subdermal Weave', type: 'Integumentary', status: 'Optimal' },
        { name: 'Neural Link Co-processor', type: 'Cognitive', status: 'Optimal' },
    ];

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Accessibility size={14}/> CYBERWARE MANIFEST
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col overflow-hidden">
                <div className="hud-panel-header grid grid-cols-3 text-xs">
                    <span>SYSTEM</span>
                    <span>TYPE</span>
                    <span className="text-center">STATUS</span>
                </div>
                <div className="flex-1 overflow-y-auto p-2 space-y-2 bg-black/20">
                    {implants.map((implant, i) => (
                        <div key={i} className="grid grid-cols-3 gap-4 p-3 border border-gray-800 rounded items-center font-mono text-sm animate-enter">
                            <span className="text-white font-bold truncate">{implant.name}</span>
                            <span className="text-gray-400 truncate">{implant.type}</span>
                            <div className="flex items-center justify-center gap-2 font-bold text-green-400">
                                <Activity size={12} className="animate-pulse" />
                                {implant.status}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default CyberneticsPanel;
