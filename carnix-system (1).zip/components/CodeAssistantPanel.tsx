
import React, { useState } from 'react';
import { Message, Mode } from '../types';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Bot, Code, Send, Loader2, Copy, Check } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { copyToClipboard } from '../utils/nativeBridge';

interface CodeAssistantPanelProps {
    addMessage: (sender: 'user' | 'carnix' | 'system', text: string) => void;
}

const CodeAssistantPanel: React.FC<CodeAssistantPanelProps> = ({ addMessage }) => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const [prompt, setPrompt] = useState('');
    const [response, setResponse] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [hasCopied, setHasCopied] = useState(false);

    const handleGenerate = async () => {
        if (!prompt.trim() || !activeProfile) return;
        setIsLoading(true);
        dispatch({ type: 'SET_TASK_LOADING', payload: true });
        setResponse(null);
        playSound('process');
        try {
            const res = await getAIResponse(prompt, Mode.CodeAssistant, activeProfile.aiSettings);
            setResponse(res.text);
            playSound('success');
        } catch (e: any) {
            setResponse(`Error generating code: ${e.message}`);
            playSound('error');
        }
        setIsLoading(false);
        dispatch({ type: 'SET_TASK_LOADING', payload: false });
    };

    const handleCopy = async () => {
        if (!response) return;
        const codeBlockMatch = response.match(/```(?:\w*\n)?([\s\S]*?)```/);
        const codeToCopy = codeBlockMatch ? codeBlockMatch[1].trim() : response;
        
        const success = await copyToClipboard(codeToCopy);
        if (success) {
            setHasCopied(true);
            playSound('click');
            setTimeout(() => setHasCopied(false), 2000);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 space-y-3">
                <h2 className="text-sm font-bold text-[var(--color-primary)] flex items-center gap-2">
                    <Code size={16} /> AI CODE GENERATOR
                </h2>
                <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="Enter a description of the code you want to generate..."
                    className="w-full h-24 bg-black/50 border border-gray-700 rounded p-2 text-sm resize-y focus:outline-none focus:border-[var(--color-primary)]"
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !prompt.trim()}
                    className="w-full flex items-center justify-center gap-2 p-3 bg-[var(--color-button-background)] hover:bg-[var(--color-button-hover)] border border-[var(--color-button-border)] rounded-md transition-colors disabled:opacity-50"
                >
                    {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                    {isLoading ? 'GENERATING...' : 'GENERATE CODE'}
                </button>
            </div>
            <div className="flex-1 bg-black border border-[var(--color-terminal-border)] rounded-md p-2 font-mono text-sm flex flex-col min-h-0 relative">
                <div className="absolute top-2 right-2 z-10">
                    <button onClick={handleCopy} className="p-2 bg-gray-800 rounded-md hover:bg-gray-700 disabled:opacity-50" disabled={!response}>
                        {hasCopied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                    </button>
                </div>
                <div className="flex-1 overflow-auto p-2">
                    {isLoading && (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            <Loader2 size={24} className="animate-spin mr-2" /> Processing...
                        </div>
                    )}
                    {response ? (
                        <pre><code className="whitespace-pre-wrap">{response}</code></pre>
                    ) : (
                        <div className="text-gray-600">Generated code will appear here.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CodeAssistantPanel;
