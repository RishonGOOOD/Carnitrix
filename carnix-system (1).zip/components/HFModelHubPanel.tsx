
import React, { useState } from 'react';
import { Search, Globe, Zap, Cpu, Star, ExternalLink, Loader2, CheckCircle, RefreshCw, Smartphone } from 'lucide-react';
import { useAppContext } from '../context';
import { Mode } from '../types';
import { playSound, triggerHaptic } from '../utils/soundEffects';

interface HFModel {
    id: string;
    author: string;
    likes: number;
    downloads: number;
    description: string;
    tags: string[];
}

const RECOMMENDED_MODELS: HFModel[] = [
    { id: 'meta-llama/Meta-Llama-3-8B-Instruct', author: 'Meta', likes: 12400, downloads: 450000, description: 'Cutting edge instruct model for fast, logical reasoning.', tags: ['Llama 3', 'Instruct', 'Fast'] },
    { id: 'mistralai/Mistral-7B-v0.3', author: 'Mistral AI', likes: 8900, downloads: 320000, description: 'Highly efficient dense model with broad knowledge base.', tags: ['Mistral', 'Dense', 'Stable'] },
    { id: 'Qwen/Qwen2.5-7B-Instruct', author: 'Alibaba', likes: 5600, downloads: 120000, description: 'Exceptional math and coding performance in a 7B package.', tags: ['Qwen', 'Coding', 'Logic'] },
    { id: 'microsoft/Phi-3.5-mini-instruct', author: 'Microsoft', likes: 4200, downloads: 85000, description: 'Tiny but mighty. Best for sub-second terminal replies.', tags: ['Phi', 'Tiny', 'Efficient'] },
    { id: 'google/gemma-2-9b-it', author: 'Google', likes: 7200, downloads: 210000, description: 'Next-gen open model from the Gemini research team.', tags: ['Gemma', 'Instruct', 'Deep'] },
];

const HFModelHubPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const [searchQuery, setSearchQuery] = useState('');
    const [isSearching, setIsSearching] = useState(false);
    const [hotSwappingId, setHotSwappingId] = useState<string | null>(null);

    const activeModel = activeProfile?.aiSettings.model;

    const handleHotSwap = (modelId: string) => {
        setHotSwappingId(modelId);
        playSound('process');
        triggerHaptic('medium');

        setTimeout(() => {
            dispatch({ 
                type: 'UPDATE_PROFILE', 
                payload: { 
                    aiSettings: { 
                        ...activeProfile!.aiSettings, 
                        engine: 'HUGGING_FACE',
                        model: modelId 
                    } 
                } 
            });
            dispatch({ type: 'ADD_LOG', payload: { source: 'NEURAL', message: `Engine hot-swapped to ${modelId}`, level: 'success' } });
            setHotSwappingId(null);
            playSound('success');
        }, 1200);
    };

    const filteredModels = RECOMMENDED_MODELS.filter(m => 
        m.id.toLowerCase().includes(searchQuery.toLowerCase()) || 
        m.description.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani] animate-in fade-in duration-500">
            {/* Header */}
            <div className="flex-shrink-0 bg-black/60 border border-yellow-500/30 p-5 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-yellow-500/10 rounded border border-yellow-500/50 shadow-lg">
                        <Smartphone size={28} className="text-yellow-500 animate-pulse" />
                    </div>
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic tracking-widest leading-none">Hugging Face Hub</h2>
                        <div className="text-[9px] font-mono text-yellow-600 uppercase tracking-widest mt-1">
                             Open-Source Substrate Explorer // Hot-Swap Protocol v1.0
                        </div>
                    </div>
                </div>
                <div className="relative w-full sm:w-80">
                    <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
                    <input 
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        placeholder="Search open-weights grid..."
                        className="w-full bg-black border border-gray-800 rounded-full pl-11 pr-4 py-3 text-xs text-white outline-none focus:border-yellow-600 font-mono transition-all"
                    />
                </div>
            </div>

            <div className="flex-1 bg-black/40 border border-white/5 rounded-3xl overflow-hidden flex flex-col shadow-inner">
                <div className="p-3 bg-white/5 border-b border-white/5 flex items-center justify-between">
                    <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Global Roster</span>
                    <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                        <span className="text-[9px] font-mono text-green-600 uppercase">Gateway_Stable</span>
                    </div>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-carnix">
                    {filteredModels.map(model => (
                        <div key={model.id} className={`group bg-black/80 border-2 rounded-2xl p-5 flex flex-col md:flex-row gap-6 transition-all relative overflow-hidden ${activeModel === model.id ? 'border-yellow-500 shadow-[0_0_20px_rgba(234,179,8,0.2)]' : 'border-white/5 hover:border-white/20'}`}>
                            <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-3 mb-2">
                                    <h3 className="text-lg font-black text-white uppercase tracking-tight truncate">{model.id}</h3>
                                    {activeModel === model.id && <CheckCircle size={16} className="text-green-500 shrink-0" />}
                                </div>
                                <p className="text-xs text-gray-400 leading-relaxed mb-4 italic">"{model.description}"</p>
                                <div className="flex flex-wrap gap-2">
                                    {model.tags.map(t => (
                                        <span key={t} className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-[8px] font-black text-gray-500 uppercase">{t}</span>
                                    ))}
                                </div>
                            </div>

                            <div className="flex flex-col justify-between items-end gap-4 shrink-0">
                                <div className="text-right space-y-1">
                                    <div className="flex items-center justify-end gap-2 text-yellow-500/60 font-black text-[9px]">
                                        <Star size={10} /> {model.likes.toLocaleString()} LIKES
                                    </div>
                                    <div className="text-[8px] font-mono text-gray-700 uppercase">{(model.downloads/1000).toFixed(0)}k DOWNLOADS/MO</div>
                                </div>

                                <button 
                                    onClick={() => handleHotSwap(model.id)}
                                    disabled={activeModel === model.id || hotSwappingId === model.id}
                                    className={`px-8 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 ${activeModel === model.id ? 'bg-green-600 text-black cursor-default' : 'bg-yellow-600 text-black hover:bg-white shadow-lg active:scale-95 disabled:opacity-50'}`}
                                >
                                    {hotSwappingId === model.id ? <Loader2 size={14} className="animate-spin"/> : activeModel === model.id ? 'ACTIVE_SUBSTRATE' : <><RefreshCw size={14}/> HOT_SWAP</>}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="p-4 bg-yellow-950/10 border border-yellow-900/30 rounded-2xl flex items-start gap-4">
                <Globe size={24} className="text-yellow-600 shrink-0 mt-0.5" />
                <div className="text-[10px] text-gray-500 font-mono leading-relaxed uppercase">
                    <span className="text-yellow-500 font-black">Architecture Note:</span> Hugging Face hot-swapping utilizes the Inference API substrate. Models are initialized on-demand and cached in the browser's persistent neural buffer for rapid subsequent calls.
                </div>
            </div>
        </div>
    );
};

export default HFModelHubPanel;
