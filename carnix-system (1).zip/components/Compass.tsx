


import React, { useState, useEffect } from 'react';
import { RotateCcw, Lock } from 'lucide-react';

interface CompassProps {
    fullSize?: boolean;
}

const Compass: React.FC<CompassProps> = ({ fullSize = false }) => {
  const [heading, setHeading] = useState(0);
  const [isSensorAvailable, setIsSensorAvailable] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState<boolean | null>(null);
  const [isCalibrating, setIsCalibrating] = useState(false);

  const handleOrientation = (event: DeviceOrientationEvent) => {
    if (event.alpha !== null) {
      let h = event.alpha;
      // webkitCompassHeading is for iOS compatibility (0 = North)
      if ((event as any).webkitCompassHeading) {
          h = (event as any).webkitCompassHeading;
      } else {
          // Standard Android: alpha is 0 at north? varies. 
          // Usually 0=North, increasing counter-clockwise.
          // To match standard compass (0=N, 90=E), we might need inversion depending on implementation.
          // For visual consistency with CSS rotation, we usually use 360 - alpha.
          h = 360 - h;
      }
      setHeading(h);
      setIsSensorAvailable(true);
    }
  };

  const requestPermission = async () => {
      if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
          try {
              const response = await (DeviceOrientationEvent as any).requestPermission();
              if (response === 'granted') {
                  setPermissionGranted(true);
                  window.addEventListener('deviceorientation', handleOrientation, true);
              } else {
                  setPermissionGranted(false);
              }
          } catch (e) {
              console.error(e);
              setPermissionGranted(false);
          }
      } else {
          // Non-iOS devices usually don't need permission request
          setPermissionGranted(true);
          window.addEventListener('deviceorientation', handleOrientation, true);
      }
  };

  const startCalibration = () => {
    setIsCalibrating(true);
    setTimeout(() => {
        setIsCalibrating(false);
    }, 8000); // 8-second calibration sequence
  };

  useEffect(() => {
    // Initial check - if we don't need explicit permission (Android/Desktop), start listening
    if (!window.DeviceOrientationEvent || typeof (DeviceOrientationEvent as any).requestPermission !== 'function') {
         window.addEventListener('deviceorientation', handleOrientation, true);
         setPermissionGranted(true);
    }

    // Fallback simulation for desktop
    const fallbackTimer = setTimeout(() => {
      if (!isSensorAvailable && permissionGranted !== false) {
        // Keep existing simulation logic
        const interval = setInterval(() => {
          if(!isSensorAvailable) setHeading(prev => (prev + 0.2) % 360);
        }, 20);
        return () => clearInterval(interval);
      }
    }, 2000);

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation);
      clearTimeout(fallbackTimer);
    };
  }, [isSensorAvailable, permissionGranted]);

  const getCardinalDirection = (angle: number) => {
    const normalized = (angle %= 360) < 0 ? angle + 360 : angle;
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(normalized / 45) % 8;
    return directions[index];
  };

  const cardinal = getCardinalDirection(heading);
  // If heading is 90, we rotate the dial -90 degrees.
  const rotation = -heading;

  if (permissionGranted === null && typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      return (
          <button onClick={requestPermission} className="flex flex-col items-center justify-center w-full h-full bg-black/40 border border-dashed border-[var(--color-primary)] rounded-full p-4 animate-pulse">
              <Lock size={24} className="mb-2 text-[var(--color-primary)]" />
              <span className="text-[10px] text-center">TAP TO ENABLE SENSORS</span>
          </button>
      )
  }

  if (isCalibrating) {
    return (
        <div className="flex flex-col items-center justify-center w-full h-full text-center p-4">
            <svg width="150" height="75" viewBox="0 0 150 75" className="mb-4">
                <path d="M 37.5 37.5 a 37.5 37.5 0 1 1 0 -0.01 M 112.5 37.5 a 37.5 37.5 0 1 1 0 -0.01" stroke="var(--color-text-muted)" strokeWidth="2" fill="none" />
                <circle cx="0" cy="0" r="6" fill="var(--color-primary)" filter="drop-shadow(0 0 4px var(--color-primary))">
                    <animateMotion dur="4s" repeatCount="indefinite" path="M 37.5 37.5 a 37.5 37.5 0 1 1 0 -0.01 M 112.5 37.5 a 37.5 37.5 0 1 0 0 -0.01" />
                </circle>
            </svg>
            <h3 className="text-lg font-bold text-[var(--color-primary)]">CALIBRATING SENSOR</h3>
            <p className="text-sm text-gray-400 max-w-xs mt-2">Move your device in a figure-eight pattern to improve compass accuracy.</p>
        </div>
    );
  }

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center select-none">
        <div className={`relative ${fullSize ? 'w-64 h-64 md:w-96 md:h-96' : 'w-24 h-24 sm:w-28 sm:h-28'} transition-all duration-500`}>
            {/* Sensor Status Indicator */}
            <div className={`absolute -top-1 -right-1 w-2 h-2 rounded-full ${isSensorAvailable ? 'bg-green-500 shadow-[0_0_5px_#22c55e]' : 'bg-yellow-500 animate-pulse'} transition-colors z-10`} title={isSensorAvailable ? "Sensor Online" : "Simulation Mode"}></div>

            {/* Full Size Specific Readout Next to Dial */}
            {fullSize && (
                <>
                    <div className="absolute top-1/2 -right-32 transform -translate-y-1/2 flex flex-col items-start">
                         <div className="text-6xl font-black text-[var(--color-primary)] tracking-tighter">{Math.round(heading)}°</div>
                         <div className="text-3xl font-bold text-[var(--color-text-muted)] pl-1">{cardinal}</div>
                    </div>
                    <div className="absolute top-1/2 -left-32 transform -translate-y-1/2 flex flex-col items-end text-right">
                         <div className="text-xs font-mono text-[var(--color-text-muted)] border-b border-[var(--color-border)] mb-1 pb-1">HEADING</div>
                         <div className="text-xs font-mono text-[var(--color-primary)]">MAGNETIC</div>
                    </div>
                </>
            )}


            <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_0_4px_rgba(0,0,0,0.8)] overflow-visible">
                {/* Static HUD Ring */}
                <circle cx="50" cy="50" r="46" fill="rgba(0,0,0,0.2)" stroke="var(--color-panel-border)" strokeWidth="0.5" />
                
                {/* Top Indicator Marker */}
                <path d="M 50 2 L 46 8 L 54 8 Z" fill="var(--color-primary)" />

                {/* Rotating Dial */}
                <g transform={`rotate(${rotation}, 50, 50)`} style={{ transition: 'transform 0.2s cubic-bezier(0.1, 0.5, 0.1, 1)' }}>
                    {/* Degree Ticks */}
                    {Array.from({ length: 72 }).map((_, i) => {
                        const angle = i * 5;
                        const isMajor = i % 18 === 0; // 0, 90, 180, 270
                        const isSemi = i % 9 === 0 && !isMajor; // 45, 135...
                        const length = isMajor ? 10 : (isSemi ? 7 : 4);
                        return (
                            <line
                                key={i}
                                x1="50" y1="6"
                                x2="50" y2={6 + length}
                                stroke={isMajor ? "var(--color-primary)" : "var(--color-text-muted)"}
                                strokeWidth={isMajor ? "1.5" : "0.5"}
                                transform={`rotate(${angle}, 50, 50)`}
                                opacity={isMajor ? 1 : 0.6}
                            />
                        );
                    })}
                    
                    {/* Cardinal Labels */}
                    <g transform="translate(0, 4)">
                        <text x="50" y="25" textAnchor="middle" fontSize="8" fill="var(--color-primary)" fontWeight="900">N</text>
                        <text x="50" y="25" textAnchor="middle" fontSize="8" fill="var(--color-primary)" fontWeight="900" transform="rotate(90, 50, 50)">E</text>
                        <text x="50" y="25" textAnchor="middle" fontSize="8" fill="var(--color-primary)" fontWeight="900" transform="rotate(180, 50, 50)">S</text>
                        <text x="50" y="25" textAnchor="middle" fontSize="8" fill="var(--color-primary)" fontWeight="900" transform="rotate(270, 50, 50)">W</text>
                    </g>
                </g>
                
                {fullSize && (
                    <circle cx="50" cy="50" r="35" fill="none" stroke="var(--color-primary)" strokeWidth="0.2" strokeDasharray="2 2" opacity="0.5" />
                )}
            </svg>

            {/* Center Digital Readout */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <div className={`flex flex-col items-center justify-center bg-black/70 ${fullSize ? 'w-24 h-24 border-2' : 'w-10 h-10 border'} rounded-full border-[var(--color-border)]/50 backdrop-blur-sm shadow-lg transition-all`}>
                     <span className={`${fullSize ? 'text-2xl' : 'text-[10px]'} font-bold text-[var(--color-primary)] leading-tight`}>{cardinal}</span>
                     <span className={`${fullSize ? 'text-sm' : 'text-[8px]'} font-mono text-[var(--color-text-muted)] leading-tight`}>{Math.round(heading).toString().padStart(3, '0')}°</span>
                 </div>
            </div>
        </div>
        
        {fullSize && (
             <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-full max-w-lg flex flex-col items-center gap-2 text-center font-mono text-sm ">
                 {!isSensorAvailable && (
                     <div className="text-xs text-yellow-500 flex items-center justify-center gap-2 animate-pulse">
                         <RotateCcw size={12} className="animate-spin" /> SENSOR OFFLINE - SIMULATION MODE ACTIVE
                     </div>
                 )}
                 <button onClick={startCalibration} className="hud-button text-xs !px-4 !py-2">Calibrate Sensor</button>
             </div>
        )}
    </div>
  );
};

export default Compass;