
import React, { useState, useEffect } from 'react';
import { Plane, Globe, ArrowUp, Zap, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { FlightData } from '../types';
import { ListSkeleton } from './Loading';

const FlightTrackerPanel: React.FC = () => {
    const { state } = useAppContext();
    const { geolocation } = state;
    const [flights, setFlights] = useState<FlightData[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (geolocation) {
            fetchFlights();
        }

        const interval = setInterval(() => {
            if (geolocation) {
                fetchFlights();
            }
        }, 60000); // Refresh every minute

        return () => clearInterval(interval);
    }, [geolocation]);

    const fetchFlights = async () => {
        if (!geolocation) return;
        setIsLoading(true);
        setError(null);
        try {
            // Bounding box of roughly 100km
            const latMin = geolocation.latitude - 0.5;
            const latMax = geolocation.latitude + 0.5;
            const lonMin = geolocation.longitude - 0.5;
            const lonMax = geolocation.longitude + 0.5;

            const res = await fetch(`https://opensky-network.org/api/states/all?lamin=${latMin}&lomin=${lonMin}&lamax=${latMax}&lomax=${lonMax}`);
            if (!res.ok) throw new Error("Failed to fetch flight data");
            const data = await res.json();

            const flightData: FlightData[] = (data.states || []).slice(0, 20).map((f: any) => ({
                icao24: f[0],
                callsign: f[1]?.trim() || 'N/A',
                origin_country: f[2],
                longitude: f[5],
                latitude: f[6],
                baro_altitude: f[7], // meters
                velocity: f[9], // m/s
                on_ground: f[8],
            }));
            
            setFlights(flightData);

        } catch (e) {
            setError("Could not retrieve flight data. API may be unavailable.");
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    };

    const metersToFeet = (m: number | null) => m ? Math.round(m * 3.28084) : 0;
    const msToKts = (ms: number | null) => ms ? Math.round(ms * 1.94384) : 0;

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Plane size={16}/> AIR TRAFFIC MONITOR</h2>
                {isLoading && <Loader2 size={16} className="animate-spin text-[var(--color-primary)]" />}
            </div>

            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden">
                <div className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400 grid grid-cols-4 md:grid-cols-5 gap-2">
                    <span>CALLSIGN</span>
                    <span className="hidden md:block">ORIGIN</span>
                    <span>ALTITUDE (FT)</span>
                    <span>SPEED (KTS)</span>
                    <span>STATUS</span>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {isLoading && flights.length === 0 ? (
                        <div className="p-2"><ListSkeleton count={10} /></div>
                    ) : error ? (
                        <div className="p-4 text-center text-red-500">{error}</div>
                    ) : !geolocation ? (
                        <div className="p-4 text-center text-yellow-500">Awaiting GPS lock to scan for air traffic...</div>
                    ) : flights.length === 0 ? (
                        <div className="p-4 text-center text-gray-500">No air traffic detected in the immediate vicinity.</div>
                    ) : (
                        flights.map(flight => (
                            <div key={flight.icao24} className="grid grid-cols-4 md:grid-cols-5 gap-2 p-3 border-b border-gray-800/50 items-center font-mono text-sm hover:bg-white/5">
                                <span className="text-white font-bold truncate">{flight.callsign}</span>
                                <span className="hidden md:block text-gray-400">{flight.origin_country}</span>
                                <span className="text-blue-400">{metersToFeet(flight.baro_altitude).toLocaleString()}</span>
                                <span className="text-green-400">{msToKts(flight.velocity)}</span>
                                <span className={`text-xs font-sans font-bold ${flight.on_ground ? 'text-yellow-500' : 'text-cyan-400'}`}>{flight.on_ground ? 'GROUNDED' : 'AIRBORNE'}</span>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

export default FlightTrackerPanel;
