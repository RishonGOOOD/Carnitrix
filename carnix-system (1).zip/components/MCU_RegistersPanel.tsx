
import React, { useState, useEffect } from 'react';
import { Database, RefreshCw, Cpu, Shield } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const MCU_RegistersPanel: React.FC = () => {
    const [registers, setRegisters] = useState<any[]>([]);
    const [isRefreshing, setIsRefreshing] = useState(false);

    const generateData = () => {
        return Array.from({ length: 16 }, (_, i) => ({
            addr: `0x${(i * 4).toString(16).padStart(4, '0').toUpperCase()}`,
            val: `0x${Math.floor(Math.random() * 0xFFFFFFFF).toString(16).padStart(8, '0').toUpperCase()}`,
            desc: i % 3 === 0 ? 'STATUS_REG' : i % 3 === 1 ? 'DATA_BUFFER' : 'CTRL_LATCH',
            status: Math.random() > 0.9 ? 'FAULT' : 'NOMINAL'
        }));
    };

    useEffect(() => {
        setRegisters(generateData());
    }, []);

    const handleRefresh = () => {
        setIsRefreshing(true);
        playSound('scan');
        setTimeout(() => {
            setRegisters(generateData());
            setIsRefreshing(false);
            playSound('success');
        }, 800);
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/40 border border-white/10 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Database size={24} className="text-orange-500" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic">MCU Register Map</h2>
                        <p className="text-[9px] font-mono text-gray-500">Live Memory Snapshot // 32-bit Architecture</p>
                    </div>
                </div>
                <button onClick={handleRefresh} className="p-2 bg-orange-600/20 text-orange-500 border border-orange-600 rounded">
                    <RefreshCw size={18} className={isRefreshing ? 'animate-spin' : ''} />
                </button>
            </div>

            <div className="flex-1 bg-black/30 border border-white/5 rounded-lg overflow-hidden flex flex-col">
                <div className="grid grid-cols-4 bg-white/5 p-2 text-[10px] font-black text-gray-400 border-b border-white/10 uppercase tracking-widest">
                    <span>Address</span>
                    <span>Value (HEX)</span>
                    <span>Description</span>
                    <span className="text-right">State</span>
                </div>
                <div className="flex-1 overflow-y-auto scrollbar-carnix">
                    {registers.map((reg, i) => (
                        <div key={i} className="grid grid-cols-4 p-3 border-b border-white/5 hover:bg-white/5 transition-colors font-mono text-xs">
                            <span className="text-orange-500">{reg.addr}</span>
                            <span className="text-white">{reg.val}</span>
                            <span className="text-gray-500">{reg.desc}</span>
                            <span className={`text-right font-black ${reg.status === 'FAULT' ? 'text-red-500 animate-pulse' : 'text-green-500'}`}>{reg.status}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default MCU_RegistersPanel;
