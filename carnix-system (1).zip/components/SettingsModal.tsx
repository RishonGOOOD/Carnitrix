
import React, { useState } from 'react';
import { X, Volume2, Monitor, User, BrainCircuit, Save, Power, LogOut, RefreshCw } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

interface Props { isOpen: boolean; onClose: () => void; }

const SettingsModal: React.FC<Props> = ({ isOpen, onClose }) => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    
    // Local state for editing
    const [tab, setTab] = useState<'AI' | 'UI' | 'PROFILE'>('AI');
    
    if (!isOpen || !activeProfile) return null;

    const handleSave = (updates: any) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: updates });
        playSound('success');
    };

    const toggleTTS = () => {
        handleSave({ 
            aiSettings: { 
                ...activeProfile.aiSettings, 
                textToSpeechEnabled: !activeProfile.aiSettings.textToSpeechEnabled 
            } 
        });
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-lg shadow-2xl flex flex-col max-h-[80vh] font-[Rajdhani]">
                {/* Header */}
                <div className="flex justify-between items-center p-4 border-b border-white/10 bg-white/5">
                    <div className="flex items-center gap-2">
                        <SettingsIcon className="text-[var(--color-primary)]" size={18}/>
                        <span className="text-sm font-black uppercase tracking-widest text-white">System Configuration</span>
                    </div>
                    <button onClick={onClose} className="text-gray-500 hover:text-white"><X size={18}/></button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-white/10">
                    <button onClick={() => setTab('AI')} className={`flex-1 p-3 text-xs font-bold uppercase transition-colors ${tab === 'AI' ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)] border-b-2 border-[var(--color-primary)]' : 'text-gray-500 hover:text-white'}`}>
                        <BrainCircuit size={14} className="inline mr-2"/> Neural Core
                    </button>
                    <button onClick={() => setTab('UI')} className={`flex-1 p-3 text-xs font-bold uppercase transition-colors ${tab === 'UI' ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)] border-b-2 border-[var(--color-primary)]' : 'text-gray-500 hover:text-white'}`}>
                        <Monitor size={14} className="inline mr-2"/> Interface
                    </button>
                    <button onClick={() => setTab('PROFILE')} className={`flex-1 p-3 text-xs font-bold uppercase transition-colors ${tab === 'PROFILE' ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)] border-b-2 border-[var(--color-primary)]' : 'text-gray-500 hover:text-white'}`}>
                        <User size={14} className="inline mr-2"/> Operator
                    </button>
                </div>

                {/* Body */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {tab === 'AI' && (
                        <div className="space-y-4">
                            <div className="bg-white/5 p-4 rounded border border-white/5 flex items-center justify-between">
                                <div>
                                    <h4 className="text-sm font-bold text-white flex items-center gap-2"><Volume2 size={16}/> Vocal Output</h4>
                                    <p className="text-[10px] text-gray-500">AI Text-to-Speech Engine</p>
                                </div>
                                <button 
                                    onClick={toggleTTS}
                                    className={`px-4 py-1.5 rounded text-xs font-bold transition-all ${activeProfile.aiSettings.textToSpeechEnabled ? 'bg-green-600 text-black' : 'bg-red-900/50 text-red-500 border border-red-500'}`}
                                >
                                    {activeProfile.aiSettings.textToSpeechEnabled ? 'ACTIVE' : 'MUTED'}
                                </button>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[10px] font-bold text-gray-500 uppercase block mb-2">Personality Model</label>
                                    <select 
                                        value={activeProfile.aiSettings.personality}
                                        onChange={(e) => handleSave({ aiSettings: { ...activeProfile.aiSettings, personality: e.target.value }})}
                                        className="w-full bg-black border border-gray-700 rounded p-2 text-xs text-white"
                                    >
                                        <option>Tactical Operative</option>
                                        <option>Friendly Assistant</option>
                                        <option>Dark Sci-Fi</option>
                                        <option>Hyper-Professional</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-gray-500 uppercase block mb-2">Processing Power</label>
                                    <select 
                                        value={activeProfile.aiSettings.model}
                                        onChange={(e) => handleSave({ aiSettings: { ...activeProfile.aiSettings, model: e.target.value }})}
                                        className="w-full bg-black border border-gray-700 rounded p-2 text-xs text-white"
                                    >
                                        <option value="gemini-3-pro-preview">Gemini 3 Pro (High Intel)</option>
                                        <option value="gemini-3-flash-preview">Gemini 3 Flash (Fast)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    )}

                    {tab === 'UI' && (
                        <div className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-[10px] font-bold text-gray-500 uppercase block mb-2">Primary Tint</label>
                                    <input 
                                        type="color" 
                                        value={activeProfile.uiSettings.primaryColor}
                                        onChange={(e) => handleSave({ uiSettings: { ...activeProfile.uiSettings, primaryColor: e.target.value }})}
                                        className="w-full h-10 rounded bg-black border border-gray-700 p-1"
                                    />
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-gray-500 uppercase block mb-2">Data Accent</label>
                                    <input 
                                        type="color" 
                                        value={activeProfile.uiSettings.accentColor}
                                        onChange={(e) => handleSave({ uiSettings: { ...activeProfile.uiSettings, accentColor: e.target.value }})}
                                        className="w-full h-10 rounded bg-black border border-gray-700 p-1"
                                    />
                                </div>
                            </div>
                            <div className="flex items-center justify-between p-3 bg-white/5 rounded border border-white/5">
                                <span className="text-xs font-bold text-gray-300">Scanline Filter Overlay</span>
                                <button 
                                    onClick={() => handleSave({ uiSettings: { ...activeProfile.uiSettings, showScanlines: !activeProfile.uiSettings.showScanlines }})}
                                    className={`w-8 h-4 rounded-full relative transition-colors ${activeProfile.uiSettings.showScanlines ? 'bg-[var(--color-primary)]' : 'bg-gray-700'}`}
                                >
                                    <div className={`absolute top-0.5 left-0.5 w-3 h-3 bg-white rounded-full transition-transform ${activeProfile.uiSettings.showScanlines ? 'translate-x-4' : 'translate-x-0'}`} />
                                </button>
                            </div>
                        </div>
                    )}

                    {tab === 'PROFILE' && (
                        <div className="space-y-4 text-center">
                            <div className="w-20 h-20 bg-[var(--color-primary)]/10 rounded-full mx-auto flex items-center justify-center border-2 border-[var(--color-primary)]">
                                <User size={40} className="text-[var(--color-primary)]"/>
                            </div>
                            <div>
                                <h3 className="text-xl font-black text-white uppercase">{activeProfile.name}</h3>
                                <p className="text-xs text-gray-500 font-mono">{activeProfile.speciality} // ID: {activeProfile.id.slice(-6)}</p>
                            </div>
                            <div className="grid grid-cols-2 gap-3 pt-4">
                                <button onClick={() => window.location.reload()} className="p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded text-xs font-bold flex items-center justify-center gap-2">
                                    <RefreshCw size={14}/> REBOOT
                                </button>
                                <button onClick={() => dispatch({type: 'LOGOUT'})} className="p-3 bg-red-900/20 hover:bg-red-900/40 border border-red-900/50 rounded text-xs font-bold text-red-500 flex items-center justify-center gap-2">
                                    <LogOut size={14}/> LOGOUT
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

// Helper for icon
const SettingsIcon: React.FC<{size?: number, className?: string}> = ({size=16, className}) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.1a2 2 0 0 1-1-1.74v-.47a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
        <circle cx="12" cy="12" r="3"></circle>
    </svg>
);

export default SettingsModal;
