import React, { useState } from 'react';
import { Bot, Zap, Send, Loader2, Code, FileJson, Box } from 'lucide-react';
import { useAppContext } from '../context';
import { generateModuleBlueprint } from '../services/geminiService';

const PluginForgePanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [description, setDescription] = useState('');
    const [blueprint, setBlueprint] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerate = async () => {
        if (!description.trim() || !activeProfile) return;
        setIsLoading(true);
        setBlueprint(null);
        try {
            const res = await generateModuleBlueprint(activeProfile.aiSettings, description);
            const formattedJson = JSON.stringify(JSON.parse(res.text), null, 2);
            setBlueprint(formattedJson);
        } catch (e: any) {
            setBlueprint(`{\n  "error": "Failed to generate a valid blueprint. Please try refining your description.",\n  "details": "${e.message}"\n}`);
        }
        setIsLoading(false);
    };

    return (
        <div className="w-full h-full flex flex-col md:flex-row gap-4 p-1">
            <div className="w-full md:w-1/3 flex flex-col gap-4">
                <div className="hud-panel p-4 flex-1 flex flex-col">
                    <h2 className="hud-panel-header !-m-4 !mb-3">
                        <Box size={16} /> PLUGIN FORGE
                    </h2>
                    <p className="text-xs text-gray-400 mb-3">Describe a new plugin or feature. The AI will generate a technical blueprint for its construction.</p>
                     <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="e.g., A plugin that connects to the Spotify API to control music playback and show the currently playing song."
                        className="flex-1 w-full hud-textarea text-sm resize-none"
                        disabled={isLoading}
                    />
                     <button
                        onClick={handleGenerate}
                        disabled={isLoading || !description.trim()}
                        className="w-full hud-button flex items-center justify-center gap-2 mt-3 disabled:opacity-50"
                    >
                        {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                        {isLoading ? 'DESIGNING...' : 'GENERATE BLUEPRINT'}
                    </button>
                </div>
            </div>
            <div className="hud-panel flex-1 font-mono text-sm flex flex-col min-h-0 relative">
                <div className="hud-panel-header">
                    <FileJson size={14} /> GENERATED BLUEPRINT (JSON)
                </div>
                 <div className="flex-1 overflow-auto p-2">
                    {isLoading && (
                        <div className="flex items-center justify-center h-full text-gray-500">
                            <Loader2 size={24} className="animate-spin mr-2" /> AI Architect is processing...
                        </div>
                    )}
                    {blueprint ? (
                        <pre><code className="whitespace-pre-wrap text-sm">{blueprint}</code></pre>
                    ) : (
                        <div className="text-gray-600">Blueprint will appear here.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PluginForgePanel;