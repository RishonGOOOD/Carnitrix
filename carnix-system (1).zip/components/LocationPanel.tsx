
import React, { useState, useMemo, useEffect } from 'react';
import { MapPin, WifiOff, LocateFixed, Navigation2, RefreshCw } from 'lucide-react';
import { Mode } from '../types';
import { getAIResponse } from '../services/geminiService';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { useAppContext } from '../context';


const LocationPanel: React.FC = () => {
    const { state } = useAppContext();
    const { geolocation, address, isOnline, activeProfile } = state;
    const aiSettings = activeProfile?.aiSettings;
    
    const [destination, setDestination] = useState('');
    const [isCalculating, setIsCalculating] = useState(false);
    const [routeInfo, setRouteInfo] = useState<string | null>(null);
    const [mapCenter, setMapCenter] = useState<{ latitude: number; longitude: number } | null>(null);

    // Set initial and periodic location
    useEffect(() => {
        if (geolocation && !mapCenter) {
            setMapCenter({ latitude: geolocation.latitude, longitude: geolocation.longitude });
        }
        
        const intervalId = setInterval(() => {
            if (geolocation) {
                setMapCenter({ latitude: geolocation.latitude, longitude: geolocation.longitude });
            }
        }, 60000); // 1 minute

        return () => clearInterval(intervalId);
    }, [geolocation, mapCenter]);

    const handleRecenter = () => {
        if (geolocation) {
            setMapCenter({ latitude: geolocation.latitude, longitude: geolocation.longitude });
            playSound('click');
            triggerHaptic('light');
        }
    };

    const handleCalculateRoute = async () => {
        if (!geolocation || !destination.trim() || !aiSettings) return;
        setIsCalculating(true);
        playSound('process');
        setRouteInfo(null);
        try {
            const prompt = `From my current location (Lat:${geolocation.latitude}, Lon:${geolocation.longitude}) to "${destination}". Provide distance, estimated driving time, walking time, and a concise path summary.`;
            const response = await getAIResponse(prompt, Mode.Location, aiSettings, geolocation, state.messages);
            setRouteInfo(response.text);
            playSound('success');
            triggerHaptic('medium');
        } catch (e: any) { setRouteInfo("Navigation Error: Could not calculate route."); playSound('error'); triggerHaptic('error'); } 
        finally { setIsCalculating(false); }
    };

    const mapUrl = useMemo(() => {
        if (!mapCenter) return "";
        const cLat = mapCenter.latitude.toFixed(5);
        const cLon = mapCenter.longitude.toFixed(5);
        return `https://www.openstreetmap.org/export/embed.html?bbox=${Number(cLon)-0.005}%2C${Number(cLat)-0.005}%2C${Number(cLon)+0.005}%2C${Number(cLat)+0.005}&layer=mapnik&marker=${cLat}%2C${cLon}`;
    }, [mapCenter]);
    
    return (
        <div className="w-full h-full flex flex-col gap-4 relative p-1">
            <div className="flex flex-wrap gap-4 flex-shrink-0">
                 <div className="flex-1 min-w-[150px] bg-black/40 border border-[var(--color-panel-border)] rounded-md p-3">
                      <div className="text-[10px] text-[var(--color-text-muted)] uppercase font-bold flex items-center gap-2 mb-1"><LocateFixed size={12}/> Coords</div>
                      <div className="font-mono text-lg text-white truncate">{geolocation ? `${geolocation.latitude.toFixed(4)}, ${geolocation.longitude.toFixed(4)}` : "SEARCHING..."}</div>
                 </div>
                 <div className="flex-1 min-w-[150px] bg-black/40 border border-[var(--color-panel-border)] rounded-md p-3">
                      <div className="text-[10px] text-[var(--color-text-muted)] uppercase font-bold flex items-center gap-2 mb-1"><MapPin size={12}/> Sector</div>
                      <div className="text-lg text-white truncate">{address?.city || address?.district || "Unknown"}</div>
                      <div className="text-[10px] text-[var(--color-primary)] uppercase tracking-widest">{address?.country || "Region Scanning"}</div>
                 </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-4 overflow-hidden">
                <div className="h-1/3 md:h-full md:w-72 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex flex-col overflow-hidden">
                    <div className="text-xs font-bold text-[var(--color-primary)] border-b border-white/10 pb-2 mb-3 flex items-center gap-2"><Navigation2 size={14} /> NAV COMPUTER</div>
                    <div className="flex gap-2 mb-3">
                        <input type="text" value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="Target Destination" className="flex-1 bg-black/50 border border-[var(--color-terminal-border)] rounded px-2 py-1 text-xs outline-none text-white" />
                        <button onClick={handleCalculateRoute} disabled={isCalculating || !destination} className="bg-[var(--color-primary)] text-black p-2 rounded hover:bg-white transition-colors disabled:opacity-50">{isCalculating ? <RefreshCw size={14} className="animate-spin"/> : <Navigation2 size={14} />}</button>
                    </div>
                    <div className="flex-1 bg-black/40 rounded border border-white/5 overflow-y-auto p-2 font-mono text-xs text-gray-300 whitespace-pre-wrap">{routeInfo || "Awaiting target designation."}</div>
                </div>

                <div className="flex-1 w-full relative bg-black/20 rounded-md overflow-hidden border border-[var(--color-panel-border)]">
                    {isOnline && mapUrl ? (
                        <iframe key={mapUrl} width="100%" height="100%" frameBorder="0" scrolling="no" title="OSM" src={mapUrl} className="filter grayscale contrast-125 brightness-75 hover:filter-none transition-all duration-500"></iframe>
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-[var(--color-primary)] bg-[radial-gradient(circle,rgba(0,20,0,0.5),black)]"><WifiOff className="mr-2"/> MAP OFFLINE</div>
                    )}
                    <div className="absolute bottom-4 left-4">
                        <button onClick={handleRecenter} className="px-3 py-2 rounded border border-white/20 bg-black/80 text-white text-xs font-bold flex items-center gap-2 hover:bg-[var(--color-primary)] hover:text-black transition-colors">
                            <LocateFixed size={14} /> RE-CENTER
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LocationPanel;
