


import React, { useState, useMemo } from 'react';
import { CalendarEvent, Profile } from '../types';
import { Calendar, Plus, Trash2, Edit, Save, X, Clock, ChevronsLeft, ChevronsRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const CalendarPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const events = activeProfile?.events || [];

    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<string | null>(null);
    const [isEditing, setIsEditing] = useState<CalendarEvent | null>(null);
    
    const onUpdateEvents = (newEvents: CalendarEvent[]) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { events: newEvents } });
    };

    const daysInMonth = useMemo(() => {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const days = [];
        while (date.getMonth() === currentDate.getMonth()) {
            days.push(new Date(date));
            date.setDate(date.getDate() + 1);
        }
        return days;
    }, [currentDate]);

    const firstDayOfMonth = useMemo(() => {
        return new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
    }, [currentDate]);

    const eventsByDate = useMemo(() => {
        return events.reduce((acc, event) => {
            (acc[event.date] = acc[event.date] || []).push(event);
            return acc;
        }, {} as Record<string, CalendarEvent[]>);
    }, [events]);

    const handleDateClick = (date: Date) => {
        const dateString = date.toISOString().split('T')[0];
        setSelectedDate(dateString);
        setIsEditing(null);
    };
    
    const handleSaveEvent = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!isEditing || !selectedDate) return;
        
        const updatedEvents = events.filter(ev => ev.id !== isEditing.id);
        onUpdateEvents([...updatedEvents, { ...isEditing, date: selectedDate }]);
        setIsEditing(null);
        playSound('success');
    };

    const handleDeleteEvent = (eventId: string) => {
        onUpdateEvents(events.filter(ev => ev.id !== eventId));
        playSound('error');
    };
    
    const handleAddNewEvent = () => {
        if (!selectedDate) return;
        const newEvent: CalendarEvent = {
            id: `event-${Date.now()}`,
            date: selectedDate,
            title: '',
            description: '',
            time: '12:00'
        };
        setIsEditing(newEvent);
    };

    const selectedDateEvents = selectedDate ? eventsByDate[selectedDate] || [] : [];
    const today = new Date().toISOString().split('T')[0];

    return (
        <div className="w-full h-full flex flex-col md:flex-row gap-4 p-1">
            <div className="flex-1 flex flex-col bg-black/30 border border-[var(--color-panel-border)] rounded-md">
                <div className="p-3 border-b border-white/10 flex items-center justify-between">
                    <h2 className="text-sm font-bold text-white tracking-widest">{currentDate.toLocaleString('default', { month: 'long', year: 'numeric' }).toUpperCase()}</h2>
                    <div className="flex items-center gap-1">
                        <button onClick={() => setCurrentDate(d => new Date(d.getFullYear() - 1, d.getMonth()))} className="p-1 hover:bg-white/10 rounded"><ChevronsLeft size={16}/></button>
                        <button onClick={() => setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() - 1))} className="p-1 hover:bg-white/10 rounded"><ChevronLeft size={16}/></button>
                        <button onClick={() => setCurrentDate(new Date())} className="px-2 text-xs hover:bg-white/10 rounded">TODAY</button>
                        <button onClick={() => setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() + 1))} className="p-1 hover:bg-white/10 rounded"><ChevronRight size={16}/></button>
                        <button onClick={() => setCurrentDate(d => new Date(d.getFullYear() + 1, d.getMonth()))} className="p-1 hover:bg-white/10 rounded"><ChevronsRight size={16}/></button>
                    </div>
                </div>
                <div className="grid grid-cols-7 text-center text-xs font-bold text-gray-400 border-b border-white/10">
                    {['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'].map(day => <div key={day} className="p-2">{day}</div>)}
                </div>
                <div className="grid grid-cols-7 flex-1">
                    {Array.from({ length: firstDayOfMonth }).map((_, i) => <div key={`empty-${i}`} className="border-r border-b border-white/5"></div>)}
                    {daysInMonth.map(day => {
                        const dateStr = day.toISOString().split('T')[0];
                        const dayEvents = eventsByDate[dateStr];
                        const isToday = dateStr === today;
                        const isSelected = dateStr === selectedDate;
                        return (
                            <div key={dateStr} onClick={() => handleDateClick(day)} className={`border-r border-b border-white/5 p-2 text-xs cursor-pointer transition-colors relative ${isSelected ? 'bg-[var(--color-primary)]/20' : 'hover:bg-white/10'}`}>
                                <span className={`absolute top-2 right-2 w-6 h-6 flex items-center justify-center rounded-full ${isToday ? 'bg-[var(--color-primary)] text-black font-bold' : ''}`}>{day.getDate()}</span>
                                <div className="mt-8 flex flex-col gap-1">
                                    {dayEvents && dayEvents.map(event => (
                                        <div key={event.id} className="w-full h-1.5 bg-[var(--color-primary)] rounded-full opacity-70" title={event.title}></div>
                                    ))}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            <div className="w-full md:w-1/3 flex flex-col bg-black/30 border border-[var(--color-panel-border)] rounded-md">
                <div className="p-3 border-b border-white/10 flex items-center justify-between">
                    <h2 className="text-sm font-bold text-white tracking-widest">{selectedDate ? new Date(selectedDate + 'T00:00:00').toDateString() : 'SELECT A DATE'}</h2>
                    <button onClick={handleAddNewEvent} disabled={!selectedDate} className="p-1 bg-[var(--color-primary)]/20 text-[var(--color-primary)] rounded hover:bg-[var(--color-primary)] hover:text-black disabled:opacity-50"><Plus size={14} /></button>
                </div>

                {isEditing ? (
                    <form onSubmit={handleSaveEvent} className="p-4 space-y-4 flex-1 overflow-y-auto">
                        <div>
                            <label className="text-xs text-gray-400">Title</label>
                            <input type="text" value={isEditing.title} onChange={e => setIsEditing(prev => prev ? {...prev, title: e.target.value} : null)} required className="w-full bg-black/50 border border-gray-700 rounded p-2 mt-1 text-sm"/>
                        </div>
                        <div>
                            <label className="text-xs text-gray-400">Time</label>
                            <input type="time" value={isEditing.time} onChange={e => setIsEditing(prev => prev ? {...prev, time: e.target.value} : null)} className="w-full bg-black/50 border border-gray-700 rounded p-2 mt-1 text-sm"/>
                        </div>
                        <div>
                            <label className="text-xs text-gray-400">Description</label>
                            <textarea value={isEditing.description} onChange={e => setIsEditing(prev => prev ? {...prev, description: e.target.value} : null)} className="w-full h-24 bg-black/50 border border-gray-700 rounded p-2 mt-1 text-sm resize-y"/>
                        </div>
                        <div className="flex gap-2">
                             <button type="submit" className="flex-1 p-2 bg-green-800 text-white rounded text-xs flex items-center justify-center gap-1"><Save size={12}/> SAVE</button>
                             <button type="button" onClick={() => setIsEditing(null)} className="flex-1 p-2 bg-gray-700 text-white rounded text-xs flex items-center justify-center gap-1"><X size={12}/> CANCEL</button>
                        </div>
                    </form>
                ) : (
                    <div className="p-4 space-y-3 flex-1 overflow-y-auto">
                        {selectedDateEvents.length > 0 ? selectedDateEvents.map(event => (
                            <div key={event.id} className="bg-black/40 p-3 rounded border border-white/10">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="font-bold text-white">{event.title}</p>
                                        {event.time && <p className="text-xs text-gray-400 flex items-center gap-1"><Clock size={12}/> {event.time}</p>}
                                    </div>
                                    <div className="flex gap-2">
                                        <button onClick={() => setIsEditing(event)} className="text-gray-400 hover:text-white"><Edit size={14}/></button>
                                        <button onClick={() => handleDeleteEvent(event.id)} className="text-red-600 hover:text-red-400"><Trash2 size={14}/></button>
                                    </div>
                                </div>
                                {event.description && <p className="text-xs text-gray-300 mt-2 pt-2 border-t border-white/5">{event.description}</p>}
                            </div>
                        )) : <p className="text-xs text-gray-500 italic text-center mt-8">No events for this date.</p>}
                    </div>
                )}
            </div>
        </div>
    );
};

export default CalendarPanel;