


import React, { useState, useEffect } from 'react';
import { BarChart, Brain, Terminal, CheckCircle } from 'lucide-react';
import { useAppContext } from '../context';

const StatisticsEvolutionPanel: React.FC = () => {
    const { state } = useAppContext();
    const [stats, setStats] = useState({
        commands: 137,
        tasks: 42,
        memories: state.activeProfile?.notes.length || 0,
        uptime: 0,
    });

    useEffect(() => {
        const interval = setInterval(() => {
            setStats(prev => ({ ...prev, uptime: prev.uptime + 1 }));
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const formatUptime = (seconds: number) => {
        const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
        const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
        const s = (seconds % 60).toString().padStart(2, '0');
        return `${h}:${m}:${s}`;
    };
    
    const evolutionProgress = (stats.commands + stats.tasks * 2 + stats.memories * 5) / 10;

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
             <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><BarChart size={16}/> STATISTICS & EVOLUTION</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-black/30 border border-gray-800 rounded-md p-4">
                    <div className="text-xs text-gray-400 flex items-center gap-2"><Terminal size={12}/> COMMANDS PROCESSED</div>
                    <div className="text-4xl font-bold font-mono text-white">{stats.commands}</div>
                </div>
                <div className="bg-black/30 border border-gray-800 rounded-md p-4">
                    <div className="text-xs text-gray-400 flex items-center gap-2"><CheckCircle size={12}/> TASKS COMPLETED</div>
                    <div className="text-4xl font-bold font-mono text-white">{stats.tasks}</div>
                </div>
                <div className="bg-black/30 border border-gray-800 rounded-md p-4">
                    <div className="text-xs text-gray-400 flex items-center gap-2"><Brain size={12}/> MEMORY FRAGMENTS</div>
                    <div className="text-4xl font-bold font-mono text-white">{stats.memories}</div>
                </div>
                <div className="bg-black/30 border border-gray-800 rounded-md p-4">
                    <div className="text-xs text-gray-400">SESSION UPTIME</div>
                    <div className="text-4xl font-bold font-mono text-white">{formatUptime(stats.uptime)}</div>
                </div>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex flex-col items-center justify-center">
                 <h3 className="text-sm font-bold text-gray-400 mb-4">AI EVOLUTIONARY PROGRESS</h3>
                 <div className="w-full max-w-md">
                    <div className="w-full bg-gray-800 rounded-full h-4">
                        <div className="bg-[var(--color-primary)] h-4 rounded-full" style={{ width: `${evolutionProgress % 100}%` }}></div>
                    </div>
                    <div className="text-center mt-2 font-mono text-sm text-[var(--color-primary)]">
                        Level {Math.floor(evolutionProgress / 100)} - {(evolutionProgress % 100).toFixed(1)}%
                    </div>
                 </div>
            </div>
        </div>
    );
};

export default StatisticsEvolutionPanel;