import React, { useState } from 'react';
import { ReportEngine } from '../services/reportEngine';
import { InvestigationService } from '../services/investigationService';
import { SecurityEngine } from '../services/securityEngine';
import { CarnixReport } from '../types';
import { 
  FileCheck2, Download, Copy, Printer, Check, 
  FileText, Shield, Sparkles, RefreshCw
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const ReportEnginePanel: React.FC = () => {
  const activeCase = InvestigationService.getActiveCase();
  const [report, setReport] = useState<CarnixReport | null>(() => {
    return activeCase ? ReportEngine.generateInvestigationReport(activeCase) : null;
  });
  const [copied, setCopied] = useState(false);
  const [reportFormat, setReportFormat] = useState<'MARKDOWN' | 'JSON'>('MARKDOWN');

  const handleGenerateCaseReport = () => {
    playSound('scan');
    triggerHaptic('medium');
    const curr = InvestigationService.getActiveCase();
    if (curr) {
      const rep = ReportEngine.generateInvestigationReport(curr);
      setReport(rep);
      playSound('success');
    }
  };

  const handleGenerateSecurityReport = async () => {
    playSound('scan');
    triggerHaptic('medium');
    const target = activeCase?.targets[0] || 'apex-defense.org';
    const assessment = await SecurityEngine.assessTarget(target);
    const rep = ReportEngine.generateSecurityAuditReport(assessment);
    setReport(rep);
    playSound('success');
  };

  const handleCopy = () => {
    if (!report) return;
    const textToCopy = reportFormat === 'MARKDOWN' ? report.markdownContent : JSON.stringify(report, null, 2);
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    playSound('click');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!report) return;
    playSound('click');
    const isMd = reportFormat === 'MARKDOWN';
    const content = isMd ? report.markdownContent : JSON.stringify(report, null, 2);
    const ext = isMd ? 'md' : 'json';
    const blob = new Blob([content], { type: isMd ? 'text/markdown' : 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `carnix-report-${report.id}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    playSound('click');
    window.print();
  };

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-red-950/20 border border-red-900/30 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-red-600/20 border border-red-500 rounded text-red-400">
              <FileCheck2 size={18} />
            </span>
            <h1 className="text-xl font-black font-orbitron text-white tracking-wider">
              TACTICAL REPORT & INTELLIGENCE COMPILER
            </h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Automated generation of defense assessments, investigation dossiers, IOC registries, and MITRE ATT&CK mappings.
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleGenerateCaseReport}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded transition-all shadow-[0_0_15px_rgba(255,0,0,0.4)]"
          >
            <RefreshCw size={13} /> COMPILE CASE REPORT
          </button>
          <button
            onClick={handleGenerateSecurityReport}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-black border border-red-900/40 hover:border-red-500 text-red-400 font-mono text-xs uppercase tracking-wider rounded transition-all"
          >
            <Shield size={13} /> SECURITY AUDIT BRIEF
          </button>
        </div>
      </div>

      {report ? (
        <div className="flex flex-col gap-3 flex-1">
          {/* Metadata Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 p-3 bg-black/70 border border-red-900/30 rounded-lg font-mono text-xs">
            <div className="space-y-0.5">
              <div className="font-bold text-white text-sm">{report.title}</div>
              <div className="text-gray-400 text-[11px]">
                Generated: {new Date(report.generatedAt).toLocaleString()} | Author: {report.author}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex bg-black p-0.5 rounded border border-white/10 text-[10px]">
                <button
                  onClick={() => setReportFormat('MARKDOWN')}
                  className={`px-2 py-1 rounded font-bold ${reportFormat === 'MARKDOWN' ? 'bg-red-600 text-black' : 'text-gray-400'}`}
                >
                  MARKDOWN
                </button>
                <button
                  onClick={() => setReportFormat('JSON')}
                  className={`px-2 py-1 rounded font-bold ${reportFormat === 'JSON' ? 'bg-red-600 text-black' : 'text-gray-400'}`}
                >
                  JSON
                </button>
              </div>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1 px-2.5 py-1 bg-black/60 border border-white/10 hover:border-white/30 text-gray-300 rounded text-xs"
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                {copied ? 'COPIED' : 'COPY'}
              </button>

              <button
                onClick={handleDownload}
                className="flex items-center gap-1 px-2.5 py-1 bg-black/60 border border-white/10 hover:border-white/30 text-gray-300 rounded text-xs"
              >
                <Download size={13} /> DOWNLOAD
              </button>

              <button
                onClick={handlePrint}
                className="flex items-center gap-1 px-2.5 py-1 bg-black/60 border border-white/10 hover:border-white/30 text-gray-300 rounded text-xs"
              >
                <Printer size={13} /> PRINT
              </button>
            </div>
          </div>

          {/* Report Viewer */}
          <div className="flex-1 p-5 bg-black/80 border border-red-900/30 rounded-xl overflow-y-auto max-h-[580px] font-mono text-xs">
            {reportFormat === 'MARKDOWN' ? (
              <pre className="whitespace-pre-wrap text-gray-200 leading-relaxed font-mono selection:bg-red-600 selection:text-black">
                {report.markdownContent}
              </pre>
            ) : (
              <pre className="whitespace-pre-wrap text-emerald-400 leading-relaxed font-mono">
                {JSON.stringify(report, null, 2)}
              </pre>
            )}
          </div>
        </div>
      ) : (
        <div className="p-12 text-center text-gray-500 font-mono">
          Select "Compile Case Report" or "Security Audit Brief" to produce a tactical report.
        </div>
      )}
    </div>
  );
};

export default ReportEnginePanel;
