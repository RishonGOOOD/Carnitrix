
import React, { useState, useEffect, useRef } from 'react';
import { AIModelSettings } from '../types';
import { Loader2, Bot, Save, Download, LogOut, Paintbrush, BrainCircuit, Upload, Trash2, Sliders, Wrench } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { useAppContext } from '../context';
import { themes } from '../theme';

const PersonalityPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile, isRecalibrating } = state;
    const { aiSettings } = activeProfile!;
    const [localSettings, setLocalSettings] = useState<AIModelSettings>(aiSettings);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => { setLocalSettings(aiSettings); }, [aiSettings]);

    const handleSaveSettings = () => {
        setIsSaving(true);
        playSound('process');
        setTimeout(() => {
            dispatch({ type: 'UPDATE_PROFILE', payload: { aiSettings: localSettings }});
            setIsSaving(false);
            playSound('access');
        }, 1000);
    };

    const handleRecalibrate = () => {
        dispatch({ type: 'SET_RECALIBRATING', payload: true });
        playSound('scan');
        setTimeout(() => dispatch({ type: 'SET_RECALIBRATING', payload: false }), 3000);
    };

    const inputClass = "w-full bg-black border border-gray-800 rounded p-2 text-xs focus:border-[var(--color-primary)] outline-none font-mono";
    const labelClass = "block text-[10px] text-gray-500 mb-1 font-black tracking-widest uppercase";

    return (
        <div className="w-full h-full flex flex-col gap-6 text-sm bg-transparent p-1">
            <div className="flex-1 overflow-y-auto pr-2 space-y-8 scrollbar-thin">
                <section>
                    <h3 className="text-xs font-black text-[var(--color-primary)] flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
                        <Sliders size={16} /> BEHAVIOR MATRIX
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className={labelClass}>Personality Engine</label>
                            <select 
                                value={localSettings.personality} 
                                onChange={e => setLocalSettings(p => ({...p, personality: e.target.value as any}))} 
                                className={inputClass}
                            >
                                <option>Neutral</option>
                                <option>Friendly</option>
                                <option>Dark Sci-Fi</option>
                                <option>Hyper-Professional</option>
                            </select>
                        </div>
                        <div>
                            <label className={labelClass}>Vocal Speed: {localSettings.speechSpeed}x</label>
                            <input 
                                type="range" 
                                min="0.5" max="1.5" step="0.1" 
                                value={localSettings.speechSpeed} 
                                onChange={e => setLocalSettings(p => ({...p, speechSpeed: parseFloat(e.target.value)}))} 
                                className="w-full accent-[var(--color-primary)]" 
                            />
                        </div>
                    </div>
                </section>

                <section>
                    <h3 className="text-xs font-black text-blue-400 flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
                        <BrainCircuit size={16} /> AI NEURAL CORE
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className={labelClass}>Active Model</label>
                            <select 
                                value={localSettings.model} 
                                onChange={e => setLocalSettings(p => ({...p, model: e.target.value}))} 
                                className={inputClass}
                            >
                                <option value="gemini-3-pro-preview">Gemini 3 Pro (Tactical)</option>
                                <option value="gemini-3-flash-preview">Gemini 3 Flash (Fast)</option>
                            </select>
                        </div>
                        <div className="flex items-end">
                            <button 
                                onClick={() => setLocalSettings(p => ({...p, useThinking: !p.useThinking}))}
                                className={`w-full p-2 border text-[10px] font-black rounded transition-all ${localSettings.useThinking ? 'border-green-500 text-green-500 bg-green-500/10' : 'border-gray-800 text-gray-500'}`}
                            >
                                {localSettings.useThinking ? 'DEEP THINKING: ENABLED' : 'DEEP THINKING: DISABLED'}
                            </button>
                        </div>
                    </div>
                </section>

                <section className="pt-4 space-y-4">
                     <button onClick={handleRecalibrate} className="w-full hud-button !py-4 flex items-center justify-center gap-2 bg-blue-900/20 !border-blue-500 !text-blue-400">
                        <Wrench size={18} /> RECALIBRATE SYSTEM INTERFACE
                    </button>
                    <button onClick={handleSaveSettings} disabled={isSaving} className="w-full hud-button !py-4 flex items-center justify-center gap-2">
                        {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
                        APPLY NEURAL CONFIGURATION
                    </button>
                </section>
            </div>
        </div>
    );
};

export default PersonalityPanel;
