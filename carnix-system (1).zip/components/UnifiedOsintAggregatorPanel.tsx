import React, { useState } from 'react';
import { 
  Search, Globe, Github, Database, Share2, Shield, Filter, ExternalLink, 
  Terminal, CheckCircle2, AlertCircle, Fingerprint, Layers, Download, RefreshCw 
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

interface FeedItem {
  id: string;
  source: 'GitHub' | 'Social Media' | 'DNS Registry' | 'Public Records' | 'Threat Feed';
  title: string;
  target: string;
  summary: string;
  confidence: number;
  timestamp: string;
  url?: string;
  metadata?: Record<string, any>;
}

export const UnifiedOsintAggregatorPanel: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('carnix-target-node');
  const [isSearching, setIsSearching] = useState(false);
  const [activeFilter, setActiveFilter] = useState<string>('ALL');
  const [feedItems, setFeedItems] = useState<FeedItem[]>([
    {
      id: 'feed-1',
      source: 'GitHub',
      title: 'Public Repository Fork & Commit History',
      target: 'carnix-security/core-engine',
      summary: 'Discovered public repository containing active configuration templates and dependency references.',
      confidence: 0.98,
      timestamp: '2 mins ago',
      url: 'https://github.com/carnix-security/core-engine',
      metadata: { stars: 124, language: 'TypeScript', license: 'MIT' }
    },
    {
      id: 'feed-2',
      source: 'DNS Registry',
      title: 'RDAP Domain & Nameserver Resolution',
      target: 'target-domain.security.net',
      summary: 'Domain registered via Cloudflare Registrar. DNSSEC enabled with Cloudflare nameservers.',
      confidence: 0.99,
      timestamp: '5 mins ago',
      metadata: { registrar: 'Cloudflare Inc.', dnssec: true, ip: '104.21.92.14' }
    },
    {
      id: 'feed-3',
      source: 'Social Media',
      title: 'Developer Handle & Mention Extraction',
      target: '@carnix_sec (X / Twitter)',
      summary: 'Recent public posts reference deployment configuration strings and release tags.',
      confidence: 0.89,
      timestamp: '12 mins ago',
      url: 'https://x.com/carnix_sec',
      metadata: { followers: 4520, verified: true }
    },
    {
      id: 'feed-4',
      source: 'Public Records',
      title: 'SSL/TLS Certificate Transparency Log',
      target: '*.security.net (SANs: 14 domains)',
      summary: 'New SAN entry logged in Let\'s Encrypt transparency logs 4 hours ago.',
      confidence: 0.95,
      timestamp: '4 hours ago',
      metadata: { issuer: 'Let\'s Encrypt Authority X3', validUntil: '2026-12-31' }
    }
  ]);

  const handleUnifiedSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    playSound('click');
    triggerHaptic('medium');

    setTimeout(() => {
      const newItems: FeedItem[] = [
        {
          id: `feed-${Date.now()}-1`,
          source: 'GitHub',
          title: `Repository Code Search: "${searchQuery}"`,
          target: `github.com/search?q=${searchQuery}`,
          summary: `Identified 3 public code snippets and configuration references matching target "${searchQuery}".`,
          confidence: 0.94,
          timestamp: 'Just now',
          url: `https://github.com/search?q=${searchQuery}`
        },
        {
          id: `feed-${Date.now()}-2`,
          source: 'DNS Registry',
          title: `A / AAAA / MX Record Lookup`,
          target: `${searchQuery}.net`,
          summary: `Resolved DNS zone records and authoritative nameservers for target domain query.`,
          confidence: 0.97,
          timestamp: 'Just now',
          metadata: { recordType: 'A', ttl: 300, ipRange: '192.0.2.14' }
        },
        {
          id: `feed-${Date.now()}-3`,
          source: 'Social Media',
          title: `Cross-Platform Handle Search`,
          target: `@${searchQuery}`,
          summary: `Scanned 48 public social platforms and developer forums for matching handle username.`,
          confidence: 0.91,
          timestamp: 'Just now',
          metadata: { matchesFound: 4 }
        }
      ];
      setFeedItems(prev => [...newItems, ...prev]);
      setIsSearching(false);
    }, 900);
  };

  const filteredFeed = activeFilter === 'ALL' 
    ? feedItems 
    : feedItems.filter(item => item.source.toLowerCase() === activeFilter.toLowerCase());

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050102] text-white font-[Rajdhani] p-2 sm:p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-red-900/40">
        <div>
          <div className="flex items-center gap-2">
            <Fingerprint className="text-red-500 animate-pulse" size={24} />
            <h1 className="text-xl font-black tracking-wider text-red-500 uppercase">UNIFIED OSINT AGGREGATOR</h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-0.5">
            Cross-platform investigation feed unifying public social media, GitHub repositories, and DNS registry lookups.
          </p>
        </div>

        <form onSubmit={handleUnifiedSearch} className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-72">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Enter target (domain, username, keyword)..."
              className="w-full bg-black/80 border border-red-900/50 rounded-lg pl-9 pr-3 py-1.5 text-xs font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
            />
          </div>
          <button
            type="submit"
            disabled={isSearching}
            className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-bold rounded-lg text-xs font-mono flex items-center gap-1.5 shadow-[0_0_15px_rgba(255,0,0,0.4)] transition-all shrink-0 disabled:opacity-50"
          >
            {isSearching ? <RefreshCw size={14} className="animate-spin" /> : <Search size={14} />}
            {isSearching ? 'AGGREGATING...' : 'SCAN'}
          </button>
        </form>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-white/5 my-3">
        {['ALL', 'GitHub', 'Social Media', 'DNS Registry', 'Public Records', 'Threat Feed'].map(cat => (
          <button
            key={cat}
            onClick={() => {
              setActiveFilter(cat);
              playSound('click');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
              activeFilter === cat 
                ? 'bg-red-600 text-black font-bold shadow-[0_0_10px_rgba(255,0,0,0.4)]' 
                : 'bg-black/60 text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Unified Investigation Feed List */}
      <div className="flex-1 space-y-3 mt-1">
        {filteredFeed.map(item => (
          <div key={item.id} className="bg-black/70 border border-red-950/80 rounded-xl p-4 hover:border-red-500/50 transition-all shadow-lg">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-2 border-b border-white/5">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold border ${
                  item.source === 'GitHub' ? 'bg-purple-950/60 text-purple-400 border-purple-900/50' :
                  item.source === 'DNS Registry' ? 'bg-cyan-950/60 text-cyan-400 border-cyan-900/50' :
                  item.source === 'Social Media' ? 'bg-pink-950/60 text-pink-400 border-pink-900/50' :
                  'bg-emerald-950/60 text-emerald-400 border-emerald-900/50'
                }`}>
                  {item.source}
                </span>
                <span className="text-xs font-mono text-gray-400">Target: <strong className="text-white">{item.target}</strong></span>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-[10px] font-mono bg-red-950/40 border border-red-900/40 px-2 py-0.5 rounded text-red-400">
                  Confidence: {Math.round(item.confidence * 100)}%
                </span>
                <span className="text-[10px] font-mono text-gray-500">{item.timestamp}</span>
              </div>
            </div>

            <div className="py-2.5">
              <h3 className="text-sm font-bold text-white tracking-wide">{item.title}</h3>
              <p className="text-xs text-gray-300 font-mono mt-1">{item.summary}</p>

              {item.metadata && (
                <div className="flex flex-wrap gap-2 mt-3 pt-2 border-t border-white/5">
                  {Object.entries(item.metadata).map(([k, v]) => (
                    <span key={k} className="text-[10px] font-mono bg-black/80 px-2 py-0.5 rounded text-gray-400 border border-white/5">
                      {k}: <span className="text-red-400 font-bold">{String(v)}</span>
                    </span>
                  ))}
                </div>
              )}
            </div>

            {item.url && (
              <div className="flex justify-end pt-2">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-mono text-red-400 hover:text-red-300 flex items-center gap-1 transition-all"
                >
                  <ExternalLink size={12} />
                  <span>Open External Link</span>
                </a>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default UnifiedOsintAggregatorPanel;
