
import React, { useState } from 'react';
import { Search, Loader2, Zap, Wifi } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const MCU_I2CScannerPanel: React.FC = () => {
    const [scanning, setScanning] = useState(false);
    const [results, setResults] = useState<number[]>([]);

    const runScan = () => {
        setScanning(true);
        setResults([]);
        playSound('scan');
        
        setTimeout(() => {
            // Simulated found addresses
            setResults([0x27, 0x3C, 0x68]);
            setScanning(false);
            playSound('success');
        }, 2000);
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/40 border border-white/10 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Wifi size={24} className="text-cyan-400" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic">I2C Protocol Scanner</h2>
                        <p className="text-[9px] font-mono text-gray-500">Bus Frequency: 400kHz // Scan Range: 0x00 - 0x7F</p>
                    </div>
                </div>
                <button onClick={runScan} disabled={scanning} className="px-6 py-2 bg-cyan-600 text-black font-black text-xs uppercase rounded flex items-center gap-2">
                    {scanning ? <Loader2 size={14} className="animate-spin" /> : <Search size={14} />}
                    {scanning ? 'Searching...' : 'Initiate Scan'}
                </button>
            </div>

            <div className="flex-1 bg-black/40 border border-white/5 rounded p-4 grid grid-cols-8 md:grid-cols-16 gap-1 relative">
                {Array.from({ length: 128 }).map((_, i) => {
                    const found = results.includes(i);
                    return (
                        <div key={i} className={`aspect-square border border-white/5 flex flex-col items-center justify-center transition-all ${found ? 'bg-cyan-500 text-black shadow-[0_0_15px_cyan] scale-110 z-10' : 'bg-black/50 text-gray-700'}`}>
                            <span className="text-[7px] font-black">{i.toString(16).toUpperCase()}</span>
                            {found && <Zap size={8} />}
                        </div>
                    );
                })}
                
                {scanning && (
                    <div className="absolute inset-0 bg-cyan-500/5 backdrop-blur-sm flex items-center justify-center">
                        <div className="text-cyan-400 font-mono text-xs animate-pulse tracking-widest">PROBING BUS NODES...</div>
                    </div>
                )}
            </div>

            <div className="p-4 bg-black/60 border border-white/5 rounded">
                <h3 className="text-[10px] font-bold text-gray-500 uppercase mb-2">Detected Hardware</h3>
                <div className="flex gap-4">
                    {results.length > 0 ? results.map(res => (
                        <div key={res} className="text-xs bg-white/5 p-2 rounded border border-white/10 flex items-center gap-2">
                            <span className="font-mono text-cyan-400">0x{res.toString(16).toUpperCase()}</span>
                            <span className="text-white font-bold uppercase tracking-tighter">
                                {res === 0x27 ? 'LCD_MODULE' : res === 0x3C ? 'OLED_DISPLAY' : 'MPU6050_IMU'}
                            </span>
                        </div>
                    )) : <span className="text-xs text-gray-700 italic">No nodes detected.</span>}
                </div>
            </div>
        </div>
    );
};

export default MCU_I2CScannerPanel;
