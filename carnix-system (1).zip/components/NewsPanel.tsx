
import React, { useState, useEffect } from 'react';
import { AIModelSettings, Address } from '../types';
import { getLiveNews } from '../services/geminiService';
import { Newspaper, RefreshCw, ExternalLink, Globe, ShieldAlert, Languages } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { ListSkeleton, TechSkeleton } from './Loading';

interface NewsPanelProps {
    aiSettings: AIModelSettings;
    address?: Address;
}

const NewsPanel: React.FC<NewsPanelProps> = ({ aiSettings, address }) => {
    const [newsContent, setNewsContent] = useState<string | null>(null);
    const [newsUrls, setNewsUrls] = useState<{uri: string, title?: string}[] | undefined>(undefined);
    const [loading, setLoading] = useState(false);
    const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
    const [language, setLanguage] = useState('English'); 

    const fetchNews = async () => {
        setLoading(true);
        playSound('click');
        triggerHaptic('light');
        
        try {
            const response = await getLiveNews(aiSettings, address, language);
            setNewsContent(response.text);
            setNewsUrls(response.urls);
            setLastUpdate(new Date());
            playSound('success');
        } catch (e) {
            setNewsContent("Secure Feed Offline. Unable to retrieve global intelligence.");
            playSound('error');
            triggerHaptic('error');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchNews();
    }, [language]); 
    
    useEffect(() => {
        if (!newsContent) fetchNews();
    }, [address?.city]);

    return (
        <div className="w-full h-full flex flex-col gap-4 relative p-1">
            {/* Header */}
            <div className="flex justify-between items-center bg-black/40 border border-[var(--color-panel-border)] rounded-lg p-3">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-[var(--color-primary)]/20 rounded-full">
                         <Newspaper size={20} className="text-[var(--color-primary)]" />
                    </div>
                    <div>
                        <h2 className="text-sm font-black tracking-wider text-white">GLOBAL INTEL FEED</h2>
                        <div className="text-[10px] font-mono text-[var(--color-text-muted)] flex items-center gap-1">
                            SOURCE: OPEN WEB // LANGUAGE: <span className="text-[var(--color-primary)]">{language.toUpperCase()}</span>
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                     <select value={language} onChange={e => setLanguage(e.target.value)} className="bg-black border border-gray-700 rounded px-2 py-1 text-xs outline-none text-white focus:border-[var(--color-primary)]">
                        <option value="English">English</option>
                        <option value="Tamil">Tamil</option>
                        <option value="Hindi">Hindi</option>
                        <option value="Global">Global</option>
                     </select>
                    <button 
                        onClick={fetchNews} 
                        disabled={loading}
                        className="p-2 bg-[var(--color-button-background)] border border-[var(--color-button-border)] rounded hover:bg-[var(--color-button-hover)] disabled:opacity-50 transition-all"
                    >
                        <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="flex-1 flex flex-col md:flex-row gap-4 overflow-hidden">
                {/* Main Feed */}
                <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-lg p-4 overflow-y-auto relative">
                    {loading ? (
                        <div className="space-y-4">
                            <TechSkeleton className="w-1/2 h-6 mb-4" />
                            <ListSkeleton count={4} />
                            <TechSkeleton className="w-3/4 h-32" />
                        </div>
                    ) : (
                        <div className="prose prose-invert prose-sm max-w-none">
                             {newsContent ? (
                                 <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-gray-300">
                                     {newsContent}
                                 </div>
                             ) : (
                                 <div className="text-center text-gray-500 italic mt-10">Feed Empty. Initialize Scan.</div>
                             )}
                        </div>
                    )}
                </div>

                {/* Sidebar / Sources */}
                <div className="h-1/3 md:h-auto md:w-64 bg-black/30 border border-[var(--color-panel-border)] rounded-lg flex flex-col overflow-hidden">
                    <div className="p-2 border-b border-[var(--color-panel-border)] text-xs font-bold text-[var(--color-text-muted)] flex items-center gap-2">
                        <ShieldAlert size={14} /> CITATIONS & SOURCES
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 space-y-2">
                        {loading ? (
                            <ListSkeleton count={5} />
                        ) : newsUrls && newsUrls.length > 0 ? (
                            newsUrls.map((url, idx) => (
                                <a 
                                    key={idx} 
                                    href={url.uri} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="block p-2 bg-white/5 border border-white/10 rounded hover:bg-white/10 hover:border-[var(--color-primary)] transition-colors group"
                                >
                                    <div className="text-[10px] font-bold text-[var(--color-primary)] truncate mb-1 flex items-center gap-1">
                                        <ExternalLink size={10} /> {url.title || "Source Link"}
                                    </div>
                                    <div className="text-[9px] text-gray-500 truncate font-mono">{new URL(url.uri).hostname}</div>
                                </a>
                            ))
                        ) : (
                            <div className="text-[10px] text-gray-500 p-2 italic">No source metadata available.</div>
                        )}
                    </div>
                    <div className="p-2 border-t border-[var(--color-panel-border)] bg-black/40">
                         <div className="text-[10px] font-bold text-gray-500 mb-1 flex items-center gap-1"><Languages size={10}/> LANGUAGE LOCK</div>
                         <div className="text-xs truncate text-[var(--color-primary)]">{language}</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default NewsPanel;
