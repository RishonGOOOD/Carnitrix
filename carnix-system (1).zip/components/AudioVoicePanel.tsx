import React, { useState } from 'react';
import { Profile, Message } from '../types'; 
import { DynamicLiveAudioCallbacks } from '../services/geminiService';
import VoiceChatPanel from './VoiceChatPanel';
import AudioTranscriptionPanel from './AudioTranscriptionPanel';
import { MessageSquare, FileText } from 'lucide-react';

// Props are a union of what both child panels need
interface AudioVoicePanelProps {
    addMessage: (sender: 'user' | 'carnix' | 'system', text: string) => void;
    startSession: (isVoiceChat: boolean) => void;
    stopSession: () => void;
    isSessionActive: boolean;
    currentProfile: Profile;
    outputAudioContext: AudioContext | null;
    outputAudioSources: React.MutableRefObject<Set<AudioBufferSourceNode>>;
    nextStartTimeRef: React.MutableRefObject<number>;
    registerCallbacks: (callbacks: DynamicLiveAudioCallbacks) => void;
}

type ActiveTab = 'VOICE_CHAT' | 'TRANSCRIPTION';

const AudioVoicePanel: React.FC<AudioVoicePanelProps> = (props) => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('VOICE_CHAT');

    return (
        <div className="w-full h-full flex flex-col text-sm bg-transparent gap-2">
            <div className="flex items-center gap-2 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-1">
                <button 
                    onClick={() => setActiveTab('VOICE_CHAT')} 
                    className={`flex-1 p-2 rounded flex items-center justify-center gap-2 text-xs font-bold transition-colors ${activeTab === 'VOICE_CHAT' ? 'bg-[var(--color-primary)] text-black' : 'bg-black/50 hover:bg-white/10'}`}
                >
                    <MessageSquare size={14}/> VOICE CHAT
                </button>
                <button 
                    onClick={() => setActiveTab('TRANSCRIPTION')} 
                    className={`flex-1 p-2 rounded flex items-center justify-center gap-2 text-xs font-bold transition-colors ${activeTab === 'TRANSCRIPTION' ? 'bg-[var(--color-primary)] text-black' : 'bg-black/50 hover:bg-white/10'}`}
                >
                    <FileText size={14}/> TRANSCRIPTION
                </button>
            </div>
            <div className="flex-1 overflow-hidden">
                {activeTab === 'VOICE_CHAT' && <VoiceChatPanel {...props} />}
                {activeTab === 'TRANSCRIPTION' && <AudioTranscriptionPanel {...props} />}
            </div>
        </div>
    );
};

export default AudioVoicePanel;