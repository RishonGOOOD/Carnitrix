import React from 'react';
import { Satellite, WifiOff, LocateFixed } from 'lucide-react';
import { useAppContext } from '../context';

const SatellitePanel: React.FC = () => {
    const { state } = useAppContext();
    const { geolocation, isOnline } = state;

    const mapUrl = geolocation 
        ? `https://www.openstreetmap.org/export/embed.html?bbox=${geolocation.longitude - 0.005},${geolocation.latitude - 0.005},${geolocation.longitude + 0.005},${geolocation.latitude + 0.005}&layer=satellite&marker=${geolocation.latitude},${geolocation.longitude}`
        : "";

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    <Satellite size={16}/> SATELLITE IMAGERY
                </h2>
                <div className="text-xs font-mono text-gray-400 flex items-center gap-2">
                    <LocateFixed size={12} className={geolocation ? "text-green-500" : "text-red-500 animate-pulse"} />
                    <span>{geolocation ? "LIVE FEED" : "NO SIGNAL"}</span>
                </div>
            </div>
            <div className="flex-1 bg-black border border-[var(--color-panel-border)] rounded-md overflow-hidden relative">
                 {isOnline && mapUrl ? (
                    <iframe 
                        key={mapUrl} 
                        width="100%" 
                        height="100%" 
                        frameBorder="0" 
                        scrolling="no" 
                        title="Satellite Map" 
                        src={mapUrl}
                        className="filter contrast-125"
                    ></iframe>
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-[var(--color-primary)] bg-black">
                        {isOnline ? (
                            <span>Awaiting GPS lock...</span>
                        ) : (
                            <div className="flex items-center gap-2">
                                <WifiOff /> SATELLITE UPLINK OFFLINE
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default SatellitePanel;