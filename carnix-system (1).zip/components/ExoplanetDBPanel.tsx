
import React, { useState, useEffect } from 'react';
import { Telescope, Loader2 } from 'lucide-react';

interface Exoplanet {
    pl_name: string;
    hostname: string;
    discoverymethod: string;
    disc_year: number;
    sy_dist: number | null; // distance in parsecs
}

const mockPlanets: Exoplanet[] = [
    { pl_name: 'Proxima Centauri b', hostname: 'Proxima Centauri', discoverymethod: 'Radial Velocity', disc_year: 2016, sy_dist: 1.3 },
    { pl_name: 'TRAPPIST-1 e', hostname: 'TRAPPIST-1', discoverymethod: 'Transit', disc_year: 2017, sy_dist: 12.1 },
    { pl_name: 'Kepler-186 f', hostname: 'Kepler-186', discoverymethod: 'Transit', disc_year: 2014, sy_dist: 178.5 },
    { pl_name: 'LHS 1140 b', hostname: 'LHS 1140', discoverymethod: 'Transit', disc_year: 2017, sy_dist: 12.5 },
    { pl_name: 'K2-18 b', hostname: 'K2-18', discoverymethod: 'Transit', disc_year: 2015, sy_dist: 34.0 },
    { pl_name: 'Kepler-452 b', hostname: 'Kepler-452', discoverymethod: 'Transit', disc_year: 2015, sy_dist: 430.0 },
    { pl_name: 'Ross 128 b', hostname: 'Ross 128', discoverymethod: 'Radial Velocity', disc_year: 2017, sy_dist: 3.37 },
    { pl_name: 'Teegarden b', hostname: 'Teegarden\'s Star', discoverymethod: 'Radial Velocity', disc_year: 2019, sy_dist: 3.8 },
    { pl_name: 'Gliese 667 Cc', hostname: 'Gliese 667 C', discoverymethod: 'Radial Velocity', disc_year: 2011, sy_dist: 7.2 },
    { pl_name: 'Kepler-22 b', hostname: 'Kepler-22', discoverymethod: 'Transit', disc_year: 2011, sy_dist: 190.0 },
];

const ExoplanetDBPanel: React.FC = () => {
    const [planets, setPlanets] = useState<Exoplanet[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [usingOfflineData, setUsingOfflineData] = useState(false);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            // Using a CORS proxy to access the NASA API
            const res = await fetch(`https://cors-anywhere.herokuapp.com/https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=select+pl_name,hostname,discoverymethod,disc_year,sy_dist+from+pscomppars+order+by+disc_year+desc&format=json`);
            if (!res.ok) throw new Error("Failed to fetch exoplanet data.");
            const data = await res.json();
            setPlanets(data.slice(0, 50)); 
            setUsingOfflineData(false);
        } catch (e: any) {
            console.warn("Exoplanet API failed, switching to offline database.", e);
            setPlanets(mockPlanets);
            setUsingOfflineData(true);
        } finally {
            setIsLoading(false);
        }
    };
    
    const parsecsToLightYears = (pc: number | null) => pc ? (pc * 3.262).toFixed(2) : 'N/A';

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
             <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <h2 className="text-sm font-bold text-white flex items-center gap-2"><Telescope size={16}/> EXOPLANET DATABASE</h2>
                    {usingOfflineData && <span className="text-[10px] bg-yellow-900/50 text-yellow-500 px-2 rounded border border-yellow-700">OFFLINE MODE</span>}
                 </div>
                 {isLoading && <Loader2 size={16} className="animate-spin text-[var(--color-primary)]" />}
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden">
                 <div className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400 grid grid-cols-4 gap-2">
                    <span>PLANET NAME</span>
                    <span>DISCOVERY METHOD</span>
                    <span>YEAR</span>
                    <span className="text-right">DISTANCE (ly)</span>
                </div>
                <div className="flex-1 overflow-y-auto scrollbar-thin">
                    {planets.map((planet, i) => (
                        <div key={`${planet.pl_name}-${i}`} className="grid grid-cols-4 gap-2 p-3 border-b border-gray-800/50 items-center font-mono text-sm hover:bg-white/5">
                            <span className="text-white font-bold truncate">{planet.pl_name}</span>
                            <span className="text-gray-400 text-xs truncate">{planet.discoverymethod}</span>
                            <span className="text-blue-400">{planet.disc_year}</span>
                            <span className="text-right text-green-400">{parsecsToLightYears(planet.sy_dist)}</span>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ExoplanetDBPanel;
