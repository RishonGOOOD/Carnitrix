import React from 'react';

const NanotechOrbs: React.FC = () => {
    return (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-40">
            {/* Top Right Lightning Orb */}
            <div className="absolute -top-32 -right-32 w-[400px] h-[400px] animate-orb will-change-transform">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                    <defs>
                        <radialGradient id="orbGrad" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stopColor="#ff0000" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
                        </radialGradient>
                    </defs>
                    <circle cx="50" cy="50" r="45" fill="url(#orbGrad)" />
                    {/* Simplified Rings */}
                    <circle cx="50" cy="50" r="35" fill="none" stroke="#ff0000" strokeWidth="0.2" strokeDasharray="10 10">
                        <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="25s" repeatCount="indefinite" />
                    </circle>
                    {/* Simple Static Glow Core */}
                    <circle cx="50" cy="50" r="5" fill="#ff0000" className="animate-pulse" />
                </svg>
            </div>

            {/* Bottom Left Nanotech Sphere */}
            <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] animate-orb-reverse will-change-transform">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                    <circle cx="50" cy="50" r="48" fill="none" stroke="#ff0000" strokeWidth="0.05" />
                    <g transform="rotate(45 50 50)">
                        <rect x="25" y="25" width="50" height="50" fill="none" stroke="#ff0000" strokeWidth="0.1">
                            <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="-360 50 50" dur="60s" repeatCount="indefinite" />
                        </rect>
                    </g>
                </svg>
            </div>
            
            <style>{`
                @keyframes orb-float {
                    0%, 100% { transform: translate3d(0, 0, 0); }
                    50% { transform: translate3d(20px, -10px, 0); }
                }
                @keyframes orb-float-rev {
                    0%, 100% { transform: translate3d(0, 0, 0); }
                    50% { transform: translate3d(-20px, 10px, 0); }
                }
                .animate-orb { animation: orb-float 20s ease-in-out infinite; }
                .animate-orb-reverse { animation: orb-float-rev 25s ease-in-out infinite; }
                .will-change-transform { will-change: transform; }
            `}</style>
        </div>
    );
};

export default NanotechOrbs;