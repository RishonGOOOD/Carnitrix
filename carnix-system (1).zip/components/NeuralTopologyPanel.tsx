
import React, { useEffect, useRef, useMemo } from 'react';
import { Brain, Share2, Activity } from 'lucide-react';
import { useAppContext } from '../context';

const NeuralTopologyPanel: React.FC = () => {
    const { state } = useAppContext();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const { activeProfile } = state;

    const clusters = useMemo(() => {
        if (!activeProfile) return [];
        const metrics = activeProfile.usageMetrics || {};
        return [
            { id: 'CORE', label: 'Processing Core', val: metrics['Holographic Dashboard'] || 1, color: '#ff003c' },
            { id: 'INTEL', label: 'Intelligence Cluster', val: metrics['Global Intel'] || metrics['Deep Query'] || 1, color: '#00f0ff' },
            { id: 'TACTICAL', label: 'Tactical Array', val: metrics['Tactical Grid'] || metrics['Physical Link'] || 1, color: '#facc15' },
            { id: 'SOCIAL', label: 'Comm Relay', val: metrics['Neural Uplink'] || 1, color: '#a855f7' },
            { id: 'DATA', label: 'Memory Banks', val: metrics['Data Vault'] || 1, color: '#22c55e' }
        ];
    }, [activeProfile]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        let time = 0;

        const nodes = clusters.map((c, i) => ({
            ...c,
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            vx: (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 2,
            baseRadius: 15 + Math.min(c.val * 2, 40)
        }));

        const resize = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        window.addEventListener('resize', resize);
        resize();

        const animate = () => {
            ctx.fillStyle = 'rgba(5, 0, 2, 0.2)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Connect nodes
            ctx.lineWidth = 1;
            for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                    const dx = nodes[i].x - nodes[j].x;
                    const dy = nodes[i].y - nodes[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    const opacity = Math.max(0, 1 - dist / 300);
                    ctx.strokeStyle = `rgba(255, 255, 255, ${opacity * 0.1})`;
                    ctx.beginPath();
                    ctx.moveTo(nodes[i].x, nodes[i].y);
                    ctx.lineTo(nodes[j].x, nodes[j].y);
                    ctx.stroke();
                }
            }

            // Update & Draw nodes
            nodes.forEach(node => {
                // Gentle float toward center
                node.vx += (canvas.width / 2 - node.x) * 0.0001;
                node.vy += (canvas.height / 2 - node.y) * 0.0001;
                
                node.x += node.vx;
                node.y += node.vy;

                // Pulsing radius
                const r = node.baseRadius + Math.sin(time + node.val) * 3;
                
                // Glow
                ctx.shadowBlur = 20;
                ctx.shadowColor = node.color;
                ctx.fillStyle = node.color;
                ctx.beginPath();
                ctx.arc(node.x, node.y, r, 0, Math.PI * 2);
                ctx.fill();
                ctx.shadowBlur = 0;

                // Label
                ctx.fillStyle = 'white';
                ctx.font = 'bold 10px Rajdhani';
                ctx.textAlign = 'center';
                ctx.fillText(node.label.toUpperCase(), node.x, node.y + r + 15);
                ctx.font = '8px Share Tech Mono';
                ctx.fillStyle = 'rgba(255,255,255,0.5)';
                ctx.fillText(`SYNC: ${Math.round(node.val * 10)}%`, node.x, node.y + r + 25);
            });

            time += 0.05;
            animationFrameId = requestAnimationFrame(animate);
        };
        animate();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resize);
        };
    }, [clusters]);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/40 border border-white/10 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Brain size={24} className="text-[var(--color-primary)] animate-pulse" />
                    <div>
                        <h2 className="text-lg font-black tracking-widest text-white uppercase italic">Neural Topology</h2>
                        <p className="text-[9px] font-mono text-gray-500 uppercase tracking-tighter">Cluster Mapping Protocol // User Habit Analysis</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="text-right">
                        <div className="text-[8px] text-gray-500 uppercase font-black">Synaptic Integrity</div>
                        <div className="text-sm font-bold text-green-500">98.2%</div>
                    </div>
                    <div className="p-2 bg-white/5 rounded border border-white/10">
                        <Share2 size={16} className="text-gray-400" />
                    </div>
                </div>
            </div>

            <div className="flex-1 bg-black/20 border border-white/5 rounded-lg relative overflow-hidden">
                <canvas ref={canvasRef} className="w-full h-full" />
                
                {/* Floating Stats */}
                <div className="absolute top-4 left-4 p-4 bg-black/60 border border-white/10 backdrop-blur-md rounded-md pointer-events-none">
                    <h3 className="text-[10px] font-black text-white uppercase tracking-widest mb-3 border-b border-white/5 pb-1">Activity Vitals</h3>
                    <div className="space-y-2">
                        <div className="flex justify-between items-center gap-8">
                            <span className="text-[9px] text-gray-500">Uplink Density</span>
                            <span className="text-xs font-bold text-cyan-400">High</span>
                        </div>
                        <div className="flex justify-between items-center gap-8">
                            <span className="text-[9px] text-gray-500">Path Stability</span>
                            <span className="text-xs font-bold text-green-500">Optimal</span>
                        </div>
                        <div className="flex justify-between items-center gap-8">
                            <span className="text-[9px] text-gray-500">Neural Decay</span>
                            <span className="text-xs font-bold text-red-500">None</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default NeuralTopologyPanel;
