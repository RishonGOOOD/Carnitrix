
import React, { useState } from 'react';
import { HeartPulse, CheckCircle2, AlertTriangle, XCircle, Loader2, Play } from 'lucide-react';
import { useAppContext } from '../context';
import { DiagnosticResult } from '../types';
import { playSound } from '../utils/soundEffects';

const DiagnosticsPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile, isOnline, geolocation } = state;
    const [results, setResults] = useState<DiagnosticResult[]>([]);
    const [isScanning, setIsScanning] = useState(false);

    const runDiagnostics = async () => {
        setIsScanning(true);
        setResults([]);
        playSound('process');
        
        const checks: (() => Promise<DiagnosticResult>)[] = [
            async () => ({
                id: 'online', category: 'NETWORK', status: isOnline ? 'OK' : 'CRITICAL',
                message: isOnline ? 'Internet connection is active.' : 'No internet connection.',
            }),
            // Comment: Strictly checking for process.env.API_KEY as per GenAI guidelines
            async () => ({
                id: 'apikey', category: 'AI', status: process.env.API_KEY ? 'OK' : 'CRITICAL',
                message: process.env.API_KEY ? 'Gemini API Key is configured.' : 'Gemini API Key is missing from system environment.',
            }),
            async () => {
                try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    stream.getTracks().forEach(t => t.stop());
                    return { id: 'mic', category: 'HARDWARE', status: 'OK', message: 'Microphone access is granted.' };
                } catch (e) {
                    return { id: 'mic', category: 'HARDWARE', status: 'CRITICAL', message: 'Microphone access denied.' };
                }
            },
            async () => ({
                id: 'geo', category: 'HARDWARE', status: geolocation ? 'OK' : 'WARNING',
                message: geolocation ? 'Geolocation is active.' : 'Geolocation is not available.',
            }),
            async () => ({
                id: 'serial', category: 'HARDWARE', status: 'serial' in navigator ? 'OK' : 'WARNING',
                message: 'serial' in navigator ? 'Web Serial API is supported.' : 'Web Serial API not supported.',
            }),
        ];

        for (const check of checks) {
            const result = await check();
            setResults(prev => [...prev, result]);
            await new Promise(r => setTimeout(r, 300));
        }

        setIsScanning(false);
        playSound('success');
    };

    const getIcon = (status: DiagnosticResult['status']) => {
        switch(status) {
            case 'OK': return <CheckCircle2 className="text-green-500" />;
            case 'WARNING': return <AlertTriangle className="text-yellow-500" />;
            case 'CRITICAL': return <XCircle className="text-red-500" />;
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><HeartPulse size={16}/> SYSTEM DIAGNOSTICS</h2>
                <button onClick={runDiagnostics} disabled={isScanning} className="px-4 py-2 bg-[var(--color-button-background)] hover:bg-[var(--color-button-hover)] border border-[var(--color-button-border)] rounded text-sm flex items-center justify-center gap-2 disabled:opacity-50">
                    {isScanning ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
                    {isScanning ? 'SCANNING...' : 'RUN DIAGNOSTICS'}
                </button>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md overflow-y-auto">
                {results.length === 0 && !isScanning && (
                    <div className="flex items-center justify-center h-full text-gray-500">
                        <p>Ready to run system diagnostics.</p>
                    </div>
                )}
                <div className="p-2 space-y-2">
                    {results.map(res => (
                        <div key={res.id} className="p-3 bg-black/40 border border-gray-800 rounded flex items-center gap-3 animate-enter">
                            {getIcon(res.status)}
                            <span className="font-mono text-xs font-bold w-24">{res.category}</span>
                            <span className="text-sm text-gray-300">{res.message}</span>
                        </div>
                    ))}
                    {isScanning && (
                         <div className="p-3 flex items-center gap-3 text-gray-400 animate-pulse">
                            <Loader2 className="animate-spin"/>
                            <span className="text-sm">Running checks...</span>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DiagnosticsPanel;
