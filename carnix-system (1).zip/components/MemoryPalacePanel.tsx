


import React, { useState, useMemo } from 'react';
import { Brain, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { useAppContext } from '../context';

const MemoryPalacePanel: React.FC = () => {
    const { state } = useAppContext();
    const notes = state.activeProfile?.notes || [];

    const [rotation, setRotation] = useState({ x: -20, y: 30 });
    const [zoom, setZoom] = useState(1);
    const [selectedNode, setSelectedNode] = useState<string | null>(null);

    const handleMouseMove = (e: React.MouseEvent) => {
        if (e.buttons === 1) { // Left mouse button down
            setRotation(prev => ({
                x: Math.max(-90, Math.min(90, prev.x - e.movementY * 0.5)),
                y: prev.y + e.movementX * 0.5,
            }));
        }
    };

    const nodePositions = useMemo(() => {
        return notes.map((_, i) => {
            const angle = (i / notes.length) * 2 * Math.PI;
            const radius = 150 + (i % 3) * 50;
            const y = (i - notes.length / 2) * 20;
            return {
                x: radius * Math.cos(angle),
                z: radius * Math.sin(angle),
                y: y,
            };
        });
    }, [notes.length]);

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Brain size={16}/> MEMORY PALACE</h2>
                <div className="flex items-center gap-2">
                    <button onClick={() => setZoom(z => Math.max(0.5, z - 0.1))} className="p-2 hover:bg-white/10 rounded"><ZoomOut size={16}/></button>
                    <button onClick={() => setZoom(z => Math.min(2, z + 0.1))} className="p-2 hover:bg-white/10 rounded"><ZoomIn size={16}/></button>
                    <button onClick={() => setRotation({ x: -20, y: 30 })} className="p-2 hover:bg-white/10 rounded"><RotateCcw size={16}/></button>
                </div>
            </div>

            <div className="flex-1 flex gap-4 overflow-hidden">
                <div onMouseMove={handleMouseMove} className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex items-center justify-center overflow-hidden perspective-1000 cursor-grab active:cursor-grabbing">
                     <div className="transform-style-3d transition-transform duration-200"
                          style={{ transform: `scale(${zoom}) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
                        {notes.map((note, i) => (
                             <div key={note.id}
                                  onClick={() => setSelectedNode(note.id)}
                                  className={`absolute p-2 rounded text-xs w-32 h-16 border transition-all duration-300 ${selectedNode === note.id ? 'bg-[var(--color-primary)] text-black border-white' : 'bg-black/50 border-[var(--color-primary)]/50'}`}
                                  style={{ transform: `translate3d(${nodePositions[i].x}px, ${nodePositions[i].y}px, ${nodePositions[i].z}px) rotateY(${-rotation.y}deg) rotateX(${-rotation.x}deg)` }}>
                                <p className="font-bold truncate">{note.title}</p>
                                <p className="text-gray-400 truncate">{note.content}</p>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="w-1/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col p-4">
                    <h3 className="text-sm font-bold border-b border-gray-700 pb-2 mb-2">SELECTED NODE</h3>
                    {selectedNode ? (
                        <div>
                            <h4 className="font-bold text-lg text-[var(--color-primary)]">{notes.find(n => n.id === selectedNode)?.title}</h4>
                            <p className="text-sm text-gray-300 mt-2 whitespace-pre-wrap">{notes.find(n => n.id === selectedNode)?.content}</p>
                        </div>
                    ) : (
                        <div className="text-center text-gray-500 mt-10">Select a node to view details.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MemoryPalacePanel;