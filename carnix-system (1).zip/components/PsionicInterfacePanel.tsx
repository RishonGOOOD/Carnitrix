import React, { useState, useEffect, useRef } from 'react';
import { BrainCircuit, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';

const PsionicInterfacePanel: React.FC = () => {
    const { state } = useAppContext();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [status, setStatus] = useState('IDLE'); // IDLE, FOCUSSING, DETECTED
    const [signal, setSignal] = useState<string | null>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        let time = 0;

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        const draw = () => {
            ctx.fillStyle = 'rgba(0, 5, 10, 0.1)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            ctx.lineWidth = 2;
            const amplitude = status === 'IDLE' ? 20 : 60;
            const frequency = status === 'IDLE' ? 0.02 : 0.05;

            // Multiple waves for complexity
            for(let i=1; i<=3; i++){
                ctx.strokeStyle = `rgba(0, 216, 255, ${0.8 / i})`;
                ctx.beginPath();
                ctx.moveTo(0, canvas.height / 2);
                for (let x = 0; x < canvas.width; x++) {
                    const y = canvas.height / 2 + Math.sin(x * frequency * i + time) * amplitude / i * (1 + Math.sin(time*i) * 0.2);
                    ctx.lineTo(x, y);
                }
                ctx.stroke();
            }

            time += 0.05;
            animationFrameId = requestAnimationFrame(draw);
        };
        draw();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, [status]);

    const handleFocus = async () => {
        if (status !== 'IDLE' || !state.activeProfile) return;
        setStatus('FOCUSSING');
        setSignal(null);
        try {
            const res = await getAIResponse(
                "Generate a short, cryptic psionic signal or thought fragment. Examples: 'The vessel is empty...', 'A memory of a field of glass flowers.', 'Fear of being watched.'",
                Mode.PsionicInterface,
                state.activeProfile.aiSettings
            );
            setSignal(res.text);
            setStatus('DETECTED');
        } catch (e) {
            setSignal('Failed to lock on signal.');
            setStatus('IDLE');
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <BrainCircuit size={14}/> PSIONIC INTERFACE
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col overflow-hidden">
                <div className="flex-1 relative bg-black">
                    <canvas ref={canvasRef} className="w-full h-full" />
                </div>
                <div className="p-4 border-t border-[var(--color-panel-header-border)] flex flex-col items-center">
                    <button onClick={handleFocus} disabled={status !== 'IDLE'} className="w-48 hud-button flex items-center justify-center gap-2 mb-4">
                        {status === 'FOCUSSING' ? <Loader2 size={16} className="animate-spin"/> : <BrainCircuit size={16}/>}
                        {status === 'FOCUSSING' ? 'FOCUSSING...' : 'FOCUS ON SIGNAL'}
                    </button>
                    <div className="h-10 text-center font-mono text-sm text-cyan-300">
                        {signal && <p>"{signal}"</p>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PsionicInterfacePanel;
