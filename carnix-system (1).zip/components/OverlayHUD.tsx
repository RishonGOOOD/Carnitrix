
import React, { useState } from 'react';
import { Profile } from '../types';
import { Activity, Shield, BrainCircuit, AlertTriangle, GripHorizontal, X } from 'lucide-react';
import { useAppContext } from '../context';

const OverlayHUD: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile, isOnline } = state;

    if (!activeProfile) return null;

    const settings = activeProfile.hudSettings || { visible: true, position: 'top-right', showSystem: true, showAI: true, showAlerts: true, opacity: 0.8 };
    
    const onUpdateProfile = (updates: Partial<Omit<Profile, 'id'>>) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: updates });
    };

    if (!settings.visible) return null;

    const getPositionClass = () => {
        switch(settings.position) {
            case 'top-left': return 'top-20 left-4';
            case 'top-right': return 'top-20 right-4';
            case 'bottom-left': return 'bottom-24 left-4';
            case 'bottom-right': return 'bottom-24 right-4';
            default: return 'top-20 right-4';
        }
    };

    const togglePosition = () => {
        const positions: typeof settings.position[] = ['top-right', 'bottom-right', 'bottom-left', 'top-left'];
        const currentIdx = positions.indexOf(settings.position);
        const nextPos = positions[(currentIdx + 1) % positions.length];
        // FIX: Ensure property name matches the Profile interface (hudSettings exists now in updated types.ts)
        onUpdateProfile({ hudSettings: { ...settings, position: nextPos } });
    };
    
    const toggleVisibility = () => {
        // FIX: Ensure property name matches the Profile interface (hudSettings exists now in updated types.ts)
        onUpdateProfile({ hudSettings: { ...settings, visible: false } });
    }

    return (
        <div 
            className={`fixed ${getPositionClass()} z-40 w-64 hud-panel transition-all duration-500 gpu-accelerated`}
            style={{ opacity: settings.opacity ?? 0.8 }}
        >
            {/* Header / Drag Handle */}
            <div className="hud-panel-header cursor-move select-none" onDoubleClick={togglePosition}>
                <GripHorizontal size={14} /> HUD OVERLAY
                 <button onClick={toggleVisibility} className="ml-auto text-[var(--color-accent)] hover:text-white"><X size={14}/></button>
            </div>

            {/* Modules */}
            <div className="p-2 space-y-2 text-xs font-mono">
                {settings.showSystem && (
                    <div className="bg-black/40 p-2 rounded border-l-2 border-green-500 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-gray-300">
                            <Activity size={12} /> SYSTEM
                        </div>
                        <span className={isOnline ? "text-green-500" : "text-red-500"}>{isOnline ? "ONLINE" : "OFFLINE"}</span>
                    </div>
                )}
                
                {settings.showAI && (
                    <div className="bg-black/40 p-2 rounded border-l-2 border-blue-500 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-gray-300">
                            <BrainCircuit size={12} /> AI CORE
                        </div>
                        <span className="text-blue-400">{activeProfile.aiSettings.model.split('-')[1]?.toUpperCase() || 'STD'}</span>
                    </div>
                )}

                {settings.showAlerts && !isOnline && (
                    <div className="bg-red-900/20 p-2 rounded border border-red-500 flex items-center gap-2 animate-pulse text-red-400">
                        <AlertTriangle size={14} /> NETWORK ERROR
                    </div>
                )}
                
                <div className="flex justify-between text-[10px] text-gray-500 pt-1">
                     <span>POS: {settings.position.toUpperCase()}</span>
                     <button onClick={togglePosition} className="hover:text-white">MOVE</button>
                </div>
            </div>
        </div>
    );
};

export default OverlayHUD;
