
import React, { useState, useRef, useEffect } from 'react';
import { ShieldAlert, Terminal, Play, Check, Copy, Loader2, FileCode, AlertTriangle, XCircle, Smartphone } from 'lucide-react';
import { useAppContext } from '../context';
import { generateHackingScript } from '../services/geminiService';
import { playSound } from '../utils/soundEffects';
import { copyToClipboard } from '../utils/nativeBridge';

const SimpleSyntaxHighlighter: React.FC<{ code: string }> = ({ code }) => {
    const renderTokenized = (text: string) => {
        const lines = text.split('\n');
        return lines.map((line, i) => {
            let formattedLine = line
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");

            if (formattedLine.trim().startsWith('#')) {
                return <div key={i} className="text-gray-500 italic pl-1">{formattedLine}</div>;
            }

            formattedLine = formattedLine.replace(/\b(import|from|def|return|if|else|elif|for|while|try|except|class|print|True|False|None|pkg|apt|install)\b/g, '<span class="text-purple-400 font-bold">$1</span>');
            formattedLine = formattedLine.replace(/(["'])(?:(?=(\\?))\2.)*?\1/g, '<span class="text-yellow-300">$0</span>');
            formattedLine = formattedLine.replace(/\b\d+\b/g, '<span class="text-blue-400">$0</span>');
            formattedLine = formattedLine.replace(/([a-zA-Z_][a-zA-Z0-9_]*)(?=\()/g, '<span class="text-blue-300">$1</span>');

            return <div key={i} className="pl-1 border-l-2 border-transparent hover:border-gray-700 hover:bg-white/5" dangerouslySetInnerHTML={{ __html: formattedLine || '&nbsp;' }} />;
        });
    };

    return <div className="font-mono text-xs md:text-sm whitespace-pre-wrap font-medium">{renderTokenized(code)}</div>;
};

const ErrorBanner: React.FC<{ message: string; suggestion: string; onClose: () => void }> = ({ message, suggestion, onClose }) => (
    <div className="bg-red-900/40 border border-red-500 rounded p-3 mb-3 flex items-start gap-3 animate-enter shadow-[0_0_15px_rgba(239,68,68,0.2)]">
        <AlertTriangle className="text-red-500 flex-shrink-0 mt-0.5" size={18} />
        <div className="flex-1 min-w-0">
            <h4 className="text-red-400 font-bold text-xs uppercase tracking-wider">Execution Error</h4>
            <p className="text-white text-xs mt-1 leading-relaxed">{message}</p>
            <p className="text-gray-400 text-[10px] mt-1 italic border-l-2 border-red-500/30 pl-2">Suggestion: {suggestion}</p>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors"><XCircle size={16} /></button>
    </div>
);

const EthicalHackingPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    
    const [activeTab, setActiveTab] = useState<'GENERATOR' | 'TERMUX'>('GENERATOR');
    
    // Generator State
    const [prompt, setPrompt] = useState('');
    const [code, setCode] = useState<string | null>(null);
    const [simulationOutput, setSimulationOutput] = useState<string | null>(null);
    const [displayedSimulation, setDisplayedSimulation] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSimulating, setIsSimulating] = useState(false);
    const [hasCopied, setHasCopied] = useState(false);
    
    // Termux State
    const [termuxScript, setTermuxScript] = useState<string>('');

    // Error State
    const [errorState, setErrorState] = useState<{ message: string; suggestion: string } | null>(null);

    const typingIntervalRef = useRef<number | null>(null);
    const terminalEndRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        return () => {
            if (typingIntervalRef.current) clearInterval(typingIntervalRef.current);
        };
    }, []);

    useEffect(() => {
        if (terminalEndRef.current) {
            terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [displayedSimulation, termuxScript]);

    const handleGenerate = async () => {
        setErrorState(null);
        if (!prompt.trim() || !activeProfile) {
             setErrorState({ message: "Input prompt is empty.", suggestion: "Describe the tool you want to generate." });
             return;
        }
        
        setIsLoading(true);
        setCode(null);
        setSimulationOutput(null);
        setDisplayedSimulation('');
        playSound('process');
        
        try {
            const res = await generateHackingScript(prompt, activeProfile.aiSettings);
            setCode(res.code);
            setSimulationOutput(res.simulationOutput);
            playSound('success');
        } catch (e: any) {
            setErrorState({ message: e.message, suggestion: "Check your API Key or prompt phrasing." });
            playSound('error');
        } finally {
            setIsLoading(false);
        }
    };

    const runSimulation = () => {
        if (!simulationOutput || isSimulating) return;
        setIsSimulating(true);
        playSound('typing');
        setDisplayedSimulation('');

        let i = 0;
        const speed = 15; 
        typingIntervalRef.current = window.setInterval(() => {
            setDisplayedSimulation(prev => simulationOutput.substring(0, i));
            i++;
            if (i > simulationOutput.length) {
                if (typingIntervalRef.current) clearInterval(typingIntervalRef.current);
                setIsSimulating(false);
                playSound('success');
            }
        }, speed);
    };

    const handleCopy = async (text: string) => {
        if (!text) return;
        const success = await copyToClipboard(text);
        if (success) {
            setHasCopied(true);
            playSound('click');
            setTimeout(() => setHasCopied(false), 2000);
        }
    };

    const termuxScripts = [
        { name: "Setup Storage", cmd: "termux-setup-storage" },
        { name: "Update Repos", cmd: "pkg update && pkg upgrade" },
        { name: "Install Python", cmd: "pkg install python" },
        { name: "Install Git", cmd: "pkg install git" },
        { name: "Install Nmap", cmd: "pkg install nmap" },
    ];

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-red-900/30 rounded border border-red-500/50">
                        <ShieldAlert size={16} className="text-red-500 animate-pulse" />
                    </div>
                    <h2 className="text-sm font-black tracking-widest text-white flex items-center gap-2">
                        ETHICAL HACKING LAB
                    </h2>
                </div>
                <div className="flex bg-black rounded border border-gray-800 p-0.5">
                    <button onClick={() => setActiveTab('GENERATOR')} className={`px-3 py-1 text-[10px] font-bold rounded transition-all ${activeTab === 'GENERATOR' ? 'bg-red-600 text-black shadow-[0_0_10px_rgba(220,38,38,0.5)]' : 'text-gray-500 hover:text-white'}`}>SCRIPT GEN</button>
                    <button onClick={() => setActiveTab('TERMUX')} className={`px-3 py-1 text-[10px] font-bold rounded transition-all ${activeTab === 'TERMUX' ? 'bg-green-600 text-black shadow-[0_0_10px_rgba(34,197,94,0.5)]' : 'text-gray-500 hover:text-white'}`}>TERMUX KIT</button>
                </div>
            </div>

            {errorState && <ErrorBanner message={errorState.message} suggestion={errorState.suggestion} onClose={() => setErrorState(null)} />}

            <div className="flex-1 flex flex-col md:flex-row relative gap-4 overflow-hidden">
                <div className="w-full md:w-1/3 flex flex-col gap-3 h-full overflow-hidden">
                    {activeTab === 'GENERATOR' && (
                        <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex-1 flex flex-col min-h-0">
                            <textarea
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="Describe the tool to generate..."
                                className="w-full flex-1 bg-black/50 border border-gray-700 rounded p-3 text-sm resize-none focus:outline-none focus:border-red-500 text-white mb-4 font-mono"
                                disabled={isLoading || isSimulating}
                            />
                            <button
                                onClick={handleGenerate}
                                disabled={isLoading || isSimulating}
                                className="p-3 bg-red-900/30 text-red-400 border border-red-800 hover:bg-red-900/50 hover:text-white rounded flex items-center justify-center gap-2 text-xs font-bold disabled:opacity-50 transition-all"
                            >
                                {isLoading ? <Loader2 size={14} className="animate-spin" /> : <Terminal size={14} />}
                                GENERATE
                            </button>
                        </div>
                    )}

                    {activeTab === 'TERMUX' && (
                        <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 flex-1 flex flex-col gap-3 overflow-y-auto">
                            <div className="flex items-center gap-2 mb-2">
                                <Smartphone size={16} className="text-green-500"/>
                                <span className="text-xs font-bold text-green-400">TERMUX COMMANDS</span>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                {termuxScripts.map((script, i) => (
                                    <button 
                                        key={i}
                                        onClick={() => { setTermuxScript(script.cmd); playSound('click'); }}
                                        className="p-3 bg-black/50 border border-gray-800 hover:border-green-600 rounded text-left transition-all"
                                    >
                                        <div className="text-[10px] font-bold text-gray-400">{script.name}</div>
                                        <div className="text-[9px] text-gray-600 font-mono truncate">{script.cmd}</div>
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                <div className="w-full md:w-2/3 flex flex-col bg-black border border-[var(--color-panel-border)] rounded-md overflow-hidden h-full">
                    <div className="h-1/2 border-b border-gray-800 flex flex-col min-h-0">
                        <div className="p-2 bg-gray-900/80 border-b border-gray-800 flex justify-between items-center shrink-0">
                            <span className="text-xs font-bold text-gray-400 flex items-center gap-2">
                                <FileCode size={14} className="text-blue-400"/> SOURCE
                            </span>
                            {(code || termuxScript) && (
                                <button onClick={() => handleCopy(activeTab === 'TERMUX' ? termuxScript : code || '')} className="text-xs flex items-center gap-1 text-gray-500 hover:text-white">
                                    {hasCopied ? <Check size={12} className="text-green-500" /> : <Copy size={12} />}
                                    {hasCopied ? 'COPIED' : 'COPY'}
                                </button>
                            )}
                        </div>
                        <div className="flex-1 overflow-auto p-3 bg-[#0a0a0a]">
                            {code ? <SimpleSyntaxHighlighter code={code} /> : termuxScript ? <SimpleSyntaxHighlighter code={termuxScript} /> : null}
                        </div>
                    </div>

                    <div className="h-1/2 flex flex-col bg-black min-h-0">
                        <div className="p-2 bg-gray-900/80 border-b border-gray-800 flex justify-between items-center shrink-0">
                            <span className="text-xs font-bold text-gray-400 flex items-center gap-2">
                                <Terminal size={14} className="text-green-500"/> OUTPUT
                            </span>
                            {code && activeTab === 'GENERATOR' && !isSimulating && (
                                <button onClick={runSimulation} className="px-2 py-0.5 bg-green-900/30 border border-green-700 rounded text-green-400 text-[10px] font-bold">
                                    <Play size={10} className="inline mr-1"/> EXECUTE
                                </button>
                            )}
                        </div>
                        <div className="flex-1 overflow-auto p-3 font-mono text-xs text-gray-300 bg-black">
                            <pre className="whitespace-pre-wrap">{displayedSimulation}</pre>
                            <div ref={terminalEndRef} />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default EthicalHackingPanel;
