
import React from 'react';

export const TechSkeleton: React.FC<{ className?: string; height?: string }> = ({ className = "", height = "h-4" }) => (
    <div className={`relative overflow-hidden bg-[#1a0505] border border-red-900/30 rounded ${height} ${className}`}>
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-red-900/20 to-transparent animate-shimmer" style={{ backgroundSize: '200% 100%' }}></div>
        {/* Scanning line decoration */}
        <div className="absolute top-0 bottom-0 w-[2px] bg-red-500/20 animate-scan-fast"></div>
    </div>
);

export const CardSkeleton: React.FC = () => (
    <div className="p-3 border border-red-900/20 bg-black/40 rounded flex flex-col gap-2">
        <div className="flex justify-between items-center mb-1">
            <TechSkeleton className="w-1/3 h-3" />
            <TechSkeleton className="w-10 h-3" />
        </div>
        <TechSkeleton className="w-full h-12" />
        <div className="flex gap-2 mt-1">
            <TechSkeleton className="w-1/4 h-2" />
            <TechSkeleton className="w-1/4 h-2" />
        </div>
    </div>
);

export const ListSkeleton: React.FC<{ count?: number }> = ({ count = 5 }) => (
    <div className="space-y-3">
        {Array.from({ length: count }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 p-2 border-b border-red-900/10">
                <TechSkeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-2">
                    <TechSkeleton className="w-3/4 h-3" />
                    <TechSkeleton className="w-1/2 h-2" />
                </div>
                <TechSkeleton className="w-12 h-4" />
            </div>
        ))}
    </div>
);

export const MapSkeleton: React.FC = () => (
    <div className="w-full h-full relative bg-[#050000] overflow-hidden flex items-center justify-center border border-red-900/30 rounded-lg">
        {/* Grid lines */}
        <div className="absolute inset-0" style={{ 
            backgroundImage: 'linear-gradient(rgba(255, 0, 60, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 0, 60, 0.1) 1px, transparent 1px)',
            backgroundSize: '40px 40px' 
        }}></div>
        {/* Radar sweep */}
        <div className="absolute inset-0 bg-[conic-gradient(from_0deg,transparent_0deg,rgba(255,0,60,0.1)_360deg)] animate-spin-slow rounded-full opacity-30"></div>
        <div className="text-red-500/50 font-mono text-xs animate-pulse tracking-widest">INITIALIZING TERRAIN DATA...</div>
    </div>
);
