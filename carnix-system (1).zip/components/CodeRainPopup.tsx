
import React, { useEffect, useState } from 'react';

const CodeRainPopup: React.FC<{ isVisible: boolean }> = ({ isVisible }) => {
    // Generate columns once to maintain stable DOM structure
    const [cols] = useState(() => Array.from({ length: 12 }).map(() => ({
        left: Math.floor(Math.random() * 80) + 10 + '%', 
        delay: Math.random() * 1.5 + 's',
        chars: Array.from({ length: 20 }, () => "01ABCDEF#$%&*@"[Math.floor(Math.random() * 14)]).join('\n')
    })));

    if (!isVisible) return null;

    return (
        <div className="fixed top-20 left-5 w-[140px] md:w-[200px] h-[160px] bg-black/80 border border-[var(--color-primary)]/30 backdrop-blur-md rounded-lg overflow-hidden z-[999] shadow-[0_0_20px_var(--color-primary)] border-t-[var(--color-primary)] animate-enter pointer-events-none">
             {/* Scanline effect */}
             <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%)] bg-[size:100%_4px] pointer-events-none z-10 opacity-50"></div>
             
             {/* Rain Columns */}
             {cols.map((col, i) => (
                <div 
                    key={i} 
                    className="absolute top-[-300px] text-[var(--color-primary)] text-xs font-mono opacity-80 whitespace-pre leading-none text-center"
                    style={{
                        left: col.left,
                        animation: `fall 1.6s linear infinite`,
                        animationDelay: col.delay,
                        textShadow: '0 0 5px var(--color-primary)'
                    }}
                >
                    {col.chars}
                </div>
            ))}
            
            {/* Embedded Styles for Self-Contained Animation */}
            <style>{`
                @keyframes fall {
                    0% { transform: translateY(0); opacity: 0; }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% { transform: translateY(400px); opacity: 0; }
                }
                .animate-enter { animation: pop-in 0.3s cubic-bezier(0.18, 0.89, 0.32, 1.28) forwards; }
                @keyframes pop-in {
                    0% { transform: scale(0.8) translateY(20px); opacity: 0; }
                    100% { transform: scale(1) translateY(0); opacity: 1; }
                }
            `}</style>
        </div>
    );
};

export default CodeRainPopup;
