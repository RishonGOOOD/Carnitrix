import React, { useRef, useState, useEffect, useCallback } from 'react';
import { 
    X, ZoomIn, ZoomOut, Target, Brain, Zap, ShieldAlert, Activity, 
    Scan, Loader2, Crosshair, RefreshCw, Camera, Eye, Radio, Sparkles 
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { useAppContext } from '../context';
import { getImageAnalysis } from '../services/geminiService';

declare const cocoSsd: any;

interface Detection {
    bbox: [number, number, number, number];
    class: string;
    score: number;
}

const CameraView: React.FC<{ onExit: () => void }> = ({ onExit }) => {
    const { state, dispatch } = useAppContext();
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const modelRef = useRef<any>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const frameIdRef = useRef<number>(0);
    const rotationRef = useRef<number>(0);
    const detectionsRef = useRef<Detection[]>([]);
    const lastPredictionTime = useRef<number>(0);

    const [isLoading, setIsLoading] = useState(true);
    const [cameraError, setCameraError] = useState<string | null>(null);
    const [isDeepScanning, setIsDeepScanning] = useState(false);
    const [detectedCount, setDetectedCount] = useState(0);
    const [zoom, setZoom] = useState(1);
    const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
    const [hudFilter, setHudFilter] = useState<'tactical' | 'thermal' | 'nightvision'>('tactical');
    const [scanResult, setScanResult] = useState<{ text: string; image: string } | null>(null);

    const stopStream = () => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(t => t.stop());
            streamRef.current = null;
        }
    };

    const initCamera = useCallback(async () => {
        setIsLoading(true);
        setCameraError(null);
        stopStream();

        try {
            let stream: MediaStream;
            try {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: { 
                        facingMode: facingMode, 
                        width: { ideal: 1280 }, 
                        height: { ideal: 720 } 
                    },
                    audio: false
                });
            } catch {
                stream = await navigator.mediaDevices.getUserMedia({ 
                    video: true,
                    audio: false
                });
            }

            streamRef.current = stream;
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
                videoRef.current.onloadedmetadata = () => {
                    videoRef.current?.play().then(() => {
                        setIsLoading(false);
                    }).catch(() => {
                        setIsLoading(false);
                    });
                };
            } else {
                setIsLoading(false);
            }

            // Background load cocoSsd if available, without blocking video display
            if (typeof cocoSsd !== 'undefined' && !modelRef.current) {
                cocoSsd.load().then((loadedModel: any) => {
                    modelRef.current = loadedModel;
                    playSound('access');
                }).catch((e: any) => {
                    console.warn("cocoSsd background init note:", e);
                });
            }
        } catch (err: any) {
            console.error("Camera Init Error:", err);
            setCameraError(err.message || "Camera access permission required.");
            setIsLoading(false);
            playSound('error');
        }
    }, [facingMode]);

    const toggleFacing = () => {
        setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
        playSound('click');
        triggerHaptic('light');
    };

    const drawOverlay = (preds: Detection[], width: number, height: number, ctx: CanvasRenderingContext2D) => {
        ctx.clearRect(0, 0, width, height);

        // Holographic HUD Grid Center reticle
        const cx = width / 2;
        const cy = height / 2;

        ctx.strokeStyle = hudFilter === 'thermal' 
            ? 'rgba(255, 68, 0, 0.4)' 
            : hudFilter === 'nightvision' 
                ? 'rgba(34, 197, 94, 0.5)' 
                : 'rgba(0, 240, 255, 0.4)';
        ctx.lineWidth = 1.5;

        // Center crosshair
        ctx.beginPath();
        ctx.moveTo(cx - 30, cy); ctx.lineTo(cx - 10, cy);
        ctx.moveTo(cx + 10, cy); ctx.lineTo(cx + 30, cy);
        ctx.moveTo(cx, cy - 30); ctx.lineTo(cx, cy - 10);
        ctx.moveTo(cx, cy + 10); ctx.lineTo(cx, cy + 30);
        ctx.stroke();

        // Rotating optical target ring
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(rotationRef.current);
        ctx.setLineDash([8, 8]);
        ctx.beginPath();
        ctx.arc(0, 0, 48, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();

        // Draw HUD Corner Framing
        ctx.setLineDash([]);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 2;
        const framePad = 32;
        const bracketLen = 24;

        // Top Left
        ctx.beginPath();
        ctx.moveTo(framePad, framePad + bracketLen); ctx.lineTo(framePad, framePad); ctx.lineTo(framePad + bracketLen, framePad);
        // Top Right
        ctx.moveTo(width - framePad - bracketLen, framePad); ctx.lineTo(width - framePad, framePad); ctx.lineTo(width - framePad, framePad + bracketLen);
        // Bottom Left
        ctx.moveTo(framePad, height - framePad - bracketLen); ctx.lineTo(framePad, height - framePad); ctx.lineTo(framePad + bracketLen, height - framePad);
        // Bottom Right
        ctx.moveTo(width - framePad - bracketLen, height - framePad); ctx.lineTo(width - framePad, height - framePad); ctx.lineTo(width - framePad, height - framePad - bracketLen);
        ctx.stroke();

        // Target bounding boxes
        preds.forEach((p, idx) => {
            const [x, y, w, h] = p.bbox;
            const primaryColor = hudFilter === 'thermal' ? '#ff3b30' : hudFilter === 'nightvision' ? '#4ade80' : '#00f0ff';

            ctx.strokeStyle = primaryColor;
            ctx.lineWidth = 2;
            ctx.setLineDash([10, 6]);
            ctx.strokeRect(x, y, w, h);

            // Bracket corners
            ctx.setLineDash([]);
            ctx.lineWidth = 3;
            const cs = Math.min(w, h) * 0.25;
            ctx.beginPath();
            ctx.moveTo(x, y + cs); ctx.lineTo(x, y); ctx.lineTo(x + cs, y);
            ctx.moveTo(x + w - cs, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + cs);
            ctx.moveTo(x + w, y + h - cs); ctx.lineTo(x + w, y + h); ctx.lineTo(x + w - cs, y + h);
            ctx.moveTo(x + cs, y + h); ctx.lineTo(x, y + h); ctx.lineTo(x, y + h - cs);
            ctx.stroke();

            // Label tag
            const label = `${p.class.toUpperCase()} [${Math.round(p.score * 100)}%]`;
            ctx.fillStyle = 'rgba(0,0,0,0.75)';
            ctx.fillRect(x, Math.max(0, y - 24), Math.max(w, 140), 22);
            ctx.strokeStyle = primaryColor;
            ctx.lineWidth = 1;
            ctx.strokeRect(x, Math.max(0, y - 24), Math.max(w, 140), 22);

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 12px Rajdhani, monospace';
            ctx.fillText(label, x + 6, Math.max(16, y - 8));
        });

        // Synthetic telemetry footer in canvas
        ctx.fillStyle = 'rgba(0, 240, 255, 0.8)';
        ctx.font = '10px monospace';
        ctx.fillText(`OPTICAL_RES: ${width}x${height} | ZOOM: ${zoom.toFixed(1)}x | MODE: ${hudFilter.toUpperCase()}`, framePad + 8, height - framePad - 8);
    };

    // Unified animation frame loop (zero state churn)
    const runFrameLoop = () => {
        const video = videoRef.current;
        const canvas = canvasRef.current;

        if (video && canvas && video.readyState >= 2) {
            if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
                canvas.width = video.videoWidth || 640;
                canvas.height = video.videoHeight || 480;
            }

            const ctx = canvas.getContext('2d');
            if (ctx) {
                rotationRef.current = (rotationRef.current + 0.03) % (Math.PI * 2);

                // Run model detection throttled every 350ms to keep 60fps smooth
                const now = performance.now();
                if (modelRef.current && now - lastPredictionTime.current > 350) {
                    lastPredictionTime.current = now;
                    modelRef.current.detect(video).then((predictions: Detection[]) => {
                        detectionsRef.current = predictions;
                        setDetectedCount(predictions.length);
                    }).catch(() => {});
                }

                drawOverlay(detectionsRef.current, canvas.width, canvas.height, ctx);
            }
        }

        frameIdRef.current = requestAnimationFrame(runFrameLoop);
    };

    useEffect(() => {
        initCamera();
        frameIdRef.current = requestAnimationFrame(runFrameLoop);

        return () => {
            stopStream();
            cancelAnimationFrame(frameIdRef.current);
        };
    }, [initCamera]);

    const captureSnapshot = () => {
        if (!videoRef.current) return;
        playSound('click');
        triggerHaptic('medium');

        const video = videoRef.current;
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = video.videoWidth || 640;
        tempCanvas.height = video.videoHeight || 480;
        const ctx = tempCanvas.getContext('2d');
        if (ctx) {
            ctx.drawImage(video, 0, 0);
            const dataUrl = tempCanvas.toDataURL('image/jpeg', 0.95);
            setScanResult({
                image: dataUrl,
                text: `OPTICAL SNAPSHOT CAPTURED [${new Date().toLocaleTimeString()}]. Targets tracked: ${detectedCount}. Lens: ${facingMode.toUpperCase()}. Ready for deep neural decomposition.`
            });
        }
    };

    const initiateDeepScan = async () => {
        if (!videoRef.current || isDeepScanning) return;

        setIsDeepScanning(true);
        playSound('scan');
        triggerHaptic('heavy');

        const video = videoRef.current;
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = video.videoWidth || 640;
        tempCanvas.height = video.videoHeight || 480;
        const ctx = tempCanvas.getContext('2d');
        if (!ctx) {
            setIsDeepScanning(false);
            return;
        }

        ctx.drawImage(video, 0, 0);
        const base64Image = tempCanvas.toDataURL('image/jpeg', 0.9).split(',')[1];
        const previewUrl = tempCanvas.toDataURL('image/jpeg', 0.7);

        try {
            const result = await getImageAnalysis(
                base64Image,
                "Master Tactical Reconnaissance: Perform complete target identification, spatial risk assessment, structural geometry, and tactical directives.",
                state.activeProfile?.aiSettings || ({} as any)
            );

            setScanResult({ text: result.text, image: previewUrl });
            playSound('success');
            dispatch({ type: 'ADD_LOG', payload: { source: 'VISION', message: `Neural Vision Decomposition Completed.`, level: 'success' } });
        } catch (err: any) {
            console.error(err);
            setScanResult({
                text: `[TACTICAL OPTICAL FEED] Frame captured. Target coordinates logged. Note: ${err.message || 'Deep inference fallback active'}.`,
                image: previewUrl
            });
            playSound('error');
        } finally {
            setIsDeepScanning(false);
        }
    };

    const getFilterClass = () => {
        switch (hudFilter) {
            case 'thermal':
                return 'hue-rotate-[180deg] saturate-[2.5] contrast-150';
            case 'nightvision':
                return 'brightness-125 contrast-150 sepia hue-rotate-[90deg] saturate-[3]';
            default:
                return 'contrast-110 saturate-110';
        }
    };

    return (
        <div className="absolute inset-0 bg-black z-[100] flex flex-col font-[Rajdhani] select-none overflow-hidden">
            {/* Top HUD Telemetry Bar */}
            <div className="absolute top-0 inset-x-0 z-30 flex items-center justify-between p-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent backdrop-blur-sm">
                <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 px-3 py-1 bg-red-950/60 border border-red-500/50 rounded text-red-400 text-xs font-mono font-bold tracking-widest uppercase">
                        <Radio size={14} className="animate-pulse text-red-500" />
                        CARNIX_AR_HUD
                    </div>
                    <span className="text-[11px] font-mono text-cyan-400 border border-cyan-800/40 bg-cyan-950/40 px-2.5 py-1 rounded">
                        TARGETS: <strong className="text-white">{detectedCount}</strong>
                    </span>
                    <span className="hidden sm:inline text-[11px] font-mono text-gray-400">
                        LENS: <strong className="text-white">{facingMode.toUpperCase()}</strong>
                    </span>
                </div>

                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setHudFilter(f => f === 'tactical' ? 'thermal' : f === 'thermal' ? 'nightvision' : 'tactical')}
                        className="px-3 py-1.5 bg-black/60 border border-white/20 rounded text-xs font-mono text-white hover:border-cyan-400 transition-colors flex items-center gap-1.5"
                    >
                        <Eye size={14} className="text-cyan-400" />
                        {hudFilter.toUpperCase()}
                    </button>
                    <button 
                        onClick={toggleFacing} 
                        className="p-1.5 bg-black/60 border border-white/20 rounded text-cyan-400 hover:text-white hover:border-cyan-400 transition-colors"
                        title="Switch Optical Lens"
                    >
                        <RefreshCw size={16} />
                    </button>
                    <button 
                        onClick={onExit} 
                        className="p-1.5 bg-red-600/80 hover:bg-red-600 text-white rounded transition-colors"
                        title="Exit Camera HUD"
                    >
                        <X size={18} />
                    </button>
                </div>
            </div>

            {/* Viewport & Canvas Overlay */}
            <div className="relative flex-1 bg-black overflow-hidden flex items-center justify-center">
                <video 
                    ref={videoRef} 
                    playsInline 
                    muted 
                    className={`w-full h-full object-cover transition-all duration-300 ${getFilterClass()}`}
                    style={{ transform: `scale(${zoom})` }} 
                />
                <canvas 
                    ref={canvasRef} 
                    className="absolute inset-0 w-full h-full object-cover z-10 pointer-events-none" 
                />

                {isLoading && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-20 backdrop-blur-md">
                        <Activity size={44} className="text-red-600 animate-pulse mb-3" />
                        <p className="text-xs font-black text-white tracking-[0.4em] uppercase">Aligning Optical Sensor Array...</p>
                        <p className="text-[10px] font-mono text-gray-400 mt-2">Requesting hardware stream link</p>
                    </div>
                )}

                {cameraError && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-20 p-6 text-center">
                        <ShieldAlert size={48} className="text-red-500 mb-3" />
                        <h3 className="text-lg font-bold text-white mb-2 tracking-wide uppercase">Optical Relay Offline</h3>
                        <p className="text-xs text-gray-400 max-w-sm mb-4">{cameraError}</p>
                        <button 
                            onClick={initCamera} 
                            className="px-6 py-2 bg-red-700 hover:bg-red-600 text-white font-bold text-xs rounded uppercase tracking-wider transition-colors"
                        >
                            Retry Sensor Link
                        </button>
                    </div>
                )}

                {/* Scan Result Overlay Modal */}
                {scanResult && (
                    <div className="absolute bottom-24 right-4 sm:right-8 z-40 w-[90vw] max-w-md animate-in fade-in slide-in-from-right duration-300">
                        <div className="bg-black/95 border-2 border-red-600 rounded-lg p-0 overflow-hidden shadow-[0_0_60px_rgba(255,0,0,0.4)] backdrop-blur-xl">
                            <div className="flex justify-between items-center bg-red-600 px-4 py-2.5">
                                <div className="flex items-center gap-2">
                                    <Brain size={16} className="text-black animate-pulse" />
                                    <span className="text-xs font-black text-black uppercase tracking-widest">TACTICAL_OPTICAL_REPORT</span>
                                </div>
                                <button onClick={() => setScanResult(null)} className="text-black hover:text-white transition-colors">
                                    <X size={18} />
                                </button>
                            </div>
                            <div className="p-4 space-y-3">
                                <div className="aspect-video w-full bg-gray-950 border border-red-900/50 rounded overflow-hidden relative">
                                    <img src={scanResult.image} className="w-full h-full object-cover" alt="Scan Capture" />
                                </div>
                                <div className="max-h-52 overflow-y-auto pr-1 text-xs font-mono text-gray-300 leading-relaxed uppercase">
                                    {scanResult.text}
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Deep Scanning Progress Modal */}
                {isDeepScanning && (
                    <div className="absolute inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-50">
                        <div className="flex flex-col items-center gap-4 p-8 bg-black/90 border border-red-600/60 rounded-xl shadow-[0_0_80px_rgba(239,68,68,0.5)]">
                            <div className="relative w-24 h-24 flex items-center justify-center">
                                <Loader2 size={80} className="text-red-600 animate-spin opacity-40 absolute inset-0 m-auto" />
                                <Scan size={36} className="text-white animate-pulse" />
                            </div>
                            <h3 className="text-xl font-black text-white italic tracking-wider uppercase">Deep Neural Deconstruction</h3>
                            <p className="text-[10px] font-mono text-red-400 uppercase tracking-[0.3em] animate-pulse">Running Multimodal Visual Intelligence</p>
                        </div>
                    </div>
                )}
            </div>

            {/* Bottom HUD Controls */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-3">
                <div className="flex items-center gap-4 bg-black/70 border border-white/20 px-4 py-2 rounded-full backdrop-blur-md shadow-2xl">
                    <button 
                        onClick={() => setZoom(z => Math.max(z - 0.2, 1))} 
                        className="p-2.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                        title="Zoom Out"
                    >
                        <ZoomOut size={20} />
                    </button>

                    {/* Snapshot Button */}
                    <button 
                        onClick={captureSnapshot} 
                        disabled={isLoading}
                        className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-all active:scale-95"
                        title="Optical Snapshot"
                    >
                        <Camera size={22} />
                    </button>

                    {/* Deep Scan AI Button */}
                    <button 
                        onClick={initiateDeepScan} 
                        disabled={isDeepScanning || isLoading} 
                        className="relative px-6 py-2.5 bg-red-600 hover:bg-red-500 text-black font-black text-xs uppercase tracking-widest rounded-full shadow-[0_0_25px_rgba(239,68,68,0.8)] flex items-center gap-2 active:scale-95 transition-all"
                    >
                        <Crosshair size={18} className="animate-spin-slow" />
                        <span>NEURAL DEEP SCAN</span>
                    </button>

                    <button 
                        onClick={() => setZoom(z => Math.min(z + 0.2, 3))} 
                        className="p-2.5 text-gray-400 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                        title="Zoom In"
                    >
                        <ZoomIn size={20} />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CameraView;
