
import React, { useState, useRef, useEffect } from 'react';
import { Globe, ArrowRight, RefreshCw, Lock, ShieldOff, Home, Loader2, ExternalLink } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { useAppContext } from '../context';

const WebBrowserPanel: React.FC = () => {
    const { state } = useAppContext();
    // Default home page
    const homeUrl = 'https://en.m.wikipedia.org/wiki/Main_Page';
    
    // Check if we were opened with a specific app URL
    const [url, setUrl] = useState(state.activeAppUrl || homeUrl);
    const [displayUrl, setDisplayUrl] = useState(state.activeAppUrl || homeUrl);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const iframeRef = useRef<HTMLIFrameElement>(null);

    // Sync if context updates (e.g. new app click)
    useEffect(() => {
        if (state.activeAppUrl) {
            navigate(state.activeAppUrl);
        }
    }, [state.activeAppUrl]);

    const navigate = (targetUrl: string) => {
        let finalUrl = targetUrl;
        if (!/^https?:\/\//i.test(finalUrl)) {
            finalUrl = 'https://' + finalUrl;
        }
        setDisplayUrl(finalUrl);
        setUrl(finalUrl); // Update input field
        setIsLoading(true);
        setError(null);
        playSound('click');
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        navigate(url);
    };

    const handleIframeLoad = () => {
        setIsLoading(false);
        // Basic check for x-frame options issues (imperfect)
        setTimeout(() => {
            try {
                // If accessing contentWindow.location throws cross-origin error, it's actually a GOOD sign (means page loaded)
                // If it returns about:blank but we set it to something else, it might be blocked.
                const loc = iframeRef.current?.contentWindow?.location.href;
                if (loc === 'about:blank' && displayUrl !== 'about:blank') {
                     // Potential block, but difficult to detect purely via JS
                }
            } catch (e) {
                // Expected cross-origin restriction
                console.log("Page loaded (Cross-origin)");
            }
        }, 500);
    };
    
    const goHome = () => {
        navigate(homeUrl);
    }
    
    const refresh = () => {
        if (iframeRef.current) {
            iframeRef.current.src = 'about:blank';
            setTimeout(() => {
                if(iframeRef.current) iframeRef.current.src = displayUrl;
                setIsLoading(true);
            }, 100);
        }
    }

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            {/* Controls */}
            <div className="flex-shrink-0 bg-black/40 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center gap-2">
                <button onClick={goHome} className="p-2 hover:bg-white/10 rounded" title="Home"><Home size={16}/></button>
                <button onClick={refresh} className="p-2 hover:bg-white/10 rounded" title="Refresh"><RefreshCw size={16} className={isLoading ? 'animate-spin' : ''}/></button>
                <form onSubmit={handleFormSubmit} className="flex-1 flex items-center relative">
                    <Lock size={14} className="absolute left-3 text-gray-500"/>
                    <input
                        type="text"
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                        placeholder="Enter URL..."
                        className="w-full bg-black/50 border border-gray-700 rounded-full pl-8 pr-10 py-1.5 text-xs focus:outline-none focus:border-[var(--color-primary)] font-mono text-white"
                    />
                    <button type="submit" className="absolute right-1 p-1.5 text-gray-400 hover:text-white">
                        <ArrowRight size={14} />
                    </button>
                </form>
                 <a href={displayUrl} target="_blank" rel="noopener noreferrer" className="p-2 hover:bg-white/10 rounded text-blue-400" title="Open in New Tab">
                    <ExternalLink size={16}/>
                 </a>
            </div>

            {/* Content Area */}
            <div className="flex-1 bg-white rounded-md overflow-hidden relative">
                {(isLoading || error) && (
                     <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-10 text-center p-4">
                        {isLoading && !error && (
                            <>
                                <Loader2 size={32} className="animate-spin text-[var(--color-primary)]" />
                                <p className="mt-2 text-xs text-gray-400">Secure Handshake Initiated...</p>
                            </>
                        )}
                        {error && (
                             <>
                                <ShieldOff size={48} className="text-red-500 mb-4" />
                                <h3 className="text-lg font-bold text-red-400">CONNECTION REFUSED</h3>
                                <p className="mt-2 text-sm text-gray-300 max-w-sm">{error}</p>
                            </>
                        )}
                    </div>
                )}
                <iframe
                    ref={iframeRef}
                    src={displayUrl}
                    className="w-full h-full border-0 bg-white"
                    title="Web Browser"
                    sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-presentation allow-same-origin allow-scripts"
                    onLoad={handleIframeLoad}
                    onError={() => { setIsLoading(false); setError("Target host refused connection (X-Frame-Options). Open in external tab."); }}
                />
            </div>
        </div>
    );
};

export default WebBrowserPanel;
