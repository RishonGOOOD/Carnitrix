
import React, { useState, useEffect } from 'react';
import { Map, CloudRain, Satellite, Compass, Crosshair, MapPin } from 'lucide-react';
import { useAppContext } from '../context';
import LocationPanel from './LocationPanel';
import WeatherRadarPanel from './WeatherRadarPanel';
import SatellitePanel from './SatellitePanel';
import CompassPanel from './CompassPanel';

const GeoIntelPanel: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'MAP' | 'WEATHER' | 'SAT' | 'COMPASS'>('MAP');
    const { state } = useAppContext();
    const { geolocation } = state;

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-[Rajdhani]">
            {/* Header */}
            <div className="flex-shrink-0 flex items-center justify-between bg-black/60 border border-white/10 p-3 rounded-lg">
                <div className="flex items-center gap-3">
                    <GlobeIcon size={24} className="text-green-500 animate-pulse" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic tracking-tighter">Geo-Intel Ops</h2>
                        <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest flex items-center gap-2">
                             {geolocation ? `LOCK: ${geolocation.latitude.toFixed(4)}, ${geolocation.longitude.toFixed(4)}` : 'SEARCHING SATELLITES...'}
                        </div>
                    </div>
                </div>
                <div className="flex bg-black rounded border border-gray-800 p-0.5">
                    <button onClick={() => setActiveTab('MAP')} className={`px-4 py-1.5 text-[10px] font-black rounded flex items-center gap-2 ${activeTab === 'MAP' ? 'bg-green-600 text-black' : 'text-gray-500 hover:text-white'}`}><Map size={12}/> NAV</button>
                    <button onClick={() => setActiveTab('WEATHER')} className={`px-4 py-1.5 text-[10px] font-black rounded flex items-center gap-2 ${activeTab === 'WEATHER' ? 'bg-green-600 text-black' : 'text-gray-500 hover:text-white'}`}><CloudRain size={12}/> ATMOS</button>
                    <button onClick={() => setActiveTab('SAT')} className={`px-4 py-1.5 text-[10px] font-black rounded flex items-center gap-2 ${activeTab === 'SAT' ? 'bg-green-600 text-black' : 'text-gray-500 hover:text-white'}`}><Satellite size={12}/> ORBIT</button>
                    <button onClick={() => setActiveTab('COMPASS')} className={`px-4 py-1.5 text-[10px] font-black rounded flex items-center gap-2 ${activeTab === 'COMPASS' ? 'bg-green-600 text-black' : 'text-gray-500 hover:text-white'}`}><Compass size={12}/> ORIENT</button>
                </div>
            </div>

            {/* Content Container */}
            <div className="flex-1 bg-black/40 border border-white/5 rounded-lg overflow-hidden relative">
                {activeTab === 'MAP' && <LocationPanel />}
                {activeTab === 'WEATHER' && <WeatherRadarPanel />}
                {activeTab === 'SAT' && <SatellitePanel />}
                {activeTab === 'COMPASS' && <CompassPanel geolocation={geolocation} address={state.address} />}
            </div>
        </div>
    );
};

const GlobeIcon = ({size, className}: {size:number, className:string}) => (
    <svg width={size} height={size} className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
);

export default GeoIntelPanel;
