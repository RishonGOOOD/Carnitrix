
import React from 'react';
import { GitCommit, Puzzle, Bot, Hammer } from 'lucide-react';
import { useAppContext } from '../context';
import { Plugin, Mode } from '../types';
import { playSound } from '../utils/soundEffects';

const PluginHubPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const plugins = state.activeProfile?.plugins || [];

    const handleTogglePlugin = (pluginId: string) => {
        const updatedPlugins = plugins.map(p =>
            p.id === pluginId ? { ...p, enabled: !p.enabled } : p
        );
        dispatch({ type: 'UPDATE_PROFILE', payload: { plugins: updatedPlugins } });
        playSound('switch');
    };
    
    const handleDesignPlugin = () => {
        dispatch({type: 'SET_MODE', payload: Mode.PluginForge });
        playSound('click');
    }

    const categories = ['System', 'Web', 'Productivity', 'Data Analysis'];

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Puzzle size={16}/> PLUGIN HUB</h2>
                <button onClick={handleDesignPlugin} className="px-3 py-1 text-xs bg-blue-900/40 text-blue-300 border border-blue-700 rounded flex items-center gap-2 hover:bg-blue-800/50">
                    <Hammer size={14} /> DESIGN NEW PLUGIN
                </button>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4 overflow-y-auto space-y-6">
                {categories.map(category => (
                    <div key={category}>
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">{category}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {plugins.filter(p => p.category === category).map(plugin => (
                                <div key={plugin.id} className={`p-4 rounded-md border flex justify-between items-start transition-all ${plugin.enabled ? 'bg-green-900/20 border-green-700' : 'bg-gray-900/20 border-gray-800'}`}>
                                    <div>
                                        <h4 className="font-bold text-white">{plugin.name}</h4>
                                        <p className="text-xs text-gray-400 mt-1">{plugin.description}</p>
                                    </div>
                                    <button onClick={() => handleTogglePlugin(plugin.id)} className={`w-12 h-6 rounded-full p-1 flex-shrink-0 transition-colors ${plugin.enabled ? 'bg-green-500' : 'bg-gray-600'}`}>
                                        <span className={`block w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${plugin.enabled ? 'translate-x-6' : 'translate-x-0'}`} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default PluginHubPanel;
