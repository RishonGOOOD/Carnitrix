
import React, { useState, useMemo } from 'react';
import { ClipboardList, Plus, Trash2, Edit, Save, X, Clock, Check, ArrowUp, ArrowDown, Calendar, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../context';
import { Task, TaskPriority } from '../types';
import { playSound } from '../utils/soundEffects';

const TaskSchedulerPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const tasks = state.activeProfile?.tasks || [];

    const [isCreating, setIsCreating] = useState(false);
    const [newTaskText, setNewTaskText] = useState('');
    const [newDueDate, setNewDueDate] = useState('');
    const [newPriority, setNewPriority] = useState<TaskPriority>('Medium');
    const [editingTask, setEditingTask] = useState<Task | null>(null);
    
    // Filtering and Sorting
    const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('all');
    const [sortBy, setSortBy] = useState<'dueDate' | 'priority' | 'text'>('priority');

    const onUpdateTasks = (newTasks: Task[]) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { tasks: newTasks } });
    };

    const getPriorityWeight = (p: TaskPriority = 'Medium') => {
        const weights = { 'Critical': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
        return weights[p];
    };

    const getPriorityColor = (p: TaskPriority = 'Medium') => {
        switch(p) {
            case 'Critical': return 'text-red-500 border-red-500 bg-red-950/30';
            case 'High': return 'text-orange-500 border-orange-500 bg-orange-950/30';
            case 'Low': return 'text-blue-400 border-blue-400 bg-blue-950/30';
            default: return 'text-green-500 border-green-500 bg-green-950/30';
        }
    }

    const sortedTasks = useMemo(() => {
        let filtered = tasks;
        if (filter === 'pending') filtered = tasks.filter(t => !t.completed);
        if (filter === 'completed') filtered = tasks.filter(t => t.completed);

        return [...filtered].sort((a, b) => {
            if (sortBy === 'priority') return getPriorityWeight(b.priority) - getPriorityWeight(a.priority);
            if (sortBy === 'dueDate') {
                if (!a.dueDate) return 1;
                if (!b.dueDate) return -1;
                return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
            }
            return a.text.localeCompare(b.text);
        });
    }, [tasks, filter, sortBy]);

    const handleAddTask = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newTaskText.trim()) return;
        const newTask: Task = {
            id: `task-${Date.now()}`,
            text: newTaskText.trim(),
            completed: false,
            dueDate: newDueDate || undefined,
            priority: newPriority,
        };
        onUpdateTasks([...tasks, newTask]);
        setNewTaskText('');
        setNewDueDate('');
        setIsCreating(false);
        playSound('success');
    };

    const handleUpdateTask = () => {
        if (!editingTask) return;
        onUpdateTasks(tasks.map(t => t.id === editingTask.id ? editingTask : t));
        setEditingTask(null);
        playSound('access');
    };

    const toggleTask = (id: string) => {
        playSound('click');
        onUpdateTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
    };

    const deleteTask = (id: string) => {
        onUpdateTasks(tasks.filter(t => t.id !== id));
        playSound('error');
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 hud-panel p-3 bg-black/40 flex flex-col gap-3">
                <div className="flex justify-between items-center">
                    <h2 className="text-sm font-black tracking-widest text-white flex items-center gap-2">
                        <ClipboardList size={16}/> OBJECTIVE MATRIX
                    </h2>
                    <button onClick={() => setIsCreating(true)} className="hud-button !py-1 !px-3 !text-[10px] flex items-center gap-1">
                        <Plus size={12}/> NEW DIRECTIVE
                    </button>
                </div>
                
                <div className="flex gap-2 text-[10px] font-black uppercase tracking-wider">
                    <button onClick={() => setFilter('all')} className={`px-2 py-1 border ${filter === 'all' ? 'border-[var(--color-primary)] text-[var(--color-primary)]' : 'border-gray-800 text-gray-500'}`}>ALL</button>
                    <button onClick={() => setFilter('pending')} className={`px-2 py-1 border ${filter === 'pending' ? 'border-[var(--color-primary)] text-[var(--color-primary)]' : 'border-gray-800 text-gray-500'}`}>PENDING</button>
                    <button onClick={() => setFilter('completed')} className={`px-2 py-1 border ${filter === 'completed' ? 'border-[var(--color-primary)] text-[var(--color-primary)]' : 'border-gray-800 text-gray-500'}`}>ARCHIVED</button>
                    <div className="ml-auto flex gap-2 items-center">
                        <span className="text-gray-600">SORT:</span>
                        <select value={sortBy} onChange={e => setSortBy(e.target.value as any)} className="bg-black text-white border-0 outline-none">
                            <option value="priority">PRIORITY</option>
                            <option value="dueDate">DEADLINE</option>
                            <option value="text">NAME</option>
                        </select>
                    </div>
                </div>
            </div>

            <div className="flex-1 bg-black/20 border border-[var(--color-panel-border)] rounded-md overflow-hidden relative">
                <div className="absolute inset-0 overflow-y-auto p-2 scrollbar-thin">
                    <div className="space-y-2">
                        {isCreating && (
                            <form onSubmit={handleAddTask} className="p-3 bg-black/80 border border-[var(--color-primary)] rounded space-y-3 animate-enter z-20 shadow-[0_0_20px_rgba(255,0,60,0.2)]">
                                <input 
                                    autoFocus
                                    type="text" 
                                    value={newTaskText} 
                                    onChange={e => setNewTaskText(e.target.value)} 
                                    placeholder="DEFINE OBJECTIVE..." 
                                    className="w-full bg-black border border-gray-700 p-2 text-sm text-white focus:border-[var(--color-primary)] outline-none" 
                                />
                                <div className="grid grid-cols-2 gap-2">
                                    <input type="datetime-local" value={newDueDate} onChange={e => setNewDueDate(e.target.value)} className="bg-black border border-gray-700 p-1.5 text-[10px] text-gray-300" />
                                    <select value={newPriority} onChange={e => setNewPriority(e.target.value as TaskPriority)} className="bg-black border border-gray-700 p-1.5 text-[10px] text-white">
                                        <option value="Low">LOW PRIORITY</option>
                                        <option value="Medium">MEDIUM</option>
                                        <option value="High">HIGH</option>
                                        <option value="Critical">CRITICAL</option>
                                    </select>
                                </div>
                                <div className="flex gap-2">
                                    <button type="submit" className="flex-1 bg-[var(--color-primary)] text-black font-black p-2 text-[10px]">INSTALL DIRECTIVE</button>
                                    <button type="button" onClick={() => setIsCreating(false)} className="flex-1 bg-gray-800 text-white p-2 text-[10px]">ABORT</button>
                                </div>
                            </form>
                        )}

                        {sortedTasks.map(task => (
                            <div key={task.id} className={`group p-3 bg-black/40 border border-gray-800 rounded flex items-center justify-between transition-all hover:border-gray-600 ${task.completed ? 'opacity-40 grayscale' : ''}`}>
                                <div className="flex items-center gap-3 flex-1">
                                    <button onClick={() => toggleTask(task.id)} className={`w-5 h-5 border flex items-center justify-center transition-colors ${task.completed ? 'bg-green-500 border-green-500 text-black' : 'border-gray-600 hover:border-[var(--color-primary)]'}`}>
                                        {task.completed && <Check size={14}/>}
                                    </button>
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-2">
                                            <span className={`text-sm font-bold ${task.completed ? 'line-through text-gray-500' : 'text-white'}`}>{task.text}</span>
                                            {task.priority && (
                                                <span className={`text-[7px] font-black px-1 border rounded ${getPriorityColor(task.priority)}`}>{task.priority.toUpperCase()}</span>
                                            )}
                                        </div>
                                        {task.dueDate && (
                                            <span className="text-[9px] text-gray-500 font-mono flex items-center gap-1 mt-0.5">
                                                <Clock size={8}/> {new Date(task.dueDate).toLocaleString()}
                                            </span>
                                        )}
                                    </div>
                                </div>
                                <button onClick={() => deleteTask(task.id)} className="text-gray-700 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-2">
                                    <Trash2 size={16}/>
                                </button>
                            </div>
                        ))}

                        {sortedTasks.length === 0 && !isCreating && (
                            <div className="h-64 flex flex-col items-center justify-center text-gray-700 font-black tracking-widest text-[10px] uppercase animate-pulse">
                                <ClipboardList size={40} className="mb-2 opacity-10"/>
                                No active directives found.
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TaskSchedulerPanel;
