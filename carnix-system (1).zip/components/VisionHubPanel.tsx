
import React, { useState, useRef } from 'react';
import { Loader2, UploadCloud, Send, Fingerprint, Search, Globe, ExternalLink, UserCheck, Film, Image as ImageIcon, FileVideo, Camera, X, Cpu, Activity, Zap, Lock } from 'lucide-react';
import { AIModelSettings, Message } from '../types';
import { playSound } from '../utils/soundEffects';
import CameraCapture from './CameraCapture';

interface VisionHubPanelProps {
    addMessage: (sender: 'user' | 'carnix' | 'system', text: string, urls?: Message['urls']) => void;
    aiSettings: AIModelSettings;
    getImageAnalysis: (base64Image: string, prompt: string, aiSettings: AIModelSettings) => Promise<{text: string, urls?: Message['urls']}>;
    getVideoAnalysis: (base64Video: string, mimeType: string, prompt: string, aiSettings: AIModelSettings) => Promise<{text: string, urls?: Message['urls']}>;
}

type VisionMode = 'IMAGE' | 'VIDEO' | 'DEEP_TRACE';

const VisionHubPanel: React.FC<VisionHubPanelProps> = ({ addMessage, aiSettings, getImageAnalysis, getVideoAnalysis }) => {
    const [mode, setMode] = useState<VisionMode>('IMAGE');
    const [analysisPrompt, setAnalysisPrompt] = useState('Describe this image in detail, identify objects, and provide a tactical overview.');
    const [analysisResult, setAnalysisResult] = useState<string | null>(null);
    const [analysisUrls, setAnalysisUrls] = useState<Message['urls']>(undefined);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [isCameraActive, setIsCameraActive] = useState(false);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [selectedFile, setSelectedFile] = useState<File | Blob | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleCapture = (data: string | Blob) => {
        if (typeof data === 'string') {
            setPreviewUrl(data);
            const byteString = atob(data.split(',')[1]);
            const mimeString = data.split(',')[0].split(':')[1].split(';')[0];
            const ab = new ArrayBuffer(byteString.length);
            const ia = new Uint8Array(ab);
            for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
            const blob = new Blob([ab], {type: mimeString});
            setSelectedFile(blob);
        } else {
            setPreviewUrl(URL.createObjectURL(data));
            setSelectedFile(data);
        }
        setIsCameraActive(false);
        playSound('success');
    };

    const handleAnalyze = async () => {
        if (!selectedFile || isAnalyzing) return;
        setIsAnalyzing(true);
        setAnalysisResult(null);
        playSound('scan');

        const reader = new FileReader();
        reader.readAsDataURL(selectedFile);
        reader.onloadend = async () => {
            const base64Data = (reader.result as string)?.split(',')[1];
            try {
                const result = mode === 'VIDEO' 
                    ? await getVideoAnalysis(base64Data, selectedFile.type, analysisPrompt, aiSettings)
                    : await getImageAnalysis(base64Data, analysisPrompt, aiSettings);
                
                setAnalysisResult(result.text);
                setAnalysisUrls(result.urls);
                playSound('success');
            } catch (error: any) {
                setAnalysisResult(`Analysis failed: ${error.message}`);
                playSound('error');
            } finally {
                setIsAnalyzing(false);
            }
        };
    };

    if (isCameraActive) {
        return (
            <div className="absolute inset-0 z-[1000] bg-black flex flex-col items-center justify-center">
                 <div className="absolute top-10 flex flex-col items-center gap-4">
                     <Lock size={32} className="text-red-600 animate-pulse" />
                     <p className="text-xs font-black text-white tracking-[0.3em] uppercase">Establishing Neural Camera Link</p>
                 </div>
                 <CameraCapture 
                    mode={mode === 'VIDEO' ? 'VIDEO' : 'PHOTO'} 
                    onCapture={handleCapture} 
                    onClose={() => setIsCameraActive(false)} 
                />
            </div>
        );
    }

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 max-w-5xl mx-auto font-[Rajdhani]">
             <div className="flex items-center gap-2 bg-black/30 border border-white/10 rounded-md p-1">
                <button onClick={() => setMode('IMAGE')} className={`flex-1 p-2 rounded text-xs font-bold transition-colors ${mode === 'IMAGE' ? 'bg-red-600 text-white' : 'bg-black/50'}`}>IMAGE</button>
                <button onClick={() => setMode('VIDEO')} className={`flex-1 p-2 rounded text-xs font-bold transition-colors ${mode === 'VIDEO' ? 'bg-red-600 text-white' : 'bg-black/50'}`}>VIDEO</button>
                <button onClick={() => setMode('DEEP_TRACE')} className={`flex-1 p-2 rounded text-xs font-bold transition-colors ${mode === 'DEEP_TRACE' ? 'bg-red-600 text-white' : 'bg-black/50'}`}>TRACE</button>
            </div>
            
            <div className="flex-1 flex flex-col md:flex-row gap-2 overflow-hidden">
                <div className="w-full md:w-5/12 flex flex-col bg-black/30 border border-white/10 rounded-md p-2 relative overflow-hidden">
                    <div className="flex-1 flex items-center justify-center bg-black/50 rounded overflow-hidden relative">
                        {previewUrl ? (
                            <img src={previewUrl} className="max-w-full max-h-full object-contain" alt="" />
                        ) : (
                            <div className="flex flex-col items-center opacity-20"><ImageIcon size={48}/><p className="text-[10px] uppercase font-black tracking-widest mt-4">Buffer Empty</p></div>
                        )}
                        {isAnalyzing && <div className="absolute inset-0 bg-red-600/20 backdrop-blur-sm animate-pulse z-10" />}
                    </div>
                    <div className="flex gap-2 mt-2">
                        <button onClick={() => setIsCameraActive(true)} className="flex-1 py-3 bg-red-600 text-black font-black text-xs uppercase flex items-center justify-center gap-2 rounded transition-all active:scale-95"><Camera size={16}/> Camera</button>
                        <button onClick={() => fileInputRef.current?.click()} className="flex-1 py-3 bg-white/5 border border-white/10 text-white font-black text-xs uppercase flex items-center justify-center gap-2 rounded"><UploadCloud size={16}/> Upload</button>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" onChange={e => handleCapture(e.target.files?.[0] || '')} />
                </div>

                <div className="w-full md:w-7/12 flex flex-col bg-black/30 border border-white/10 rounded-md p-3">
                     <textarea value={analysisPrompt} onChange={e => setAnalysisPrompt(e.target.value)} className="w-full h-20 bg-black/50 border border-white/10 rounded p-2 text-xs text-white focus:border-red-600 outline-none font-mono" />
                     <button onClick={handleAnalyze} disabled={!selectedFile || isAnalyzing} className="w-full py-3 bg-red-600 text-black font-black uppercase text-xs rounded my-2 disabled:opacity-50">
                        {isAnalyzing ? <Loader2 size={16} className="animate-spin inline mr-2"/> : <Zap size={16} className="inline mr-2"/>} Execute Analysis
                     </button>
                     <div className="flex-1 bg-black/40 p-4 rounded overflow-y-auto text-xs font-mono text-gray-300 border border-white/5">
                        {analysisResult || 'Awaiting visual uplink...'}
                     </div>
                </div>
            </div>
        </div>
    );
};

export default VisionHubPanel;
