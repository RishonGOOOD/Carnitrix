import React, { useEffect } from 'react';
import { Mic, MicOff } from 'lucide-react';
import { decode, decodeAudioData } from '../utils/audio';
import { Profile } from '../types';
import { DynamicLiveAudioCallbacks } from '../services/geminiService';

// FIX: This file was empty. The props interface is copied from AudioVoicePanel.tsx as it passes all its props down.
interface VoiceChatPanelProps {
    startSession: (isVoiceChat: boolean) => void;
    stopSession: () => void;
    isSessionActive: boolean;
    currentProfile: Profile;
    outputAudioContext: AudioContext | null;
    outputAudioSources: React.MutableRefObject<Set<AudioBufferSourceNode>>;
    nextStartTimeRef: React.MutableRefObject<number>;
    registerCallbacks: (callbacks: DynamicLiveAudioCallbacks) => void;
}

const VoiceChatPanel: React.FC<VoiceChatPanelProps> = ({ startSession, stopSession, isSessionActive, outputAudioContext, outputAudioSources, nextStartTimeRef, registerCallbacks }) => {
    
    useEffect(() => {
        const onOutputAudio = async (base64Audio: string) => {
            if (outputAudioContext && base64Audio) {
                try {
                    // Ensure context is running
                    if (outputAudioContext.state === 'suspended') {
                        await outputAudioContext.resume();
                    }
                    const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
                    const source = outputAudioContext.createBufferSource();
                    source.buffer = audioBuffer;
                    source.connect(outputAudioContext.destination);

                    const currentTime = outputAudioContext.currentTime;
                    const startTime = Math.max(currentTime, nextStartTimeRef.current);
                    source.start(startTime);
                    nextStartTimeRef.current = startTime + audioBuffer.duration;

                    outputAudioSources.current.add(source);
                    source.onended = () => {
                        outputAudioSources.current.delete(source);
                    };
                } catch (e) {
                    console.error("Error playing audio chunk:", e);
                }
            }
        };

        registerCallbacks({
            onOutputAudio: onOutputAudio,
            onInputTranscription: () => {}, // Not used in this panel
            onOutputTranscription: () => {}, // Not used in this panel
            onTurnComplete: () => {}, // Not used in this panel
            onInterrupt: () => {
                outputAudioSources.current.forEach(source => source.stop());
                outputAudioSources.current.clear();
                nextStartTimeRef.current = 0;
            },
            onError: (e) => console.error('Live session error:', e),
            onClose: () => console.log('Live session closed'),
        });
    }, [registerCallbacks, outputAudioContext, outputAudioSources, nextStartTimeRef]);

    const toggleSession = () => {
        if (isSessionActive) {
            stopSession();
        } else {
            startSession(true);
        }
    };

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-black/30 border border-[var(--color-panel-border)] rounded-md p-4">
            <div className="text-sm text-gray-400 mb-4">{isSessionActive ? 'LIVE VOICE CHANNEL OPEN' : 'VOICE CHANNEL STANDBY'}</div>
            <button onClick={toggleSession} className={`w-32 h-32 rounded-full flex items-center justify-center border-4 transition-all ${isSessionActive ? 'bg-red-500/20 border-red-500 text-red-400 animate-pulse' : 'bg-green-500/20 border-green-500 text-green-400'}`}>
                {isSessionActive ? <MicOff size={48} /> : <Mic size={48} />}
            </button>
            <div className="mt-4 text-xs font-mono">{isSessionActive ? 'Tap to disconnect' : 'Tap to connect'}</div>
        </div>
    );
};

export default VoiceChatPanel;
