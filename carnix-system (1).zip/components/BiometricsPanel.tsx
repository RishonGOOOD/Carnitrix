
import React, { useState, useEffect, useRef } from 'react';
import { HeartPulse, Brain, Activity, Droplets } from 'lucide-react';

const BiometricsPanel: React.FC = () => {
    const [heartRate, setHeartRate] = useState(72);
    const [cognitiveLoad, setCognitiveLoad] = useState(35);
    const [stressLevel, setStressLevel] = useState(15);
    const [hydration, setHydration] = useState(98);

    const heartDataRef = useRef<number[]>(new Array(100).fill(50));
    const brainDataRef = useRef<number[]>(new Array(100).fill(50));

    useEffect(() => {
        const interval = setInterval(() => {
            // Simulate vital sign fluctuations
            setHeartRate(hr => Math.max(60, Math.min(120, hr + (Math.random() - 0.5) * 4)));
            setCognitiveLoad(cl => Math.max(10, Math.min(90, cl + (Math.random() - 0.5) * 8)));
            setStressLevel(sl => Math.max(5, Math.min(80, sl + (Math.random() - 0.5) * 5)));
            setHydration(h => Math.max(80, Math.min(100, h - 0.1)));

            // Update graph data
            heartDataRef.current.push(50 + (heartRate - 75) * 0.5);
            heartDataRef.current.shift();
            brainDataRef.current.push(cognitiveLoad);
            brainDataRef.current.shift();
        }, 1000);
        return () => clearInterval(interval);
    }, [heartRate, cognitiveLoad]);

    const renderGraph = (data: number[], color: string) => (
        <svg viewBox="0 0 100 40" className="w-full h-full" preserveAspectRatio="none">
            <path d={`M 0 ${40 - data[0]/2.5} ` + data.map((p, i) => `L ${i+1} ${40 - p/2.5}`).join(' ')}
                  fill="none" stroke={color} strokeWidth="1"/>
        </svg>
    );

    const getStatusIndicator = (value: number, thresholds: { warn: number, high: number }) => {
        const color = value > thresholds.high ? 'bg-red-500' : value > thresholds.warn ? 'bg-yellow-500' : 'bg-green-500';
        return <div className={`w-3 h-3 rounded-full ${color}`}></div>;
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-black/30 border-l-4 border-red-500 rounded-r-md p-4">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                        <span>HEART RATE</span>
                        <HeartPulse size={16} />
                    </div>
                    <div className="text-4xl font-bold font-mono text-white">{Math.round(heartRate)} <span className="text-lg">BPM</span></div>
                    {getStatusIndicator(heartRate, { warn: 95, high: 110 })}
                </div>
                <div className="bg-black/30 border-l-4 border-blue-500 rounded-r-md p-4">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                        <span>COGNITIVE LOAD</span>
                        <Brain size={16} />
                    </div>
                    <div className="text-4xl font-bold font-mono text-white">{Math.round(cognitiveLoad)}<span className="text-lg">%</span></div>
                    {getStatusIndicator(cognitiveLoad, { warn: 60, high: 80 })}
                </div>
                <div className="bg-black/30 border-l-4 border-yellow-500 rounded-r-md p-4">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                        <span>STRESS LEVEL</span>
                        <Activity size={16} />
                    </div>
                    <div className="text-4xl font-bold font-mono text-white">{Math.round(stressLevel)}<span className="text-lg">%</span></div>
                     {getStatusIndicator(stressLevel, { warn: 50, high: 70 })}
                </div>
                 <div className="bg-black/30 border-l-4 border-cyan-500 rounded-r-md p-4">
                    <div className="flex justify-between items-center text-xs text-gray-400">
                        <span>HYDRATION</span>
                        <Droplets size={16} />
                    </div>
                    <div className="text-4xl font-bold font-mono text-white">{Math.round(hydration)}<span className="text-lg">%</span></div>
                     {getStatusIndicator(100-hydration, { warn: 10, high: 20 })}
                </div>
            </div>

            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 overflow-hidden">
                <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <h3 className="p-2 border-b border-gray-700 text-xs font-bold text-red-400">CARDIAC MONITOR (EKG)</h3>
                    <div className="flex-1 p-2 relative">
                        {renderGraph(heartDataRef.current, '#ef4444')}
                    </div>
                </div>
                <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col">
                    <h3 className="p-2 border-b border-gray-700 text-xs font-bold text-blue-400">NEURAL ACTIVITY (EEG)</h3>
                    <div className="flex-1 p-2">
                        {renderGraph(brainDataRef.current, '#3b82f6')}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BiometricsPanel;
