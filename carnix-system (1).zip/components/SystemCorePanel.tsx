
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Profile, SystemFeature, DiagnosticResult, NanobotSwarm } from '../types';
import { generateSystemFeature } from '../services/geminiService';
import { Cpu, Zap, Terminal, Loader2, CheckCircle2, Activity, Trash2, AlertTriangle, RefreshCw, ShieldCheck, Wrench, Shield, Box, Play, Pause, Power, TrendingUp, Atom, Brain } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { themes, crimsonEclipseTheme } from '../theme';

interface SystemCorePanelProps {
    profile: Profile;
    onUpdateProfile: (updates: Partial<Omit<Profile, 'id'>>) => void;
    addMessage: (sender: 'user' | 'carnix' | 'system', text: string) => void;
    isConnected: boolean;
    activeConnectionName?: string;
}

const SystemCorePanel: React.FC<SystemCorePanelProps> = ({ profile, onUpdateProfile, addMessage }) => {
    const [activeTab, setActiveTab] = useState<'EVOLUTION' | 'DIAGNOSTICS' | 'NANOTECH'>('EVOLUTION');
    const [isGenerating, setIsGenerating] = useState(false);
    
    // Calculate time until next evolution
    const nextEvolInfo = useMemo(() => {
        const twelveHoursInMs = 12 * 60 * 60 * 1000;
        const timeElapsedSinceStart = Date.now() - profile.nodeCreatedAt;
        const timeUntilNext = twelveHoursInMs - (timeElapsedSinceStart % twelveHoursInMs);
        
        const hours = Math.floor(timeUntilNext / (1000 * 60 * 60));
        const minutes = Math.floor((timeUntilNext % (1000 * 60 * 60)) / (1000 * 60));
        
        return { hours, minutes, progress: ((twelveHoursInMs - timeUntilNext) / twelveHoursInMs) * 100 };
    }, [profile.nodeCreatedAt]);

    return (
        <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani]">
            <div className="flex gap-4 border-b border-white/10 pb-2">
                <button onClick={() => { setActiveTab('EVOLUTION'); playSound('switch'); }} className={`px-4 py-2 text-xs font-black tracking-widest uppercase transition-all ${activeTab === 'EVOLUTION' ? 'text-[var(--color-primary)] border-b-2 border-[var(--color-primary)]' : 'text-gray-500 hover:text-white'}`}>AI Evolution</button>
                <button onClick={() => { setActiveTab('DIAGNOSTICS'); playSound('switch'); }} className={`px-4 py-2 text-xs font-black tracking-widest uppercase transition-all ${activeTab === 'DIAGNOSTICS' ? 'text-[var(--color-primary)] border-b-2 border-[var(--color-primary)]' : 'text-gray-500 hover:text-white'}`}>Diagnostics</button>
                <button onClick={() => { setActiveTab('NANOTECH'); playSound('switch'); }} className={`px-4 py-2 text-xs font-black tracking-widest uppercase transition-all ${activeTab === 'NANOTECH' ? 'text-[var(--color-primary)] border-b-2 border-[var(--color-primary)]' : 'text-gray-500 hover:text-white'}`}>Nanotech</button>
            </div>

            <div className="flex-1 overflow-hidden">
                {activeTab === 'EVOLUTION' && (
                    <div className="h-full grid grid-cols-1 md:grid-cols-2 gap-4 animate-enter">
                        {/* Status Card */}
                        <div className="jarvis-panel p-6 bg-black/40 flex flex-col gap-6">
                            <div className="flex items-center gap-4">
                                <div className="w-16 h-16 rounded-2xl bg-[var(--color-primary)]/10 border-2 border-[var(--color-primary)] flex items-center justify-center shadow-[0_0_20px_rgba(255,0,60,0.2)]">
                                    <Brain size={32} className="text-[var(--color-primary)]" />
                                </div>
                                <div>
                                    <h3 className="text-2xl font-black text-white uppercase italic">Neural Level {profile.aiEvolutionLevel}</h3>
                                    <p className="text-[10px] font-mono text-gray-500 tracking-widest uppercase">Self-Optimizing Protocol: Active</p>
                                </div>
                            </div>

                            <div className="bg-white/5 border border-white/5 p-4 rounded-lg">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Evolution Progress</span>
                                    <span className="text-xs font-mono text-[var(--color-primary)]">{Math.round(nextEvolInfo.progress)}%</span>
                                </div>
                                <div className="h-2 w-full bg-gray-900 rounded-full overflow-hidden border border-white/5">
                                    <div className="h-full bg-[var(--color-primary)] shadow-[0_0_10px_var(--color-primary)] transition-all duration-1000" style={{ width: `${nextEvolInfo.progress}%` }}></div>
                                </div>
                                <div className="mt-3 flex items-center justify-between text-[10px] font-mono text-gray-500">
                                    <span className="flex items-center gap-1"><RefreshCw size={10} className="animate-spin-slow" /> Next Phase:</span>
                                    <span className="text-white font-bold">{nextEvolInfo.hours}H {nextEvolInfo.minutes}M</span>
                                </div>
                            </div>

                            <div className="flex-1 space-y-4">
                                <p className="text-xs text-gray-400 leading-relaxed italic">
                                    CARNIX Neural Core utilizes a 12-hour recursive learning cycle. Every phase transition increases processing complexity, emotional depth, and tactical capability.
                                </p>
                                <div className="grid grid-cols-2 gap-2">
                                    <div className="p-3 bg-black/40 border border-gray-800 rounded">
                                        <div className="text-[8px] text-gray-600 uppercase font-black mb-1">Latency Gain</div>
                                        <div className="text-lg font-bold text-green-500">-{profile.aiEvolutionLevel * 2}ms</div>
                                    </div>
                                    <div className="p-3 bg-black/40 border border-gray-800 rounded">
                                        <div className="text-[8px] text-gray-600 uppercase font-black mb-1">Logic Depth</div>
                                        <div className="text-lg font-bold text-cyan-400">+{profile.aiEvolutionLevel * 10}%</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Special Abilities / Manifest */}
                        <div className="flex flex-col gap-4 overflow-hidden">
                            <div className="jarvis-panel flex-1 p-6 bg-black/40 overflow-hidden flex flex-col">
                                <h4 className="text-sm font-black text-white uppercase tracking-[0.2em] mb-4 flex items-center gap-2 border-b border-white/5 pb-2">
                                    <Atom size={16} className="text-cyan-400" /> Active Enhancements
                                </h4>
                                <div className="flex-1 overflow-y-auto space-y-3 scrollbar-thin pr-1">
                                    {profile.features.length === 0 ? (
                                        <div className="h-full flex flex-col items-center justify-center opacity-20 text-center gap-2">
                                            <Zap size={32} />
                                            <span className="text-[10px] uppercase font-black tracking-widest">No Active Augmentations</span>
                                        </div>
                                    ) : (
                                        profile.features.map(f => (
                                            <div key={f.id} className="p-3 border border-white/5 bg-white/5 rounded hover:border-[var(--color-primary)] transition-all group">
                                                <div className="flex justify-between items-start">
                                                    <span className="text-xs font-bold text-white uppercase">{f.name}</span>
                                                    <span className="text-[8px] font-mono text-gray-500 px-1 border border-gray-800 rounded">{f.type}</span>
                                                </div>
                                                <p className="text-[10px] text-gray-500 mt-1">{f.description}</p>
                                            </div>
                                        ))
                                    )}
                                </div>
                                <button 
                                    onClick={() => setIsGenerating(true)}
                                    className="w-full mt-4 p-3 bg-[var(--color-primary)] text-black font-black uppercase text-xs tracking-widest hover:bg-white transition-all shadow-[0_0_20px_rgba(255,0,60,0.3)] flex items-center justify-center gap-2"
                                >
                                    {isGenerating ? <Loader2 size={16} className="animate-spin" /> : <Zap size={16} />}
                                    Initiate Forced Evolution
                                </button>
                            </div>
                        </div>
                    </div>
                )}
                
                {/* Fallback to original tab content for others */}
                {activeTab !== 'EVOLUTION' && (
                    <div className="h-full flex items-center justify-center opacity-40 text-xs italic">
                        [Module Fragment: {activeTab} Online]
                    </div>
                )}
            </div>
        </div>
    );
};

export default SystemCorePanel;
