import React, { useState } from 'react';
import { 
    Github, Star, ExternalLink, Copy, Check, Terminal, 
    Search, Filter, Sparkles, Play, Code, Eye, MessageSquare, 
    Volume2, Image as ImageIcon, FileText, Cpu, ShieldAlert,
    Download, Layers, ArrowUpRight
} from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { Mode } from '../types';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';

export interface GithubRepoItem {
    name: string;
    repo: string;
    category: 'VISION' | 'OSINT' | 'LLM' | 'AUDIO' | 'GENERATIVE' | 'CODE' | 'OCR';
    stars: string;
    license: string;
    description: string;
    installCmd: string;
    quickTestMode?: Mode;
    tags: string[];
}

const GITHUB_REPOS: GithubRepoItem[] = [
    // 1. COMPUTER VISION & OBJECT RECOGNITION
    {
        name: 'Ultralytics YOLOv11 & YOLOv8',
        repo: 'ultralytics/ultralytics',
        category: 'VISION',
        stars: '46.8k',
        license: 'AGPL-3.0 / Enterprise',
        description: 'Real-time state-of-the-art object detection, image segmentation, pose estimation, and tracking with edge acceleration.',
        installCmd: 'pip install ultralytics\nyolo predict model=yolo11n.pt source="https://ultralytics.com/images/bus.jpg"',
        quickTestMode: Mode.ObjectRecognition,
        tags: ['Object Detection', 'YOLO', 'Edge AI', 'Tracking', 'PyTorch']
    },
    {
        name: 'Google MediaPipe',
        repo: 'google-ai-edge/mediapipe',
        category: 'VISION',
        stars: '27.4k',
        license: 'Apache-2.0',
        description: 'Cross-platform, ultra-fast customizable ML solutions for live streaming media (face mesh, hands, holistic, pose, object detection).',
        installCmd: 'npm install @mediapipe/tasks-vision\n# or pip install mediapipe',
        quickTestMode: Mode.ObjectRecognition,
        tags: ['Real-Time', 'On-Device', 'Pose', 'Hand Tracking', 'Face Mesh']
    },
    {
        name: 'Meta Segment Anything 2 (SAM 2)',
        repo: 'facebookresearch/segment-anything-2',
        category: 'VISION',
        stars: '22.1k',
        license: 'Apache-2.0',
        description: 'Foundation model for visual segmentation in images and video streams with zero-shot generalization and promptable mask generation.',
        installCmd: 'pip install git+https://github.com/facebookresearch/segment-anything-2.git',
        tags: ['Zero-Shot', 'Segmentation', 'Video AI', 'Foundation Model']
    },
    {
        name: 'Roboflow Supervision',
        repo: 'roboflow/supervision',
        category: 'VISION',
        stars: '21.5k',
        license: 'MIT',
        description: 'Reusable, modular computer vision utility toolkit for detection annotators, ByteTrack tracking, heatmaps, and polygon zones.',
        installCmd: 'pip install supervision[all]',
        quickTestMode: Mode.ObjectRecognition,
        tags: ['Tracking', 'Annotator', 'ByteTrack', 'Heatmaps']
    },
    {
        name: 'Depth Anything V2',
        repo: 'DepthAnything/Depth-Anything-V2',
        category: 'VISION',
        stars: '14.2k',
        license: 'Apache-2.0',
        description: 'Highly robust monocular depth estimation across complex indoor/outdoor lighting, generating metric 3D point clouds from single images.',
        installCmd: 'pip install -r requirements.txt\npython run.py --img-path assets/demo.png',
        tags: ['Depth Map', '3D Vision', 'Monocular', 'Sensors']
    },

    // 2. OSINT & CYBER RECONNAISSANCE
    {
        name: 'Sherlock Project',
        repo: 'sherlock-project/sherlock',
        category: 'OSINT',
        stars: '64.5k',
        license: 'MIT',
        description: 'Hunt down social media and developer accounts by username across 400+ public social networks and platforms simultaneously.',
        installCmd: 'git clone https://github.com/sherlock-project/sherlock.git\ncd sherlock\npython3 -m pip install -r requirements.txt\npython3 sherlock target_username',
        quickTestMode: Mode.DeepOsintAI,
        tags: ['Username OSINT', 'Social Recon', 'Fast Async', 'CLI']
    },
    {
        name: 'SpiderFoot OSINT Automation',
        repo: 'smicallef/spiderfoot',
        category: 'OSINT',
        stars: '15.8k',
        license: 'MIT',
        description: 'Automated OSINT collection tool integrating 200+ data sources to gather intelligence on IP addresses, domain names, e-mails, and ASN.',
        installCmd: 'git clone https://github.com/smicallef/spiderfoot.git\ncd spiderfoot\npip3 install -r requirements.txt\npython3 ./sf.py -l 127.0.0.1:5001',
        quickTestMode: Mode.DeepOsintAI,
        tags: ['Threat Intel', 'Automated OSINT', 'DNS/IP', 'Mapping']
    },
    {
        name: 'Holehe Email OSINT',
        repo: 'megadose/holehe',
        category: 'OSINT',
        stars: '6.8k',
        license: 'GPL-3.0',
        description: 'Checks if an email is attached to an account on sites like Twitter, Instagram, Discord, Imgur, and 120+ other services without alerting target.',
        installCmd: 'pip3 install holehe\nholehe target@domain.com',
        quickTestMode: Mode.DeepOsintAI,
        tags: ['Email Recon', 'Password Recovery', 'Breach Hunter']
    },
    {
        name: 'PhoneInfoga',
        repo: 'sundowndev/phoneinfoga',
        category: 'OSINT',
        stars: '12.6k',
        license: 'GPL-3.0',
        description: 'Advanced information gathering & OSINT framework for international phone numbers with carrier lookup, VoIP detection, and Google dorks.',
        installCmd: 'docker run --rm -it sundowndev/phoneinfoga scan -n "+14155552671"',
        quickTestMode: Mode.DeepOsintAI,
        tags: ['Telecom', 'Carrier Lookup', 'E.164', 'Fraud Prevention']
    },
    {
        name: 'theHarvester',
        repo: 'laramies/theHarvester',
        category: 'OSINT',
        stars: '11.4k',
        license: 'GPL-2.0',
        description: 'Gather e-mails, subdomains, open ports, employee names, and employee IPs from multiple public search engines, PGP keyservers, and Shodan.',
        installCmd: 'python3 -m pip install theHarvester\ntheHarvester -d target.com -b all',
        quickTestMode: Mode.DeepOsintAI,
        tags: ['Subdomain Enum', 'Reconnaissance', 'OSINT', 'Pentesting']
    },

    // 3. LLMs & INFERENCE ENGINES
    {
        name: 'Ollama',
        repo: 'ollama/ollama',
        category: 'LLM',
        stars: '122.3k',
        license: 'MIT',
        description: 'Get up and running with Llama 3.3, DeepSeek-R1, Mistral, and Qwen locally with automated GPU offloading and OpenAI-compatible API.',
        installCmd: 'curl -fsSL https://ollama.com/install.sh | sh\nollama run deepseek-r1:8b',
        quickTestMode: Mode.HFModelHub,
        tags: ['Local LLM', 'GPU Acceleration', 'DeepSeek', 'Llama 3']
    },
    {
        name: 'vLLM',
        repo: 'vllm-project/vllm',
        category: 'LLM',
        stars: '41.2k',
        license: 'Apache-2.0',
        description: 'High-throughput and low-latency LLM serving engine powered by PagedAttention with state-of-the-art serving throughput.',
        installCmd: 'pip install vllm\npython3 -m vllm.entrypoints.openai.api_server --model mistralai/Mistral-7B-Instruct-v0.3',
        tags: ['PagedAttention', 'Production Serving', 'Fast Inference']
    },
    {
        name: 'llama.cpp',
        repo: 'ggerganov/llama.cpp',
        category: 'LLM',
        stars: '78.5k',
        license: 'MIT',
        description: 'LLM inference in pure C/C++ without dependencies. Quantizes models to 4-bit/8-bit GGUF with lightning CPU/Metal/CUDA performance.',
        installCmd: 'git clone https://github.com/ggerganov/llama.cpp\ncd llama.cpp && cmake -B build && cmake --build build --config Release',
        tags: ['C++', 'GGUF', 'Quantization', 'Lightweight']
    },
    {
        name: 'DeepSeek-R1',
        repo: 'deepseek-ai/DeepSeek-R1',
        category: 'LLM',
        stars: '74.8k',
        license: 'MIT',
        description: 'Open-weights reasoning foundation model developed via large-scale reinforcement learning, matching OpenAI o1 on math, coding, and reasoning.',
        installCmd: 'ollama run deepseek-r1:14b',
        quickTestMode: Mode.Chat,
        tags: ['Reasoning', 'Open Weights', 'RL', 'o1 Competitor']
    },
    {
        name: 'Open WebUI',
        repo: 'open-webui/open-webui',
        category: 'LLM',
        stars: '72.6k',
        license: 'MIT',
        description: 'Extensible, feature-rich, and user-friendly self-hosted WebUI designed to operate entirely offline with Ollama and OpenAI-compatible APIs.',
        installCmd: 'docker run -d -p 3000:8080 --add-host=host.docker.internal:host-gateway -v open-webui:/app/backend/data --name open-webui --restart always ghcr.io/open-webui/open-webui:main',
        tags: ['Web UI', 'RAG', 'Self-Hosted', 'Offline']
    },

    // 4. AUDIO, SPEECH & VOICE
    {
        name: 'Whisper & Whisper.cpp',
        repo: 'openai/whisper',
        category: 'AUDIO',
        stars: '76.8k',
        license: 'MIT',
        description: 'General-purpose speech recognition model trained on 680,000 hours of multilingual data. Fast transcription and translation.',
        installCmd: 'pip install -U openai-whisper\nwhisper audio.mp3 --model turbo',
        quickTestMode: Mode.AudioVoice,
        tags: ['STT', 'Speech-to-Text', 'Multilingual', 'Whisper']
    },
    {
        name: 'Kokoro TTS (82M SOTA)',
        repo: 'hexgrad/kokoro',
        category: 'AUDIO',
        stars: '15.4k',
        license: 'Apache-2.0',
        description: 'Ultra-lightweight 82M open-weight text-to-speech model rivaling ElevenLabs in natural inflection, speed, and real-time streaming cadence.',
        installCmd: 'pip install kokoro>=0.8.4 soundfile\npython -c "from kokoro import KPipeline; p = KPipeline(lang_code=\'a\'); ..."',
        quickTestMode: Mode.AudioLab,
        tags: ['Ultra-Fast TTS', '82M Model', 'Natural Voice', 'Edge']
    },
    {
        name: 'Bark Audio Generation',
        repo: 'suno-ai/bark',
        category: 'AUDIO',
        stars: '36.2k',
        license: 'MIT',
        description: 'Transformer-based text-to-audio model capable of generating highly realistic speech, laughing, sighing, and ambient music.',
        installCmd: 'pip install git+https://github.com/suno-ai/bark.git',
        tags: ['Generative Audio', 'Music', 'Voice Synthesis']
    },

    // 5. GENERATIVE MEDIA & DIFFUSION
    {
        name: 'ComfyUI',
        repo: 'comfyanonymous/ComfyUI',
        category: 'GENERATIVE',
        stars: '65.2k',
        license: 'GPL-3.0',
        description: 'The most powerful and modular stable diffusion GUI and backend with a graph/nodes-based pipeline for SDXL, Flux, and animatediff.',
        installCmd: 'git clone https://github.com/comfyanonymous/ComfyUI.git\ncd ComfyUI && pip install -r requirements.txt\npython main.py',
        quickTestMode: Mode.Workspace,
        tags: ['Node Graph', 'Diffusion', 'Flux.1', 'SDXL', 'Workflows']
    },
    {
        name: 'Black Forest Labs FLUX.1',
        repo: 'black-forest-labs/flux',
        category: 'GENERATIVE',
        stars: '19.8k',
        license: 'Apache-2.0 / Non-Commercial',
        description: '12-billion parameter rectified flow transformer model generating photorealistic images, pristine typography, and anatomical accuracy.',
        installCmd: 'pip install diffusers transformers\n# Load flux-1-schnell via Diffusers',
        quickTestMode: Mode.Workspace,
        tags: ['Text-to-Image', '12B Transformer', 'Typography', 'SOTA']
    },

    // 6. CODE & AGENTIC FRAMEWORKS
    {
        name: 'Qwen2.5-Coder',
        repo: 'QwenLM/Qwen2.5-Coder',
        category: 'CODE',
        stars: '14.6k',
        license: 'Apache-2.0',
        description: 'State-of-the-art open-source code LLM series matching GPT-4o on coding evaluations, supporting 92 programming languages and 128k context.',
        installCmd: 'ollama run qwen2.5-coder:7b',
        quickTestMode: Mode.CodeAssistant,
        tags: ['Code Generation', 'Debugging', '128k Context', 'Open Source']
    },
    {
        name: 'LangChain & LangGraph',
        repo: 'langchain-ai/langchain',
        category: 'CODE',
        stars: '104.2k',
        license: 'MIT',
        description: 'Build context-aware, reasoning AI applications, RAG pipelines, and multi-agent cyclic computational graphs.',
        installCmd: 'pip install langchain langgraph langchain-community',
        tags: ['AI Agents', 'RAG', 'Chains', 'Multi-Agent']
    },

    // 7. OCR & DOCUMENT EXTRACTION
    {
        name: 'Tesseract.js',
        repo: 'naptha/tesseract.js',
        category: 'OCR',
        stars: '36.1k',
        license: 'Apache-2.0',
        description: 'Pure JavaScript port of the popular Tesseract OCR engine, running optical character recognition in browser WebWorkers and Node.js.',
        installCmd: 'npm install tesseract.js\n# or use directly in browser',
        tags: ['Browser OCR', 'Client-Side', 'Multi-Language', 'WASM']
    },
    {
        name: 'Docling Document Parser',
        repo: 'DS4SD/docling',
        category: 'OCR',
        stars: '18.4k',
        license: 'MIT',
        description: 'Parses complex PDFs, DOCX, PPTX into structured clean Markdown and JSON, preserving table structures, formulas, and document layouts.',
        installCmd: 'pip install docling\ndocling https://arxiv.org/pdf/2408.09869',
        tags: ['PDF to Markdown', 'Table Extraction', 'Doc AI']
    }
];

export const FreeAiGithubHubPanel: React.FC = () => {
    const { dispatch } = useAppContext();
    const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
    const [searchQuery, setSearchQuery] = useState('');
    const [copiedIndex, setCopiedIndex] = useState<string | null>(null);

    // AI Query Recommender
    const [assistantQuery, setAssistantQuery] = useState('');
    const [assistantLoading, setAssistantLoading] = useState(false);
    const [assistantRecommendation, setAssistantRecommendation] = useState<string | null>(null);

    const categories = [
        { id: 'ALL', label: 'ALL REPOSITORIES', count: GITHUB_REPOS.length },
        { id: 'VISION', label: 'COMPUTER VISION', count: GITHUB_REPOS.filter(r => r.category === 'VISION').length },
        { id: 'OSINT', label: 'OSINT & RECON', count: GITHUB_REPOS.filter(r => r.category === 'OSINT').length },
        { id: 'LLM', label: 'LLM & REASONING', count: GITHUB_REPOS.filter(r => r.category === 'LLM').length },
        { id: 'AUDIO', label: 'SPEECH & AUDIO', count: GITHUB_REPOS.filter(r => r.category === 'AUDIO').length },
        { id: 'GENERATIVE', label: 'MEDIA & DIFFUSION', count: GITHUB_REPOS.filter(r => r.category === 'GENERATIVE').length },
        { id: 'CODE', label: 'CODE & AGENTS', count: GITHUB_REPOS.filter(r => r.category === 'CODE').length },
        { id: 'OCR', label: 'OCR & DOCS', count: GITHUB_REPOS.filter(r => r.category === 'OCR').length }
    ];

    const filteredRepos = GITHUB_REPOS.filter(repo => {
        if (selectedCategory !== 'ALL' && repo.category !== selectedCategory) return false;
        if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase();
            return (
                repo.name.toLowerCase().includes(q) ||
                repo.repo.toLowerCase().includes(q) ||
                repo.description.toLowerCase().includes(q) ||
                repo.tags.some(t => t.toLowerCase().includes(q))
            );
        }
        return true;
    });

    const copyToClipboard = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopiedIndex(id);
        playSound('click');
        setTimeout(() => setCopiedIndex(null), 2000);
    };

    const handleAskAi = async () => {
        if (!assistantQuery.trim()) return;
        setAssistantLoading(true);
        setAssistantRecommendation(null);
        playSound('process');

        try {
            const prompt = `As a senior AI open-source systems architect, recommend the best 100% free open-source GitHub AI repositories for this requirement: "${assistantQuery}".
Explain:
1. Top recommended GitHub Repo & why it fits best
2. Exact pip/git/docker command to run it
3. Practical advice or configuration tips.
Keep it sharp, tactical, and practical.`;

            const res = await getAIResponse(prompt, Mode.FreeAiGithubHub, {
                directive: 'You are the CARNIX Open Source AI Substrate Architect. Recommend free GitHub AI tools.',
                temperature: 0.3
            } as any);

            setAssistantRecommendation(res.text);
            playSound('success');
        } catch (e: any) {
            setAssistantRecommendation(`Substrate query failed: ${e.message}`);
            playSound('error');
        } finally {
            setAssistantLoading(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-mono text-xs overflow-hidden">
            {/* Top Hub Bar */}
            <div className="hud-panel p-3 flex flex-wrap items-center justify-between gap-3 border border-red-500/30 bg-black/80">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-red-600/10 border border-red-500/40 rounded-lg text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]">
                        <Github size={18} />
                    </div>
                    <div>
                        <div className="flex items-center gap-2">
                            <h2 className="text-sm font-black tracking-wider text-red-400">FREE OPEN-SOURCE AI GITHUB REPOSITORY HUB</h2>
                            <span className="px-2 py-0.5 bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 text-[10px] font-bold rounded">
                                100% FREE & OPEN-WEIGHTS
                            </span>
                        </div>
                        <p className="text-[11px] text-gray-400">Curated industrial open-source AI frameworks across Vision, OSINT, LLM, Audio, Diffusion & Code</p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <div className="relative">
                        <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)}
                            placeholder="Search repos, models, tags..."
                            className="bg-black/90 border border-red-900/60 focus:border-red-400 rounded pl-8 pr-3 py-1.5 text-[11px] text-white placeholder-gray-500 focus:outline-none w-48 sm:w-64"
                        />
                    </div>
                </div>
            </div>

            {/* AI Repository Recommender Drawer */}
            <div className="hud-panel p-3 border border-purple-500/30 bg-purple-950/10 space-y-2">
                <div className="flex items-center justify-between">
                    <span className="text-purple-300 font-bold flex items-center gap-1.5 text-[11px]">
                        <Sparkles size={13} />
                        AI SUBSTRATE RECOMMENDER (GEMINI MATCH ENGINE)
                    </span>
                    <span className="text-[10px] text-gray-500">Need a model for an exact task? Type it below:</span>
                </div>
                <div className="flex items-center gap-2">
                    <input
                        type="text"
                        value={assistantQuery}
                        onChange={e => setAssistantQuery(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && handleAskAi()}
                        placeholder="e.g. 'I need a model to run real-time license plate OCR on a Raspberry Pi' or 'extract tables from PDFs'..."
                        className="flex-1 bg-black/80 border border-purple-900/60 rounded px-3 py-1.5 text-[11px] text-white placeholder-gray-500 focus:outline-none focus:border-purple-400"
                    />
                    <button
                        onClick={handleAskAi}
                        disabled={assistantLoading || !assistantQuery.trim()}
                        className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 disabled:bg-purple-950 text-white font-bold rounded text-[11px] transition-all flex items-center gap-1.5 active:scale-95 shadow-[0_0_15px_rgba(168,85,247,0.3)]"
                    >
                        <Sparkles size={12} className={assistantLoading ? 'animate-spin' : ''} />
                        <span>{assistantLoading ? 'MATCHING...' : 'FIND REPOS'}</span>
                    </button>
                </div>

                {assistantRecommendation && (
                    <div className="p-3 bg-black/80 border border-purple-500/40 rounded text-gray-200 text-[11px] whitespace-pre-line leading-relaxed max-h-48 overflow-y-auto scrollbar-carnix">
                        {assistantRecommendation}
                    </div>
                )}
            </div>

            {/* Category Filter Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {categories.map(cat => (
                    <button
                        key={cat.id}
                        onClick={() => {
                            setSelectedCategory(cat.id);
                            playSound('click');
                        }}
                        className={`px-3 py-1 rounded text-[10px] font-bold tracking-wider flex-shrink-0 transition-all ${
                            selectedCategory === cat.id
                                ? 'bg-red-600 text-white shadow-[0_0_12px_rgba(239,68,68,0.4)]'
                                : 'bg-black/60 border border-red-950/60 text-gray-400 hover:text-white hover:border-red-600/40'
                        }`}
                    >
                        {cat.label} ({cat.count})
                    </button>
                ))}
            </div>

            {/* Repositories Bento Grid */}
            <div className="flex-1 min-h-0 overflow-y-auto scrollbar-carnix pr-1">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pb-4">
                    {filteredRepos.map((repo, idx) => (
                        <div
                            key={repo.repo}
                            className="hud-panel p-4 border border-red-500/20 bg-black/80 hover:border-red-500/50 rounded-lg flex flex-col justify-between transition-all group"
                        >
                            <div className="space-y-2">
                                {/* Header: Title + Star + Link */}
                                <div className="flex items-start justify-between gap-2">
                                    <div>
                                        <h3 className="font-bold text-white text-sm group-hover:text-red-400 transition-colors">
                                            {repo.name}
                                        </h3>
                                        <div className="text-[11px] text-red-500/90 font-mono mt-0.5">
                                            {repo.repo}
                                        </div>
                                    </div>
                                    <a
                                        href={`https://github.com/${repo.repo}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="p-1.5 bg-black/60 border border-red-900/40 hover:border-red-400 text-gray-400 hover:text-white rounded transition-all"
                                        title="Open GitHub Repository"
                                    >
                                        <ArrowUpRight size={14} />
                                    </a>
                                </div>

                                {/* Badges */}
                                <div className="flex items-center gap-2 text-[10px]">
                                    <span className="px-2 py-0.5 bg-yellow-950/40 border border-yellow-500/40 text-yellow-400 font-bold rounded flex items-center gap-1">
                                        <Star size={10} className="fill-yellow-400" />
                                        {repo.stars}
                                    </span>
                                    <span className="px-2 py-0.5 bg-black/60 border border-gray-700 text-gray-400 rounded">
                                        {repo.license}
                                    </span>
                                    <span className="px-2 py-0.5 bg-red-950/30 border border-red-900/40 text-red-400 font-bold rounded">
                                        {repo.category}
                                    </span>
                                </div>

                                {/* Description */}
                                <p className="text-[11px] text-gray-300 leading-relaxed line-clamp-3">
                                    {repo.description}
                                </p>

                                {/* Tags */}
                                <div className="flex flex-wrap gap-1 pt-1">
                                    {repo.tags.map(t => (
                                        <span key={t} className="px-1.5 py-0.5 bg-black/60 border border-red-950/80 text-gray-500 text-[9px] rounded">
                                            #{t}
                                        </span>
                                    ))}
                                </div>
                            </div>

                            {/* Actions footer */}
                            <div className="pt-3 mt-3 border-t border-red-950/60 flex items-center justify-between gap-2">
                                <button
                                    onClick={() => copyToClipboard(repo.installCmd, repo.repo)}
                                    className="px-2.5 py-1 rounded bg-black/60 border border-red-900/50 hover:border-red-400 text-gray-300 hover:text-white text-[10px] flex items-center gap-1.5 transition-all"
                                    title="Copy Installation Command"
                                >
                                    {copiedIndex === repo.repo ? (
                                        <>
                                            <Check size={11} className="text-emerald-400" />
                                            <span className="text-emerald-400 font-bold">COPIED</span>
                                        </>
                                    ) : (
                                        <>
                                            <Terminal size={11} className="text-red-400" />
                                            <span>COPY COMMAND</span>
                                        </>
                                    )}
                                </button>

                                {repo.quickTestMode && (
                                    <button
                                        onClick={() => {
                                            dispatch({ type: 'SET_MODE', payload: repo.quickTestMode! });
                                            playSound('click');
                                        }}
                                        className="px-3 py-1 rounded bg-red-600 hover:bg-red-500 text-white font-bold text-[10px] flex items-center gap-1 shadow-[0_0_12px_rgba(239,68,68,0.3)] transition-all"
                                    >
                                        <Play size={10} className="fill-white" />
                                        <span>RUN IN CARNIX</span>
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default FreeAiGithubHubPanel;
