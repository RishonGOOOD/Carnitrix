


import React, { useState } from 'react';
import { Search, Globe, Loader2, ExternalLink } from 'lucide-react';
import { useAppContext } from '../context';
import { getWebIntelligenceReport } from '../services/geminiService';
import { Message } from '../types';
import { playSound } from '../utils/soundEffects';

const WebIntelligencePanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [topic, setTopic] = useState('');
    const [report, setReport] = useState<string | null>(null);
    const [urls, setUrls] = useState<Message['urls']>(undefined);
    const [isLoading, setIsLoading] = useState(false);

    const handleGenerateReport = async () => {
        if (!topic.trim() || !activeProfile) return;
        setIsLoading(true);
        setReport(null);
        setUrls(undefined);
        playSound('process');
        try {
            const res = await getWebIntelligenceReport(activeProfile.aiSettings, topic);
            setReport(res.text);
            setUrls(res.urls);
            playSound('success');
        } catch (e: any) {
            setReport(`Error gathering intelligence: ${e.message}`);
            playSound('error');
        }
        setIsLoading(false);
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3">
                <form onSubmit={(e) => { e.preventDefault(); handleGenerateReport(); }} className="flex gap-2">
                    <input
                        type="text"
                        value={topic}
                        onChange={e => setTopic(e.target.value)}
                        placeholder="Enter research topic for deep analysis..."
                        className="flex-1 bg-black/50 border border-gray-700 rounded px-3 py-2 text-sm focus:outline-none focus:border-[var(--color-primary)]"
                        disabled={isLoading}
                    />
                    <button type="submit" disabled={isLoading || !topic.trim()} className="p-3 bg-[var(--color-primary)]/20 text-[var(--color-primary)] rounded hover:bg-[var(--color-primary)] hover:text-black transition-colors flex items-center justify-center gap-2">
                        {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
                    </button>
                </form>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden">
                <h3 className="p-2 border-b border-gray-700 text-sm font-bold text-white flex items-center gap-2">
                    <Globe size={16} className="text-blue-400"/> WEB INTELLIGENCE REPORT
                </h3>
                <div className="flex-1 overflow-y-auto p-4 relative">
                    {isLoading ? (
                        <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-10">
                            <Loader2 size={32} className="animate-spin text-[var(--color-primary)] mb-2" />
                            <p className="text-sm text-gray-400">Compiling data from web sources...</p>
                        </div>
                    ) : (
                        report ? (
                            <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-gray-300">
                               {report}
                               {urls && urls.length > 0 && (
                                    <div className="mt-6 border-t border-white/20 pt-4">
                                        <h4 className="font-bold text-gray-400 mb-2">Cited Sources:</h4>
                                        <div className="space-y-2">
                                            {urls.map((url, i) => (
                                                 <a key={i} href={url.uri} target="_blank" rel="noreferrer" className="block text-blue-400 hover:underline text-xs truncate">
                                                    <ExternalLink size={12} className="inline-block mr-1"/>
                                                    {url.title || url.uri}
                                                </a>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center h-full text-gray-500 text-center">
                                <p>Enter a topic to generate a report.</p>
                            </div>
                        )
                    )}
                </div>
            </div>
        </div>
    );
};

export default WebIntelligencePanel;