
import React from 'react';

interface FlightHUDProps {
    pitch: number;
    roll: number;
    altitude: number;
    speed: number;
    heading: number;
}

const FlightHUD: React.FC<FlightHUDProps> = ({ pitch, roll, altitude, speed, heading }) => {
    // Pitch lines calculation
    const pitchPixels = pitch * 5; // 5 pixels per degree approx

    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden text-green-500 font-mono text-xs select-none">
            {/* Crosshair */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 border border-green-500/50 rounded-full flex items-center justify-center">
                <div className="w-1 h-1 bg-green-500 rounded-full"></div>
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-[1px] bg-green-500/30"></div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1px] h-20 bg-green-500/30"></div>

            {/* Artificial Horizon / Pitch Ladder */}
            <div 
                className="absolute top-1/2 left-1/2 w-64 h-64 border-l border-r border-green-500/20"
                style={{ 
                    transform: `translate(-50%, -50%) rotate(${-roll}deg)` 
                }}
            >
                <div 
                    className="absolute left-0 right-0 flex flex-col items-center justify-center transition-transform duration-100 ease-linear"
                    style={{ transform: `translateY(${pitchPixels}px)` }}
                >
                    {/* Horizon Line */}
                    <div className="w-full h-[2px] bg-green-500 flex items-center justify-between px-2">
                        <span className="text-[10px] -mt-4">0</span>
                        <span className="text-[10px] -mt-4">0</span>
                    </div>
                    
                    {/* Ladder Lines */}
                    {[-10, -20, -30, 10, 20, 30].map(deg => (
                        <div key={deg} className="absolute w-32 border-t border-green-500/50 flex justify-between px-1" style={{ top: deg > 0 ? `${-deg * 5}px` : `${-deg * 5}px` }}>
                            <span className="text-[8px]">{Math.abs(deg)}</span>
                            <span className="text-[8px]">{Math.abs(deg)}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* Altitude Tape (Right) */}
            <div className="absolute right-10 top-1/4 bottom-1/4 w-12 border-l border-green-500/50 bg-black/20 flex flex-col items-end overflow-hidden mask-fade">
                <div className="absolute top-1/2 right-0 w-3 h-[2px] bg-green-500"></div>
                <div className="w-full text-right pr-2 py-1 transition-transform duration-300" style={{ transform: `translateY(${((altitude % 100) / 100) * 20}px)` }}>
                    {Array.from({length: 20}).map((_, i) => {
                        const val = Math.floor(altitude / 100) * 100 + (10 - i) * 10;
                        return <div key={i} className="h-6 flex items-center justify-end">{val}</div>
                    })}
                </div>
                <div className="absolute top-1/2 right-4 bg-black border border-green-500 px-1 text-sm font-bold -translate-y-1/2">{Math.round(altitude)}</div>
            </div>

            {/* Speed Tape (Left) */}
            <div className="absolute left-10 top-1/4 bottom-1/4 w-12 border-r border-green-500/50 bg-black/20 flex flex-col overflow-hidden mask-fade">
                <div className="absolute top-1/2 left-0 w-3 h-[2px] bg-green-500"></div>
                <div className="w-full pl-2 py-1 transition-transform duration-300" style={{ transform: `translateY(${((speed % 10) / 10) * 20}px)` }}>
                     {Array.from({length: 20}).map((_, i) => {
                        const val = Math.floor(speed / 10) * 10 + (10 - i) * 5;
                        return <div key={i} className="h-6 flex items-center">{val >= 0 ? val : ''}</div>
                    })}
                </div>
                <div className="absolute top-1/2 left-4 bg-black border border-green-500 px-1 text-sm font-bold -translate-y-1/2">{Math.round(speed)}</div>
            </div>

            {/* Heading Tape (Top) */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-64 h-8 border-b border-green-500/50 overflow-hidden bg-black/20">
                <div className="absolute bottom-0 left-1/2 w-[2px] h-3 bg-green-500 -translate-x-1/2"></div>
                <div className="flex items-end h-full transition-transform duration-200" style={{ transform: `translateX(${-heading * 2}px)` }}>
                    {Array.from({length: 73}).map((_, i) => ( // 0 to 360 step 5
                        <div key={i} className="flex-shrink-0 w-[10px] flex flex-col items-center justify-end h-full">
                            <div className={`w-[1px] ${i % 9 === 0 ? 'h-4 bg-green-500' : 'h-2 bg-green-500/50'}`}></div>
                            {i % 9 === 0 && <span className="text-[8px] absolute top-0">{i * 5}</span>}
                        </div>
                    ))}
                </div>
            </div>
            
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-center">
                <div className="text-[10px] uppercase tracking-widest text-green-500/70">Drone Telemetry Link</div>
                <div className="text-sm font-bold">MODE: STABILIZED</div>
            </div>
        </div>
    );
};

export default FlightHUD;
