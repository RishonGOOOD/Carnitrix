
import React, { useState } from 'react';
import { MessageSquare, Send, User, Shield, Lock } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const Android_SmsRelayPanel: React.FC = () => {
    const [messages, setMessages] = useState([
        { id: 1, sender: 'OPERATOR', text: 'Secure frequency established.', type: 'out' },
        { id: 2, sender: 'NODE_X', text: 'Packet received. Initiating ghost handshake.', type: 'in' }
    ]);
    const [input, setInput] = useState('');

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim()) return;
        setMessages(prev => [...prev, { id: Date.now(), sender: 'OPERATOR', text: input, type: 'out' }]);
        setInput('');
        playSound('success');
        
        setTimeout(() => {
            setMessages(prev => [...prev, { id: Date.now()+1, sender: 'NODE_X', text: 'ACK_SECURE_RECEPTION_0x'+Math.random().toString(16).slice(2,6), type: 'in' }]);
            playSound('alert');
        }, 1500);
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 bg-black/40 border border-white/10 p-4 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <MessageSquare size={24} className="text-green-500" />
                    <div>
                        <h2 className="text-lg font-black text-white uppercase italic">Ghost Link Relay</h2>
                        <p className="text-[9px] font-mono text-gray-500">GSM/LTE Tunneling // End-to-End Encrypted</p>
                    </div>
                </div>
                <div className="flex items-center gap-2 text-green-500">
                    <Lock size={14}/>
                    <span className="text-[10px] font-black uppercase tracking-widest">Active Tunnel</span>
                </div>
            </div>

            <div className="flex-1 bg-black/30 border border-white/5 rounded-lg overflow-y-auto p-4 space-y-4 scrollbar-carnix">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.type === 'out' ? 'justify-end' : 'justify-start'} animate-enter`}>
                        <div className={`max-w-[80%] p-3 rounded border ${msg.type === 'out' ? 'bg-green-900/10 border-green-500 text-white' : 'bg-white/5 border-white/10 text-gray-300'}`}>
                            <div className="text-[8px] font-bold text-gray-500 mb-1 uppercase tracking-tighter">{msg.sender}</div>
                            <div className="text-sm">{msg.text}</div>
                        </div>
                    </div>
                ))}
            </div>

            <form onSubmit={handleSend} className="p-2 bg-black/60 border border-white/10 rounded-lg flex gap-2">
                <input 
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    placeholder="Enter encrypted transmission..."
                    className="flex-1 bg-black/40 border border-white/10 p-3 text-xs outline-none focus:border-green-500 text-white font-mono"
                />
                <button type="submit" className="p-3 bg-green-600 text-black rounded hover:bg-white transition-all">
                    <Send size={20} />
                </button>
            </form>
        </div>
    );
};

export default Android_SmsRelayPanel;
