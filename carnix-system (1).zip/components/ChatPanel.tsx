import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Message, ChatSession, Mode } from '../types';
import { Send, Loader2, Bot, User, Mic, FolderOpen, Plus, FileText, Download, Trash2, ChevronLeft, HardDrive, Cpu } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound, triggerHaptic } from '../utils/soundEffects';

interface ChatPanelProps {
    messages: Message[];
    onChatSubmit: (prompt: string) => void;
    isLoading: boolean;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ onChatSubmit, isLoading }) => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const [input, setInput] = useState('');
    const [view, setView] = useState<'CHAT' | 'LOGS'>('CHAT');
    const endRef = useRef<HTMLDivElement>(null);

    const chats = activeProfile?.chats || [];
    const activeChatId = activeProfile?.activeChatId;
    const activeChat = useMemo(() => chats.find(c => c.id === activeChatId), [chats, activeChatId]);

    useEffect(() => { 
        if (view === 'CHAT') endRef.current?.scrollIntoView({ behavior: 'smooth' }); 
    }, [activeChat?.messages, isLoading, view]);

    const handleNewChat = () => {
        const newChat: ChatSession = {
            id: `log-${Date.now()}`,
            title: `TACTICAL_LOG_${chats.length + 1}`,
            createdAt: Date.now(),
            messages: [{ id: Date.now(), sender: 'carnix', text: "NEURAL_LINK_ESTABLISHED. AWAITING MASTER COMMAND." }]
        };
        dispatch({ type: 'UPDATE_PROFILE', payload: { 
            chats: [newChat, ...chats],
            activeChatId: newChat.id
        }});
        setView('CHAT');
        playSound('success');
    };

    const deleteChat = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        const updated = chats.filter(c => c.id !== id);
        dispatch({ type: 'UPDATE_PROFILE', payload: { 
            chats: updated,
            activeChatId: activeChatId === id ? undefined : activeChatId
        }});
        playSound('error');
    };

    const exportToMobile = (chat: ChatSession) => {
        const content = chat.messages.map(m => `[${new Date(m.id).toLocaleTimeString()}] ${m.sender.toUpperCase()}: ${m.text}`).join('\n\n');
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${chat.title.toLowerCase()}.log`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        playSound('success');
    };

    const submit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading || !activeChatId) return;
        
        const userMsg = { id: Date.now(), sender: 'user', text: input.trim() };
        const updatedChats = chats.map(c => 
            c.id === activeChatId ? { ...c, messages: [...c.messages, userMsg] } : c
        );
        dispatch({ type: 'UPDATE_PROFILE', payload: { chats: updatedChats }});
        
        onChatSubmit(input.trim());
        setInput('');
        playSound('click');
        triggerHaptic('light');
    };

    if (view === 'LOGS') {
        return (
            <div className="w-full h-full flex flex-col bg-black/60 rounded-3xl border border-white/5 font-[Rajdhani] animate-enter overflow-hidden">
                <div className="p-6 border-b border-white/10 flex justify-between items-center bg-black/40 backdrop-blur-xl">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-yellow-500/10 rounded-xl">
                            <FolderOpen size={32} className="text-yellow-500" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-black text-white uppercase italic tracking-widest leading-none">Logs Folder</h2>
                            <p className="text-[10px] font-mono text-gray-500 uppercase mt-1">/root/carnix/logs/</p>
                        </div>
                    </div>
                    <button onClick={() => setView('CHAT')} className="p-4 bg-white/5 border-2 border-white/10 rounded-2xl text-gray-400 hover:text-white transition-all active:scale-90">
                        <ChevronLeft size={24}/>
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-carnix">
                    <button onClick={handleNewChat} className="w-full p-8 border-2 border-dashed border-red-600/30 rounded-[2rem] flex flex-col items-center justify-center gap-4 text-red-500 hover:bg-red-600/10 hover:border-red-600/60 transition-all group">
                        <Plus size={44} className="group-hover:scale-110 transition-transform" />
                        <span className="font-black text-sm uppercase tracking-[0.4em]">Initialize Session</span>
                    </button>

                    {chats.map(chat => (
                        <div 
                            key={chat.id}
                            onClick={() => { dispatch({ type: 'UPDATE_PROFILE', payload: { activeChatId: chat.id }}); setView('CHAT'); playSound('click'); }}
                            className={`p-6 rounded-[2rem] border-2 transition-all flex items-center justify-between group cursor-pointer ${activeChatId === chat.id ? 'border-red-600 bg-red-950/20 shadow-[0_0_20px_rgba(255,0,0,0.1)]' : 'border-white/5 bg-white/5 hover:border-white/20'}`}
                        >
                            <div className="flex items-center gap-6">
                                <div className={`p-4 rounded-2xl ${activeChatId === chat.id ? 'bg-red-600 text-black shadow-lg' : 'bg-black text-gray-600'}`}>
                                    <FileText size={28} />
                                </div>
                                <div>
                                    <div className="text-lg font-black text-white uppercase tracking-tight">{chat.title}</div>
                                    <div className="text-[10px] font-mono text-gray-500 uppercase flex gap-4 mt-1">
                                        <span>{chat.messages.length} PKTS</span>
                                        <span>{new Date(chat.createdAt).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={(e) => { e.stopPropagation(); exportToMobile(chat); }} className="p-3.5 bg-cyan-500/10 text-cyan-500 border border-cyan-500/30 rounded-2xl hover:bg-cyan-500 hover:text-black transition-all">
                                    <Download size={22}/>
                                </button>
                                <button onClick={(e) => deleteChat(e, chat.id)} className="p-3.5 bg-red-500/10 text-red-500 border border-red-500/30 rounded-2xl hover:bg-red-600 hover:text-white transition-all">
                                    <Trash2 size={22}/>
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    return (
        <div className="w-full h-full flex flex-col bg-black/40 rounded-[2.5rem] border border-white/5 overflow-hidden font-[Rajdhani] relative">
            <div className="flex-shrink-0 bg-black/80 border-b border-white/5 p-5 flex justify-between items-center z-20 backdrop-blur-3xl">
                <div className="flex items-center gap-5">
                    <div className="w-12 h-12 bg-red-600 rounded-2xl flex items-center justify-center shadow-[0_0_25px_rgba(255,0,0,0.5)]">
                        <Bot size={28} className="text-black animate-pulse" />
                    </div>
                    <div>
                        <span className="text-sm font-black text-white tracking-widest uppercase block leading-none">{activeChat?.title || 'Neural Link'}</span>
                        <div className="flex items-center gap-2 mt-1">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span className="text-[9px] font-mono text-green-500 uppercase tracking-widest">SUBSTRATE_LINK_OK</span>
                        </div>
                    </div>
                </div>
                <button onClick={() => { setView('LOGS'); playSound('click'); }} className="flex items-center gap-3 px-5 py-3 bg-white/5 border-2 border-white/10 rounded-2xl text-gray-400 hover:text-red-500 transition-all group active:scale-95">
                    <FolderOpen size={20} className="group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-black uppercase tracking-widest">Logs</span>
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 scrollbar-carnix pb-32">
                {!activeChatId ? (
                    <div className="h-full flex flex-col items-center justify-center text-center px-12">
                        <div className="p-10 bg-red-600/5 border-2 border-dashed border-red-600/20 rounded-full mb-8">
                             <HardDrive size={72} className="text-red-600/20" />
                        </div>
                        <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">Link Buffering Required</h3>
                        <button onClick={handleNewChat} className="mt-8 px-12 py-5 bg-red-600 text-black font-black text-xs rounded-full uppercase tracking-[0.4em] hover:bg-white transition-all shadow-[0_0_40px_rgba(255,0,0,0.4)] active:scale-90">Open Neural Uplink</button>
                    </div>
                ) : (
                    activeChat?.messages.map((m) => (
                        <div key={m.id} className={`flex gap-5 ${m.sender === 'user' ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-4 duration-300`}>
                            <div className={`w-11 h-11 rounded-2xl border-2 flex items-center justify-center shrink-0 ${m.sender === 'user' ? 'bg-blue-600/10 border-blue-500 text-blue-400' : 'bg-red-600/10 border-red-500 text-red-500 shadow-[0_0_20px_rgba(255,0,0,0.3)]'}`}>
                                {m.sender === 'user' ? <User size={22}/> : <Bot size={22}/>}
                            </div>
                            <div className={`max-w-[85%] p-6 rounded-[1.8rem] text-[15px] leading-relaxed border-2 shadow-2xl ${m.sender === 'user' ? 'bg-blue-900/20 border-blue-800/40 text-blue-50 rounded-tr-none' : 'bg-black/90 border-red-900/20 text-gray-100 rounded-tl-none'}`}>
                                <p className="whitespace-pre-wrap font-medium">{m.text}</p>
                            </div>
                        </div>
                    ))
                )}
                {isLoading && (
                    <div className="flex gap-5">
                        <div className="w-11 h-11 rounded-2xl border-2 bg-red-600/10 border-red-500 text-red-500 flex items-center justify-center animate-pulse"><Bot size={22}/></div>
                        <div className="p-6 bg-black/50 border border-white/5 rounded-[1.8rem] rounded-tl-none text-xs text-gray-500 font-mono italic animate-pulse">Neural Substrate Thinking...</div>
                    </div>
                )}
                <div ref={endRef} />
            </div>

            {activeChatId && (
                <form onSubmit={submit} className="absolute bottom-0 left-0 right-0 p-5 bg-black/90 border-t border-white/10 flex gap-4 items-center z-30 backdrop-blur-3xl">
                    <button type="button" className="p-4 text-gray-500 hover:text-red-500 transition-all active:scale-90"><Mic size={26}/></button>
                    <input 
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        placeholder="Direct neural command..."
                        className="flex-1 bg-black/60 border-2 border-white/10 rounded-[1.5rem] px-6 py-4 text-sm focus:border-red-600 outline-none text-white font-mono placeholder-gray-700 transition-all"
                    />
                    <button type="submit" disabled={!input.trim() || isLoading} className="p-5 bg-red-600 text-black rounded-[1.5rem] hover:bg-white transition-all disabled:opacity-50 shadow-[0_0_30px_rgba(255,0,0,0.3)] active:scale-90">
                        <Send size={26} />
                    </button>
                </form>
            )}
        </div>
    );
};

export default ChatPanel;