
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { RefreshCw, ShieldAlert, Activity } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface ErrorBoundaryProps {
  children?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  isFixing: boolean;
}

/**
 * Standardized implementation of ErrorBoundary using React.Component.
 */
// Fix: Explicitly extending Component with Props and State interfaces to ensure that 'props', 'state', and 'setState' are properly inherited and correctly typed by the TypeScript compiler.
export default class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  // Fix: Explicitly defining state property within the class body with type annotation to satisfy the compiler.
  state: ErrorBoundaryState = {
    hasError: false,
    isFixing: false
  };

  constructor(props: ErrorBoundaryProps) {
    super(props);
  }

  static getDerivedStateFromError(_: Error): ErrorBoundaryState {
    return { hasError: true, isFixing: false };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("NEURAL_STATION_FAULT:", error, errorInfo);
    playSound('error');
  }

  // Fix: Using an arrow function as a class property ensures the 'this' context refers correctly to the ErrorBoundary instance, granting access to inherited methods like setState.
  initiateAutoRepair = async () => {
    // Fix: Correctly calling setState, which is inherited from the base Component class.
    this.setState({ isFixing: true });
    playSound('process');
    await new Promise(r => setTimeout(r, 2200));
    sessionStorage.clear();
    window.location.reload();
  };

  render() {
    // Fix: Accessing state and props inherited from the Component base class.
    const { hasError, isFixing } = this.state;
    // Fix: Correctly accessing props inherited from the base Component class.
    const { children } = this.props;

    if (hasError) {
        return (
            <div className="fixed inset-0 bg-[#020001] z-[9999] flex flex-col items-center justify-center font-mono p-6">
                <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(255,0,0,0.08)_50%,rgba(0,0,0,0.2)_50%)] bg-[size:100%_4px] opacity-40"></div>
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,0,60,0.15)_0%,transparent_70%)]"></div>
                
                <div className="w-full max-w-xl bg-black/90 border-2 border-red-600 shadow-[0_0_120px_rgba(255,0,60,0.3)] p-12 text-center rounded-xl relative overflow-hidden backdrop-blur-3xl">
                    <div className="absolute top-0 left-0 w-full h-[4px] bg-red-600 animate-pulse"></div>
                    
                    <div className="relative mb-10">
                        <ShieldAlert size={80} className="text-red-500 mx-auto animate-bounce" />
                        <Activity size={32} className="text-red-600 absolute bottom-0 right-[40%] animate-pulse" />
                    </div>

                    <h1 className="text-4xl font-black text-white tracking-[0.2em] uppercase mb-6 italic drop-shadow-[0_0_15px_red]">NEURAL CORE FAULT</h1>
                    <p className="text-[12px] text-gray-400 mb-12 uppercase tracking-[0.3em] architecture-loose font-bold border-y border-white/5 py-4">
                        A critical logic exception has compromised the nanotech neural pathways. Core workstation kernels are currently unresponsive.
                    </p>

                    <button 
                        onClick={this.initiateAutoRepair} 
                        disabled={isFixing}
                        className="w-full py-6 bg-red-600 text-black font-black hover:bg-white transition-all flex items-center justify-center gap-4 uppercase tracking-[0.4em] text-sm shadow-[0_0_40px_rgba(255,0,60,0.5)] disabled:opacity-50"
                    >
                        {isFixing ? <RefreshCw size={24} className="animate-spin" /> : <RefreshCw size={24} />}
                        {isFixing ? "Syncing Kernels..." : "REBOOT SYSTEM CORE"}
                    </button>
                    
                    <div className="mt-8 flex justify-between text-[9px] text-red-900 font-mono font-bold tracking-widest uppercase">
                        <span>Error_Code: 0xDEADBEEF</span>
                        <span className="animate-pulse">Memory_Dump: ACTIVE</span>
                    </div>
                </div>
            </div>
        );
    }
    return children;
  }
}
