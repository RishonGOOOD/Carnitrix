import React, { useState, useEffect, useRef } from 'react';
import { FileText, Mic, MicOff } from 'lucide-react';
import { decode, decodeAudioData } from '../utils/audio';
import { DynamicLiveAudioCallbacks } from '../services/geminiService';
import { Profile } from '../types';

// FIX: This file was empty. The props interface is copied from AudioVoicePanel.tsx as it passes all its props down.
interface AudioTranscriptionPanelProps {
    startSession: (isVoiceChat: boolean) => void;
    stopSession: () => void;
    isSessionActive: boolean;
    currentProfile: Profile;
    outputAudioContext: AudioContext | null;
    outputAudioSources: React.MutableRefObject<Set<AudioBufferSourceNode>>;
    nextStartTimeRef: React.MutableRefObject<number>;
    registerCallbacks: (callbacks: DynamicLiveAudioCallbacks) => void;
}

const AudioTranscriptionPanel: React.FC<AudioTranscriptionPanelProps> = ({ startSession, stopSession, isSessionActive, registerCallbacks, outputAudioContext, outputAudioSources, nextStartTimeRef }) => {
    const [inputTranscript, setInputTranscript] = useState('');
    const [outputTranscript, setOutputTranscript] = useState('');
    const [history, setHistory] = useState<{ user: string, carnix: string }[]>([]);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        const onOutputAudio = async (base64Audio: string) => {
             if (outputAudioContext && base64Audio) {
                try {
                    if (outputAudioContext.state === 'suspended') {
                        await outputAudioContext.resume();
                    }
                    const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
                    const source = outputAudioContext.createBufferSource();
                    source.buffer = audioBuffer;
                    source.connect(outputAudioContext.destination);

                    const currentTime = outputAudioContext.currentTime;
                    const startTime = Math.max(currentTime, nextStartTimeRef.current);
                    source.start(startTime);
                    nextStartTimeRef.current = startTime + audioBuffer.duration;

                    outputAudioSources.current.add(source);
                    source.onended = () => {
                        outputAudioSources.current.delete(source);
                    };
                } catch(e) { console.error("Error playing audio chunk:", e); }
            }
        };

        registerCallbacks({
            onOutputAudio,
            onInputTranscription: text => setInputTranscript(prev => prev + text),
            onOutputTranscription: text => setOutputTranscript(prev => prev + text),
            onTurnComplete: (fullInput, fullOutput) => {
                setHistory(prev => [...prev, { user: fullInput, carnix: fullOutput }]);
                setInputTranscript('');
                setOutputTranscript('');
            },
            onInterrupt: () => {
                outputAudioSources.current.forEach(source => source.stop());
                outputAudioSources.current.clear();
                nextStartTimeRef.current = 0;
            },
            onError: (e) => console.error('Live session error:', e),
            onClose: () => console.log('Live session closed'),
        });
    }, [registerCallbacks, outputAudioContext, outputAudioSources, nextStartTimeRef]);

     useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [history, inputTranscript, outputTranscript]);


    const toggleSession = () => {
        if (isSessionActive) {
            stopSession();
        } else {
            setHistory([]);
            setInputTranscript('');
            setOutputTranscript('');
            startSession(false);
        }
    };

    return (
         <div className="w-full h-full flex flex-col bg-black/30 border border-[var(--color-panel-border)] rounded-md">
            <div className="p-2 border-b border-gray-700 flex justify-between items-center">
                <h3 className="text-sm font-bold text-white flex items-center gap-2"><FileText size={16}/> LIVE TRANSCRIPTION</h3>
                <button onClick={toggleSession} className={`px-3 py-1 rounded text-xs flex items-center gap-1 ${isSessionActive ? 'bg-red-600' : 'bg-green-600'}`}>
                   {isSessionActive ? <MicOff size={12}/> : <Mic size={12}/>} {isSessionActive ? 'STOP' : 'START'}
                </button>
            </div>
            <div className="flex-1 p-4 space-y-4 overflow-y-auto font-mono">
                {history.map((turn, i) => (
                    <div key={i}>
                        <p className="text-blue-400 font-bold">Commander: <span className="text-gray-300 font-normal">{turn.user}</span></p>
                        <p className="text-[var(--color-primary)] font-bold">Carnix: <span className="text-gray-300 font-normal">{turn.carnix}</span></p>
                    </div>
                ))}
                {inputTranscript && <p className="text-blue-400 font-bold">Commander: <span className="text-gray-300 font-normal italic">{inputTranscript}</span></p>}
                {outputTranscript && <p className="text-[var(--color-primary)] font-bold">Carnix: <span className="text-gray-300 font-normal italic">{outputTranscript}</span></p>}
                <div ref={messagesEndRef} />
            </div>
        </div>
    );
};

export default AudioTranscriptionPanel;
