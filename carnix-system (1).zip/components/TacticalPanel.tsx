
import React, { useState } from 'react';
import { Target, Crosshair, Shield, Zap, Bot, Activity } from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

const TacticalPanel: React.FC = () => {
    const [units, setUnits] = useState<any[]>([]);
    const [selectedType, setSelectedType] = useState('DRONE');

    const toggleCell = (r: number, c: number) => {
        const id = `${r}-${c}`;
        const exists = units.find(u => u.id === id);
        if (exists) {
            setUnits(prev => prev.filter(u => u.id !== id));
            playSound('error');
        } else {
            setUnits(prev => [...prev, { id, r, c, type: selectedType }]);
            playSound('access');
            triggerHaptic('light');
        }
    };

    const UnitIcon = ({ type }: any) => {
        switch(type) {
            case 'DRONE': return <Bot size={10} />;
            case 'ARMOR': return <Shield size={10} />;
            case 'STRIKE': return <Zap size={10} />;
            default: return <Target size={10} />;
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="bg-black/60 border border-red-600/30 p-3 rounded-lg flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Crosshair size={20} className="text-red-600 animate-pulse" />
                    <h2 className="text-sm font-black text-white uppercase italic">Battle Matrix Protocol</h2>
                </div>
                <div className="flex gap-1 bg-black p-0.5 border border-gray-800 rounded">
                    {['DRONE', 'ARMOR', 'STRIKE'].map(t => (
                        <button key={t} onClick={() => setSelectedType(t)} className={`px-3 py-1 text-[8px] font-black rounded ${selectedType === t ? 'bg-red-600 text-black' : 'text-gray-600'}`}>{t}</button>
                    ))}
                </div>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row gap-2 overflow-hidden">
                <div className="flex-1 bg-black/40 border border-white/5 rounded-lg p-2 flex items-center justify-center select-none overflow-auto scrollbar-hide">
                    <div className="grid grid-cols-12 gap-0.5 border border-red-600/10 p-0.5 bg-gray-900/40" style={{ width: 'min(90vw, 420px)', aspectRatio: '1/1' }}>
                        {Array.from({ length: 144 }).map((_, i) => {
                            const r = Math.floor(i / 12);
                            const c = i % 12;
                            const unit = units.find(u => u.r === r && u.c === c);
                            return (
                                <div 
                                    key={i} 
                                    onClick={() => toggleCell(r, c)}
                                    className={`aspect-square border border-white/5 flex items-center justify-center transition-all cursor-crosshair ${unit ? 'bg-red-600/20 text-red-500 shadow-[inset_0_0_10px_red]' : 'hover:bg-white/5'}`}
                                >
                                    {unit ? <UnitIcon type={unit.type} /> : <span className="text-[5px] text-gray-800">{c}:{r}</span>}
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="w-full lg:w-56 bg-black/60 border border-white/10 rounded-lg p-3 flex flex-col gap-3">
                    <div className="text-[9px] font-black text-white uppercase tracking-widest flex items-center gap-2 border-b border-white/5 pb-2">
                        <Activity size={12} className="text-red-600"/> Unit Telemetry
                    </div>
                    <div className="flex-1 space-y-2 overflow-y-auto scrollbar-tactical">
                        {units.map(u => (
                            <div key={u.id} className="p-2 bg-white/5 border border-white/10 rounded text-[9px] flex justify-between items-center group">
                                <span className="font-bold text-gray-300">[{u.r}:{u.c}] {u.type}</span>
                                <span className="text-green-500 font-mono">NOMINAL</span>
                            </div>
                        ))}
                        {units.length === 0 && <div className="text-center py-10 opacity-10 text-[9px] font-black uppercase">No Deployments</div>}
                    </div>
                    <button onClick={() => setUnits([])} className="w-full py-2 bg-red-900/20 border border-red-600 text-red-500 text-[9px] font-black uppercase hover:bg-red-600 hover:text-black transition-all">Emergency Purge</button>
                </div>
            </div>
        </div>
    );
};

export default TacticalPanel;
