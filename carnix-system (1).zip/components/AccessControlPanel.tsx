
import React, { useState, useEffect } from 'react';
import { User, ShieldCheck, Lock, Unlock, Keypad } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const AccessControlPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [enteredCode, setEnteredCode] = useState('');
    const [status, setStatus] = useState<'IDLE' | 'SUCCESS' | 'ERROR'>('IDLE');

    const handleKeypadPress = (key: string) => {
        if (status !== 'IDLE') return;
        playSound('click');
        setEnteredCode(prev => prev + key);
    };

    const handleClear = () => {
        setEnteredCode('');
        setStatus('IDLE');
        playSound('click');
    };

    const handleSubmit = () => {
        if (!activeProfile) return;
        
        // If profile has no passcode, treat any input as valid or just check against empty
        const targetPasscode = activeProfile.passcode || "";
        
        if (enteredCode === targetPasscode || (targetPasscode === "" && enteredCode.length > 0)) {
            setStatus('SUCCESS');
            playSound('success');
            setTimeout(() => {
                setEnteredCode('');
                setStatus('IDLE');
            }, 2000);
        } else {
            setStatus('ERROR');
            playSound('error');
            setTimeout(() => {
                setEnteredCode('');
                setStatus('IDLE');
            }, 1500);
        }
    };

    if (!activeProfile) return null;

    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'CLR', '0', 'ENT'];

    return (
        <div className="w-full h-full flex flex-col md:flex-row gap-4 p-1">
            <div className="w-full md:w-1/3 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-6 flex flex-col items-center justify-center text-center">
                <User size={64} className="mb-4 text-gray-400" />
                <h2 className="text-2xl font-bold text-white">{activeProfile.name}</h2>
                <p className="text-sm text-[var(--color-primary)] flex items-center gap-2">
                    <ShieldCheck size={14} /> LEVEL {activeProfile.isSuperUser ? '5 (ROOT)' : '1 (USER)'} CLEARANCE
                </p>
                <div className="mt-6 w-full text-left text-xs space-y-2 font-mono">
                    <p><span className="text-gray-500">ID:</span> {activeProfile.id}</p>
                    <p><span className="text-gray-500">STATUS:</span> OPERATIONAL</p>
                    <p><span className="text-gray-500">SECURITY:</span> {activeProfile.passcode ? 'ENCRYPTED' : 'OPEN'}</p>
                </div>
            </div>
            
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-6 flex flex-col items-center justify-center">
                <h3 className="text-sm font-bold text-gray-400 mb-6 flex items-center gap-2">
                    <Lock size={14}/> SECURITY CLEARANCE REQUIRED
                </h3>
                
                {/* Status Display */}
                <div className={`w-64 h-12 mb-6 border rounded flex items-center justify-center text-xl font-mono tracking-widest transition-colors ${
                    status === 'ERROR' ? 'border-red-500 bg-red-900/20 text-red-500' :
                    status === 'SUCCESS' ? 'border-green-500 bg-green-900/20 text-green-500' :
                    'border-[var(--color-primary)] bg-black/50 text-white'
                }`}>
                    {status === 'IDLE' ? enteredCode.replace(/./g, '*') : status}
                </div>

                {/* Keypad */}
                <div className="grid grid-cols-3 gap-3 w-64">
                    {keys.map(key => (
                        <button
                            key={key}
                            onClick={() => {
                                if (key === 'CLR') handleClear();
                                else if (key === 'ENT') handleSubmit();
                                else handleKeypadPress(key);
                            }}
                            className={`h-12 border rounded font-bold text-lg transition-all active:scale-95 ${
                                key === 'CLR' ? 'border-red-800 text-red-500 hover:bg-red-900/20' :
                                key === 'ENT' ? 'border-green-800 text-green-500 hover:bg-green-900/20' :
                                'border-gray-700 text-gray-300 hover:border-[var(--color-primary)] hover:text-[var(--color-primary)] hover:bg-[var(--color-primary)]/10'
                            }`}
                        >
                            {key}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default AccessControlPanel;
