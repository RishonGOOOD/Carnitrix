
import React, { useState, useRef } from 'react';
import { Mode } from '../types';
import { useAppContext } from '../context';
import { getAIResponse, generateImage, generateModuleBlueprint, generateVideo, editImage } from '../services/geminiService';
import { Bot, Code, Send, Loader2, Copy, Check, Save, FolderOpen, FilePlus, BrainCircuit, Zap, Image as ImageIcon, FileJson, Layers, Film, Wand2 } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { copyToClipboard } from '../utils/nativeBridge';

const AIWorkspacePanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const [activeTab, setActiveTab] = useState<'GENERATOR' | 'IMAGER' | 'BLUEPRINT' | 'VIDEO'>('GENERATOR');
    
    // Generator State
    const [prompt, setPrompt] = useState('');
    const [response, setResponse] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [hasCopied, setHasCopied] = useState(false);
    const [fileName, setFileName] = useState('new_file.js');
    
    // Imager State
    const [imagePrompt, setImagePrompt] = useState('');
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [isGeneratingImage, setIsGeneratingImage] = useState(false);
    const [aspectRatio, setAspectRatio] = useState("1:1");
    const [editMode, setEditMode] = useState(false);
    const [editImageFile, setEditImageFile] = useState<File | null>(null);
    const editInputRef = useRef<HTMLInputElement>(null);

    // Video State
    const [videoPrompt, setVideoPrompt] = useState('');
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);

    // Blueprint State
    const [blueprintPrompt, setBlueprintPrompt] = useState('');
    const [blueprint, setBlueprint] = useState<string | null>(null);
    const [isDesigning, setIsDesigning] = useState(false);

    const startLoading = () => {
        dispatch({ type: 'SET_TASK_LOADING', payload: true });
    }

    const stopLoading = () => {
        dispatch({ type: 'SET_TASK_LOADING', payload: false });
    }

    const handleGenerate = async () => {
        if (!prompt.trim() || !activeProfile) return;
        setIsLoading(true);
        startLoading();
        setResponse(null);
        playSound('process');
        try {
            const fullPrompt = `Generate code for the following request. The request is: "${prompt}". Provide only the raw code, without any explanation or markdown. If a language isn't specified, assume JavaScript.`;
            const res = await getAIResponse(fullPrompt, Mode.CodeAssistant, activeProfile.aiSettings);
            const codeBlockMatch = res.text.match(/```(?:\w*\n)?([\s\S]*?)```/);
            const cleanedCode = codeBlockMatch ? codeBlockMatch[1].trim() : res.text.trim();
            setResponse(cleanedCode);
            playSound('success');
        } catch (e: any) {
            setResponse(`Error generating code: ${e.message}`);
            playSound('error');
        }
        setIsLoading(false);
        stopLoading();
    };

    const handleGenerateImage = async () => {
        if (!imagePrompt.trim() || !activeProfile) return;
        setIsGeneratingImage(true);
        startLoading();
        setImageUrl(null);
        playSound('process');
        try {
            let resultUrl;
            if (editMode && editImageFile) {
                const reader = new FileReader();
                reader.readAsDataURL(editImageFile);
                resultUrl = await new Promise<string>((resolve, reject) => {
                    reader.onloadend = async () => {
                        const base64 = (reader.result as string).split(',')[1];
                        try {
                            const url = await editImage(base64, imagePrompt, activeProfile.aiSettings);
                            resolve(url);
                        } catch (e) { reject(e); }
                    };
                });
            } else {
                resultUrl = await generateImage(imagePrompt, activeProfile.aiSettings, { aspectRatio });
            }
            setImageUrl(resultUrl);
            playSound('success');
        } catch (e: any) {
            alert(`Image generation failed: ${e.message}`);
        }
        setIsGeneratingImage(false);
        stopLoading();
    };

    const handleGenerateVideo = async () => {
        if (!videoPrompt.trim() || !activeProfile) return;
        setIsGeneratingVideo(true);
        startLoading();
        setVideoUrl(null);
        playSound('process');
        try {
            const resultUrl = await generateVideo(videoPrompt, activeProfile.aiSettings);
            setVideoUrl(resultUrl);
            playSound('success');
        } catch (e: any) {
            alert(`Video generation failed: ${e.message}`);
        }
        setIsGeneratingVideo(false);
        stopLoading();
    }

    const handleGenerateBlueprint = async () => {
        if (!blueprintPrompt.trim() || !activeProfile) return;
        setIsDesigning(true);
        startLoading();
        setBlueprint(null);
        playSound('process');
        try {
            const res = await generateModuleBlueprint(activeProfile.aiSettings, blueprintPrompt);
            const formattedJson = JSON.stringify(JSON.parse(res.text), null, 2);
            setBlueprint(formattedJson);
            playSound('success');
        } catch (e: any) {
            setBlueprint(`{\n  "error": "Failed to generate blueprint.",\n  "details": "${e.message}"\n}`);
            playSound('error');
        }
        setIsDesigning(false);
        stopLoading();
    };

    const handleCopy = async (text: string) => {
        if (!text) return;
        const success = await copyToClipboard(text);
        if (success) {
            setHasCopied(true);
            playSound('click');
            setTimeout(() => setHasCopied(false), 2000);
        }
    };

    const handleSaveFile = async () => {
        if (!response || !fileName.trim()) {
            alert("No code generated or filename is empty.");
            return;
        }
        try {
            const blob = new Blob([response], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName.trim();
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            playSound('success');
        } catch (e) {
            console.error("Save file error", e);
            alert("Error saving file.");
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
             <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-[var(--color-primary)] flex items-center gap-2">
                    <BrainCircuit size={16} /> AI WORKSPACE
                </h2>
                <div className="flex gap-1 bg-black rounded border border-gray-800 p-1">
                    <button onClick={() => setActiveTab('GENERATOR')} className={`px-3 py-1 text-xs rounded ${activeTab === 'GENERATOR' ? 'bg-[var(--color-primary)] text-black' : 'text-gray-400'}`}>CODE</button>
                    <button onClick={() => setActiveTab('BLUEPRINT')} className={`px-3 py-1 text-xs rounded ${activeTab === 'BLUEPRINT' ? 'bg-[var(--color-primary)] text-black' : 'text-gray-400'}`}>PLUGIN</button>
                    <button onClick={() => setActiveTab('IMAGER')} className={`px-3 py-1 text-xs rounded ${activeTab === 'IMAGER' ? 'bg-[var(--color-primary)] text-black' : 'text-gray-400'}`}>IMAGER</button>
                    <button onClick={() => setActiveTab('VIDEO')} className={`px-3 py-1 text-xs rounded ${activeTab === 'VIDEO' ? 'bg-[var(--color-primary)] text-black' : 'text-gray-400'}`}>VIDEO</button>
                </div>
            </div>

            {activeTab === 'GENERATOR' && (
                <div className="flex-1 flex flex-col md:flex-row gap-2 overflow-hidden">
                    <div className="w-full md:w-1/3 flex flex-col gap-2">
                         <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 space-y-3 flex flex-col">
                            <h3 className="text-xs font-bold text-gray-400 border-b border-gray-700 pb-2">PROMPT</h3>
                            <textarea
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="e.g., A React component for a login form"
                                className="flex-1 w-full bg-black/50 border border-gray-700 rounded p-2 text-sm resize-none focus:outline-none focus:border-[var(--color-primary)]"
                                disabled={isLoading}
                            />
                            <button onClick={handleGenerate} disabled={isLoading || !prompt.trim()} className="w-full flex items-center justify-center gap-2 p-3 bg-[var(--color-button-background)] hover:bg-[var(--color-button-hover)] border border-[var(--color-button-border)] rounded-md transition-colors disabled:opacity-50">
                                {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                                {isLoading ? 'GENERATING...' : 'GENERATE CODE'}
                            </button>
                        </div>
                        <div className="bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 space-y-2">
                             <h3 className="text-xs font-bold text-gray-400">SAVE TO DEVICE</h3>
                             <input type="text" value={fileName} onChange={e => setFileName(e.target.value)} className="w-full bg-black/50 border border-gray-700 rounded p-2 text-sm focus:outline-none focus:border-[var(--color-primary)]" placeholder="filename.js"/>
                             <button onClick={handleSaveFile} disabled={!response} className="w-full flex items-center justify-center gap-2 p-2 bg-green-900/40 text-green-400 hover:bg-green-800/50 border border-green-700 rounded-md transition-colors disabled:opacity-50">
                                <Save size={14} /> SAVE
                            </button>
                        </div>
                    </div>
                    <div className="flex-1 bg-black border border-[var(--color-terminal-border)] rounded-md p-2 font-mono text-sm flex flex-col min-h-0 relative">
                        <div className="absolute top-2 right-2 z-10">
                            <button onClick={() => handleCopy(response || '')} className="p-2 bg-gray-800 rounded-md hover:bg-gray-700 disabled:opacity-50" disabled={!response}>
                                {hasCopied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                            </button>
                        </div>
                        <div className="flex-1 overflow-auto p-2">
                            {isLoading && (
                                <div className="flex items-center justify-center h-full text-gray-500">
                                    <Loader2 size={24} className="animate-spin mr-2" /> Processing...
                                </div>
                            )}
                            {response ? (
                                <pre><code className="whitespace-pre-wrap">{response}</code></pre>
                            ) : (
                                <div className="text-gray-600">Generated code will appear here.</div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'BLUEPRINT' && (
                <div className="flex-1 flex flex-col md:flex-row gap-2 overflow-hidden">
                    <div className="w-full md:w-1/3 flex flex-col gap-2">
                        <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex flex-col">
                            <h3 className="text-xs font-bold text-gray-400 border-b border-gray-700 pb-2 mb-2">PLUGIN SPECIFICATION</h3>
                            <textarea
                                value={blueprintPrompt}
                                onChange={(e) => setBlueprintPrompt(e.target.value)}
                                placeholder="Describe a new system feature"
                                className="flex-1 w-full bg-black/50 border border-gray-700 rounded p-2 text-sm resize-none focus:outline-none focus:border-[var(--color-primary)]"
                                disabled={isDesigning}
                            />
                            <button onClick={handleGenerateBlueprint} disabled={isDesigning || !blueprintPrompt.trim()} className="w-full mt-3 flex items-center justify-center gap-2 p-3 bg-[var(--color-button-background)] hover:bg-[var(--color-button-hover)] border border-[var(--color-button-border)] rounded-md transition-colors disabled:opacity-50">
                                {isDesigning ? <Loader2 size={16} className="animate-spin" /> : <Layers size={16} />}
                                {isDesigning ? 'ARCHITECTING...' : 'DESIGN PLUGIN'}
                            </button>
                        </div>
                    </div>
                    <div className="flex-1 bg-black border border-[var(--color-terminal-border)] rounded-md p-2 font-mono text-sm flex flex-col min-h-0 relative">
                        <div className="p-2 border-b border-gray-700 text-xs text-gray-400 flex items-center gap-2">
                            <FileJson size={14} /> BLUEPRINT JSON
                        </div>
                        <div className="flex-1 overflow-auto p-2">
                            {isDesigning && (
                                <div className="flex items-center justify-center h-full text-gray-500">
                                    <Loader2 size={24} className="animate-spin mr-2" /> Drafting specifications...
                                </div>
                            )}
                            {blueprint ? (
                                <pre><code className="whitespace-pre-wrap text-green-400">{blueprint}</code></pre>
                            ) : (
                                <div className="text-gray-600">JSON blueprint will appear here.</div>
                            )}
                        </div>
                    </div>
                </div>
            )}
            
            {activeTab === 'IMAGER' && (
                <div className="flex-1 flex flex-col gap-2 overflow-hidden">
                    <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3">
                         <div className="flex gap-2 mb-2">
                             <button onClick={() => setEditMode(false)} className={`flex-1 text-xs py-1 rounded border ${!editMode ? 'bg-[var(--color-primary)] text-black border-[var(--color-primary)]' : 'bg-transparent text-gray-400 border-gray-700'}`}>GENERATE</button>
                             <button onClick={() => setEditMode(true)} className={`flex-1 text-xs py-1 rounded border ${editMode ? 'bg-[var(--color-primary)] text-black border-[var(--color-primary)]' : 'bg-transparent text-gray-400 border-gray-700'}`}>EDIT</button>
                         </div>
                         
                         {editMode && (
                             <div className="flex gap-2 mb-2 items-center">
                                 <input type="file" accept="image/*" className="hidden" ref={editInputRef} onChange={(e) => setEditImageFile(e.target.files?.[0] || null)} />
                                 <button onClick={() => editInputRef.current?.click()} className="p-2 border border-gray-600 rounded bg-gray-800 text-xs flex items-center gap-2 hover:bg-gray-700">
                                     <FolderOpen size={12}/> {editImageFile ? editImageFile.name : "Select Source"}
                                 </button>
                             </div>
                         )}

                         <textarea
                            value={imagePrompt}
                            onChange={(e) => setImagePrompt(e.target.value)}
                            placeholder={editMode ? "How to modify..." : "Describe image..."}
                            className="w-full h-20 hud-textarea text-sm resize-y"
                            disabled={isGeneratingImage}
                        />
                        <div className="flex gap-2 mt-2">
                            {!editMode && (
                                <select value={aspectRatio} onChange={e => setAspectRatio(e.target.value)} className="bg-black border border-gray-700 rounded px-2 text-xs text-white">
                                    <option value="1:1">1:1</option>
                                    <option value="16:9">16:9</option>
                                    <option value="9:16">9:16</option>
                                </select>
                            )}
                            <button onClick={handleGenerateImage} disabled={isGeneratingImage || !imagePrompt.trim() || (editMode && !editImageFile)} className="flex-1 hud-button flex items-center justify-center gap-2 disabled:opacity-50">
                                {isGeneratingImage ? <Loader2 size={16} className="animate-spin" /> : editMode ? <Wand2 size={16}/> : <Zap size={16} />}
                                {isGeneratingImage ? 'PROCESSING...' : editMode ? 'EDIT' : 'GENERATE'}
                            </button>
                        </div>
                    </div>
                    <div className="flex-1 hud-panel flex items-center justify-center p-2 relative bg-black/50">
                        {isGeneratingImage && <Loader2 size={48} className="animate-spin text-[var(--color-primary)]" />}
                        {imageUrl && <img src={imageUrl} alt="Result" className="max-w-full max-h-full object-contain" />}
                        {!isGeneratingImage && !imageUrl && <div className="text-gray-600 flex flex-col items-center gap-2"><ImageIcon size={32}/>Result will appear here.</div>}
                    </div>
                </div>
            )}

            {activeTab === 'VIDEO' && (
                <div className="flex-1 flex flex-col gap-2 overflow-hidden">
                    <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3">
                         <textarea
                            value={videoPrompt}
                            onChange={(e) => setVideoPrompt(e.target.value)}
                            placeholder="Describe video..."
                            className="w-full h-20 hud-textarea text-sm resize-y"
                            disabled={isGeneratingVideo}
                        />
                        <button onClick={handleGenerateVideo} disabled={isGeneratingVideo || !videoPrompt.trim()} className="w-full hud-button flex items-center justify-center gap-2 mt-2 disabled:opacity-50">
                            {isGeneratingVideo ? <Loader2 size={16} className="animate-spin" /> : <Film size={16} />}
                            {isGeneratingVideo ? 'RENDERING...' : 'GENERATE VIDEO'}
                        </button>
                    </div>
                    <div className="flex-1 hud-panel flex items-center justify-center p-2 relative bg-black/50">
                        {isGeneratingVideo && <Loader2 size={48} className="animate-spin text-[var(--color-primary)]" />}
                        {videoUrl && <video src={videoUrl} controls autoPlay loop className="max-w-full max-h-full object-contain" />}
                        {!isGeneratingVideo && !videoUrl && <div className="text-gray-600 flex flex-col items-center gap-2"><Film size={32}/>Video will appear here.</div>}
                    </div>
                </div>
            )}
        </div>
    );
};

export default AIWorkspacePanel;
