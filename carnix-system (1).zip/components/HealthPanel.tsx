


import React, { useState } from 'react';
import { HeartPulse, Stethoscope, Dumbbell, BrainCircuit, Send, Loader2, Camera } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';
import { playSound } from '../utils/soundEffects';

type TherapistMode = 'General Physician' | 'Physiotherapist' | 'Mental Health Advisor';

const HealthPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [mode, setMode] = useState<TherapistMode>('General Physician');
    const [symptoms, setSymptoms] = useState('');
    const [analysis, setAnalysis] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [useCamera, setUseCamera] = useState(false);

    const getSystemInstruction = () => {
        switch (mode) {
            case 'Physiotherapist':
                return "You are an expert AI Physiotherapist. Analyze the user's symptoms related to physical pain, movement, and posture. Provide potential causes, recommend safe exercises, and suggest when to see a specialist. Use web search to ground your advice.";
            case 'Mental Health Advisor':
                return "You are an empathetic AI Mental Health Advisor. Listen to the user's feelings and symptoms. Provide supportive advice, coping strategies, and resources for mental well-being. Emphasize that you are not a replacement for a professional therapist. Use web search for context.";
            case 'General Physician':
            default:
                return "You are a helpful AI Medical Assistant acting as a General Physician. Analyze the user's described symptoms. Use web search to identify potential conditions, suggest next steps, and advise when to seek professional medical help. You must include a disclaimer that you are not a real doctor.";
        }
    }

    const handleAnalyze = async () => {
        if (!symptoms.trim() || !activeProfile) return;
        setIsLoading(true);
        setAnalysis(null);
        playSound('process');
        try {
            const cameraInfo = useCamera ? "The user has also provided a camera scan of the affected area." : "";
            const fullPrompt = `My symptoms are: "${symptoms}". ${cameraInfo}`;
            
            // Create a temporary AI settings override for this specific call
            const healthAISettings = {
                ...activeProfile.aiSettings,
                directive: getSystemInstruction(),
                useSearchGrounding: true
            };

            const res = await getAIResponse(fullPrompt, Mode.Health, healthAISettings);
            setAnalysis(res.text);
            playSound('success');
        } catch (e: any) {
            setAnalysis(`Error performing analysis: ${e.message}`);
            playSound('error');
        }
        setIsLoading(false);
    };

    const ModeButton: React.FC<{ current: TherapistMode, target: TherapistMode, children: React.ReactNode, icon: React.ReactNode }> = ({ current, target, children, icon }) => (
        <button 
            onClick={() => setMode(target)}
            className={`flex-1 p-3 rounded flex items-center justify-center gap-2 text-xs font-bold transition-colors ${current === target ? 'bg-[var(--color-primary)] text-black' : 'bg-black/50 hover:bg-white/10'}`}
        >
            {icon} {children}
        </button>
    );

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2 flex flex-col gap-2">
                 <div className="flex items-center gap-2">
                    <ModeButton current={mode} target="General Physician" icon={<Stethoscope size={14}/>}>General</ModeButton>
                    <ModeButton current={mode} target="Physiotherapist" icon={<Dumbbell size={14}/>}>Physio</ModeButton>
                    <ModeButton current={mode} target="Mental Health Advisor" icon={<BrainCircuit size={14}/>}>Mental Health</ModeButton>
                </div>
                 <textarea
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    placeholder={`Describe your symptoms to the ${mode}...`}
                    className="w-full h-24 hud-textarea text-sm resize-y"
                    disabled={isLoading}
                />
                <div className="flex gap-2 items-center">
                    <button
                        onClick={() => setUseCamera(p => !p)}
                        className={`hud-button flex items-center gap-2 ${useCamera ? 'bg-[var(--color-accent)] text-black' : ''}`}
                    >
                        <Camera size={14}/>
                        {useCamera ? 'CAMERA SCAN ACTIVE' : 'ADD CAMERA SCAN'}
                    </button>
                    <button
                        onClick={handleAnalyze}
                        disabled={isLoading || !symptoms.trim()}
                        className="flex-1 hud-button flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                        {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                        {isLoading ? 'ANALYZING...' : 'GET ANALYSIS'}
                    </button>
                </div>
            </div>
            <div className="flex-1 hud-panel flex flex-col">
                 <div className="hud-panel-header">
                    <HeartPulse size={14}/> AI Health Assessment
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                     {isLoading && (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-400">
                            <Loader2 size={32} className="animate-spin text-[var(--color-primary)] mb-4" />
                            <p>Consulting medical database and web sources...</p>
                        </div>
                    )}
                    {analysis ? (
                        <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-gray-300">
                           {analysis}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-600">
                             <p>Medical analysis will be displayed here.</p>
                             <p className="text-xs mt-2">This is not a substitute for professional medical advice.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default HealthPanel;