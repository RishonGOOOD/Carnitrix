import React, { useState } from 'react';
import { Mode } from '../types';
import { 
  LayoutDashboard, Search, MessageCircle, Fingerprint, ShieldCheck, 
  ShieldAlert, FolderKanban, Network, FileCheck2, Terminal, 
  Boxes, Cpu, Grid, ChevronLeft, ChevronRight, ScanEye, Activity, CloudSun, Compass
} from 'lucide-react';
import { useAppContext } from '../context';
import { playSound, triggerHaptic } from '../utils/soundEffects';

interface Props { 
  onNavigate: (m: Mode) => void; 
}

interface NavItem {
  mode: Mode;
  label: string;
  icon: React.ElementType;
  badge?: string;
  color: string;
}

export const Sidebar: React.FC<Props> = ({ onNavigate }) => {
  const { state } = useAppContext();
  const { mode: curr } = state;
  const [collapsed, setCollapsed] = useState(false);

  const nav = (m: Mode) => {
    onNavigate(m);
    playSound('click');
    triggerHaptic('light');
  };

  const navGroups: { title: string; items: NavItem[] }[] = [
    {
      title: 'CORE WORKSTATION',
      items: [
        { mode: Mode.Home, label: 'Dashboard HUD', icon: LayoutDashboard, color: 'text-red-400 hover:text-white' },
        { mode: Mode.GlobalSearch, label: 'Omni Search', icon: Search, badge: 'AI', color: 'text-red-400 hover:text-white' },
        { mode: Mode.Chat, label: 'Neural AI Core', icon: MessageCircle, color: 'text-cyan-400 hover:text-white' },
      ]
    },
    {
      title: 'INTELLIGENCE & DEFENSE',
      items: [
        { mode: Mode.UnifiedOsintAggregator, label: 'Unified OSINT Feed', icon: Fingerprint, badge: 'NEW', color: 'text-red-400 hover:text-white' },
        { mode: Mode.TacticalDiagnostics, label: 'Tactical Diagnostics', icon: Activity, badge: 'TEST', color: 'text-emerald-400 hover:text-white' },
        { mode: Mode.DeepOsintAI, label: 'Deep OSINT Engine', icon: Search, color: 'text-pink-400 hover:text-white' },
        { mode: Mode.SecurityEngine, label: 'Defensive Security', icon: ShieldCheck, color: 'text-emerald-400 hover:text-white' },
        { mode: Mode.ThreatIntel, label: 'Threat Intelligence', icon: ShieldAlert, color: 'text-amber-400 hover:text-white' },
      ]
    },
    {
      title: 'INVESTIGATION & CASES',
      items: [
        { mode: Mode.InvestigationWorkspace, label: 'Case Workspace', icon: FolderKanban, color: 'text-blue-400 hover:text-white' },
        { mode: Mode.EvidenceEngine, label: 'Evidence Graph', icon: Network, color: 'text-purple-400 hover:text-white' },
        { mode: Mode.ReportEngine, label: 'Report Compiler', icon: FileCheck2, color: 'text-emerald-400 hover:text-white' },
      ]
    },
    {
      title: 'GITHUB TOOLS & ECOSYSTEM',
      items: [
        { mode: Mode.CarnixPlatformHub, label: 'Carnix Platform Hub', icon: Cpu, badge: 'MASTER', color: 'text-red-400 hover:text-white' },
        { mode: Mode.AiToolsSuite, label: 'AI Tools & Connectors', icon: CloudSun, badge: 'SUITE', color: 'text-amber-400 hover:text-white' },
        { mode: Mode.JarvisSensors, label: 'Jarvis Sensors & HUD', icon: Compass, badge: 'SENSORS', color: 'text-emerald-400 hover:text-white' },
        { mode: Mode.ToolDiscovery, label: 'GitHub Tools Catalog', icon: Terminal, badge: 'NEW', color: 'text-yellow-400 hover:text-white' },
        { mode: Mode.McpHub, label: 'MCP Connectors', icon: Boxes, color: 'text-teal-400 hover:text-white' },
        { mode: Mode.FreeAiGithubHub, label: 'Free AI Hub', icon: Cpu, color: 'text-cyan-400 hover:text-white' },
        { mode: Mode.PanelsHub, label: 'All Subsystems', icon: Grid, badge: '42', color: 'text-gray-400 hover:text-white' },
      ]
    }
  ];

  return (
    <aside 
      className={`h-full border-r border-red-900/30 bg-[#070103]/95 flex flex-col justify-between shrink-0 z-30 select-none transition-all duration-300 font-[Rajdhani] ${
        collapsed ? 'w-12 sm:w-14' : 'w-44 lg:w-48'
      }`}
    >
      {/* Navigation List */}
      <div className="flex-1 overflow-y-auto scrollbar-carnix py-3 px-2 space-y-4">
        {navGroups.map((group, gIdx) => (
          <div key={gIdx} className="space-y-1">
            {!collapsed && (
              <div className="px-2 pb-1 text-[9px] font-mono font-bold tracking-widest text-red-600/80 uppercase">
                {group.title}
              </div>
            )}

            <div className="space-y-0.5">
              {group.items.map((item, index) => {
                const Icon = item.icon;
                const isActive = curr === item.mode;

                return (
                  <button
                    key={`${item.mode}-${index}`}
                    onClick={() => nav(item.mode)}
                    title={collapsed ? item.label : undefined}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-bold transition-all text-left group ${
                      isActive 
                        ? 'bg-red-600 text-black shadow-[0_0_15px_rgba(255,0,0,0.5)] font-black' 
                        : 'text-gray-400 hover:text-white hover:bg-red-950/30'
                    }`}
                  >
                    <Icon size={16} className={`shrink-0 ${isActive ? 'text-black' : item.color}`} />
                    
                    {!collapsed && (
                      <div className="flex-1 flex items-center justify-between truncate font-mono">
                        <span className="truncate">{item.label}</span>
                        {item.badge && (
                          <span className={`text-[9px] font-black px-1.5 py-0.2 rounded shrink-0 ${
                            isActive ? 'bg-black text-red-500' : 'bg-red-950/80 text-red-400 border border-red-900/50'
                          }`}>
                            {item.badge}
                          </span>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Collapse Rail Toggle Footer */}
      <div className="p-2 border-t border-red-900/30 flex items-center justify-between">
        {!collapsed && (
          <div className="text-[9px] font-mono text-gray-500 pl-2">
            CARNIX WORKSTATION
          </div>
        )}
        <button
          onClick={() => {
            setCollapsed(!collapsed);
            playSound('click');
          }}
          title={collapsed ? "Expand Navigation" : "Collapse Navigation"}
          className="p-1.5 rounded-lg bg-black/60 hover:bg-red-950/40 text-gray-400 hover:text-white border border-white/5 transition-all mx-auto"
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
