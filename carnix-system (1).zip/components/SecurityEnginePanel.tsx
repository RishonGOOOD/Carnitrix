import React, { useState } from 'react';
import { SecurityEngine } from '../services/securityEngine';
import { SecurityAssessment, SecurityFinding } from '../types';
import { 
  ShieldCheck, ShieldAlert, Key, FileCode, Terminal, 
  Search, CheckCircle2, AlertTriangle, Bug, Lock, RefreshCw, Copy, Check
} from 'lucide-react';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const SecurityEnginePanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ASSESSMENT' | 'SECRETS' | 'SAST' | 'LOGS' | 'IOCS' | 'SIGMA'>('ASSESSMENT');
  
  // Assessment State
  const [targetHost, setTargetHost] = useState('example.com');
  const [assessment, setAssessment] = useState<SecurityAssessment | null>(null);
  const [isAssessing, setIsAssessing] = useState(false);

  // Secret Scanner State
  const [secretInput, setSecretInput] = useState(`// Sample Configuration Buffer
const AWS_KEY = "AKIA1234567890ABCDEF";
const GITHUB_TOKEN = "ghp_1234567890abcdefghijklmnopqrstuvwx";
const DB_CONN = "postgres://admin:SuperSecretPass123@db.prod.internal:5432/core";
`);
  const [secretResults, setSecretResults] = useState<any | null>(null);

  // SAST Scanner State
  const [sastCode, setSastCode] = useState(`function executeUserPayload(req, res) {
  const query = "SELECT * FROM users WHERE id = " + req.query.id;
  eval(req.body.customScript);
  document.getElementById("output").innerHTML = req.body.username;
}
`);
  const [sastFindings, setSastFindings] = useState<SecurityFinding[]>([]);
  const [sastScore, setSastScore] = useState<number | null>(null);

  // Log Analyzer State
  const [logBuffer, setLogBuffer] = useState(`Sep 19 04:12:01 edge-server sshd[24801]: Failed password for invalid user root from 185.220.101.5 port 44812 ssh2
Sep 19 04:12:03 edge-server sshd[24801]: Failed password for invalid user admin from 185.220.101.5 port 44813 ssh2
Sep 19 04:12:05 edge-server sshd[24801]: Failed password for invalid user test from 185.220.101.5 port 44814 ssh2
Sep 19 04:12:07 edge-server sshd[24801]: Failed password for invalid user guest from 185.220.101.5 port 44815 ssh2
Sep 19 04:15:22 edge-server nginx[8110]: 198.51.100.22 - - [19/Sep/2026:04:15:22 +0000] "GET /../../etc/passwd HTTP/1.1" 404
Sep 19 04:18:10 edge-server nginx[8110]: 203.0.113.88 - - [19/Sep/2026:04:18:10 +0000] "GET /search?id=1%27+UNION+SELECT+null,username,password+FROM+users-- HTTP/1.1" 200
`);
  const [logResults, setLogResults] = useState<any | null>(null);

  // IOC Extractor State
  const [iocInput, setIocInput] = useState(`Observed C2 beacon from IP 45.154.255.89 contacting malware host update-system-login.top. 
Payload hash verified: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855.
Contact point: security-alerts@threat-intel.org`);
  const [iocResults, setIocResults] = useState<any | null>(null);

  // Sigma Rule State
  const [sigmaRule, setSigmaRule] = useState(`title: Suspicious Web Path Traversal Probe
level: HIGH
detection:
    selection:
        - '/etc/passwd'
        - '../'
    condition: selection
`);
  const [sigmaResult, setSigmaResult] = useState<any | null>(null);

  // Handlers
  const handleRunAssessment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetHost.trim()) return;
    setIsAssessing(true);
    playSound('scan');
    triggerHaptic('medium');
    const result = await SecurityEngine.assessTarget(targetHost.trim());
    setAssessment(result);
    setIsAssessing(false);
    playSound('success');
  };

  const handleScanSecrets = () => {
    playSound('scan');
    const res = SecurityEngine.scanForSecrets(secretInput);
    setSecretResults(res);
    playSound(res.totalSecrets > 0 ? 'alert' : 'success');
  };

  const handleRunSast = () => {
    playSound('scan');
    const { findings, score } = SecurityEngine.runSastScan(sastCode);
    setSastFindings(findings);
    setSastScore(score);
    playSound(findings.length > 0 ? 'alert' : 'success');
  };

  const handleAnalyzeLogs = () => {
    playSound('scan');
    const lines = logBuffer.split('\n').filter(Boolean);
    const res = SecurityEngine.analyzeLogs(lines);
    setLogResults(res);
    playSound(res.suspiciousCount > 0 ? 'alert' : 'success');
  };

  const handleExtractIocs = () => {
    playSound('click');
    const res = SecurityEngine.extractIocs(iocInput);
    setIocResults(res);
  };

  const handleEvaluateSigma = () => {
    playSound('scan');
    const lines = logBuffer.split('\n').filter(Boolean);
    const res = SecurityEngine.evaluateSigmaRule(sigmaRule, lines);
    setSigmaResult(res);
    playSound(res.matched ? 'alert' : 'success');
  };

  return (
    <div className="w-full h-full flex flex-col gap-4 font-[Rajdhani] bg-[#050002]/95 text-white overflow-y-auto scrollbar-carnix p-3 sm:p-5">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-red-950/20 border border-red-900/30 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-red-600/20 border border-red-500 rounded text-red-400">
              <ShieldCheck size={18} />
            </span>
            <h1 className="text-xl font-black font-orbitron text-white tracking-wider">
              DEFENSIVE SECURITY & CODE AUDIT ENGINE
            </h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-1">
            Authorized defensive posture evaluation, secret detection, SAST vulnerability auditing, and SIEM log correlation.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex flex-wrap gap-1 bg-black/60 p-1 rounded-lg border border-red-900/30 font-mono text-xs">
          {(['ASSESSMENT', 'SECRETS', 'SAST', 'LOGS', 'IOCS', 'SIGMA'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => {
                setActiveTab(tab);
                playSound('click');
              }}
              className={`px-3 py-1.5 rounded transition-all font-bold ${
                activeTab === tab 
                  ? 'bg-red-600 text-black shadow-[0_0_10px_rgba(255,0,0,0.5)]' 
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: DEFENSIVE TARGET ASSESSMENT */}
      {activeTab === 'ASSESSMENT' && (
        <div className="space-y-4">
          <form onSubmit={handleRunAssessment} className="flex gap-2">
            <input
              type="text"
              value={targetHost}
              onChange={(e) => setTargetHost(e.target.value)}
              placeholder="Enter target domain or URL (e.g. example.com)..."
              className="flex-1 px-4 py-2.5 bg-black/80 border border-red-900/40 rounded-lg text-sm font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500"
            />
            <button
              type="submit"
              disabled={isAssessing}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded-lg transition-all shadow-[0_0_15px_rgba(255,0,0,0.4)] disabled:opacity-50 flex items-center gap-2"
            >
              <RefreshCw size={14} className={isAssessing ? 'animate-spin' : ''} />
              {isAssessing ? 'AUDITING...' : 'RUN AUDIT'}
            </button>
          </form>

          {assessment && (
            <div className="space-y-4">
              {/* Score & Grade Hero Card */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-mono text-gray-400">DEFENSIVE SCORE</div>
                    <div className="text-3xl font-black font-orbitron text-white">{assessment.score}/100</div>
                  </div>
                  <div className="text-3xl font-black font-orbitron text-red-500 px-3 py-1 bg-red-950/60 border border-red-800 rounded">
                    {assessment.grade}
                  </div>
                </div>

                <div className="p-4 bg-black/60 border border-white/5 rounded-xl font-mono">
                  <div className="text-[10px] text-gray-400">TARGET</div>
                  <div className="text-sm font-bold text-cyan-400 truncate">{assessment.target}</div>
                  <div className="text-[9px] text-gray-500">{assessment.scanType}</div>
                </div>

                <div className="p-4 bg-black/60 border border-white/5 rounded-xl font-mono">
                  <div className="text-[10px] text-gray-400">TLS CIPHER SUITE</div>
                  <div className="text-xs font-bold text-emerald-400 truncate">{assessment.tlsAudit?.cipher}</div>
                  <div className="text-[9px] text-gray-500">{assessment.tlsAudit?.issuer}</div>
                </div>

                <div className="p-4 bg-black/60 border border-white/5 rounded-xl font-mono">
                  <div className="text-[10px] text-gray-400">TOTAL FINDINGS</div>
                  <div className="text-3xl font-black text-amber-400">{assessment.findings.length}</div>
                </div>
              </div>

              {/* Security Headers Breakdown */}
              {assessment.headersAudit && (
                <div className="p-4 bg-black/60 border border-red-900/30 rounded-xl space-y-3 font-mono">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Lock size={14} className="text-red-500" /> DEFENSIVE HTTP HEADERS STATUS
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                    {Object.entries(assessment.headersAudit).map(([hdr, data]) => (
                      <div key={hdr} className="p-2.5 rounded bg-black/40 border border-white/5 flex items-center justify-between">
                        <div>
                          <div className="font-bold text-gray-300">{hdr}</div>
                          <div className="text-[10px] text-gray-500">{data.risk}</div>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          data.present ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-900/40' : 'bg-red-950/60 text-red-400 border border-red-900/40'
                        }`}>
                          {data.present ? 'ENFORCED' : 'MISSING'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Findings list */}
              <div className="space-y-2">
                <h3 className="text-sm font-bold text-white font-orbitron">ACTIONABLE REMEDIATIONS</h3>
                {assessment.findings.map(f => (
                  <div key={f.id} className="p-3 bg-red-950/10 border border-red-900/30 rounded-lg text-xs font-mono space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white flex items-center gap-1.5">
                        <AlertTriangle size={14} className="text-amber-400" /> {f.title}
                      </span>
                      <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800 text-[10px] font-bold">
                        {f.severity}
                      </span>
                    </div>
                    <p className="text-gray-400">{f.description}</p>
                    <div className="text-emerald-400 pt-1">Fix: {f.remediation}</div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SECRET DETECTION */}
      {activeTab === 'SECRETS' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono text-gray-400">
              Scans for AWS keys, GitHub tokens, Slack webhooks, Private keys, and high-entropy secrets.
            </span>
            <button
              onClick={handleScanSecrets}
              className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded"
            >
              SCAN FOR SECRETS
            </button>
          </div>

          <textarea
            value={secretInput}
            onChange={(e) => setSecretInput(e.target.value)}
            rows={8}
            className="w-full p-3 bg-black/80 border border-red-900/40 rounded-lg text-xs font-mono text-emerald-400 focus:outline-none focus:border-red-500"
          />

          {secretResults && (
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-xl font-mono space-y-3">
              <div className="flex justify-between items-center">
                <span className="font-bold text-sm text-white">SCAN RESULTS</span>
                <span className="text-xs text-red-400 font-bold">{secretResults.totalSecrets} Secrets Detected</span>
              </div>
              {secretResults.secretsFound.map((s: any, idx: number) => (
                <div key={idx} className="p-2.5 bg-black/60 rounded border border-red-900/30 text-xs flex justify-between items-center">
                  <div>
                    <span className="font-bold text-white">{s.type}</span>
                    <span className="text-gray-500 ml-2">Line {s.line}</span>
                    <div className="text-amber-400 font-mono text-[11px] mt-0.5">{s.matchSnippet}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800 text-[10px] font-bold">
                    {s.severity}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: SAST SCANNER */}
      {activeTab === 'SAST' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono text-gray-400">
              Static Application Security Testing rules for XSS, SQLi, Code Execution, and ReDoS.
            </span>
            <button
              onClick={handleRunSast}
              className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded"
            >
              RUN SAST AUDIT
            </button>
          </div>

          <textarea
            value={sastCode}
            onChange={(e) => setSastCode(e.target.value)}
            rows={8}
            className="w-full p-3 bg-black/80 border border-red-900/40 rounded-lg text-xs font-mono text-cyan-300 focus:outline-none focus:border-red-500"
          />

          {sastScore !== null && (
            <div className="space-y-3 font-mono">
              <div className="p-3 bg-black/60 border border-red-900/30 rounded-xl flex justify-between items-center">
                <span className="font-bold text-white">CODE AUDIT SCORE: {sastScore}/100</span>
                <span className="text-xs text-amber-400">{sastFindings.length} Vulnerabilities Identified</span>
              </div>
              {sastFindings.map(f => (
                <div key={f.id} className="p-3 bg-red-950/10 border border-red-900/30 rounded-lg text-xs space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white">{f.title}</span>
                    <span className="text-red-400 font-bold">{f.severity}</span>
                  </div>
                  <div className="text-gray-400">{f.description}</div>
                  <div className="text-emerald-400">Fix: {f.remediation}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: DEFENSIVE LOG ANALYZER */}
      {activeTab === 'LOGS' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono text-gray-400">
              Parses Syslog, Apache/Nginx, and auth.log buffers for brute force attacks and traversal probes.
            </span>
            <button
              onClick={handleAnalyzeLogs}
              className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded"
            >
              ANALYZE LOGS
            </button>
          </div>

          <textarea
            value={logBuffer}
            onChange={(e) => setLogBuffer(e.target.value)}
            rows={8}
            className="w-full p-3 bg-black/80 border border-red-900/40 rounded-lg text-xs font-mono text-gray-300 focus:outline-none focus:border-red-500"
          />

          {logResults && (
            <div className="p-4 bg-red-950/20 border border-red-900/30 rounded-xl font-mono space-y-3">
              <div className="flex justify-between items-center">
                <span className="font-bold text-sm text-white">SECURITY ALERTS</span>
                <span className="text-xs text-red-400 font-bold">{logResults.suspiciousCount} Suspicious Incidents Detected</span>
              </div>
              {logResults.alerts.map((a: any, idx: number) => (
                <div key={idx} className="p-2.5 bg-black/60 rounded border border-red-900/30 text-xs flex justify-between items-center">
                  <div>
                    <span className="font-bold text-white">{a.threat}</span>
                    <div className="text-gray-500 text-[11px]">IP: {a.ip} | MITRE: {a.mitre}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800 text-[10px] font-bold">
                    {a.severity}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: IOC EXTRACTOR */}
      {activeTab === 'IOCS' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono text-gray-400">
              Extracts and defangs IPv4, SHA-256, MD5, Domains, URLs, and Emails from threat intelligence reports.
            </span>
            <button
              onClick={handleExtractIocs}
              className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded"
            >
              EXTRACT & DEFANG
            </button>
          </div>

          <textarea
            value={iocInput}
            onChange={(e) => setIocInput(e.target.value)}
            rows={6}
            className="w-full p-3 bg-black/80 border border-red-900/40 rounded-lg text-xs font-mono text-gray-300 focus:outline-none focus:border-red-500"
          />

          {iocResults && (
            <div className="space-y-3 font-mono text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-3 bg-black/60 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">IPV4 INDICATORS</div>
                  <div className="text-lg font-bold text-cyan-400">{iocResults.ipv4.length}</div>
                </div>
                <div className="p-3 bg-black/60 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">DOMAINS</div>
                  <div className="text-lg font-bold text-amber-400">{iocResults.domains.length}</div>
                </div>
                <div className="p-3 bg-black/60 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">HASHES (SHA256/MD5)</div>
                  <div className="text-lg font-bold text-emerald-400">{iocResults.sha256.length + iocResults.md5.length}</div>
                </div>
                <div className="p-3 bg-black/60 rounded border border-white/5">
                  <div className="text-gray-500 text-[10px]">TOTAL EXTRACTED</div>
                  <div className="text-lg font-bold text-white">{iocResults.totalIocs}</div>
                </div>
              </div>

              <div className="p-3 bg-black/60 rounded border border-red-900/30 space-y-1">
                <div className="text-xs font-bold text-red-400">DEFANGED OUTPUT (SAFE FOR TRANSMISSION)</div>
                <pre className="text-gray-300 overflow-x-auto p-2 bg-black/80 rounded">{iocResults.defangedText}</pre>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 6: SIGMA RULES */}
      {activeTab === 'SIGMA' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-xs font-mono text-gray-400">
              Evaluates Sigma detection rules against current forensic log lines.
            </span>
            <button
              onClick={handleEvaluateSigma}
              className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-black font-black font-mono text-xs uppercase tracking-wider rounded"
            >
              EVALUATE SIGMA RULE
            </button>
          </div>

          <textarea
            value={sigmaRule}
            onChange={(e) => setSigmaRule(e.target.value)}
            rows={8}
            className="w-full p-3 bg-black/80 border border-red-900/40 rounded-lg text-xs font-mono text-amber-300 focus:outline-none focus:border-red-500"
          />

          {sigmaResult && (
            <div className="p-4 bg-black/60 border border-red-900/30 rounded-xl font-mono text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-bold text-white">RULE: {sigmaResult.ruleTitle}</span>
                <span className={`px-2 py-0.5 rounded font-bold ${
                  sigmaResult.matched ? 'bg-red-950/80 text-red-400 border border-red-800' : 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                }`}>
                  {sigmaResult.matched ? 'MATCH TRIGGERED' : 'NO MATCH'}
                </span>
              </div>
              {sigmaResult.matched && (
                <div className="text-gray-400 space-y-1">
                  <div>Matched Logs:</div>
                  {sigmaResult.detectedLogs.map((log: string, i: number) => (
                    <div key={i} className="p-2 bg-red-950/30 rounded border border-red-900/40 text-red-300 text-[11px]">
                      {log}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SecurityEnginePanel;
