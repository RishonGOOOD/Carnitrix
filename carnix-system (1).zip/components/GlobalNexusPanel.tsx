
import React, { useState, useEffect, useMemo } from 'react';
import { Mode, GlobalPost } from '../types';
import { useAppContext } from '../context';
import { playSound, triggerHaptic } from '../utils/soundEffects';
import { 
    Globe, MessageSquare, Plus, ArrowUp, Zap, Newspaper, 
    ShieldAlert, User, Clock, Search, Filter, Loader2, Send
} from 'lucide-react';

const GlobalNexusPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { activeProfile } = state;
    const [posts, setPosts] = useState<GlobalPost[]>([]);
    const [isPosting, setIsPosting] = useState(false);
    const [newPost, setNewPost] = useState({ title: '', content: '', type: 'GENERAL' as GlobalPost['type'] });
    const [filterType, setFilterType] = useState<'ALL' | GlobalPost['type']>('ALL');
    const [isLoading, setIsLoading] = useState(true);

    // Initial Data Seed
    useEffect(() => {
        const saved = localStorage.getItem('carnix_nexus_posts');
        if (saved) {
            setPosts(JSON.parse(saved));
            setIsLoading(false);
        } else {
            const seed: GlobalPost[] = [
                { id: '1', author: 'ROOT_ADMIN', authorId: '0', title: 'Carnix OS v5.2 Patch Notes', content: 'Neural pathways optimized by 12%. Nanotech injection rate increased.', type: 'NEWS', timestamp: Date.now() - 3600000, upvotes: 124, tags: ['System', 'Patch'] },
                { id: '2', author: 'GHOST_8', authorId: '1', title: 'Help with Subspace Frequency', content: 'Anyone know the correct offset for the Alpha-7 cluster? I am getting heavy interference.', type: 'HELP', timestamp: Date.now() - 7200000, upvotes: 42, tags: ['Comms', 'Interference'] },
                { id: '3', author: 'INTEL_EYE', authorId: '2', title: 'Threat Detected in Sector 4', content: 'Unusual activity detected in the local mesh network. Secure your nodes.', type: 'INTEL', timestamp: Date.now() - 10800000, upvotes: 89, tags: ['Threat', 'Security'] }
            ];
            setPosts(seed);
            localStorage.setItem('carnix_nexus_posts', JSON.stringify(seed));
            setIsLoading(false);
        }
    }, []);

    const filteredPosts = useMemo(() => {
        return posts
            .filter(p => filterType === 'ALL' || p.type === filterType)
            .sort((a, b) => b.timestamp - a.timestamp);
    }, [posts, filterType]);

    const handleCreatePost = (e: React.FormEvent) => {
        e.preventDefault();
        if (!activeProfile || !newPost.title.trim() || !newPost.content.trim()) return;

        const post: GlobalPost = {
            id: `post-${Date.now()}`,
            author: activeProfile.name,
            authorId: activeProfile.id,
            title: newPost.title,
            content: newPost.content,
            type: newPost.type,
            timestamp: Date.now(),
            upvotes: 1,
            tags: []
        };

        const updated = [post, ...posts];
        setPosts(updated);
        localStorage.setItem('carnix_nexus_posts', JSON.stringify(updated));
        setNewPost({ title: '', content: '', type: 'GENERAL' });
        setIsPosting(false);
        playSound('success');
        triggerHaptic('medium');
    };

    const handleUpvote = (id: string) => {
        const updated = posts.map(p => p.id === id ? { ...p, upvotes: p.upvotes + 1 } : p);
        setPosts(updated);
        localStorage.setItem('carnix_nexus_posts', JSON.stringify(updated));
        playSound('click');
    };

    const getPostColor = (type: GlobalPost['type']) => {
        switch(type) {
            case 'NEWS': return 'text-green-400 border-green-900/50';
            case 'HELP': return 'text-blue-400 border-blue-900/50';
            case 'INTEL': return 'text-red-400 border-red-900/50';
            default: return 'text-cyan-400 border-cyan-900/50';
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-1 font-[Rajdhani]">
            {/* Header Control */}
            <div className="flex-shrink-0 jarvis-panel p-3 bg-black/60 border-b-2 border-cyan-500/30 flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Globe size={20} className="text-cyan-400 animate-pulse" />
                    <div>
                        <h2 className="text-sm font-black tracking-widest text-white uppercase">GLOBAL NEXUS</h2>
                        <div className="text-[8px] font-mono text-cyan-800 uppercase tracking-tighter">Decentralized Intel Network // Active Nodes: 1,402</div>
                    </div>
                </div>
                <button 
                    onClick={() => { setIsPosting(!isPosting); playSound('switch'); }}
                    className={`px-4 py-1.5 rounded border text-[10px] font-black flex items-center gap-2 transition-all ${isPosting ? 'bg-red-900/20 border-red-500 text-red-500' : 'bg-cyan-900/20 border-cyan-500 text-cyan-400'}`}
                >
                    {isPosting ? 'ABORT UPLINK' : <><Plus size={12}/> BROADCAST DATA</>}
                </button>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-3 overflow-hidden">
                {/* Main Feed */}
                <div className="flex-1 flex flex-col gap-3 overflow-hidden">
                    {isPosting && (
                        <form onSubmit={handleCreatePost} className="jarvis-panel p-4 bg-black/80 border border-cyan-500/50 animate-enter space-y-3 z-20">
                            <div className="flex justify-between items-center border-b border-white/10 pb-2">
                                <span className="text-[10px] font-black text-cyan-500 uppercase tracking-widest">Constructing Data Packet</span>
                                <select 
                                    value={newPost.type} 
                                    onChange={e => setNewPost({...newPost, type: e.target.value as any})}
                                    className="bg-black border border-gray-800 text-[10px] p-1 rounded font-bold text-gray-400"
                                >
                                    <option value="GENERAL">GENERAL</option>
                                    <option value="NEWS">NEWS</option>
                                    <option value="HELP">HELP REQUEST</option>
                                    <option value="INTEL">INTEL DROP</option>
                                </select>
                            </div>
                            <input 
                                value={newPost.title}
                                onChange={e => setNewPost({...newPost, title: e.target.value})}
                                placeholder="PACKET HEADER (TITLE)..."
                                className="w-full bg-black/40 border border-gray-800 p-2 text-xs font-bold text-white focus:border-cyan-500 outline-none uppercase"
                            />
                            <textarea 
                                value={newPost.content}
                                onChange={e => setNewPost({...newPost, content: e.target.value})}
                                placeholder="PACKET BODY CONTENT..."
                                className="w-full h-24 bg-black/40 border border-gray-800 p-2 text-xs text-gray-300 focus:border-cyan-500 outline-none"
                            />
                            <button type="submit" className="w-full py-3 bg-cyan-600 text-black font-black uppercase text-xs tracking-widest hover:bg-white transition-all shadow-[0_0_15px_rgba(0,240,255,0.4)]">
                                INITIALIZE UPLINK
                            </button>
                        </form>
                    )}

                    <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-carnix">
                        {isLoading ? (
                            <div className="flex flex-col items-center justify-center h-64 text-cyan-800 gap-2">
                                <Loader2 size={32} className="animate-spin" />
                                <span className="text-[10px] font-black tracking-widest uppercase">Syncing Nexus Mesh...</span>
                            </div>
                        ) : filteredPosts.map(post => (
                            <div key={post.id} className="jarvis-panel p-4 bg-black/40 border border-white/5 group hover:border-cyan-500/30 transition-all">
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center gap-2">
                                        <div className={`p-1 border rounded text-[8px] font-black tracking-widest ${getPostColor(post.type)}`}>
                                            {post.type}
                                        </div>
                                        <span className="text-[10px] font-bold text-gray-500 flex items-center gap-1">
                                            <User size={10} /> {post.author}
                                        </span>
                                    </div>
                                    <span className="text-[8px] font-mono text-gray-600 flex items-center gap-1">
                                        <Clock size={8} /> {new Date(post.timestamp).toLocaleTimeString()}
                                    </span>
                                </div>
                                <h3 className="text-sm font-black text-white group-hover:text-cyan-400 transition-colors uppercase mb-2 tracking-tight">{post.title}</h3>
                                <p className="text-xs text-gray-400 leading-relaxed italic border-l-2 border-gray-800 pl-3 mb-4">
                                    "{post.content}"
                                </p>
                                <div className="flex items-center gap-4">
                                    <button 
                                        onClick={() => handleUpvote(post.id)}
                                        className="flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded hover:bg-cyan-500/20 hover:border-cyan-500 transition-all group/btn"
                                    >
                                        <ArrowUp size={12} className="text-gray-500 group-hover/btn:text-cyan-400" />
                                        <span className="text-[10px] font-black text-gray-400 group-hover/btn:text-white">{post.upvotes}</span>
                                    </button>
                                    <button className="flex items-center gap-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded hover:bg-white/10 transition-all">
                                        <MessageSquare size={12} className="text-gray-600" />
                                        <span className="text-[10px] font-black text-gray-500">COMMS</span>
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Sidebar Stats */}
                <div className="w-full md:w-64 flex flex-col gap-3">
                    <div className="jarvis-panel p-4 bg-black/60 border-l-2 border-red-500">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-widest mb-4 flex items-center gap-2">
                            <ShieldAlert size={14} className="text-red-500" /> HOT THREATS
                        </h4>
                        <div className="space-y-3">
                            <div className="p-2 bg-red-900/10 border border-red-900/30 rounded">
                                <div className="text-[8px] font-bold text-red-500 mb-1">0xFC32 CRITICAL</div>
                                <div className="text-[10px] text-gray-400">Large scale DDoS detected in Frankfurt node.</div>
                            </div>
                            <div className="p-2 bg-yellow-900/10 border border-yellow-900/30 rounded">
                                <div className="text-[8px] font-bold text-yellow-500 mb-1">DATA LEAK</div>
                                <div className="text-[10px] text-gray-400">Credentials dump on sector-7 dark web.</div>
                            </div>
                        </div>
                    </div>

                    <div className="jarvis-panel p-4 bg-black/60 border-l-2 border-cyan-500 flex-1">
                        <h4 className="text-[10px] font-black text-white uppercase tracking-widest mb-4">MESH FILTERS</h4>
                        <div className="space-y-1">
                            {['ALL', 'NEWS', 'INTEL', 'HELP', 'GENERAL'].map(type => (
                                <button 
                                    key={type}
                                    onClick={() => { setFilterType(type as any); playSound('click'); }}
                                    className={`w-full text-left px-3 py-2 text-[10px] font-bold transition-all border-l-2 ${filterType === type ? 'bg-cyan-500/10 border-cyan-500 text-white' : 'border-transparent text-gray-600 hover:text-gray-400'}`}
                                >
                                    {type}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GlobalNexusPanel;
