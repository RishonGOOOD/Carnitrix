import React, { useState } from 'react';
import { 
  Grid, Settings, Zap, Home, Cloud, HardDrive, 
  Search, ShieldAlert, Eye, Volume2, VolumeX, ShieldCheck, Smartphone
} from 'lucide-react';
import { useAppContext } from '../context';
import { Mode } from '../types';
import { playSound, isSoundMuted, toggleMuteSound, triggerHaptic } from '../utils/soundEffects';

interface TopBarProps {
  onOpenSettings: () => void;
  onOpenMatrix: () => void;
  onOpenStorage?: () => void;
  isAndroidMode: boolean;
  onToggleAndroidMode: () => void;
}

const TopBar: React.FC<TopBarProps> = ({ onOpenSettings, onOpenMatrix, onOpenStorage, isAndroidMode, onToggleAndroidMode }) => {
  const { state, dispatch } = useAppContext();
  const { isOnline, mode, isStealthMode } = state;
  const [headerSearch, setHeaderSearch] = useState('');
  const [isMuted, setIsMuted] = useState(isSoundMuted());

  const goHome = () => {
    playSound('access');
    dispatch({ type: 'SET_MODE', payload: Mode.Home });
  };

  const handleHeaderSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!headerSearch.trim()) return;
    playSound('scan');
    dispatch({ type: 'SET_MODE', payload: Mode.GlobalSearch });
  };

  const handleToggleSound = () => {
    const muted = toggleMuteSound();
    setIsMuted(muted);
    if (!muted) playSound('click');
  };

  const handleToggleStealth = () => {
    dispatch({ type: 'TOGGLE_STEALTH' });
    playSound(state.isStealthMode ? 'access' : 'alert');
    triggerHaptic('medium');
  };

  return (
    <header className="h-14 border-b border-red-900/30 bg-[#060002] px-3 sm:px-4 flex items-center justify-between shrink-0 z-40 font-[Rajdhani] select-none gap-2">
      {/* Left: Brand Identity */}
      <button 
        onClick={goHome}
        title="Return to Core HUD Dashboard"
        className="flex items-center gap-2.5 hover:opacity-90 transition-opacity active:scale-95 group text-left shrink-0"
      >
        <div className="p-1.5 bg-red-600 rounded-lg shadow-[0_0_15px_rgba(255,0,0,0.6)] group-hover:rotate-12 transition-transform">
          <Zap size={16} className="text-black fill-black" />
        </div>
        <div className="flex flex-col">
          <span className="text-xs sm:text-sm font-black text-white tracking-wider uppercase italic leading-none font-orbitron">
            CARNIX CORE
          </span>
          <span className="text-[8px] sm:text-[9px] font-bold text-red-500 uppercase tracking-widest mt-0.5">
            {isStealthMode ? 'GHOST_CLOAK' : 'DEFENSIVE_OSINT_AI'}
          </span>
        </div>
      </button>

      {/* Center: Global Omni Search Quick Bar */}
      <form onSubmit={handleHeaderSearchSubmit} className="hidden md:flex items-center flex-1 max-w-md mx-3">
        <div className="relative w-full">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            placeholder="Omni-search target IP, domain, username, or CVE..."
            value={headerSearch}
            onChange={(e) => setHeaderSearch(e.target.value)}
            className="w-full pl-8 pr-12 py-1.5 bg-black/80 border border-red-900/40 rounded-lg text-xs font-mono text-white placeholder-gray-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500"
          />
          <kbd className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/90 border border-red-900/40 text-gray-400">
            ENTER
          </kbd>
        </div>
      </form>

      {/* Right Controls & Telemetry */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Stealth Mode Toggle */}
        <button
          onClick={handleToggleStealth}
          title={isStealthMode ? "Disable Ghost Protocol" : "Enable Ghost Protocol"}
          className={`px-2 py-1 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1 transition-all ${
            isStealthMode 
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300 shadow-[0_0_10px_rgba(0,240,255,0.4)]' 
              : 'bg-black/60 border-white/5 text-gray-400 hover:text-white'
          }`}
        >
          <Eye size={12} className={isStealthMode ? 'text-cyan-400' : 'text-gray-400'} />
          <span className="hidden sm:inline">{isStealthMode ? 'CLOAKED' : 'STEALTH'}</span>
        </button>

        {/* Android App Mode Toggle */}
        <button
          onClick={() => {
            playSound('click');
            onToggleAndroidMode();
          }}
          title={isAndroidMode ? "Switch to Desktop Workstation" : "Switch to Android Phone App View"}
          className={`px-2 py-1 rounded-lg border text-[10px] font-mono font-bold flex items-center gap-1 transition-all ${
            isAndroidMode 
              ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-[0_0_10px_rgba(0,255,100,0.4)]' 
              : 'bg-black/60 border-white/5 text-gray-400 hover:text-white'
          }`}
        >
          <Smartphone size={12} className={isAndroidMode ? 'text-emerald-400' : 'text-gray-400'} />
          <span className="hidden sm:inline">{isAndroidMode ? 'ANDROID APP' : 'PHONE VIEW'}</span>
        </button>

        {/* Audio Mute */}
        <button
          onClick={handleToggleSound}
          title={isMuted ? "Unmute Audio" : "Mute Audio"}
          className="p-1.5 rounded-lg bg-black/60 hover:bg-red-950/40 text-gray-400 hover:text-white border border-white/5 transition-all"
        >
          {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} className="text-red-400" />}
        </button>

        {/* Storage status */}
        <button
          onClick={() => {
            playSound('click');
            onOpenStorage?.();
          }}
          title="Storage Databanks"
          className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[10px] font-mono tracking-wider transition-all ${
            isOnline 
              ? 'bg-cyan-950/30 border-cyan-500/40 text-cyan-300' 
              : 'bg-amber-950/30 border-amber-500/40 text-amber-300'
          }`}
        >
          {isOnline ? (
            <Cloud size={12} className="text-cyan-400 animate-pulse" />
          ) : (
            <HardDrive size={12} className="text-amber-400" />
          )}
          <span className="font-bold">{isOnline ? 'CLOUD SYNC' : 'LOCAL VAULT'}</span>
        </button>

        {/* Home HUD */}
        {mode !== Mode.Home && (
          <button 
            onClick={goHome}
            title="Return to Core Dashboard"
            className="p-1.5 bg-black/80 border border-red-600/40 rounded-lg text-red-400 hover:text-white hover:bg-red-600/30 transition-all active:scale-95"
          >
            <Home size={15} />
          </button>
        )}

        {/* Matrix [42] */}
        <button 
          onClick={() => {
            playSound('click');
            onOpenMatrix();
          }}
          title="Open All 42 Subsystems Matrix"
          className="p-1.5 bg-black/80 border border-red-600/40 rounded-lg text-red-400 hover:text-white hover:bg-red-600/30 transition-all active:scale-95"
        >
          <Grid size={15} />
        </button>
        
        {/* Settings */}
        <button 
          onClick={() => {
            playSound('click');
            onOpenSettings();
          }}
          title="Settings"
          className="p-1.5 bg-black/80 border border-red-600/40 rounded-lg text-red-400 hover:text-white hover:bg-red-600/30 transition-all active:scale-95"
        >
          <Settings size={15} />
        </button>
      </div>
    </header>
  );
};

export default TopBar;
