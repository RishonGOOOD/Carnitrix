

import React, { useState, useEffect } from 'react';
import { Profile, Mode, ProfileClass } from '../types';
import { UserPlus, Trash2, Save, User, X, Shield, Lock, Layers } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const ProfileManagerPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const [profiles, setProfiles] = useState<Profile[]>([]);
    
    // Form State
    const [editingId, setEditingId] = useState<string | null>(null);
    const [name, setName] = useState('');
    const [passcode, setPasscode] = useState('');
    const [isSuperUser, setIsSuperUser] = useState(false);
    const [selectedModes, setSelectedModes] = useState<Mode[]>([]);
    
    const allModes = Object.values(Mode).filter(m => m !== Mode.ProfileManager);

    useEffect(() => {
        const saved = localStorage.getItem('carnix_profiles');
        if (saved) {
            setProfiles(JSON.parse(saved));
        }
    }, []);

    /* Comment: Updated getDefaultProfile to include missing required properties like 'nexusLinks' and 'chats' to match Profile interface */
    const getDefaultProfile = (): Profile => ({
        id: `p-${Date.now()}`,
        name: name.toUpperCase(),
        passcode: passcode,
        isSuperUser: isSuperUser,
        allowedModes: selectedModes.length > 0 ? selectedModes : undefined,
        // Comment: Added missing nexusLinks property to fix Profile type mismatch error
        nexusLinks: [],
        lastMode: Mode.Home,
        speciality: isSuperUser ? 'Overlord' : 'Generalist',
        nodeCreatedAt: Date.now(),
        aiEvolutionLevel: 1,
        aiSettings: {
            model: 'gemini-3-pro-preview',
            // Fix: Added missing engine property to meet AIModelSettings interface requirements
            engine: 'GEMINI_CLOUD',
            temperature: 0.7,
            useSearchGrounding: true,
            useMapsGrounding: false,
            personality: 'Neutral',
            tone: 'Neutral',
            verbosity: 'Balanced',
            voiceName: 'Zephyr',
            speechSpeed: 1.0,
            textToSpeechEnabled: true,
            useThinking: false,
            useLingo: false,
            useLocalModel: false,
            isLocalModelLoaded: false,
            localEndpoint: 'http://localhost:8080',
            contextWindow: 2048,
            gpuLayers: 32
        },
        uiSettings: {
            primaryColor: '#FF003C',
            accentColor: '#00F0FF',
            hudPosition: 'standard',
            showScanlines: true,
            codeRainDensity: 40,
            uiScale: 100,
            soundVolume: 80,
            hapticEnabled: true,
            glowIntensity: 50
        },
        // Comment: Fix - added required 'chats' property
        chats: [],
        registeredModels: [],
        notes: [],
        contacts: [],
        features: [],
        activeTheme: 'crimson_eclipse',
        customThemes: {},
        nanobotSwarm: { status: 'IDLE', activeCount: 0, efficiency: 100, currentTask: 'Standby' },
        chatHistory: [{ id: 1, sender: 'system', text: `Welcome, ${name}. System initialized.` }],
        groupChatHistory: [],
        systemLog: [],
        events: [],
        journal: [],
        automations: [],
        plugins: [],
        launcherApps: [],
        usageMetrics: {},
        tasks: []
    });

    const resetForm = () => {
        setEditingId(null);
        setName('');
        setPasscode('');
        setIsSuperUser(false);
        setSelectedModes([]);
        playSound('click');
    };

    const loadProfileForEdit = (profile: Profile) => {
        setEditingId(profile.id);
        setName(profile.name);
        setPasscode(profile.passcode || '');
        setIsSuperUser(!!profile.isSuperUser);
        setSelectedModes(profile.allowedModes || []);
        playSound('process');
    };

    const applyPreset = (presetName: string) => {
        setName(presetName);
        setPasscode('1234'); // Default weak code for presets
        
        switch(presetName) {
            case 'MASTER_CONTROL':
                setIsSuperUser(true);
                setSelectedModes([...allModes]); 
                break;
            case 'ENGINEER':
                setSelectedModes([Mode.Microcontroller, Mode.Hardware, Mode.Diagnostics, Mode.Settings, Mode.Terminal]);
                setIsSuperUser(false);
                break;
            case 'MEDIC':
                setSelectedModes([Mode.Health, Mode.EmergencyServicesMonitor, Mode.ChemicalAnalysis, Mode.Cybernetics]);
                setIsSuperUser(false);
                break;
            case 'SCIENTIST':
                setSelectedModes([Mode.Vision, Mode.Geo, Mode.ExoplanetDB, Mode.StellarCartography, Mode.QuantumSearch]);
                setIsSuperUser(false);
                break;
            case 'INTEL':
                setSelectedModes([Mode.News, Mode.WebIntelligence, Mode.ThreatIntel, Mode.GlobalNexus, Mode.Crypto]);
                setIsSuperUser(false);
                break;
            case 'PILOT':
                // Comment: Fixed DroneControl -> DriveControl
                setSelectedModes([Mode.DriveControl, Mode.FlightTracker, Mode.Location, Mode.WeatherRadar, Mode.Camera]);
                setIsSuperUser(false);
                break;
            case 'GHOST':
                setSelectedModes([Mode.StealthSystems, Mode.SecureComms, Mode.EthicalHacking, Mode.SignalIntercept]);
                setIsSuperUser(false);
                break;
            case 'COMMANDER':
                setSelectedModes([Mode.Tactical, Mode.WorldStatus, Mode.AccessControl, Mode.Tasks, Mode.GroupChat]);
                setIsSuperUser(false);
                break;
            case 'ECR':
                setSelectedModes([Mode.RecoveryBackup, Mode.Files, Mode.Settings, Mode.SystemCore]);
                setIsSuperUser(true);
                break;
            default:
                setSelectedModes([]);
        }
        playSound('access');
    }

    const handleSave = () => {
        if (!name.trim()) return;
        playSound('process');
        
        let updatedProfiles: Profile[];

        if (editingId) {
            updatedProfiles = profiles.map(p => {
                if (p.id === editingId) {
                    return {
                        ...p,
                        name: name.toUpperCase(),
                        passcode: passcode,
                        isSuperUser: isSuperUser,
                        allowedModes: selectedModes.length > 0 ? selectedModes : undefined,
                        speciality: name.toUpperCase() as ProfileClass // Simple mapping
                    };
                }
                return p;
            });
            
            if (editingId === state.activeProfile?.id) {
                dispatch({ 
                    type: 'UPDATE_PROFILE', 
                    payload: { 
                        name: name.toUpperCase(),
                        passcode: passcode,
                        isSuperUser: isSuperUser,
                        allowedModes: selectedModes.length > 0 ? selectedModes : undefined,
                        speciality: name.toUpperCase() as ProfileClass
                    } 
                });
            }
        } else {
            const newProfile = getDefaultProfile();
            updatedProfiles = [...profiles, newProfile];
        }
        
        setProfiles(updatedProfiles);
        localStorage.setItem('carnix_profiles', JSON.stringify(updatedProfiles));
        resetForm();
        playSound('success');
    };

    const handleDelete = (id: string) => {
        if (confirm("Permanently delete this identity node?")) {
            const updated = profiles.filter(p => p.id !== id);
            setProfiles(updated);
            localStorage.setItem('carnix_profiles', JSON.stringify(updated));
            playSound('error');
            if (id === state.activeProfile?.id) dispatch({ type: 'LOGOUT' });
        }
    };

    const toggleModeSelection = (mode: Mode) => {
        setSelectedModes(prev => prev.includes(mode) ? prev.filter(m => m !== mode) : [...prev, mode]);
    };

    const presets = ['MASTER_CONTROL', 'ECR', 'INTEL', 'GHOST', 'PILOT', 'MEDIC', 'ENGINEER', 'SCIENTIST', 'COMMANDER'];

    return (
        <div className="w-full h-full flex flex-col md:flex-row gap-6 p-2 font-[Rajdhani]">
            <div className="w-full md:w-1/3 flex flex-col gap-4">
                <div className={`border-2 rounded-lg p-5 bg-black/60 transition-colors ${editingId ? 'border-blue-500' : 'border-[var(--color-primary)]'}`}>
                    <div className="flex justify-between items-center mb-6">
                        <h2 className={`text-lg font-black tracking-widest uppercase ${editingId ? 'text-blue-400' : 'text-[var(--color-primary)]'}`}>
                            {editingId ? 'Edit ID Node' : 'Register New Node'}
                        </h2>
                        {editingId && <button onClick={resetForm}><X size={18}/></button>}
                    </div>
                    
                    <div className="space-y-4">
                        <div className="flex flex-wrap gap-2 mb-4">
                            {presets.map(p => (
                                <button key={p} onClick={() => applyPreset(p)} className="px-2 py-1 text-[8px] border border-gray-700 rounded bg-gray-800 hover:bg-[var(--color-primary)] hover:text-black transition-all font-black">{p}</button>
                            ))}
                        </div>
                        
                        <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-black border border-gray-700 p-3 text-white font-mono uppercase" placeholder="OPERATOR CALLSIGN" />
                        <input value={passcode} onChange={e => setPasscode(e.target.value)} className="w-full bg-black border border-gray-700 p-3 text-white font-mono" placeholder="ACCESS PASSCODE" />
                        
                        <div onClick={() => setIsSuperUser(!isSuperUser)} className={`p-3 border rounded cursor-pointer ${isSuperUser ? 'border-red-500 bg-red-900/20' : 'border-gray-700'}`}>
                            <div className="text-xs font-black text-white">LEVEL 5 ROOT CLEARANCE</div>
                            <div className="text-[9px] text-gray-500">ALLOW UNRESTRICTED CORE ACCESS</div>
                        </div>

                        <div className="flex flex-col h-48">
                            <label className="text-[10px] font-black text-gray-500 mb-2 uppercase">Module Deployment Permissions</label>
                            <div className="flex-1 overflow-y-auto bg-black/40 border border-gray-800 p-2 space-y-1 scrollbar-carnix">
                                {allModes.map(m => (
                                    <div key={m} onClick={() => toggleModeSelection(m)} className="flex items-center gap-2 p-1 cursor-pointer hover:bg-white/5">
                                        <div className={`w-3 h-3 border ${selectedModes.includes(m) ? 'bg-[var(--color-primary)]' : 'border-gray-600'}`}></div>
                                        <span className={`text-[10px] ${selectedModes.includes(m) ? 'text-white' : 'text-gray-600'}`}>{m}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    <button onClick={handleSave} className="w-full p-4 mt-6 bg-[var(--color-primary)] text-black font-black uppercase tracking-widest hover:bg-white transition-all shadow-[0_0_20px_rgba(255,0,60,0.4)] flex items-center justify-center gap-2">
                        <Save size={18}/> {editingId ? 'Update Node' : 'Initialize Node'}
                    </button>
                </div>
            </div>

            <div className="flex-1 bg-black/40 border border-white/5 rounded-lg p-4 flex flex-col overflow-hidden">
                <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest mb-4 border-b border-white/10 pb-2">Active Node Registry</h3>
                <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {profiles.map(p => (
                        <div key={p.id} onClick={() => loadProfileForEdit(p)} className={`p-4 border rounded cursor-pointer group hover:border-[var(--color-primary)] transition-all ${editingId === p.id ? 'border-blue-500 bg-blue-900/10' : 'border-gray-800 bg-black/40'}`}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <div className="flex items-center gap-2">
                                        <span className="font-black text-white">{p.name}</span>
                                        {p.isSuperUser && <Shield size={10} className="text-red-500" />}
                                    </div>
                                    <div className="text-[10px] text-gray-500 font-mono">NODE_ID: {p.id.slice(-8)}</div>
                                    <div className="flex gap-1 mt-2">
                                        <span className="text-[8px] px-1 border border-gray-700 text-gray-400">{p.speciality}</span>
                                        <span className="text-[8px] px-1 border border-gray-700 text-gray-400">{p.allowedModes?.length || allModes.length} MODS</span>
                                    </div>
                                </div>
                                <button onClick={(e) => { e.stopPropagation(); handleDelete(p.id); }} className="text-gray-700 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={16}/></button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default ProfileManagerPanel;
