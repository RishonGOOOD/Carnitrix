




import React, { useState } from 'react';
import { Repeat, Plus, Trash2, Edit, Save, X, Clock, MapPin, Bell, Cpu } from 'lucide-react';
import { useAppContext } from '../context';
import { AutomationRule, Mode } from '../types';
import { playSound } from '../utils/soundEffects';

const AutomationPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const automations = state.activeProfile?.automations || [];

    const [isEditing, setIsEditing] = useState<Partial<AutomationRule> | null>(null);

    const onUpdateAutomations = (newAutomations: AutomationRule[]) => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { automations: newAutomations } });
    };

    const handleSave = () => {
        if (!isEditing || !isEditing.trigger?.type || !isEditing.action?.type) return;

        const newRule: AutomationRule = {
            id: isEditing.id || `auto-${Date.now()}`,
            trigger: isEditing.trigger,
            action: isEditing.action,
            enabled: isEditing.enabled ?? true,
        };

        const existing = automations.find(a => a.id === newRule.id);
        if (existing) {
            onUpdateAutomations(automations.map(a => a.id === newRule.id ? newRule : a));
        } else {
            onUpdateAutomations([...automations, newRule]);
        }
        setIsEditing(null);
        playSound('success');
    };

    const handleToggle = (id: string) => {
        onUpdateAutomations(automations.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
        playSound('switch');
    };
    
    const handleDelete = (id: string) => {
        onUpdateAutomations(automations.filter(a => a.id !== id));
        playSound('error');
    };

    const renderRule = (rule: AutomationRule) => (
        <div key={rule.id} className="p-3 bg-black/40 border border-gray-800 rounded flex items-center justify-between group">
            <div className="flex items-center gap-4">
                {rule.trigger.type === 'TIME' ? <Clock size={20} className="text-blue-400"/> : rule.trigger.type === 'SYSTEM_EVENT' ? <Cpu size={20} className="text-purple-400"/> : <MapPin size={20} className="text-green-400"/>}
                <div>
                    <p className="font-bold text-white">IF <span className="text-blue-400">{rule.trigger.type} is {rule.trigger.value}</span></p>
                    <p className="text-sm text-gray-300">THEN <span className="text-yellow-400">{rule.action.type.replace('_', ' ')}: "{rule.action.value}"</span></p>
                </div>
            </div>
            <div className="flex items-center gap-2">
                 <button onClick={() => handleToggle(rule.id)} className={`w-10 h-5 rounded-full p-0.5 flex-shrink-0 transition-colors ${rule.enabled ? 'bg-green-500' : 'bg-gray-600'}`}>
                    <span className={`block w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${rule.enabled ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
                <button onClick={() => handleDelete(rule.id)} className="text-red-500 opacity-0 group-hover:opacity-100"><Trash2 size={16}/></button>
            </div>
        </div>
    );
    
    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Repeat size={16}/> AUTOMATION HUB</h2>
                <button onClick={() => setIsEditing({})} className="px-3 py-1 bg-[var(--color-primary)]/20 text-[var(--color-primary)] rounded text-xs flex items-center gap-1">
                    <Plus size={12} /> NEW RULE
                </button>
            </div>
            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md overflow-y-auto p-2 space-y-2">
                {isEditing && (
                    <div className="p-4 bg-blue-900/20 border border-blue-700 rounded space-y-3">
                        <h3 className="font-bold text-white">{isEditing.id ? 'Edit Rule' : 'Create New Rule'}</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs text-gray-400">Trigger Type</label>
                                <select value={isEditing.trigger?.type} onChange={e => setIsEditing(p => ({...p, trigger: {type: e.target.value as any, value: ''}}))} className="w-full bg-black/50 p-2 mt-1 rounded border border-gray-600 text-sm">
                                    <option>Select...</option>
                                    <option value="TIME">Time</option>
                                    <option value="SYSTEM_EVENT">System Event</option>
                                </select>
                            </div>
                            {isEditing.trigger?.type === 'TIME' && (
                                <div>
                                    <label className="text-xs text-gray-400">Time (HH:MM)</label>
                                    <input type="time" value={isEditing.trigger.value} onChange={e => setIsEditing(p => ({...p, trigger: {...p!.trigger!, value: e.target.value}}))} className="w-full bg-black/50 p-2 mt-1 rounded border border-gray-600 text-sm" />
                                </div>
                            )}
                            {isEditing.trigger?.type === 'SYSTEM_EVENT' && (
                                <div>
                                    <label className="text-xs text-gray-400">Event</label>
                                    <select value={isEditing.trigger.value} onChange={e => setIsEditing(p => ({...p, trigger: {...p!.trigger!, value: e.target.value}}))} className="w-full bg-black/50 p-2 mt-1 rounded border border-gray-600 text-sm">
                                        <option value="">Select Event...</option>
                                        <option value="STARTUP">System Startup</option>
                                        <option value="LOW_BATTERY">Low Battery (&lt;20%)</option>
                                        <option value="HIGH_CPU">High CPU Load</option>
                                        <option value="OFFLINE">Network Offline</option>
                                    </select>
                                </div>
                            )}
                        </div>
                         <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs text-gray-400">Action Type</label>
                                <select value={isEditing.action?.type} onChange={e => setIsEditing(p => ({...p, action: {type: e.target.value as any, value: ''}}))} className="w-full bg-black/50 p-2 mt-1 rounded border border-gray-600 text-sm">
                                    <option>Select...</option>
                                    <option value="SET_MODE">Set Mode</option>
                                    <option value="SHOW_ALERT">Show Alert</option>
                                    <option value="SEND_MESSAGE">Log Message</option>
                                </select>
                            </div>
                            {isEditing.action?.type === 'SET_MODE' && (
                                 <div>
                                    <label className="text-xs text-gray-400">Mode</label>
                                    <select value={isEditing.action.value} onChange={e => setIsEditing(p => ({...p, action: {...p!.action!, value: e.target.value}}))} className="w-full bg-black/50 p-2 mt-1 rounded border border-gray-600 text-sm">
                                        {Object.values(Mode).map(m => <option key={m} value={m}>{m}</option>)}
                                    </select>
                                </div>
                            )}
                             {(isEditing.action?.type === 'SHOW_ALERT' || isEditing.action?.type === 'SEND_MESSAGE') && (
                                <div>
                                    <label className="text-xs text-gray-400">Message Text</label>
                                    <input type="text" value={isEditing.action.value} onChange={e => setIsEditing(p => ({...p, action: {...p!.action!, value: e.target.value}}))} className="w-full bg-black/50 p-2 mt-1 rounded border border-gray-600 text-sm" />
                                </div>
                            )}
                        </div>
                        <div className="flex gap-2">
                            <button onClick={handleSave} className="p-2 bg-green-700 rounded text-xs flex-1">Save Rule</button>
                            <button onClick={() => setIsEditing(null)} className="p-2 bg-gray-700 rounded text-xs flex-1">Cancel</button>
                        </div>
                    </div>
                )}
                {automations.map(renderRule)}
            </div>
        </div>
    );
};

export default AutomationPanel;
