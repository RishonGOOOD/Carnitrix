import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Activity, RefreshCw, CheckCircle2, AlertTriangle, XCircle, 
  Terminal, Cpu, Database, Eye, Fingerprint, ShieldAlert, Zap, Clock 
} from 'lucide-react';
import { runTacticalTestSuit, SubsystemTestResult, SystemHealthSummary } from '../services/tacticalTestEngine';
import { playSound, triggerHaptic } from '../utils/soundEffects';

export const TacticalDiagnosticsPanel: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<SubsystemTestResult[]>([]);
  const [summary, setSummary] = useState<SystemHealthSummary | null>(null);
  const [selectedSubsystem, setSelectedSubsystem] = useState<string>('ALL');

  const executeTests = async () => {
    setIsRunning(true);
    playSound('click');
    triggerHaptic('medium');
    try {
      const data = await runTacticalTestSuit();
      setResults(data.results);
      setSummary(data.summary);
    } catch (err) {
      console.error(err);
    } finally {
      setIsRunning(false);
    }
  };

  useEffect(() => {
    executeTests();
  }, []);

  const filteredResults = selectedSubsystem === 'ALL' 
    ? results 
    : results.filter(r => r.subsystem.toLowerCase().includes(selectedSubsystem.toLowerCase()));

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050102] text-white font-[Rajdhani] p-2 sm:p-4 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-red-900/40">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="text-red-500 animate-pulse" size={24} />
            <h1 className="text-xl font-black tracking-wider text-red-500 uppercase">TACTICAL SUBSYSTEM DIAGNOSTICS</h1>
          </div>
          <p className="text-xs text-gray-400 font-mono mt-0.5">
            Real-time health monitoring, test suite verification, and performance telemetry across OSINT, Vision, Forensics, and Terminal engines.
          </p>
        </div>

        <button
          onClick={executeTests}
          disabled={isRunning}
          className="px-4 py-2 bg-red-600 hover:bg-red-500 text-black font-bold rounded-lg text-xs font-mono flex items-center gap-2 shadow-[0_0_15px_rgba(255,0,0,0.4)] transition-all disabled:opacity-50"
        >
          <RefreshCw size={14} className={isRunning ? 'animate-spin' : ''} />
          {isRunning ? 'RUNNING TEST SUITE...' : 'RUN FULL TEST SUITE'}
        </button>
      </div>

      {/* Summary Scorecard */}
      {summary && (
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 my-4">
          <div className="bg-black/60 border border-red-900/40 rounded-xl p-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-gray-400">OVERALL HEALTH</span>
              <div className={`text-lg font-black tracking-wide ${summary.overallHealth === 'OPTIMAL' ? 'text-emerald-400' : 'text-amber-400'}`}>
                {summary.overallHealth}
              </div>
            </div>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${
              summary.overallHealth === 'OPTIMAL' ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400' : 'bg-amber-950/40 border-amber-500/40 text-amber-400'
            }`}>
              <ShieldCheck size={20} />
            </div>
          </div>

          <div className="bg-black/60 border border-red-900/40 rounded-xl p-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-gray-400">HEALTH SCORE</span>
              <div className="text-lg font-black font-mono text-white">{summary.score}%</div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-red-950/40 border border-red-500/40 text-red-400 flex items-center justify-center">
              <Zap size={20} />
            </div>
          </div>

          <div className="bg-black/60 border border-red-900/40 rounded-xl p-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-gray-400">TESTS PASSED</span>
              <div className="text-lg font-black font-mono text-emerald-400">{summary.passedCount} / {results.length}</div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
              <CheckCircle2 size={20} />
            </div>
          </div>

          <div className="bg-black/60 border border-red-900/40 rounded-xl p-3 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono text-gray-400">LAST VERIFICATION</span>
              <div className="text-xs font-mono text-gray-300 mt-1">{new Date(summary.lastRunTimestamp).toLocaleTimeString()}</div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-purple-950/40 border border-purple-500/40 text-purple-400 flex items-center justify-center">
              <Clock size={20} />
            </div>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-white/5 my-2">
        {['ALL', 'OSINT', 'Computer Vision', 'Digital Forensics', 'Threat Intelligence', 'Terminal Sandbox', 'Network Analysis'].map(cat => (
          <button
            key={cat}
            onClick={() => {
              setSelectedSubsystem(cat);
              playSound('click');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
              selectedSubsystem === cat 
                ? 'bg-red-600 text-black font-bold shadow-[0_0_10px_rgba(255,0,0,0.4)]' 
                : 'bg-black/60 text-gray-400 hover:text-white border border-white/5'
            }`}
          >
            {cat.toUpperCase()}
          </button>
        ))}
      </div>

      {/* Results List */}
      <div className="flex-1 space-y-2 mt-2">
        {filteredResults.map(test => (
          <div key={test.id} className="bg-black/70 border border-red-950/60 rounded-xl p-3.5 hover:border-red-500/50 transition-all">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg mt-0.5 border ${
                  test.status === 'PASSED' 
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400' 
                    : test.status === 'WARNING'
                    ? 'bg-amber-950/40 border-amber-500/40 text-amber-400'
                    : 'bg-red-950/40 border-red-500/40 text-red-400'
                }`}>
                  {test.status === 'PASSED' ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-900/40">
                      {test.subsystem}
                    </span>
                    <h3 className="text-sm font-bold text-white tracking-wide">{test.name}</h3>
                  </div>
                  <p className="text-xs text-gray-300 font-mono mt-1">{test.message}</p>
                  
                  {test.details && (
                    <div className="flex flex-wrap gap-2 mt-2 pt-2 border-t border-white/5">
                      {Object.entries(test.details).map(([k, v]) => (
                        <span key={k} className="text-[10px] font-mono bg-black/80 px-2 py-0.5 rounded text-gray-400 border border-white/5">
                          {k}: <span className="text-red-400 font-bold">{String(v)}</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="text-xs font-mono text-emerald-400 font-bold">{test.latencyMs} ms</span>
                <div className="text-[9px] font-mono text-gray-500 mt-1">{new Date(test.timestamp).toLocaleTimeString()}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TacticalDiagnosticsPanel;
