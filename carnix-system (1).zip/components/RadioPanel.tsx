
import React, { useState, useEffect, useRef } from 'react';
import { RadioStation } from '../types';
import { Play, Pause, Radio, Signal, Loader2, SkipForward, SkipBack, AlertTriangle, Volume2 } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

const stations: RadioStation[] = [
    { name: "CHENNAI RAINBOW", url_resolved: "https://air.pc.cdn.bitgravity.com/air/live/pbaudio023/playlist.m3u8", tags: 'Tamil, AIR, Classics' },
    { name: "HELLO FM", url_resolved: "https://stream.zeno.fm/1qz8y1a1z7zuv", tags: 'Tamil, Hits, Pop' },
    { name: "TAMIL FM (ZENO)", url_resolved: "https://stream.zeno.fm/0r0ksv3wxg0uv", tags: 'Tamil, Variety' },
    { name: "LOFI HIP HOP", url_resolved: "https://stream.zeno.fm/0r0xa792kwzuv", tags: 'Chill, Study' },
    { name: "NIGHTWAVE PLAZA", url_resolved: "https://radio.plaza.one/mp3", tags: 'Vaporwave, Synth' },
    { name: "SOMA FM GROOVE", url_resolved: "https://ice1.somafm.com/groovesalad-128-mp3", tags: 'Ambient, Downtempo' },
    { name: "DEFCON RADIO", url_resolved: "https://stream.zeno.fm/f3wvbbqmdg8uv", tags: 'Hacker, Dark' },
];

const RadioPanel: React.FC = () => {
    const [stationIdx, setStationIdx] = useState(0);
    const [isPlaying, setIsPlaying] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [volume, setVolume] = useState(0.5);
    const audioRef = useRef<HTMLAudioElement | null>(null);
    const current = stations[stationIdx];

    useEffect(() => {
        const audio = new Audio();
        audio.crossOrigin = "anonymous";
        audioRef.current = audio;
        return () => {
            audio.pause();
            audio.src = "";
        };
    }, []);

    useEffect(() => {
        if (!audioRef.current) return;
        audioRef.current.volume = volume;
    }, [volume]);

    useEffect(() => {
        if (!audioRef.current) return;
        
        const stopAndLoad = async () => {
            setIsLoading(true);
            setError(null);
            audioRef.current!.pause();
            setIsPlaying(false);
            
            audioRef.current!.src = current.url_resolved;
            setIsLoading(false);
        };

        stopAndLoad();
    }, [stationIdx]);

    const togglePlay = async () => {
        if (!audioRef.current) return;
        playSound('switch');

        if (isPlaying) {
            audioRef.current.pause();
            setIsPlaying(false);
        } else {
            setIsLoading(true);
            setError(null);
            try {
                await audioRef.current.play();
                setIsPlaying(true);
            } catch (e: any) {
                console.error("Radio Error:", e);
                setError("Stream Offline / Codec Error");
                setIsPlaying(false);
            } finally {
                setIsLoading(false);
            }
        }
    };

    const changeStation = (dir: number) => {
        playSound('click');
        setStationIdx(prev => {
            const next = prev + dir;
            if (next < 0) return stations.length - 1;
            if (next >= stations.length) return 0;
            return next;
        });
    };

    return (
        <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-black/20 font-[Rajdhani]">
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10">
                <div className={`w-48 h-48 border-4 border-[var(--color-primary)] rounded-full ${isPlaying ? 'animate-ping' : ''}`}></div>
            </div>

            <div className="w-full max-w-sm bg-black/80 border border-[var(--color-panel-border)] rounded-xl p-6 flex flex-col items-center gap-6 relative z-10 backdrop-blur-md shadow-2xl">
                <div className="flex justify-between w-full items-start">
                    <div className="flex flex-col">
                        <span className="text-[10px] font-black text-[var(--color-primary)] uppercase tracking-widest">Global Tuner</span>
                        <h2 className="text-xl font-black text-white uppercase italic tracking-tighter truncate max-w-[200px]">{current.name}</h2>
                    </div>
                    <div className="flex items-center gap-1 text-[var(--color-primary)]">
                        {isPlaying && <Signal size={16} className="animate-pulse" />}
                        <Radio size={16} />
                    </div>
                </div>

                <div className="w-32 h-32 rounded-full border-4 border-gray-800 bg-black flex items-center justify-center relative group">
                    <div className={`absolute inset-0 rounded-full border-t-4 border-[var(--color-primary)] ${isPlaying ? 'animate-spin' : ''}`}></div>
                    {error ? (
                        <AlertTriangle size={32} className="text-red-500" />
                    ) : (
                        <Radio size={40} className={`text-gray-500 ${isPlaying ? 'text-white' : ''}`} />
                    )}
                </div>

                <div className="flex flex-col items-center gap-1">
                    <span className={`text-xs font-mono font-bold ${error ? 'text-red-500' : 'text-gray-400'}`}>
                        {error ? error : isPlaying ? 'BROADCASTING...' : 'SIGNAL STANDBY'}
                    </span>
                    <span className="text-[9px] text-gray-600 uppercase tracking-[0.2em]">{current.tags}</span>
                </div>

                <div className="flex items-center gap-6 w-full justify-center">
                    <button onClick={() => changeStation(-1)} className="p-3 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-all"><SkipBack size={24}/></button>
                    <button 
                        onClick={togglePlay} 
                        disabled={isLoading}
                        className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-all transform hover:scale-105 ${isPlaying ? 'bg-[var(--color-primary)] text-black' : 'bg-gray-800 text-white border border-gray-700'}`}
                    >
                        {isLoading ? <Loader2 size={24} className="animate-spin" /> : isPlaying ? <Pause size={24} fill="currentColor"/> : <Play size={24} fill="currentColor"/>}
                    </button>
                    <button onClick={() => changeStation(1)} className="p-3 rounded-full hover:bg-white/10 text-gray-400 hover:text-white transition-all"><SkipForward size={24}/></button>
                </div>

                <div className="flex items-center gap-3 w-full px-4">
                    <Volume2 size={14} className="text-gray-500"/>
                    <input 
                        type="range" 
                        min="0" max="1" step="0.05" 
                        value={volume} 
                        onChange={(e) => setVolume(parseFloat(e.target.value))} 
                        className="w-full h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-[var(--color-primary)]"
                    />
                </div>
            </div>
        </div>
    );
};

export default RadioPanel;
