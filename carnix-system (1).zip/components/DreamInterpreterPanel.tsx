


import React, { useState } from 'react';
import { Lightbulb, Send, Loader2 } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';
import { playSound } from '../utils/soundEffects';

const DreamInterpreterPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    const [dream, setDream] = useState('');
    const [interpretation, setInterpretation] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleInterpret = async () => {
        if (!dream.trim() || !activeProfile) return;
        setIsLoading(true);
        setInterpretation(null);
        playSound('process');
        try {
            const prompt = `Interpret the following dream based on psychological and symbolic analysis. Be creative but insightful. The dream is: "${dream}"`;
            const res = await getAIResponse(prompt, Mode.DreamInterpreter, activeProfile.aiSettings);
            setInterpretation(res.text);
            playSound('success');
        } catch (e: any) {
            setInterpretation(`Error interpreting dream: ${e.message}`);
            playSound('error');
        }
        setIsLoading(false);
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 hud-panel p-4 flex flex-col gap-3">
                <h2 className="text-sm font-black tracking-widest text-[var(--color-primary)] flex items-center gap-2">
                    <Lightbulb size={16} /> DREAM LOGIC INTERPRETER
                </h2>
                <textarea
                    value={dream}
                    onChange={(e) => setDream(e.target.value)}
                    placeholder="Describe your dream in detail..."
                    className="w-full h-24 hud-textarea text-sm resize-y"
                    disabled={isLoading}
                />
                <button
                    onClick={handleInterpret}
                    disabled={isLoading || !dream.trim()}
                    className="w-full hud-button flex items-center justify-center gap-2 disabled:opacity-50"
                >
                    {isLoading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                    {isLoading ? 'ANALYZING...' : 'INTERPRET DREAM'}
                </button>
            </div>
            <div className="flex-1 hud-panel flex flex-col">
                 <div className="hud-panel-header">
                    AI INTERPRETATION
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                     {isLoading && (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-400">
                            <Loader2 size={32} className="animate-spin text-[var(--color-primary)] mb-4" />
                            <p>Accessing subconscious matrix...</p>
                        </div>
                    )}
                    {interpretation ? (
                        <div className="whitespace-pre-wrap font-mono text-sm leading-relaxed text-gray-300">
                           {interpretation}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-600">
                             <p>Interpretation will be displayed here.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DreamInterpreterPanel;