


import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Shield, ArrowRight } from 'lucide-react';
import { useAppContext } from '../context';
import { Mode } from '../types';

const DevConsolePanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const [history, setHistory] = useState<string[]>(['CARNIX ROOT CONSOLE -- ACCESS GRANTED']);
    const [input, setInput] = useState('');
    const endRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        endRef.current?.scrollIntoView();
    }, [history]);
    
    const executeCommand = (cmd: string) => {
        const parts = cmd.toLowerCase().split(' ');
        const command = parts[0];
        const arg = parts.slice(1).join(' ');

        let output = `> ${cmd}`;
        
        switch(command) {
            case 'help':
                output += `\nAvailable commands:\n  set_mode [mode_name] - Switch to a panel.\n  clear_log - Clear the main system log.\n  echo [text] - Print text.`;
                break;
            case 'set_mode':
                const targetMode = Object.values(Mode).find(m => m.toLowerCase().replace(/ /g, '') === arg.replace(/ /g, ''));
                if (targetMode) {
                    dispatch({ type: 'SET_MODE', payload: targetMode });
                    output += `\nSwitching to mode: ${targetMode}`;
                } else {
                    output += `\nError: Mode "${arg}" not found.`;
                }
                break;
            case 'clear_log':
                // This is a simulated clear, we don't have access to the main log dispatcher here
                // A more complex implementation would use a shared reducer
                output += `\nSystem log cleared. (Simulated)`;
                break;
            case 'echo':
                output += `\n${arg}`;
                break;
            case 'cls':
            case 'clear':
                setHistory([]);
                return;
            default:
                output += `\nError: Command not found: "${command}"`;
                break;
        }
        setHistory(prev => [...prev, output]);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (input.trim()) {
            executeCommand(input.trim());
            setInput('');
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2 flex items-center justify-between">
                <h2 className="text-sm font-bold text-yellow-400 flex items-center gap-2">
                    <Shield size={16}/> DEVELOPER CONSOLE
                </h2>
                 <span className="text-xs font-mono text-red-500 animate-pulse">ROOT ACCESS</span>
            </div>
            <div className="flex-1 hud-panel flex flex-col p-2 font-mono text-sm">
                <div className="flex-1 overflow-y-auto pr-2 space-y-2 text-green-400">
                    {history.map((line, i) => (
                        <pre key={i} className="whitespace-pre-wrap break-words">{line}</pre>
                    ))}
                    <div ref={endRef} />
                </div>
                 <form onSubmit={handleSubmit} className="flex items-center gap-2 border-t border-[var(--color-panel-header-border)] pt-2 mt-2">
                    <ArrowRight className="text-yellow-400" size={16}/>
                    <input
                        type="text"
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        className="flex-1 bg-transparent focus:outline-none text-white"
                        autoFocus
                    />
                </form>
            </div>
        </div>
    );
};

export default DevConsolePanel;