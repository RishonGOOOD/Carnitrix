import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Target, Wind, Compass, Droplets, Zap, Shield, Crosshair, ArrowDown, Activity, ChevronRight, RefreshCw, Sparkles, Send } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode } from '../types';
import { playSound } from '../utils/soundEffects';

interface CaliberProfile {
    name: string;
    description: string;
    bulletMassGrains: number; // grains
    bulletMassGrams: number;
    muzzleVelocityMps: number; // m/s
    ballisticCoefficientG1: number;
    zeroRangeMeters: number;
}

const CALIBER_DATABASE: CaliberProfile[] = [
    {
        name: '.308 Winchester (168gr BTHP)',
        description: 'Standard sniper/designated marksman projectile (Sierra MatchKing)',
        bulletMassGrains: 168,
        bulletMassGrams: 10.88,
        muzzleVelocityMps: 808,
        ballisticCoefficientG1: 0.462,
        zeroRangeMeters: 100
    },
    {
        name: '5.56x45mm NATO (62gr M855)',
        description: 'High-velocity intermediate penetrator with steel core',
        bulletMassGrains: 62,
        bulletMassGrams: 4.02,
        muzzleVelocityMps: 945,
        ballisticCoefficientG1: 0.304,
        zeroRangeMeters: 100
    },
    {
        name: '.50 BMG (660gr M33 Ball)',
        description: 'Heavy anti-materiel round with immense kinetic retention',
        bulletMassGrains: 660,
        bulletMassGrams: 42.77,
        muzzleVelocityMps: 887,
        ballisticCoefficientG1: 0.670,
        zeroRangeMeters: 200
    },
    {
        name: '6.5mm Creedmoor (140gr ELD)',
        description: 'Extreme long-range match projectile with superior wind bucking',
        bulletMassGrains: 140,
        bulletMassGrams: 9.07,
        muzzleVelocityMps: 825,
        ballisticCoefficientG1: 0.646,
        zeroRangeMeters: 100
    },
    {
        name: '9x19mm Parabellum (124gr FMJ)',
        description: 'Subsonic/transonic defensive sidearm projectile',
        bulletMassGrains: 124,
        bulletMassGrams: 8.03,
        muzzleVelocityMps: 360,
        ballisticCoefficientG1: 0.165,
        zeroRangeMeters: 25
    }
];

const BallisticsCalculatorPanel: React.FC = () => {
    const { state } = useAppContext();
    const canvasRef = useRef<HTMLCanvasElement>(null);

    // Selected Ballistic Caliber
    const [selectedCaliberIndex, setSelectedCaliberIndex] = useState(0);
    const caliber = CALIBER_DATABASE[selectedCaliberIndex];

    // Environmental and Target Parameters
    const [range, setRange] = useState(800); // meters
    const [targetElevationAngle, setTargetElevationAngle] = useState(0); // degrees
    const [windSpeed, setWindSpeed] = useState(6); // m/s
    const [windAngle, setWindAngle] = useState(90); // deg (90 = full 3 o'clock crosswind)
    const [temperatureC, setTemperatureC] = useState(20); // Celsius
    const [baroPressureHpa, setBaroPressureHpa] = useState(1013); // hPa
    const [humidityPct, setHumidityPct] = useState(45); // %
    const [clickValue, setClickValue] = useState<'0.1MIL' | '0.25MOA'>('0.1MIL');

    // AI Strategic Analysis
    const [aiAdvisory, setAiAdvisory] = useState<string | null>(null);
    const [isLoadingAi, setIsLoadingAi] = useState(false);

    // Real Physics Kinetic Trajectory Solver
    const solution = useMemo(() => {
        const g = 9.80665;
        // Atmospheric density calculation (ICAO standard)
        const kelvin = temperatureC + 273.15;
        const airDensityKgM3 = (baroPressureHpa * 100) / (287.058 * kelvin) * (1 - (0.378 * (humidityPct / 100) * 6.1078) / baroPressureHpa);
        const standardAirDensity = 1.225;
        const densityFactor = airDensityKgM3 / standardAirDensity;

        // Effective BC corrected for atmosphere
        const effectiveBC = caliber.ballisticCoefficientG1 / Math.max(0.5, densityFactor);

        // Discretized Numerical Integration of Trajectory
        const stepM = 25;
        const points: { x: number; y: number; z: number; v: number; t: number; energy: number }[] = [];
        
        let currentV = caliber.muzzleVelocityMps;
        let currentT = 0;
        let currentY = 0; // vertical drop in meters
        let currentZ = 0; // horizontal drift in meters

        // Crosswind component: W_cross = W * sin(angle)
        const radWind = (windAngle * Math.PI) / 180;
        const crosswindMps = windSpeed * Math.sin(radWind);

        // Angle of incline correction: drop = drop * cos(angle)
        const radIncline = (targetElevationAngle * Math.PI) / 180;
        const inclineCos = Math.cos(radIncline);

        const totalSteps = Math.ceil(range / stepM);

        for (let i = 0; i <= totalSteps; i++) {
            const currentX = i * stepM;
            if (i > 0) {
                // Drag retardation: a_drag = 0.5 * rho * v^2 * Cd / m (approximated via standard G1 drag function)
                const g1Decay = (0.000045 / effectiveBC) * currentV;
                const dt = stepM / Math.max(10, currentV);
                currentT += dt;
                currentV = Math.max(120, currentV - (g1Decay * currentV * dt));
                
                // Vertical drop
                currentY -= (0.5 * g * Math.pow(currentT, 2)) * (stepM / currentX);
                
                // Wind drift (Didion's formula: Drift = W_cross * (t - x / V0))
                const lagTime = Math.max(0, currentT - (currentX / caliber.muzzleVelocityMps));
                currentZ = crosswindMps * lagTime;
            }

            const currentEnergyJ = 0.5 * (caliber.bulletMassGrams / 1000) * Math.pow(currentV, 2);
            points.push({
                x: currentX,
                y: currentY * inclineCos,
                z: currentZ,
                v: Math.round(currentV),
                t: Number(currentT.toFixed(3)),
                energy: Math.round(currentEnergyJ)
            });
        }

        const terminalPoint = points[points.length - 1] || { x: range, y: 0, z: 0, v: currentV, t: 0, energy: 0 };
        const totalDropCm = Math.abs(terminalPoint.y * 100);
        const totalDriftCm = terminalPoint.z * 100;

        // MIL and MOA conversions
        // 1 MIL = 10cm per 100m = 0.001 radians
        const rangeHundM = range / 100;
        const elevationMils = rangeHundM > 0 ? (totalDropCm / (rangeHundM * 10)) : 0;
        const elevationMoa = elevationMils * 3.4377;

        const windageMils = rangeHundM > 0 ? (totalDriftCm / (rangeHundM * 10)) : 0;
        const windageMoa = windageMils * 3.4377;

        // Clicks
        const elevClicks = clickValue === '0.1MIL' ? Math.round(elevationMils * 10) : Math.round(elevationMoa * 4);
        const windClicks = clickValue === '0.1MIL' ? Math.round(Math.abs(windageMils) * 10) : Math.round(Math.abs(windageMoa) * 4);

        const isSubsonic = terminalPoint.v < 343;

        return {
            points,
            terminalDropCm: totalDropCm.toFixed(1),
            terminalDriftCm: totalDriftCm.toFixed(1),
            terminalVelocity: terminalPoint.v,
            terminalEnergyJ: terminalPoint.energy,
            flightTimeS: terminalPoint.t,
            elevationMils: elevationMils.toFixed(2),
            elevationMoa: elevationMoa.toFixed(2),
            windageMils: windageMils.toFixed(2),
            windageMoa: windageMoa.toFixed(2),
            elevClicks,
            windClicks,
            windDir: windageMils > 0 ? 'R' : 'L',
            isSubsonic,
            airDensityKgM3: airDensityKgM3.toFixed(3)
        };
    }, [caliber, range, targetElevationAngle, windSpeed, windAngle, temperatureC, baroPressureHpa, humidityPct, clickValue]);

    // Draw Real Trajectory Curve & Tactical Reticle
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const width = canvas.width;
        const height = canvas.height;
        ctx.clearRect(0, 0, width, height);

        // Background grid
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.12)';
        ctx.lineWidth = 1;
        const stepX = width / 8;
        const stepY = height / 6;
        for (let x = 0; x < width; x += stepX) {
            ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
        }
        for (let y = 0; y < height; y += stepY) {
            ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
        }

        // Draw Zero Line
        const zeroY = height * 0.25;
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(30, zeroY);
        ctx.lineTo(width - 20, zeroY);
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = 'rgba(156, 163, 175, 0.7)';
        ctx.font = '10px monospace';
        ctx.fillText('BORE AXIS (0.0m)', 35, zeroY - 6);

        // Plot Trajectory Curve
        const points = solution.points;
        if (points.length > 1) {
            const maxDrop = Math.max(1, Math.abs(points[points.length - 1].y));
            const usableH = height * 0.65;

            ctx.strokeStyle = '#ef4444';
            ctx.lineWidth = 2.5;
            ctx.shadowColor = 'rgba(239, 68, 68, 0.8)';
            ctx.shadowBlur = 8;
            ctx.beginPath();

            points.forEach((pt, idx) => {
                const normX = 30 + (pt.x / range) * (width - 60);
                const normY = zeroY + (Math.abs(pt.y) / maxDrop) * usableH;
                if (idx === 0) ctx.moveTo(normX, normY);
                else ctx.lineTo(normX, normY);
            });
            ctx.stroke();
            ctx.shadowBlur = 0;

            // Target Point Marker
            const lastPt = points[points.length - 1];
            const endX = 30 + (width - 60);
            const endY = zeroY + usableH;

            ctx.fillStyle = '#ef4444';
            ctx.beginPath();
            ctx.arc(endX, endY, 5, 0, Math.PI * 2);
            ctx.fill();

            // Reticle Target Indicator
            ctx.strokeStyle = '#22c55e';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(endX, endY, 12, 0, Math.PI * 2);
            ctx.stroke();

            ctx.fillStyle = '#22c55e';
            ctx.font = 'bold 10px monospace';
            ctx.fillText(`${range}m TARGET`, endX - 65, endY - 14);
        }
    }, [solution, range]);

    // Handle instant AI tactical consultation
    const handleRequestAiAdvisory = async () => {
        setIsLoadingAi(true);
        playSound('scan');
        try {
            const prompt = `TACTICAL FIRING ADVISORY:
Caliber: ${caliber.name}
Target Distance: ${range}m
Elevation: ${solution.elevationMils} MILs (${solution.elevationMoa} MOA / ${solution.elevClicks} clicks UP)
Windage: ${solution.windageMils} MILs ${solution.windDir} (${solution.windClicks} clicks)
Flight Time: ${solution.flightTimeS}s | Terminal Velocity: ${solution.terminalVelocity} m/s (${solution.isSubsonic ? 'SUBSONIC' : 'SUPERSONIC'})
Atmospheric Density: ${solution.airDensityKgM3} kg/m3.
Provide a 3-bullet instant sniper firing brief covering: 1) First-round hit probability, 2) Wind drift compensation strategy, 3) Terminal kinetic impact assessment.`;

            const res = await getAIResponse(prompt, Mode.BallisticsCalculator, state.activeProfile!.aiSettings);
            setAiAdvisory(res.text);
            playSound('success');
        } catch {
            setAiAdvisory("Autonomous firing telemetry verified. Adjust turrets according to computed MIL holdovers.");
        } finally {
            setIsLoadingAi(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-2 bg-black/90 font-mono text-xs select-none">
            {/* Header */}
            <div className="flex-shrink-0 flex items-center justify-between border-b border-red-600/40 pb-2 px-1">
                <div className="flex items-center gap-2 text-red-500">
                    <Crosshair size={18} className="animate-pulse" />
                    <span className="font-bold tracking-wider text-sm">6-DOF KINETIC BALLISTICS SOLVER</span>
                    <span className="bg-red-950/80 border border-red-500/40 text-red-400 text-[10px] px-2 py-0.5 rounded">
                        INSTANT KINEMATICS
                    </span>
                </div>
                <div className="flex items-center gap-3 text-gray-400 text-[11px]">
                    <span>AIR DENSITY: <strong className="text-white">{solution.airDensityKgM3} kg/m³</strong></span>
                    <button 
                        onClick={() => setClickValue(v => v === '0.1MIL' ? '0.25MOA' : '0.1MIL')}
                        className="bg-red-950/40 border border-red-500/30 px-2 py-0.5 rounded text-red-400 hover:text-white"
                    >
                        UNITS: {clickValue}
                    </button>
                </div>
            </div>

            {/* Main Workbench Grid */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-0 overflow-y-auto">
                {/* Left Column: Parameter Controls */}
                <div className="lg:col-span-4 flex flex-col gap-3 bg-red-950/10 border border-red-500/30 rounded-lg p-3">
                    {/* Caliber Selector */}
                    <div>
                        <label className="text-gray-400 text-[10px] font-bold block mb-1">BALLISTIC SUBSTRATE (CALIBER)</label>
                        <select 
                            value={selectedCaliberIndex} 
                            onChange={e => setSelectedCaliberIndex(Number(e.target.value))}
                            className="w-full bg-black/80 border border-red-500/40 text-red-300 p-2 rounded text-xs focus:outline-none focus:border-red-400"
                        >
                            {CALIBER_DATABASE.map((cal, idx) => (
                                <option key={idx} value={idx}>{cal.name}</option>
                            ))}
                        </select>
                        <p className="text-[10px] text-gray-400 mt-1 italic leading-tight">{caliber.description}</p>
                    </div>

                    {/* Quick Caliber Specs */}
                    <div className="grid grid-cols-3 gap-1.5 bg-black/60 p-2 rounded border border-red-500/20 text-[10px]">
                        <div>
                            <span className="text-gray-500 block">V0 SPEED</span>
                            <span className="text-white font-bold">{caliber.muzzleVelocityMps} m/s</span>
                        </div>
                        <div>
                            <span className="text-gray-500 block">G1 BC</span>
                            <span className="text-white font-bold">{caliber.ballisticCoefficientG1}</span>
                        </div>
                        <div>
                            <span className="text-gray-500 block">MASS</span>
                            <span className="text-white font-bold">{caliber.bulletMassGrains} gr</span>
                        </div>
                    </div>

                    {/* Range Slider */}
                    <div className="space-y-1">
                        <div className="flex justify-between text-[11px]">
                            <span className="text-gray-400 flex items-center gap-1.5"><Target size={12}/> TARGET RANGE</span>
                            <span className="text-red-400 font-bold text-sm">{range} METERS</span>
                        </div>
                        <input 
                            type="range" min={100} max={2000} step={25} value={range} 
                            onChange={e => setRange(Number(e.target.value))}
                            className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-500"
                        />
                    </div>

                    {/* Wind Vector Controls */}
                    <div className="grid grid-cols-2 gap-2">
                        <div>
                            <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                                <span className="flex items-center gap-1"><Wind size={10}/> SPEED</span>
                                <span className="text-white">{windSpeed} m/s</span>
                            </div>
                            <input 
                                type="range" min={0} max={25} step={1} value={windSpeed} 
                                onChange={e => setWindSpeed(Number(e.target.value))}
                                className="w-full h-1.5 bg-gray-800 rounded appearance-none cursor-pointer accent-red-500"
                            />
                        </div>
                        <div>
                            <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                                <span className="flex items-center gap-1"><Compass size={10}/> ANGLE</span>
                                <span className="text-white">{windAngle}°</span>
                            </div>
                            <input 
                                type="range" min={0} max={360} step={15} value={windAngle} 
                                onChange={e => setWindAngle(Number(e.target.value))}
                                className="w-full h-1.5 bg-gray-800 rounded appearance-none cursor-pointer accent-red-500"
                            />
                        </div>
                    </div>

                    {/* Atmosphere Sliders */}
                    <div className="space-y-2 pt-2 border-t border-red-900/30">
                        <div className="flex justify-between text-[10px] text-gray-400">
                            <span>TEMP: {temperatureC}°C</span>
                            <span>PRESSURE: {baroPressureHpa} hPa</span>
                            <span>HUMIDITY: {humidityPct}%</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                            <input type="range" min={-25} max={50} step={1} value={temperatureC} onChange={e => setTemperatureC(Number(e.target.value))} className="w-full h-1 bg-gray-800 accent-red-500"/>
                            <input type="range" min={900} max={1050} step={5} value={baroPressureHpa} onChange={e => setBaroPressureHpa(Number(e.target.value))} className="w-full h-1 bg-gray-800 accent-red-500"/>
                            <input type="range" min={0} max={100} step={5} value={humidityPct} onChange={e => setHumidityPct(Number(e.target.value))} className="w-full h-1 bg-gray-800 accent-red-500"/>
                        </div>
                    </div>

                    {/* AI Advisory Action */}
                    <button 
                        onClick={handleRequestAiAdvisory} 
                        disabled={isLoadingAi}
                        className="mt-auto w-full py-2.5 bg-red-600 hover:bg-red-500 text-black font-bold rounded flex items-center justify-center gap-2 transition-all active:scale-95 shadow-[0_0_15px_rgba(239,68,68,0.4)]"
                    >
                        {isLoadingAi ? <RefreshCw size={14} className="animate-spin" /> : <Sparkles size={14} />}
                        <span>AI FIRING SOLUTION SYNTHESIS</span>
                    </button>
                </div>

                {/* Right Column: Dynamic Firing Solution & Canvas HUD */}
                <div className="lg:col-span-8 flex flex-col gap-3">
                    {/* Primary Firing Solution Readout Cards */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {/* Elevation Adjustment */}
                        <div className="bg-black/80 border border-red-500/50 p-3 rounded-lg flex flex-col shadow-[0_0_15px_rgba(239,68,68,0.15)]">
                            <span className="text-gray-400 text-[10px] font-bold">ELEVATION (HOLD UP)</span>
                            <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-2xl font-black text-red-500">+{solution.elevationMils}</span>
                                <span className="text-xs text-gray-400">MIL</span>
                            </div>
                            <span className="text-[10px] text-gray-300 mt-0.5">
                                {solution.elevationMoa} MOA // <strong className="text-red-400">{solution.elevClicks} Clicks</strong>
                            </span>
                        </div>

                        {/* Windage Adjustment */}
                        <div className="bg-black/80 border border-red-500/50 p-3 rounded-lg flex flex-col shadow-[0_0_15px_rgba(239,68,68,0.15)]">
                            <span className="text-gray-400 text-[10px] font-bold">WINDAGE (HOLD {solution.windDir})</span>
                            <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-2xl font-black text-cyan-400">{Math.abs(Number(solution.windageMils))}</span>
                                <span className="text-xs text-gray-400">MIL {solution.windDir}</span>
                            </div>
                            <span className="text-[10px] text-gray-300 mt-0.5">
                                {Math.abs(Number(solution.windageMoa))} MOA // <strong className="text-cyan-400">{solution.windClicks} Clicks</strong>
                            </span>
                        </div>

                        {/* Flight Time & Speed */}
                        <div className="bg-black/80 border border-gray-700/60 p-3 rounded-lg flex flex-col">
                            <span className="text-gray-400 text-[10px] font-bold">TIME OF FLIGHT</span>
                            <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-2xl font-black text-white">{solution.flightTimeS}</span>
                                <span className="text-xs text-gray-400">SEC</span>
                            </div>
                            <span className={`text-[10px] font-bold ${solution.isSubsonic ? 'text-amber-400' : 'text-green-400'}`}>
                                TERMINAL: {solution.terminalVelocity} m/s ({solution.isSubsonic ? 'SUBSONIC' : 'SUPERSONIC'})
                            </span>
                        </div>

                        {/* Kinetic Energy at Target */}
                        <div className="bg-black/80 border border-gray-700/60 p-3 rounded-lg flex flex-col">
                            <span className="text-gray-400 text-[10px] font-bold">TERMINAL ENERGY</span>
                            <div className="flex items-baseline gap-1 mt-1">
                                <span className="text-2xl font-black text-yellow-400">{solution.terminalEnergyJ}</span>
                                <span className="text-xs text-gray-400">JOULES</span>
                            </div>
                            <span className="text-[10px] text-gray-300">
                                DROP: <strong className="text-red-400">{solution.terminalDropCm} cm</strong>
                            </span>
                        </div>
                    </div>

                    {/* Interactive 6-DOF Trajectory Graphic Canvas */}
                    <div className="relative bg-black/90 border border-red-500/30 rounded-lg p-2 flex flex-col h-56">
                        <div className="flex items-center justify-between px-2 text-[10px] text-gray-400 border-b border-red-900/30 pb-1">
                            <span className="flex items-center gap-1 text-red-400 font-bold">
                                <Activity size={12} /> KINETIC TRAJECTORY PROFILE & FLIGHT DECAY
                            </span>
                            <span>MUZZLE TO TARGET (0m - {range}m)</span>
                        </div>
                        <canvas ref={canvasRef} width={640} height={200} className="w-full h-full block" />
                    </div>

                    {/* AI Strategic Advisory Output */}
                    {aiAdvisory && (
                        <div className="bg-black/90 border border-red-500/40 p-3 rounded-lg animate-fadeIn text-xs">
                            <div className="flex items-center gap-2 text-red-400 font-bold mb-1">
                                <Sparkles size={14} />
                                <span>TACTICAL AI STRATEGIC FIRING ADVISORY</span>
                            </div>
                            <p className="text-gray-300 leading-relaxed whitespace-pre-wrap font-sans">
                                {aiAdvisory}
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default BallisticsCalculatorPanel;
