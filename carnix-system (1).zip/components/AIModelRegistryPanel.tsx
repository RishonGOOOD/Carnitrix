
import React, { useState, useRef } from 'react';
import { Database, Plus, Trash2, Cpu, HardDrive, ShieldCheck, Loader2, Play, Power, Box, Zap, Settings, Activity } from 'lucide-react';
import { useAppContext } from '../context';
import { RegisteredAIModel } from '../types';
import { playSound, triggerHaptic } from '../utils/soundEffects';

const AIModelRegistryPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const models = state.activeProfile?.registeredModels || [];
    const aiSettings = state.activeProfile?.aiSettings;
    const [isRegistering, setIsRegistering] = useState(false);
    const [mountingId, setMountingId] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsRegistering(true);
        playSound('process');

        // Simulated LlamaBridge registration
        setTimeout(() => {
            const newModel: RegisteredAIModel = {
                id: `model-${Date.now()}`,
                name: file.name.split('.')[0].toUpperCase(),
                fileName: file.name,
                sizeMB: Math.round(file.size / 1024 / 1024),
                path: `/models/${file.name}`,
                type: file.name.endsWith('.gguf') ? 'GGUF' : 'BIN',
                addedAt: Date.now(),
                isActive: false
            };

            dispatch({ type: 'UPDATE_PROFILE', payload: { registeredModels: [...models, newModel] }});
            setIsRegistering(false);
            playSound('success');
            if (fileInputRef.current) fileInputRef.current.value = '';
        }, 1500);
    };

    const activateModel = (id: string) => {
        setMountingId(id);
        playSound('scan');
        triggerHaptic('heavy');

        // Logic Bridge Simulation (Connecting to LlamaBridge.kt)
        setTimeout(() => {
            const updatedModels = models.map(m => ({ ...m, isActive: m.id === id }));
            dispatch({ type: 'UPDATE_PROFILE', payload: { 
                registeredModels: updatedModels,
                aiSettings: { 
                    ...aiSettings!, 
                    useLocalModel: true, 
                    activeLocalModelId: id,
                    isLocalModelLoaded: true
                }
            }});
            setMountingId(null);
            playSound('access');
            dispatch({ type: 'ADD_LOG', payload: { source: 'KERNEL', message: `GGUF Kernel Synchronized: ${models.find(m => m.id === id)?.name}`, level: 'success' }});
        }, 3000);
    };

    const toggleHybrid = () => {
        dispatch({ type: 'UPDATE_PROFILE', payload: { 
            aiSettings: { ...aiSettings!, useLocalModel: !aiSettings?.useLocalModel }
        }});
        playSound('switch');
    };

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1 font-[Rajdhani]">
            {/* Header Readout */}
            <div className="flex-shrink-0 bg-black/60 border border-red-600/30 p-6 rounded-[2rem] flex justify-between items-center shadow-2xl relative overflow-hidden">
                <div className="absolute bottom-0 right-0 p-2 opacity-5 pointer-events-none">
                    <Database size={80} className="text-red-600" />
                </div>
                <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-red-600/10 border border-red-600/50 rounded-2xl flex items-center justify-center text-red-500 shadow-lg">
                        <Database size={28} />
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-white uppercase italic tracking-widest leading-none">Neural Registry</h2>
                        <div className="text-[10px] font-mono text-red-900 uppercase tracking-widest mt-1">
                            Current Mode: {aiSettings?.useLocalModel ? <span className="text-cyan-400 font-bold">LOCAL_GGUF_ACTIVE</span> : <span className="text-blue-400 font-bold">CLOUD_MATRIX_LINK</span>}
                        </div>
                    </div>
                </div>
                <div className="flex gap-3">
                    <button onClick={toggleHybrid} className={`px-6 py-3 rounded-full font-black text-[10px] uppercase tracking-widest border transition-all ${aiSettings?.useLocalModel ? 'bg-cyan-600/20 border-cyan-500 text-cyan-400' : 'bg-gray-800 border-gray-700 text-gray-500'}`}>
                         {aiSettings?.useLocalModel ? 'Engage Cloud API' : 'Enable Local Kernel'}
                    </button>
                    <button onClick={() => fileInputRef.current?.click()} disabled={isRegistering} className="px-6 py-3 bg-red-600 text-black font-black text-[10px] rounded-full uppercase tracking-widest flex items-center gap-2 hover:bg-white transition-all shadow-lg active:scale-95 disabled:opacity-50">
                        {isRegistering ? <Loader2 size={16} className="animate-spin"/> : <Plus size={16}/>} Register Neural Core
                    </button>
                    <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".gguf" />
                </div>
            </div>

            <div className="flex-1 bg-black/40 border border-white/5 rounded-[3rem] overflow-y-auto p-6 scrollbar-carnix">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-32">
                    {models.map(model => (
                        <div key={model.id} className={`bg-black border-2 rounded-[2rem] p-6 flex flex-col gap-6 group transition-all relative overflow-hidden ${model.isActive ? 'border-cyan-500 bg-cyan-950/10' : 'border-red-900/20 hover:border-red-600/40'}`}>
                            {model.isActive && <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500 animate-pulse"></div>}
                            
                            <div className="flex justify-between items-start z-10">
                                <div className="flex items-center gap-4">
                                    <div className={`p-4 rounded-2xl ${model.isActive ? 'bg-cyan-500 text-black shadow-[0_0_20px_cyan]' : 'bg-white/5 text-gray-600'}`}>
                                        <Box size={24} />
                                    </div>
                                    <div>
                                        <div className="text-lg font-black text-white uppercase tracking-tight truncate max-w-[150px]">{model.name}</div>
                                        <div className="text-[10px] text-gray-500 font-mono tracking-tighter">{model.sizeMB} MB // GGUF_V3</div>
                                    </div>
                                </div>
                                <button onClick={() => dispatch({ type: 'UPDATE_PROFILE', payload: { registeredModels: models.filter(m => m.id !== model.id) }})} className="p-2 text-gray-800 hover:text-red-500 transition-colors">
                                    <Trash2 size={20} />
                                </button>
                            </div>
                            
                            <div className="bg-white/5 p-4 rounded-2xl border border-white/5 font-mono text-[10px] text-gray-500 leading-relaxed">
                                <div className="flex justify-between mb-1"><span>ARCHITECTURE:</span> <span className="text-white">arm64-v8a</span></div>
                                <div className="flex justify-between"><span>RAM_REQUIRED:</span> <span className="text-white">~{(model.sizeMB / 1024 + 1).toFixed(1)}GB</span></div>
                            </div>

                            <button 
                                onClick={() => activateModel(model.id)}
                                disabled={model.isActive || mountingId === model.id}
                                className={`w-full py-4 border rounded-2xl text-[10px] font-black uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-3 ${model.isActive ? 'bg-cyan-500 text-black shadow-lg cursor-default' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-cyan-600 hover:text-black hover:border-cyan-600'}`}
                            >
                                {mountingId === model.id ? <Loader2 size={16} className="animate-spin"/> : model.isActive ? <ShieldCheck size={16}/> : <Power size={16}/>}
                                {mountingId === model.id ? 'MOUNTING TO RAM...' : model.isActive ? 'CORE_STABLE' : 'SYNC_TO_BRIDGE'}
                            </button>
                            
                            <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
                                <Activity size={60} className="text-white" />
                            </div>
                        </div>
                    ))}

                    {models.length === 0 && !isRegistering && (
                        <div className="col-span-full h-80 flex flex-col items-center justify-center opacity-10 uppercase tracking-[1em] text-xs font-black">
                            Awaiting GGUF Local Weights
                        </div>
                    )}
                </div>
            </div>

            <div className="p-6 bg-cyan-950/20 border border-cyan-900/30 rounded-[2rem] flex items-start gap-5">
                <Settings size={28} className="text-cyan-500 shrink-0" />
                <div className="text-[10px] text-gray-500 font-mono leading-relaxed uppercase">
                    <span className="text-cyan-500 font-black">Kernel Note:</span> Local inference requires a dedicated LlamaBridge.kt instance or Termux llama-cpp server running on port <span className="text-white">8080</span>. GGUF models are executed directly on mobile CPU/GPU clusters for maximum privacy.
                </div>
            </div>
        </div>
    );
};

export default AIModelRegistryPanel;
