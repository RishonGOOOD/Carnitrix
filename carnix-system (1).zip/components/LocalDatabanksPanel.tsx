
import React, { useState, useRef, useEffect } from 'react';
import { FolderOpen, File as FileIcon, HardDrive, FileImage, FileVideo, FileAudio, FileText, FileQuestion, Shield, Mic, Loader2, X, Music, Video } from 'lucide-react';
import { playSound } from '../utils/soundEffects';

interface FileSystemEntry {
    name: string;
    kind: 'file';
    handle: File;
}

type FileCategory = 'images' | 'videos' | 'audio' | 'documents' | 'other';

const getFileCategory = (fileName: string): FileCategory => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'].includes(ext)) return 'images';
    if (['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(ext)) return 'videos';
    if (['mp3', 'wav', 'ogg', 'flac', 'm4a'].includes(ext)) return 'audio';
    if (['pdf', 'doc', 'docx', 'txt', 'md', 'json', 'log', 'csv', 'xml', 'html', 'css', 'js', 'ts', 'jsx', 'tsx'].includes(ext)) return 'documents';
    return 'other';
};

const CategoryDisplay: React.FC<{ icon: React.ReactNode; label: string; count: number; colorClass: string }> = ({ icon, label, count, colorClass }) => (
    <div className={`bg-black/40 border border-gray-800 rounded p-2 flex items-center gap-3 transition-colors hover:border-${colorClass.split('-')[1]}`}>
        <div className={colorClass}>{icon}</div>
        <div>
            <div className="font-bold text-lg text-white leading-none">{count}</div>
            <div className="text-[10px] text-gray-500 uppercase tracking-wider">{label}</div>
        </div>
    </div>
);

const LocalDatabanksPanel: React.FC = () => {
    const [dirName, setDirName] = useState<string | null>(null);
    const [entries, setEntries] = useState<FileSystemEntry[]>([]);
    const [status, setStatus] = useState('Select a local directory to begin analysis.');
    const [isLoading, setIsLoading] = useState(false);
    const [isScanning, setIsScanning] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [selectedEntry, setSelectedEntry] = useState<FileSystemEntry | null>(null);
    const [previewContent, setPreviewContent] = useState<string | null>(null);
    const [previewType, setPreviewType] = useState<'image' | 'text' | 'other' | null>(null);

    useEffect(() => {
        return () => {
            if (previewType === 'image' && previewContent) {
                URL.revokeObjectURL(previewContent);
            }
        };
    }, [previewContent, previewType]);

    const handleSelectEntry = async (entry: FileSystemEntry) => {
        if (previewType === 'image' && previewContent) {
            URL.revokeObjectURL(previewContent);
        }
    
        setSelectedEntry(entry);
        setPreviewContent(null);
        setPreviewType(null);
        playSound('click');
        
        const category = getFileCategory(entry.name);
        const isTextReadable = entry.name.match(/\.(txt|md|json|log|csv|xml|html|css|js|ts)$/i);
        
        try {
            if (category === 'images') {
                setPreviewType('image');
                const url = URL.createObjectURL(entry.handle);
                setPreviewContent(url);
            } else if (category === 'documents' && isTextReadable) {
                setPreviewType('text');
                const text = await entry.handle.text();
                setPreviewContent(text);
            } else {
                setPreviewType('other');
                const fileInfo = `FILE METADATA:\n\n- Name: ${entry.handle.name}\n- Size: ${(entry.handle.size / 1024).toFixed(2)} KB\n- Type: ${entry.handle.type || 'Unknown'}\n\nNo preview available for this file type.`;
                setPreviewContent(fileInfo);
            }
        } catch(e) {
            setPreviewType('other');
            setPreviewContent(`Error reading file: ${(e as Error).message}`);
        }
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const fileList = event.target.files;
        if (!fileList || fileList.length === 0) {
            setStatus("No files selected or directory is empty.");
            return;
        }

        setIsLoading(true);
        const firstFile = fileList[0];
        const directoryName = firstFile.webkitRelativePath ? firstFile.webkitRelativePath.split('/')[0] : "Selected Files";
        
        setDirName(directoryName);
        setStatus(`Scanning directory: ${directoryName}...`);
        playSound('process');
        
        const entryList: FileSystemEntry[] = [];
        for (let i = 0; i < fileList.length; i++) {
            const file = fileList[i];
            entryList.push({ name: file.name, kind: 'file', handle: file });
        }
        
        entryList.sort((a, b) => a.name.localeCompare(b.name));
        
        setEntries(entryList);
        setStatus(`Scan complete. Loaded ${entryList.length} items from /${directoryName}`);
        playSound('success');
        setIsLoading(false);
    };
    
    const handleCorruptionScan = () => {
        if (!entries.length) return;
        setIsScanning(true);
        setStatus('Initiating integrity scan...');
        playSound('scan');
        setTimeout(() => {
            setIsScanning(false);
            setStatus(`Integrity scan complete. All ${entries.length} files nominal.`);
            playSound('success');
        }, 3000);
    }
    
    const handleReadAloud = (fileName: string) => {
        playSound('click');
        alert(`Simulating "Read Aloud" for ${fileName}. This feature requires a Text-to-Speech engine integration.`);
    }

    const renderPreview = () => {
        if (!selectedEntry) {
            return <div className="flex items-center justify-center h-full text-gray-600">Select a file to preview its contents.</div>;
        }
        if (!previewContent) {
            return <div className="flex items-center justify-center h-full text-gray-400"><Loader2 className="animate-spin" /></div>;
        }
        switch (previewType) {
            case 'image':
                return <img src={previewContent} alt={selectedEntry.name} className="max-w-full max-h-full object-contain" />;
            case 'text':
                return <pre className="whitespace-pre-wrap break-words text-sm font-mono text-gray-300">{previewContent}</pre>;
            case 'other':
            default:
                return <pre className="whitespace-pre-wrap text-sm text-gray-400">{previewContent}</pre>;
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
             <input type="file" ref={fileInputRef} onChange={handleFileChange} multiple style={{ display: 'none' }} />
            
            <div className="flex-shrink-0 hud-panel p-2 flex flex-col sm:flex-row items-center gap-2">
                <button onClick={() => fileInputRef.current?.click()} disabled={isLoading || isScanning} className="flex-1 w-full sm:w-auto hud-button flex items-center justify-center gap-2 disabled:opacity-50">
                    <FolderOpen size={16} />
                    {isLoading ? 'AWAITING PERMISSION...' : 'MOUNT LOCAL DATABANK'}
                </button>
                 <button onClick={handleCorruptionScan} disabled={isScanning || !entries.length} className="flex-1 w-full sm:w-auto hud-button flex items-center justify-center gap-2 disabled:opacity-50">
                    {isScanning ? <Loader2 size={16} className="animate-spin" /> : <Shield size={16} />}
                    {isScanning ? 'SCANNING...' : 'INTEGRITY SCAN'}
                </button>
                <div className="w-full sm:flex-1 bg-black/40 p-2 rounded text-xs border border-gray-800">
                    <div className="font-mono text-white truncate">{status}</div>
                </div>
            </div>

            <div className="flex-1 flex flex-col md:flex-row gap-2 overflow-hidden">
                <div className="w-full md:w-1/3 hud-panel flex flex-col overflow-hidden">
                    <div className="hud-panel-header">
                        <HardDrive size={14} /> {dirName ? `/${dirName}` : 'NO DIRECTORY'}
                    </div>
                    <div className="flex-1 overflow-y-auto scrollbar-thin">
                        {entries.length === 0 && dirName && (
                             <div className="p-4 text-center text-sm text-gray-500">Directory is empty.</div>
                        )}
                        {entries.map(entry => (
                            <div key={entry.name} onClick={() => handleSelectEntry(entry)} className={`p-2 border-b border-gray-800/50 flex items-center gap-2 hover:bg-white/5 transition-colors group cursor-pointer ${selectedEntry?.name === entry.name ? 'bg-[var(--color-primary)]/10' : ''}`}>
                                <FileIcon size={14} className="text-gray-400 flex-shrink-0" />
                                <span className="text-xs text-white flex-1 truncate">{entry.name}</span>
                                {entry.kind === 'file' && getFileCategory(entry.name) === 'documents' && (
                                    <button onClick={(e) => { e.stopPropagation(); handleReadAloud(entry.name);}} className="text-gray-500 hover:text-[var(--color-accent)] opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Mic size={12} />
                                    </button>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
                 <div className="flex-1 hud-panel flex flex-col overflow-hidden">
                     <div className="hud-panel-header flex justify-between items-center">
                        <span>PREVIEW</span>
                        {selectedEntry && (
                            <button onClick={() => setSelectedEntry(null)} className="text-gray-500 hover:text-white">
                                <X size={14} />
                            </button>
                        )}
                    </div>
                    <div className="flex-1 p-2 overflow-auto flex items-center justify-center">
                       {renderPreview()}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LocalDatabanksPanel;