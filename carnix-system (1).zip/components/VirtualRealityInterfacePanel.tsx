
import React, { useState, useEffect, useRef } from 'react';
import { Box, Play, Loader2, StopCircle } from 'lucide-react';

const VirtualRealityInterfacePanel: React.FC = () => {
    const [activeSim, setActiveSim] = useState<string | null>(null);
    const [status, setStatus] = useState('Select a simulation module to begin.');
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const simulations = [
        { name: 'Combat Training: Zero-G', description: 'Hone your skills in a zero-gravity environment.' },
        { name: 'Stealth Operations: Urban', description: 'Infiltrate a high-security facility undetected.' },
        { name: 'Evasion Protocol: Vehicle', description: 'Advanced driving simulation under extreme conditions.' },
    ];

    const launchSim = (name: string) => {
        setActiveSim(name);
        setStatus(`Initializing ${name}...`);
        setTimeout(() => setStatus('Calibrating neural interface...'), 1000);
        setTimeout(() => setStatus('SIMULATION ACTIVE'), 2000);
    };

    // Canvas Visualizer Effect
    useEffect(() => {
        if (!activeSim || !canvasRef.current) return;
        
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        let time = 0;

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        const draw = () => {
            // Fade effect for trails
            ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            const w = canvas.width;
            const h = canvas.height;
            const cx = w / 2;
            const cy = h / 2;

            ctx.lineWidth = 1;
            ctx.strokeStyle = '#00F0FF'; // Cyber Cyan

            // 3D Grid / Tunnel Effect
            for (let i = 0; i < 5; i++) {
                const perspective = (time + i * 20) % 100;
                const size = perspective * (w / 100);
                const opacity = perspective / 100;
                
                ctx.beginPath();
                ctx.globalAlpha = opacity;
                ctx.rect(cx - size/2, cy - size/2, size, size);
                ctx.stroke();
                
                // Diagonals
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx - size/2, cy - size/2);
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx + size/2, cy - size/2);
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx + size/2, cy + size/2);
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx - size/2, cy + size/2);
                ctx.stroke();
            }
            
            // Random Glitch Elements
            if(Math.random() > 0.9) {
                ctx.fillStyle = `rgba(255, 0, 60, ${Math.random() * 0.5})`;
                const gx = Math.random() * w;
                const gy = Math.random() * h;
                ctx.fillRect(gx, gy, Math.random() * 100, 2);
            }

            time += 0.5;
            animationFrameId = requestAnimationFrame(draw);
        };
        draw();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, [activeSim]);

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1">
            <div className="flex-shrink-0 hud-panel p-2">
                <h2 className="hud-panel-header">
                    <Box size={14}/> VIRTUAL REALITY INTERFACE
                </h2>
            </div>
            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden">
                <div className="w-full lg:w-1/3 border-b lg:border-b-0 lg:border-r border-[var(--color-panel-header-border)] flex flex-col">
                     <div className="hud-panel-header">
                        TRAINING MODULES
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 space-y-2">
                        {simulations.map(sim => (
                             <div key={sim.name} className={`p-3 border rounded group transition-all ${activeSim === sim.name ? 'border-blue-500 bg-blue-900/20' : 'border-gray-800 hover:border-blue-700'}`}>
                                <p className="font-bold text-white">{sim.name}</p>
                                <p className="text-xs text-gray-400 mt-1">{sim.description}</p>
                                <button onClick={() => launchSim(sim.name)} disabled={!!activeSim} className="w-full text-xs font-bold p-1 mt-2 rounded bg-blue-900/50 text-blue-300 border border-blue-700 hover:bg-blue-800 disabled:opacity-50">
                                    {activeSim === sim.name ? <Loader2 size={12} className="animate-spin inline mr-1"/> : <Play size={12} className="inline mr-1"/>}
                                    {activeSim === sim.name ? 'RUNNING' : 'LAUNCH'}
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="flex-1 bg-black/20 flex flex-col relative overflow-hidden">
                    {activeSim ? (
                        <>
                            <canvas ref={canvasRef} className="absolute inset-0 w-full h-full z-0" />
                            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center pointer-events-none">
                                <h3 className="font-black text-2xl text-[var(--color-primary)] tracking-[0.2em] animate-pulse bg-black/50 px-4 py-2 rounded">{status}</h3>
                                <p className="text-xs text-blue-300 font-mono mt-2 bg-black/50 px-2">NEURAL LINK STABLE</p>
                            </div>
                            <button onClick={() => { setActiveSim(null); setStatus('Select a simulation module.'); }} className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 hud-button !bg-red-900/50 !border-red-500 hover:!bg-red-800 text-white flex items-center gap-2">
                                <StopCircle size={16} /> END SIMULATION
                            </button>
                        </>
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center text-gray-600">
                            <Box size={48} className="mb-4 opacity-20"/>
                            <p>No simulation active.</p>
                            <p className="text-xs mt-1">Select a module from the roster to begin training.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default VirtualRealityInterfacePanel;
