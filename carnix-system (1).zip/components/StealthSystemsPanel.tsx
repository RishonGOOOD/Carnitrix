import React, { useState, useEffect, useRef, useMemo } from 'react';
import { EyeOff, Mic, VolumeX, Shield, ShieldCheck, AlertTriangle, Activity, Lock, RefreshCw, Radio, HardDrive, Wifi, Ghost } from 'lucide-react';
import { useAppContext } from '../context';
import { playSound } from '../utils/soundEffects';

const StealthSystemsPanel: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const { isStealthMode } = state;

    // Web Audio Acoustic Sensor State
    const [isListeningMic, setIsListeningMic] = useState(false);
    const [decibelLevel, setDecibelLevel] = useState<number>(-60);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const animFrameRef = useRef<number | null>(null);

    // Browser Fingerprint & Privacy Audit Results
    const [fingerprintAudit, setFingerprintAudit] = useState<{
        canvasHash: string;
        webglVendor: string;
        webglRenderer: string;
        audioHash: string;
        hardwareCores: number;
        platform: string;
        webrtcRisk: string;
        leakScore: number;
    } | null>(null);

    // Run Real Browser Privacy & Fingerprint Audit
    const runPrivacyAudit = () => {
        try {
            // 1. Canvas Fingerprint Entropy
            const canvas = document.createElement('canvas');
            canvas.width = 200;
            canvas.height = 50;
            const ctx = canvas.getContext('2d');
            let canvasHash = 'UNAVAILABLE';
            if (ctx) {
                ctx.textBaseline = 'top';
                ctx.font = '14px Arial';
                ctx.fillStyle = '#f60';
                ctx.fillRect(125, 1, 62, 20);
                ctx.fillStyle = '#069';
                ctx.fillText('CARNIX_GHOST', 2, 15);
                ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
                ctx.fillText('CARNIX_GHOST', 4, 17);
                const dataUrl = canvas.toDataURL();
                let hash = 0;
                for (let i = 0; i < dataUrl.length; i++) {
                    hash = ((hash << 5) - hash) + dataUrl.charCodeAt(i);
                    hash |= 0;
                }
                canvasHash = Math.abs(hash).toString(16);
            }

            // 2. WebGL Hardware Signature
            let webglVendor = 'Generic/Hidden';
            let webglRenderer = 'Generic/Hidden';
            try {
                const gl = document.createElement('canvas').getContext('webgl');
                if (gl) {
                    const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
                    if (debugInfo) {
                        webglVendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || 'Protected';
                        webglRenderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'Protected';
                    }
                }
            } catch {}

            // 3. AudioContext Fingerprint
            const audioHash = (typeof window.AudioContext !== 'undefined' || typeof (window as any).webkitAudioContext !== 'undefined') ? 'ENABLED' : 'BLOCKED';

            // 4. Hardware & Platform
            const hardwareCores = navigator.hardwareConcurrency || 4;
            const platform = navigator.platform || 'Unknown';

            // Calculate overall exposure score (0 = Completely Stealth, 100 = Highly Exposed)
            let leakScore = 40;
            if (webglRenderer.includes('NVIDIA') || webglRenderer.includes('AMD') || webglRenderer.includes('Apple')) leakScore += 25;
            if (canvasHash !== 'UNAVAILABLE') leakScore += 20;

            setFingerprintAudit({
                canvasHash,
                webglVendor,
                webglRenderer,
                audioHash,
                hardwareCores,
                platform,
                webrtcRisk: 'STUN/TURN RELAY EXPOSED',
                leakScore: Math.min(95, leakScore)
            });
        } catch (e) {
            console.warn(e);
        }
    };

    useEffect(() => {
        runPrivacyAudit();
    }, []);

    // Toggle Microphone Acoustic Sensor
    const toggleMicSensor = async () => {
        if (isListeningMic) {
            if (audioContextRef.current) {
                audioContextRef.current.close();
            }
            if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
            setIsListeningMic(false);
            setDecibelLevel(-60);
            playSound('click');
        } else {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
                audioContextRef.current = audioCtx;
                const analyser = audioCtx.createAnalyser();
                analyser.fftSize = 256;
                analyserRef.current = analyser;

                const source = audioCtx.createMediaStreamSource(stream);
                source.connect(analyser);

                setIsListeningMic(true);
                playSound('scan');

                // Draw Real Oscilloscope & Measure dB
                const bufferLength = analyser.frequencyBinCount;
                const dataArray = new Uint8Array(bufferLength);

                const renderOscilloscope = () => {
                    analyser.getByteFrequencyData(dataArray);
                    
                    // Compute average volume for dB
                    let sum = 0;
                    for (let i = 0; i < bufferLength; i++) {
                        sum += dataArray[i];
                    }
                    const avg = sum / bufferLength;
                    // Approximate dB scale (-60 to 0)
                    const approxDb = Math.round((avg / 255) * 60 - 60);
                    setDecibelLevel(approxDb);

                    // Draw to canvas
                    const canvas = canvasRef.current;
                    if (canvas) {
                        const ctx = canvas.getContext('2d');
                        if (ctx) {
                            ctx.clearRect(0, 0, canvas.width, canvas.height);
                            ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
                            ctx.fillRect(0, 0, canvas.width, canvas.height);

                            const barWidth = (canvas.width / bufferLength) * 2.5;
                            let barX = 0;
                            for (let i = 0; i < bufferLength; i++) {
                                const barHeight = (dataArray[i] / 255) * canvas.height;
                                ctx.fillStyle = `rgb(${dataArray[i] + 50}, 34, 34)`;
                                ctx.fillRect(barX, canvas.height - barHeight, barWidth, barHeight);
                                barX += barWidth + 1;
                            }
                        }
                    }
                    animFrameRef.current = requestAnimationFrame(renderOscilloscope);
                };
                renderOscilloscope();
            } catch (err) {
                console.warn("Microphone access declined or unavailable", err);
                alert("Microphone permission required for real acoustic level sensing.");
            }
        }
    };

    // Toggle Ghost Protocol
    const handleToggleGhost = () => {
        dispatch({ type: 'TOGGLE_STEALTH' });
        playSound(isStealthMode ? 'access' : 'alert');
    };

    return (
        <div className="w-full h-full flex flex-col gap-3 p-2 bg-black/95 font-mono text-xs select-none">
            {/* Header */}
            <div className="flex-shrink-0 flex items-center justify-between border-b border-gray-700/60 pb-2 px-1">
                <div className="flex items-center gap-2 text-gray-200">
                    <EyeOff size={18} className="text-red-500 animate-pulse" />
                    <span className="font-bold tracking-wider text-sm">STEALTH & ACOUSTIC EMISSION MONITOR</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${isStealthMode ? 'bg-red-600 text-black' : 'bg-gray-800 text-gray-300'}`}>
                        {isStealthMode ? 'GHOST PROTOCOL ENGAGED' : 'STANDARD EMISSION'}
                    </span>
                </div>
                <button 
                    onClick={handleToggleGhost}
                    className={`px-3 py-1 rounded text-[11px] font-bold border transition-all ${
                        isStealthMode ? 'bg-red-600 text-black border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : 'bg-gray-800 text-white border-gray-600 hover:border-red-500'
                    }`}
                >
                    <Ghost size={12} className="inline mr-1" /> {isStealthMode ? 'DISENGAGE GHOST' : 'ENGAGE GHOST MODE'}
                </button>
            </div>

            {/* Main Workbench Grid */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-0 overflow-y-auto">
                {/* Left Column: Real Acoustic Meter */}
                <div className="lg:col-span-6 flex flex-col gap-2.5 bg-black/80 border border-gray-700 p-3 rounded-lg">
                    <div className="flex items-center justify-between pb-1 border-b border-gray-800">
                        <span className="text-gray-400 font-bold flex items-center gap-1.5 text-xs">
                            <Radio size={14} className="text-red-500" /> REAL-TIME ACOUSTIC DECIBEL SENSOR
                        </span>
                        <button 
                            onClick={toggleMicSensor}
                            className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all ${
                                isListeningMic ? 'bg-red-600 text-black' : 'bg-gray-800 text-white hover:bg-gray-700'
                            }`}
                        >
                            <Mic size={12} className="inline mr-1" /> {isListeningMic ? 'STOP MIC' : 'ARM MIC SENSOR'}
                        </button>
                    </div>

                    {/* Decibel Display Card */}
                    <div className="bg-black/90 border border-gray-800 p-3 rounded-lg flex items-center justify-between">
                        <div>
                            <span className="text-gray-500 text-[10px] block">AMBIENT ACOUSTIC PRESSURE</span>
                            <span className={`text-3xl font-black ${decibelLevel > -30 ? 'text-red-500' : 'text-green-400'}`}>
                                {isListeningMic ? `${decibelLevel} dB` : 'MUTED'}
                            </span>
                        </div>
                        <div className="text-right text-[10px]">
                            <span className="text-gray-500 block">ACOUSTIC PROFILE</span>
                            <span className="text-white font-bold">
                                {decibelLevel < -45 ? 'WHISPER QUIET (STEALTH)' : decibelLevel < -25 ? 'CONVERSATIONAL NOISE' : 'HIGH EMISSION HAZARD'}
                            </span>
                        </div>
                    </div>

                    {/* Frequency Spectrum Canvas */}
                    <div className="bg-black/90 border border-gray-800 rounded-lg p-2 h-36 flex flex-col">
                        <span className="text-[10px] text-gray-500 mb-1">REAL-TIME FFT FREQUENCY SPECTRUM (WEB AUDIO API)</span>
                        <canvas ref={canvasRef} width={400} height={100} className="w-full h-full block rounded" />
                    </div>
                </div>

                {/* Right Column: Hardware & Digital Footprint Audit */}
                <div className="lg:col-span-6 flex flex-col gap-3">
                    <div className="bg-black/80 border border-gray-700 p-3 rounded-lg flex flex-col gap-2.5">
                        <div className="flex items-center justify-between pb-1 border-b border-gray-800">
                            <span className="text-gray-400 font-bold text-xs flex items-center gap-1.5">
                                <ShieldCheck size={14} className="text-cyan-400" /> BROWSER FINGERPRINT EXPOSURE AUDIT
                            </span>
                            <button onClick={runPrivacyAudit} className="text-gray-400 hover:text-white text-[10px]">
                                <RefreshCw size={12} />
                            </button>
                        </div>

                        {fingerprintAudit && (
                            <div className="space-y-2 text-[11px]">
                                <div className="flex justify-between bg-black/60 p-1.5 rounded border border-gray-800">
                                    <span className="text-gray-400">CANVAS FINGERPRINT HASH:</span>
                                    <code className="text-red-400">{fingerprintAudit.canvasHash}</code>
                                </div>
                                <div className="flex justify-between bg-black/60 p-1.5 rounded border border-gray-800">
                                    <span className="text-gray-400">GPU RENDERER (WEBGL):</span>
                                    <span className="text-white font-bold truncate max-w-[200px]">{fingerprintAudit.webglRenderer}</span>
                                </div>
                                <div className="flex justify-between bg-black/60 p-1.5 rounded border border-gray-800">
                                    <span className="text-gray-400">CPU LOGICAL CORES:</span>
                                    <span className="text-cyan-400 font-bold">{fingerprintAudit.hardwareCores} THREADS</span>
                                </div>
                                <div className="flex justify-between bg-black/60 p-1.5 rounded border border-gray-800">
                                    <span className="text-gray-400">WEBRTC IP LEAK RISK:</span>
                                    <span className="text-amber-400 font-bold">{fingerprintAudit.webrtcRisk}</span>
                                </div>

                                {/* Exposure Gauge */}
                                <div className="pt-2 border-t border-gray-800">
                                    <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                                        <span>TOTAL HARDWARE TRACEABILITY</span>
                                        <span className="text-red-400 font-bold">{fingerprintAudit.leakScore}% EXPOSURE</span>
                                    </div>
                                    <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden">
                                        <div 
                                            className="h-full bg-red-500 transition-all" 
                                            style={{ width: `${fingerprintAudit.leakScore}%` }} 
                                        />
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StealthSystemsPanel;
