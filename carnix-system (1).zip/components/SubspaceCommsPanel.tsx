
import React, { useState, useEffect, useRef } from 'react';
import { Signal, Send, Loader2, ShieldCheck, History, Terminal } from 'lucide-react';
import { useAppContext } from '../context';
import { getAIResponse } from '../services/geminiService';
import { Mode, Message } from '../types';
import { playSound } from '../utils/soundEffects';

const SubspaceCommsPanel: React.FC = () => {
    const { state } = useAppContext();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [message, setMessage] = useState('');
    const [encoded, setEncoded] = useState('');
    const [isTransmitting, setIsTransmitting] = useState(false);
    const [history, setHistory] = useState<string[]>([]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        const stars = Array.from({ length: 200 }, () => ({
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            z: Math.random() * canvas.width,
        }));

        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        const draw = () => {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            const centerX = canvas.width / 2;
            const centerY = canvas.height / 2;

            stars.forEach(star => {
                star.z -= 2;
                if (star.z <= 0) {
                    star.x = Math.random() * canvas.width;
                    star.y = Math.random() * canvas.height;
                    star.z = canvas.width;
                }

                const k = 128 / star.z;
                const px = (star.x - centerX) * k + centerX;
                const py = (star.y - centerY) * k + centerY;
                const size = (1 - star.z / canvas.width) * 2;
                
                ctx.fillStyle = `rgba(255, 0, 60, ${0.3 + (size / 2)})`;
                ctx.beginPath();
                ctx.arc(px, py, size, 0, Math.PI * 2);
                ctx.fill();
            });

            animationFrameId = requestAnimationFrame(draw);
        };
        draw();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, []);

    const handleTransmit = async () => {
        if (!message.trim() || !state.activeProfile) return;
        setIsTransmitting(true);
        setEncoded('');
        playSound('process');
        
        try {
            const prompt = `Encode the following subspace message: "${message}". Format it as a military data packet with a header (Origin: CARNIX-OS), body (scrambled cipher), and hash key. Be concise.`;
            const res = await getAIResponse(prompt, Mode.SubspaceComms, state.activeProfile.aiSettings);
            
            setEncoded(res.text);
            setHistory(prev => [res.text, ...prev].slice(0, 5));
            setMessage('');
            playSound('success');
        } catch (e) {
            setEncoded('CRITICAL: SUBSPACE RELAY OFFLINE. ENCRYPTION ENGINE FAILED.');
            playSound('error');
        } finally {
            setIsTransmitting(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col gap-2 p-1 font-[Rajdhani]">
            <div className="flex-shrink-0 hud-panel p-2 flex justify-between items-center bg-black/40">
                <h2 className="hud-panel-header text-sm">
                    <Signal size={16} className="text-[var(--color-primary)]"/> SECURE SUBSPACE COMMS
                </h2>
                <div className="flex items-center gap-2 text-[10px] font-mono text-green-500 animate-pulse">
                    <ShieldCheck size={12}/> CHANNEL ENCRYPTED [AES-512-QUANTUM]
                </div>
            </div>

            <div className="flex-1 hud-panel flex flex-col lg:flex-row overflow-hidden relative border-t-0">
                <canvas ref={canvasRef} className="absolute inset-0 w-full h-full bg-[#020001] z-0" />
                
                {/* INPUT ZONE */}
                <div className="relative z-10 w-full lg:w-[400px] flex flex-col p-4 gap-4 bg-black/60 backdrop-blur-md border-r border-white/5">
                    <div className="flex-1 flex flex-col">
                        <label className="text-[10px] font-bold text-gray-500 tracking-widest mb-2 flex items-center gap-2">
                            <Terminal size={12}/> INPUT SECURE BUFFER
                        </label>
                        <textarea
                            value={message}
                            onChange={e => setMessage(e.target.value)}
                            placeholder="Enter plaintext message for FTL encryption..."
                            className="flex-1 w-full bg-black/80 border border-gray-800 p-4 font-mono text-xs text-[var(--color-primary)] outline-none focus:border-[var(--color-primary)] resize-none"
                            disabled={isTransmitting}
                        />
                        <button onClick={handleTransmit} disabled={isTransmitting || !message.trim()} className="w-full hud-button mt-4 flex items-center justify-center gap-2 h-12">
                            {isTransmitting ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
                            {isTransmitting ? 'SEQUENCING DATA...' : 'EXECUTE TRANSMISSION'}
                        </button>
                    </div>
                </div>

                {/* LOGS ZONE */}
                <div className="relative z-10 flex-1 flex flex-col p-4 overflow-hidden bg-black/20">
                     <div className="hud-panel-header !bg-transparent !p-0 !mb-4 !text-[10px] opacity-70">
                        <History size={12}/> RECENT DATA PACKETS
                    </div>
                    
                    <div className="flex-1 overflow-y-auto space-y-4 pr-2 scrollbar-thin">
                        {encoded && (
                            <div className="bg-[var(--color-primary)]/10 border-l-2 border-[var(--color-primary)] p-4 rounded-r animate-enter">
                                <div className="text-[8px] text-[var(--color-primary)] font-black uppercase mb-1">LATEST OUTPUT // DECRYPTED</div>
                                <pre className="whitespace-pre-wrap font-mono text-xs text-gray-200">{encoded}</pre>
                            </div>
                        )}
                        
                        {history.map((h, i) => (
                            <div key={i} className="bg-white/5 border border-white/5 p-3 rounded font-mono text-[10px] text-gray-500 opacity-60">
                                <pre className="whitespace-pre-wrap truncate max-h-16">{h}</pre>
                            </div>
                        ))}
                        
                        {!encoded && history.length === 0 && (
                            <div className="h-full flex flex-col items-center justify-center text-gray-700 font-mono text-[10px] tracking-widest animate-pulse">
                                AWAITING SUBSPACE SIGNAL...
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SubspaceCommsPanel;
