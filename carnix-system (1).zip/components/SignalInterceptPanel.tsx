
import React, { useState, useEffect, useRef } from 'react';
import { Rss, Mic, BarChart3, AlertTriangle, ShieldCheck } from 'lucide-react';

const SignalInterceptPanel: React.FC = () => {
    const [isListening, setIsListening] = useState(false);
    const [isSimulated, setIsSimulated] = useState(false);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const audioCtxRef = useRef<AudioContext | null>(null);
    const analyserRef = useRef<AnalyserNode | null>(null);
    const animationFrameRef = useRef<number>(0);
    const streamRef = useRef<MediaStream | null>(null);

    const startListening = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            streamRef.current = stream;
            const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const analyser = audioCtx.createAnalyser();
            analyser.fftSize = 2048;
            const source = audioCtx.createMediaStreamSource(stream);
            source.connect(analyser);

            audioCtxRef.current = audioCtx;
            analyserRef.current = analyser;
            
            setIsListening(true);
            setIsSimulated(false);
            draw();
        } catch (err) {
            console.warn("Microphone access denied. Switching to simulation mode.");
            setIsListening(true);
            setIsSimulated(true); // Switch to simulation
            draw();
        }
    };

    const stopListening = () => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
        }
        if (audioCtxRef.current) {
            audioCtxRef.current.close();
            audioCtxRef.current = null;
        }
        cancelAnimationFrame(animationFrameRef.current);
        setIsListening(false);
        setIsSimulated(false);
    };

    const draw = () => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        // Ensure canvas matches display size
        if (canvas.width !== canvas.offsetWidth || canvas.height !== canvas.offsetHeight) {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        }

        const bufferLength = 128; // Reduced count for cleaner bars
        const dataArray = new Uint8Array(bufferLength);

        if (!isSimulated && analyserRef.current) {
            analyserRef.current.getByteFrequencyData(dataArray);
        } else if (isSimulated) {
            // Generate fake data
            for(let i=0; i<bufferLength; i++) {
                // Perlin-noise-ish randomness
                const noise = Math.sin(Date.now() * 0.005 + i * 0.1) * 50 + 50;
                dataArray[i] = Math.max(0, noise + (Math.random() * 50));
            }
        }

        ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        const barWidth = (canvas.width / bufferLength) * 1.5;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
            const barHeight = (dataArray[i] / 255) * canvas.height;
            
            const percent = barHeight / canvas.height;
            const hue = percent * 120; // Green to Red (heatmap style) or Cyan based
            
            ctx.fillStyle = `hsl(${180 + (percent * 60)}, 100%, 50%)`; // Cyan to Blue gradient
            ctx.shadowBlur = 10;
            ctx.shadowColor = ctx.fillStyle;
            
            ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
            ctx.shadowBlur = 0;
            
            x += barWidth + 1;
        }

        animationFrameRef.current = requestAnimationFrame(draw);
    };

    useEffect(() => {
        return () => {
            stopListening();
        };
    }, []);

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 bg-black/30 border border-[var(--color-panel-border)] rounded-md p-3 flex items-center justify-between">
                <h2 className="text-sm font-bold text-white flex items-center gap-2"><Rss size={16}/> SIGNAL INTERCEPT</h2>
                <div className="flex items-center gap-2">
                    {isSimulated && isListening && (
                        <span className="text-[10px] text-yellow-500 flex items-center gap-1 bg-yellow-900/20 px-2 py-1 rounded border border-yellow-700">
                            <AlertTriangle size={10} /> SIMULATION MODE
                        </span>
                    )}
                    <button onClick={isListening ? stopListening : startListening} className={`px-4 py-2 text-sm font-bold rounded ${isListening ? 'bg-red-600' : 'bg-green-600'}`}>
                        {isListening ? 'STOP SCAN' : 'START SCAN'}
                    </button>
                </div>
            </div>

            <div className="flex-1 bg-black/30 border border-[var(--color-panel-border)] rounded-md flex flex-col overflow-hidden">
                 <div className="p-2 border-b border-gray-700 text-xs font-bold text-gray-400 flex items-center justify-between">
                    <div className="flex items-center gap-2"><BarChart3 size={14}/> FREQUENCY SPECTRUM</div>
                    <div className="font-mono text-[var(--color-primary)]">{isListening ? (isSimulated ? "SYNTHESIZED SIGNAL" : "LIVE FEED") : "STANDBY"}</div>
                </div>
                <div className="flex-1 relative bg-black">
                    {!isListening && (
                         <div className="absolute inset-0 flex items-center justify-center text-gray-500 flex-col gap-2">
                            <ShieldCheck size={48} className="opacity-20"/>
                            <p>Activate scan to begin signal analysis.</p>
                        </div>
                    )}
                    <canvas ref={canvasRef} className="w-full h-full" />
                </div>
            </div>
        </div>
    );
};

export default SignalInterceptPanel;
