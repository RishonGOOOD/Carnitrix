
import React, { useState, useRef, useEffect } from 'react';
import { Search, Loader2, File, Globe, Cloud, Terminal, ExternalLink, Clock, Trash2, RotateCcw } from 'lucide-react';
import { playSound } from '../utils/soundEffects';
import { getAIResponse } from '../services/geminiService';
import { useAppContext } from '../context';
import { Mode, Message } from '../types';

interface SearchResult {
    type: 'web' | 'knowledge' | 'system';
    title: string;
    description: string;
    url?: string;
}

interface HistoryItem {
    query: string;
    timestamp: number;
}

const QuantumSearchPanel: React.FC = () => {
    const { state } = useAppContext();
    const { activeProfile } = state;
    
    // Load persisted state
    const [query, setQuery] = useState(() => localStorage.getItem('carnix_qs_last_query') || '');
    const [history, setHistory] = useState<HistoryItem[]>(() => {
        try {
            return JSON.parse(localStorage.getItem('carnix_qs_history') || '[]');
        } catch { return []; }
    });
    const [results, setResults] = useState<SearchResult[] | null>(() => {
        try {
            return JSON.parse(localStorage.getItem('carnix_qs_last_results') || 'null');
        } catch { return null; }
    });

    const [isSearching, setIsSearching] = useState(false);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    // Persist state effects
    useEffect(() => { localStorage.setItem('carnix_qs_last_query', query); }, [query]);
    useEffect(() => { localStorage.setItem('carnix_qs_history', JSON.stringify(history)); }, [history]);
    useEffect(() => { 
        if(results) localStorage.setItem('carnix_qs_last_results', JSON.stringify(results)); 
    }, [results]);

    // Particle Animation Background
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        const particles: any[] = [];
        const particleCount = 80;
        
        const resizeCanvas = () => {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
        };
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);

        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.8,
                vy: (Math.random() - 0.5) * 0.8,
                size: Math.random() * 2 + 1,
            });
        }

        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Draw particles
            particles.forEach(p => {
                if(isSearching) {
                    const dx = canvas.width / 2 - p.x;
                    const dy = canvas.height / 2 - p.y;
                    p.vx += dx * 0.005;
                    p.vy += dy * 0.005;
                } else {
                    if (Math.random() > 0.98) {
                        p.vx += (Math.random() - 0.5) * 0.2;
                        p.vy += (Math.random() - 0.5) * 0.2;
                    }
                }
                
                // Friction
                p.vx *= 0.96;
                p.vy *= 0.96;
                p.x += p.vx;
                p.y += p.vy;

                // Bounds
                if (p.x < 0 || p.x > canvas.width) { p.vx *= -1; p.x = Math.max(0, Math.min(canvas.width, p.x)); }
                if (p.y < 0 || p.y > canvas.height) { p.vy *= -1; p.y = Math.max(0, Math.min(canvas.height, p.y)); }

                ctx.fillStyle = `rgba(0, 240, 255, 0.6)`;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });

            // Draw connections
            ctx.strokeStyle = `rgba(0, 240, 255, 0.15)`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            for (let i = 0; i < particleCount; i++) {
                for (let j = i + 1; j < particleCount; j++) {
                    const dx = particles[i].x - particles[j].x;
                    const dy = particles[i].y - particles[j].y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 100) {
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                    }
                }
            }
            ctx.stroke();

            animationFrameId = requestAnimationFrame(animate);
        };
        animate();

        return () => {
            cancelAnimationFrame(animationFrameId);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, [isSearching]);


    const executeSearch = async (searchQuery: string) => {
        if (!searchQuery.trim() || !activeProfile) return;

        setIsSearching(true);
        setResults(null);
        setQuery(searchQuery);
        
        // Update history
        setHistory(prev => {
            const newHistory = [{ query: searchQuery, timestamp: Date.now() }, ...prev.filter(h => h.query !== searchQuery)];
            return newHistory.slice(0, 10); // Keep last 10
        });

        playSound('process');
        
        try {
            // We use the AI to search and format results as JSON
            const prompt = `Search specifically for: "${searchQuery}". Return a JSON array of 5 result objects. Each object must have: "type" (one of: "web", "knowledge", "system"), "title", "description", and optional "url". Use the Google Search tool to find real information.`;
            
            const aiResponse = await getAIResponse(prompt, Mode.QuantumSearch, activeProfile.aiSettings);
            
            // Basic JSON extraction attempt
            const jsonMatch = aiResponse.text.match(/\[[\s\S]*\]/);
            if (jsonMatch) {
                const parsed = JSON.parse(jsonMatch[0]);
                setResults(parsed);
            } else {
                // Fallback if AI refuses JSON structure
                setResults([{ type: 'web', title: 'Search Result', description: aiResponse.text }]);
            }
            playSound('success');
        } catch (error) {
            console.error(error);
            setResults([{ type: 'system', title: 'Error', description: 'Quantum search failed. Retrieval system offline.' }]);
            playSound('error');
        } finally {
            setIsSearching(false);
        }
    };

    const handleSearchSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        executeSearch(query);
    }
    
    const getIcon = (type: SearchResult['type']) => {
        switch (type) {
            case 'system': return <Terminal size={16} className="text-yellow-400" />;
            case 'web': return <Globe size={16} className="text-green-400" />;
            case 'knowledge': return <Cloud size={16} className="text-purple-400" />;
            default: return <File size={16} className="text-blue-400" />;
        }
    }

    const clearHistory = () => {
        setHistory([]);
        playSound('click');
    }

    return (
        <div className="w-full h-full flex flex-col gap-4 p-1">
            <div className="flex-shrink-0 hud-panel p-4 z-10 relative">
                <form onSubmit={handleSearchSubmit} className="flex items-center gap-3">
                    <Search size={24} className={`transition-colors ${isSearching ? 'text-[var(--color-primary)] animate-pulse' : 'text-gray-500'}`} />
                    <input
                        type="text"
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        placeholder="Initialize Quantum Query..."
                        className="flex-1 bg-transparent text-lg md:text-2xl font-bold text-white focus:outline-none placeholder-gray-700 font-mono tracking-wider"
                        disabled={isSearching}
                        autoFocus
                    />
                </form>
            </div>
            
            <div className="flex-1 flex gap-4 overflow-hidden relative">
                <div className="flex-1 hud-panel relative overflow-hidden flex flex-col">
                    <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none opacity-50" />
                    
                    <div className="relative z-10 flex-1 overflow-y-auto p-4">
                        {isSearching && (
                            <div className="flex flex-col items-center justify-center h-full text-center text-gray-200 backdrop-blur-sm gap-4">
                                <div className="relative">
                                    <Loader2 size={64} className="animate-spin text-[var(--color-primary)] opacity-50" />
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <Globe size={32} className="animate-pulse text-white"/>
                                    </div>
                                </div>
                                <p className="font-bold tracking-widest text-[var(--color-primary)]">ENTANGLING DATASTREAMS...</p>
                                <p className="text-xs text-gray-400 font-mono">Searching local nodes, web archives, and neural clouds.</p>
                            </div>
                        )}
                        {results && (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                {results.map((res, i) => (
                                    <div 
                                        key={i} 
                                        className="p-4 bg-black/80 border border-gray-800 hover:border-[var(--color-primary)] rounded-lg flex flex-col gap-2 animate-enter backdrop-blur-md group transition-all duration-300 hover:shadow-[0_0_15px_var(--color-primary)] cursor-pointer" 
                                        style={{animationDelay: `${i*100}ms`}}
                                        onClick={() => res.url && window.open(res.url, '_blank')}
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                {getIcon(res.type)}
                                                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{res.type}</span>
                                            </div>
                                            {res.url && <ExternalLink size={12} className="text-gray-600 group-hover:text-white"/>}
                                        </div>
                                        <p className="font-bold text-white group-hover:text-[var(--color-primary)] line-clamp-2 leading-tight">{res.title}</p>
                                        <p className="text-xs text-gray-400 line-clamp-3 leading-relaxed">{res.description}</p>
                                    </div>
                                ))}
                            </div>
                        )}
                        {!isSearching && !results && (
                            <div className="flex flex-col items-center justify-center h-full text-gray-600">
                                <Search size={48} className="opacity-20 mb-4"/>
                                <p>Enter query to begin quantum retrieval.</p>
                            </div>
                        )}
                    </div>
                </div>

                {/* History Sidebar */}
                <div className="w-1/4 hud-panel flex flex-col overflow-hidden bg-black/40 hidden lg:flex">
                    <div className="hud-panel-header flex justify-between">
                        <span className="flex items-center gap-2"><Clock size={12}/> HISTORY</span>
                        <button onClick={clearHistory} className="hover:text-red-500"><Trash2 size={12}/></button>
                    </div>
                    <div className="flex-1 overflow-y-auto p-2 space-y-2">
                        {history.map((item, i) => (
                            <div key={i} onClick={() => executeSearch(item.query)} className="p-2 border-b border-gray-800 hover:bg-white/5 cursor-pointer group">
                                <p className="text-xs font-bold text-gray-300 group-hover:text-[var(--color-primary)] truncate">{item.query}</p>
                                <p className="text-[9px] text-gray-600">{new Date(item.timestamp).toLocaleTimeString()}</p>
                            </div>
                        ))}
                        {history.length === 0 && <p className="text-[10px] text-gray-600 text-center mt-4">No recent queries.</p>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default QuantumSearchPanel;
