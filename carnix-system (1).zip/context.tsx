import React, { createContext, useContext, Dispatch, useEffect, useReducer } from 'react';
import { Profile, Mode, Message, LogEntry, Intent, AIDaemonState, GlobalPost } from './types';
import { speak } from './utils/textToSpeech';
import { storageSync } from './services/storageSyncService';

export interface AppState {
    activeProfile: Profile | null;
    mode: Mode;
    messages: Message[];
    systemLog: LogEntry[];
    isOnline: boolean;
    performance: { cpu: number; memory: number; gpu: number; latency: number; };
    isRecalibrating: boolean;
    isSettingsOpen: boolean;
    activeAppUrl: string | null;
    isStealthMode: boolean; 
    intentQueue: Intent[];
    daemonState: AIDaemonState;
    geolocation?: { latitude: number; longitude: number; altitude?: number; };
    address?: { city?: string; district?: string; country?: string; };
    isTaskLoading?: boolean;
}

export type Action =
  | { type: 'SET_PROFILE'; payload: Profile }
  | { type: 'LOGOUT' }
  | { type: 'UPDATE_PROFILE'; payload: Partial<Profile> }
  | { type: 'SET_MODE'; payload: Mode }
  | { type: 'ADD_MESSAGE'; payload: Message }
  | { type: 'ADD_LOG'; payload: Omit<LogEntry, 'id' | 'timestamp'> }
  | { type: 'SET_ONLINE_STATUS'; payload: boolean }
  | { type: 'TOGGLE_SETTINGS'; payload: boolean }
  | { type: 'SET_RECALIBRATING'; payload: boolean }
  | { type: 'OPEN_APP'; payload: string }
  | { type: 'TOGGLE_STEALTH' }
  | { type: 'QUEUE_INTENT'; payload: Intent }
  | { type: 'CLEAR_INTENT_QUEUE' }
  | { type: 'SET_DAEMON_STATUS'; payload: Partial<AIDaemonState> }
  | { type: 'SET_LOCATION'; payload: { geo: AppState['geolocation'], addr: AppState['address'] } }
  | { type: 'ADD_NEXUS_POST'; payload: GlobalPost }
  | { type: 'SET_TASK_LOADING'; payload: boolean };

export const initialState: AppState = {
    activeProfile: null,
    mode: Mode.Home,
    messages: [],
    systemLog: [],
    isOnline: navigator.onLine,
    performance: { cpu: 0, memory: 0, gpu: 0, latency: 0 },
    isRecalibrating: false,
    isSettingsOpen: false,
    activeAppUrl: null,
    isStealthMode: false,
    intentQueue: [],
    daemonState: {
        active: true,
        stealthAware: true,
        lastThoughtTs: Date.now(),
        heartbeatInterval: 30000,
        isProcessing: false,
        isExchanging: false
    }
};

const appReducer = (state: AppState, action: Action): AppState => {
    let newState: AppState;
    switch (action.type) {
        case 'SET_PROFILE':
            newState = { ...state, activeProfile: action.payload, mode: action.payload.lastMode || Mode.Home };
            break;
        case 'LOGOUT':
            newState = { ...initialState };
            break;
        case 'UPDATE_PROFILE':
            if (!state.activeProfile) return state;
            newState = { ...state, activeProfile: { ...state.activeProfile, ...action.payload } };
            break;
        case 'SET_MODE':
            if (!state.activeProfile) return { ...state, mode: action.payload };
            newState = { 
                ...state, 
                mode: action.payload, 
                activeProfile: { ...state.activeProfile, lastMode: action.payload } 
            };
            break;
        case 'ADD_MESSAGE':
            if (action.payload.sender === 'carnix') speak(action.payload.text, state.activeProfile, state.isStealthMode);
            newState = { ...state, messages: [...state.messages, action.payload] };
            break;
        case 'ADD_LOG':
            const newLog = { ...action.payload, id: `log-${Date.now()}`, timestamp: Date.now() };
            newState = { ...state, systemLog: [newLog, ...state.systemLog].slice(0, 100) };
            break;
        case 'SET_ONLINE_STATUS':
            newState = { ...state, isOnline: action.payload };
            break;
        case 'TOGGLE_SETTINGS':
            newState = { ...state, isSettingsOpen: action.payload };
            break;
        case 'SET_RECALIBRATING':
            newState = { ...state, isRecalibrating: action.payload };
            break;
        case 'OPEN_APP':
            newState = { ...state, activeAppUrl: action.payload, mode: Mode.Browser };
            break;
        case 'TOGGLE_STEALTH':
            newState = { ...state, isStealthMode: !state.isStealthMode };
            break;
        case 'QUEUE_INTENT':
            newState = { ...state, intentQueue: [...state.intentQueue, action.payload] };
            break;
        case 'CLEAR_INTENT_QUEUE':
            newState = { ...state, intentQueue: [] };
            break;
        case 'SET_DAEMON_STATUS':
            newState = { ...state, daemonState: { ...state.daemonState, ...action.payload } };
            break;
        case 'SET_LOCATION':
            newState = { ...state, geolocation: action.payload.geo, address: action.payload.addr };
            break;
        case 'ADD_NEXUS_POST':
            const savedNexus = localStorage.getItem('carnix_nexus_posts');
            const nexusPosts = savedNexus ? JSON.parse(savedNexus) : [];
            localStorage.setItem('carnix_nexus_posts', JSON.stringify([action.payload, ...nexusPosts]));
            return state; 
        case 'SET_TASK_LOADING':
            newState = { ...state, isTaskLoading: action.payload };
            break;
        default:
            return state;
    }

    if (newState.activeProfile) {
        storageSync.saveProfile(newState.activeProfile);
    }
    return newState;
};

export const AppContext = createContext<{ state: AppState; dispatch: Dispatch<Action> } | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [state, dispatch] = useReducer(appReducer, initialState);

    useEffect(() => {
        const saved = localStorage.getItem('carnix_master_profile');
        if (saved) {
            try {
                const profile = JSON.parse(saved);
                dispatch({ type: 'SET_PROFILE', payload: profile });
            } catch (e) {
                console.error("Master Profile Corruption Detected.");
            }
        }

        const handleOnline = () => {
            dispatch({ type: 'SET_ONLINE_STATUS', payload: true });
            dispatch({ type: 'ADD_LOG', payload: { source: 'SYNC', message: 'Network link restored. Quantum cloud sync active.', level: 'success' } });
            storageSync.performAutoSync();
        };

        const handleOffline = () => {
            dispatch({ type: 'SET_ONLINE_STATUS', payload: false });
            dispatch({ type: 'ADD_LOG', payload: { source: 'SYNC', message: 'Network severed. Local autonomous storage engaged.', level: 'warn' } });
        };

        window.addEventListener('online', handleOnline);
        window.addEventListener('offline', handleOffline);

        return () => {
            window.removeEventListener('online', handleOnline);
            window.removeEventListener('offline', handleOffline);
        };
    }, []);

    useEffect(() => {
        if (state.activeProfile?.uiSettings) {
            const ui = state.activeProfile.uiSettings;
            document.documentElement.style.setProperty('--color-primary', state.isStealthMode ? '#111111' : ui.primaryColor);
            document.documentElement.style.setProperty('--color-accent', state.isStealthMode ? '#222222' : ui.accentColor);
        }
    }, [state.activeProfile?.uiSettings, state.isStealthMode]);

    return (
        <AppContext.Provider value={{ state, dispatch }}>
            {children}
        </AppContext.Provider>
    );
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (!context) throw new Error('useAppContext must be used within AppProvider');
    return context;
};
