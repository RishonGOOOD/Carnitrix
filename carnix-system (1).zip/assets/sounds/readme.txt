
CARNIX OS // SOUND ASSET DIRECTORY

To activate physical sound effects, convert these .txt files to .mp3 files.
The system is configured to prioritize these files over synthesized oscillators.

REQUIRED FILES:
- click.mp3    (UI Taps)
- success.mp3  (Successful Actions)
- error.mp3    (Denial/Fault)
- alert.mp3    (Notifications)
- scan.mp3     (Sensor Activation)
- access.mp3   (System Entrance)
