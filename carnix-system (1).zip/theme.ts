
export interface Theme {
  name: string;
  displayName: string;
  primary: string;
  secondary: string;
  accent: string;
  glow: string;
  text: string;
  textMuted: string;
  border: string;
  panel: {
    background: string;
    border: string;
    headerBorder: string;
  };
}

export const crimsonEclipseTheme: Theme = {
  name: 'crimson_eclipse',
  displayName: 'Crimson Eclipse (Rider)',
  primary: '#FF003C',       // Rider Red
  secondary: '#1A0505',     // Deep Blood
  accent: '#00F0FF',        // Cyber Cyan (Data)
  glow: '#FF003C',
  text: '#FFFFFF',
  textMuted: '#888888',
  border: 'rgba(255, 0, 60, 0.8)',
  panel: {
    background: 'rgba(5, 0, 2, 0.90)', 
    border: 'rgba(255, 0, 60, 0.5)',
    headerBorder: 'rgba(255, 0, 60, 0.3)',
  },
};

export const nanotechBlue: Theme = {
  name: 'nanotech_blue',
  displayName: 'Nanotech Blue',
  primary: '#00F0FF',
  secondary: '#002030',
  accent: '#FF003C',
  glow: '#00F0FF',
  text: '#E0F0FF',
  textMuted: '#507080',
  border: 'rgba(0, 240, 255, 0.6)',
  panel: {
    background: 'rgba(0, 10, 20, 0.90)',
    border: 'rgba(0, 240, 255, 0.4)',
    headerBorder: 'rgba(0, 240, 255, 0.2)',
  },
};

export const shadowProtocol: Theme = {
  name: 'shadow_protocol',
  displayName: 'Shadow Protocol',
  primary: '#FFFFFF',
  secondary: '#101010',
  accent: '#505050',
  glow: '#FFFFFF',
  text: '#D0D0D0',
  textMuted: '#606060',
  border: 'rgba(255, 255, 255, 0.3)',
  panel: {
    background: 'rgba(0, 0, 0, 0.95)',
    border: 'rgba(255, 255, 255, 0.2)',
    headerBorder: 'rgba(255, 255, 255, 0.1)',
  },
};

export const themes: Record<string, Theme> = {
    [crimsonEclipseTheme.name]: crimsonEclipseTheme,
    [nanotechBlue.name]: nanotechBlue,
    [shadowProtocol.name]: shadowProtocol,
    // Fix for legacy/default profile referencing 'carnix_red'
    'carnix_red': crimsonEclipseTheme
};
