
// High-Fidelity Tactical Sci-Fi UI Synthesizer (Web Audio API)

let audioCtx: AudioContext | null = null;
let soundMuted = false;

export const toggleMuteSound = (muted?: boolean) => {
    soundMuted = muted !== undefined ? muted : !soundMuted;
    return soundMuted;
};

export const isSoundMuted = () => soundMuted;

const getContext = () => {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return audioCtx;
};

const createOscillator = (type: OscillatorType, frequency: number, duration: number, startTime: number, vol: number = 0.08) => {
    try {
        const ctx = getContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = type;
        osc.frequency.setValueAtTime(frequency, startTime);
        
        gain.gain.setValueAtTime(vol, startTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(startTime);
        osc.stop(startTime + duration);
    } catch {
        // Audio policy fallback
    }
};

export const playSound = (type: 'click' | 'hover' | 'success' | 'error' | 'switch' | 'typing' | 'alert' | 'process' | 'access' | 'scan') => {
    if (soundMuted) return;
    try {
        const ctx = getContext();
        if (ctx.state === 'suspended') {
            ctx.resume();
        }
        const now = ctx.currentTime;

        switch (type) {
            case 'click':
                createOscillator('sine', 1100, 0.04, now, 0.07);
                break;
            case 'hover':
                createOscillator('sine', 1400, 0.02, now, 0.02);
                break;
            case 'typing':
                createOscillator('triangle', 950, 0.025, now, 0.04);
                break;
            case 'switch':
                createOscillator('sine', 400, 0.06, now, 0.08);
                createOscillator('sine', 850, 0.08, now + 0.03, 0.07);
                break;
            case 'success':
                createOscillator('sine', 587.33, 0.12, now, 0.08);
                createOscillator('sine', 880, 0.15, now + 0.08, 0.08);
                createOscillator('sine', 1174.66, 0.22, now + 0.16, 0.07);
                break;
            case 'error':
                createOscillator('sawtooth', 220, 0.15, now, 0.12);
                createOscillator('sawtooth', 140, 0.2, now + 0.08, 0.12);
                break;
            case 'alert':
                createOscillator('square', 880, 0.1, now, 0.06);
                createOscillator('square', 660, 0.1, now + 0.1, 0.06);
                createOscillator('square', 880, 0.12, now + 0.2, 0.06);
                break;
            case 'scan': {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(300, now);
                osc.frequency.exponentialRampToValueAtTime(1600, now + 0.35);
                gain.gain.setValueAtTime(0.06, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now);
                osc.stop(now + 0.35);
                break;
            }
            case 'access':
                createOscillator('sine', 700, 0.1, now, 0.08);
                createOscillator('sine', 1400, 0.2, now + 0.07, 0.09);
                createOscillator('sine', 2100, 0.3, now + 0.15, 0.06);
                break;
            case 'process':
                createOscillator('triangle', 320, 0.08, now, 0.05);
                createOscillator('triangle', 480, 0.08, now + 0.08, 0.05);
                break;
        }
    } catch {
        // Silent failure
    }
};

export const triggerHaptic = (type: 'light' | 'medium' | 'heavy' | 'error' | 'success') => {
    if (!navigator.vibrate) return;
    
    switch (type) {
        case 'light': navigator.vibrate(5); break;
        case 'medium': navigator.vibrate(15); break;
        case 'heavy': navigator.vibrate(40); break;
        case 'success': navigator.vibrate([10, 30, 10]); break;
        case 'error': navigator.vibrate([50, 50, 50, 50, 100]); break;
    }
};
