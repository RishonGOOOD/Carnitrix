
import { playSound, triggerHaptic } from './soundEffects';

/**
 * CARNIX NATIVE BRIDGE v5.3 (Android Optimized)
 * Protocol: carnix.launch.clipboard
 */

/**
 * Copies text to the system clipboard using the best available method.
 * Mimics native 'Clipboard.setString' behavior.
 */
export const copyToClipboard = async (text: string): Promise<boolean> => {
    try {
        // Use the standard web API as a fallback, but wrap it for bridge consistency
        if (navigator.clipboard && navigator.clipboard.writeText) {
            await navigator.clipboard.writeText(text);
            return true;
        }
        
        // Secondary fallback for restricted contexts
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        const successful = document.execCommand('copy');
        document.body.removeChild(textArea);
        return successful;
    } catch (e) {
        console.error("[BRIDGE] Clipboard access denied.");
        return false;
    }
};

/**
 * Triggers a direct kernel intent to open an Android app by package name.
 * Uses the Automate Broadcast protocol: carnix.launch.clipboard
 */
export const launchAndroidApp = async (packageName: string): Promise<boolean> => {
    if (!packageName) return false;
    
    const pkg = packageName.trim().toLowerCase();
    
    // 1. Sync Package to Clipboard (Critical for Automate Flow Decision)
    await copyToClipboard(pkg);
    console.log(`[KERNEL] Node ${pkg} buffered to substrate.`);

    // 2. Automate Broadcast Intent (Fix A3)
    // Format: automate://send-broadcast?action=carnix.launch.clipboard&extras={"package":"pkg_name"}
    const automateUrl = `automate://send-broadcast?action=carnix.launch.clipboard&extras=${encodeURIComponent(JSON.stringify({ package: pkg }))}`;
    
    // 3. Standard Android Intent (Fallback Fix A2)
    const standardIntent = `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${pkg};end`;
    
    try {
        playSound('access');
        triggerHaptic('heavy');
        
        // Attempt specialized Automate broadcast first
        window.location.href = automateUrl;
        
        // Fail-safe redirect if Carnix remains visible after 800ms
        setTimeout(() => {
            if (document.visibilityState === 'visible') {
                window.location.href = standardIntent;
            }
        }, 800);

        return true;
    } catch (e) {
        console.error("[BRIDGE] UPLINK_DENIED:", e);
        return false;
    }
};

/**
 * Triggers the Automate app picker broadcast request
 */
export const requestAppSelection = () => {
    const pickerUrl = `automate://send-broadcast?action=carnix.request.app.pick`;
    window.location.href = pickerUrl;
    playSound('scan');
};
