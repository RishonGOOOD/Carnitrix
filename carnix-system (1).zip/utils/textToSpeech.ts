
import { Profile } from '../types';
import { playSound } from './soundEffects';

export const speak = async (text: string, profile: Profile | null, isStealthMode: boolean = false): Promise<void> => {
    if (!profile || !profile.aiSettings.textToSpeechEnabled) return;
    
    cancelSpeech();
    const settings = profile.aiSettings;

    if (typeof window.speechSynthesis !== 'undefined') {
        const utterance = new SpeechSynthesisUtterance(text);
        
        // VAMPIRE ROBOT MODULATION
        // Phase 6 Stealth Modulation
        if (isStealthMode) {
            utterance.rate = (settings.speechSpeed || 1.1) + 0.3; // Rapid whisper
            utterance.volume = 0.2; // Stealth volume
            utterance.pitch = 0.5; // Deep tone
        } else {
            utterance.rate = settings.speechSpeed || 1.1; 
            utterance.pitch = settings.personality === 'Dark Sci-Fi' ? 0.7 : 0.95;
            utterance.volume = 1.0;
        }
        
        // Find a high-quality neural voice if available
        const voices = window.speechSynthesis.getVoices();
        const preferred = voices.find(v => v.name.includes('Google') || v.name.includes('Neural')) || voices[0];
        if (preferred) utterance.voice = preferred;

        window.speechSynthesis.speak(utterance);
    }
};

export const cancelSpeech = (): void => {
    if (typeof window.speechSynthesis !== 'undefined') {
        window.speechSynthesis.cancel();
    }
};
