
import { Mode } from '../types';

const modeKeywords: Record<string, Mode> = {
    'home': Mode.Home, 'dashboard': Mode.Home,
    'notes': Mode.Notes, 'intel database': Mode.Notes,
    'chat': Mode.Chat,
    // Fix: Corrected property names to match Mode enum
    'vision': Mode.Vision, 'vision hub': Mode.Vision,
    'code assistant': Mode.CodeAssistant, 'codegen': Mode.CodeAssistant,
    'device control': Mode.Microcontroller, 'control': Mode.Microcontroller,
    // Fix: Corrected property names to match Mode enum
    'browser': Mode.Browser, 'web': Mode.Browser,
    'settings': Mode.Settings, 'config': Mode.Settings, 'personality': Mode.Settings,
    'map': Mode.Location, 'location': Mode.Location,
    'radio': Mode.Radio,
    'news': Mode.News,
    'media': Mode.Media,
    'camera': Mode.Camera,
    'logs': Mode.Logs,
    'calendar': Mode.Calendar,
    // Fix: Corrected property names to match Mode enum
    'workspace': Mode.Workspace,
    'comms': Mode.SecureComms, 'contacts': Mode.SecureComms,
    // Fix: Corrected property names to match Mode enum
    'files': Mode.Files, 'databanks': Mode.Files,
    // Fix: Corrected property names to match Mode enum
    'tasks': Mode.Tasks, 'scheduler': Mode.Tasks,
    'lab': Mode.AudioLab, 'synth': Mode.AudioLab,
    'climate': Mode.Climate,
    
    // Persona Panels
    'access control': Mode.AccessControl, 'security': Mode.AccessControl,
    'memory vault': Mode.MemoryVault, 'vault': Mode.MemoryVault,
    'app matrix': Mode.AppMatrix, 'matrix': Mode.AppMatrix,
    'web intelligence': Mode.WebIntelligence, 'research': Mode.WebIntelligence,
    'diagnostics': Mode.Diagnostics,
    'journal': Mode.Journal, 'log': Mode.Journal, "captain's log": Mode.Journal,
    
    // Functional
    // Fix: Corrected property name to match Mode enum
    'device scan': Mode.Sensors,
    'audio': Mode.AudioVoice, 'voice': Mode.AudioVoice,
    'crypto': Mode.Crypto, 'market': Mode.Crypto,
    'weather': Mode.WeatherRadar,
    'hacking': Mode.EthicalHacking,
};

const activationKeywords = ['activate', 'enable', 'engage', 'start', 'turn on', 'go', 'switch to', 'open', 'show me', 'enter'];

export interface CommandAnalysis {
    action: 'ACTIVATE' | 'NONE';
    targetMode?: Mode;
}

export const analyzeCommand = (text: string): CommandAnalysis => {
    const lowerText = text.toLowerCase();

    for (const [keyword, mode] of Object.entries(modeKeywords)) {
        if (lowerText.includes(keyword)) {
            if (activationKeywords.some(verb => lowerText.includes(verb)) || !activationKeywords.some(v => lowerText.includes(v))) {
                return { action: 'ACTIVATE', targetMode: mode };
            }
        }
    }

    return { action: 'NONE' };
};
