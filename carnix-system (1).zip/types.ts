
export enum Mode {
  Home = 'Core Command',
  Chat = 'Neural Link',
  Vision = 'Vision Hub',
  Geo = 'Global Ops',
  Media = 'Signal Relay',
  Files = 'Data Banks',
  Browser = 'Web Link',
  Sensors = 'Device Bridge',
  Tasks = 'Directives',
  Workspace = 'AI Forge',
  Notes = 'Intel Database',
  Hardware = 'Hardware Bridge',
  Microcontroller = 'Device Controller',
  WebIntelligence = 'Web Intelligence',
  News = 'Global News',
  CodeAssistant = 'Code Assistant',
  Settings = 'System Settings',
  Location = 'Location Services',
  Radio = 'Frequency Tuner',
  Camera = 'Optical Feed',
  Logs = 'System Logs',
  Calendar = 'Temporal Grid',
  SecureComms = 'Secure Comms',
  AudioLab = 'Audio Lab',
  Climate = 'Climate Monitor',
  AccessControl = 'Access Control',
  MemoryVault = 'Memory Vault',
  AppMatrix = 'App Matrix',
  Diagnostics = 'System Diagnostics',
  Journal = 'Captain\'s Log',
  AudioVoice = 'Voice Link',
  Crypto = 'Market Data',
  EconomicForecaster = 'Economic Forecast',
  LinguisticsTranslator = 'Translator',
  ProfileManager = 'Profile Manager',
  ThreatIntel = 'Threat Intel',
  Satellite = 'Satellite Feed',
  QuantumSearch = 'Quantum Search',
  GlobalSearch = 'Omni Search',
  DriverPanel = 'Carnix Gear',
  FaizApp = 'Nexus Node',
  AppLauncher = 'Nexus Link',
  PanelsHub = 'Internal Matrix',
  GlobalNexus = 'Global Nexus',
  AIModelRegistry = 'Model Registry',
  WeatherRadar = 'Weather Radar',
  EthicalHacking = 'Ethical Hacking',
  Terminal = 'Terminal Console',
  PluginForge = 'Plugin Forge',
  DreamInterpreter = 'Dream Interpreter',
  Health = 'Health Monitor',
  SubspaceComms = 'Subspace Comms',
  StellarCartography = 'Stellar Cartography',
  PsionicInterface = 'Psionic Interface',
  ForensicAnalysis = 'Forensic Analysis',
  BallisticsCalculator = 'Ballistics Calculator',
  RoboticsControl = 'Robotics Control',
  SocialEngineeringToolkit = 'Social Engineering Toolkit',
  EmergencyServicesMonitor = 'Emergency Services Monitor',
  GeothermalAnalysis = 'Geothermal Analysis',
  ChemicalAnalysis = 'Chemical Analysis',
  Tactical = 'Tactical Deployment',
  WorldStatus = 'World Status',
  GroupChat = 'Group Chat',
  RecoveryBackup = 'Recovery & Backup',
  SystemCore = 'System Core',
  MathSolver = 'Math Solver',
  ExoplanetDB = 'Exoplanet Database',
  DriveControl = 'Drone Control',
  FlightTracker = 'Flight Tracker',
  Cybernetics = 'Cybernetics Manifest',
  PluginHub = 'Plugin Hub',
  StealthSystems = 'Stealth Systems',
  SignalIntercept = 'Signal Intercept',
  GPTLogic = 'GPT Logic Simulation',
  HFModelHub = 'Hugging Face Hub',
  ObjectRecognition = 'Object Recognition',
  DeepOsintAI = 'Deep OSINT AI',
  FreeAiGithubHub = 'Free AI GitHub Hub',
  InvestigationWorkspace = 'Investigation Workspace',
  SecurityEngine = 'Security Engine',
  EvidenceEngine = 'Evidence Engine',
  ReportEngine = 'Report Engine',
  ToolDiscovery = 'Tool Discovery',
  McpHub = 'MCP Hub',
  CarnixPlatformHub = 'Carnix Platform Hub',
  AiToolsSuite = 'AI Tools Suite',
  JarvisSensors = 'Jarvis Sensors HUD'
}

export type ProfileClass = 'Generalist' | 'Sentinel' | 'Infiltrator' | 'Architect' | 'Overlord' | 'Custom';
export type AIEngine = 'GEMINI_CLOUD' | 'HUGGING_FACE' | 'LOCAL_GGUF';

export type IntentPriority = 'LOW' | 'HIGH' | 'CRITICAL';
export type TaskPriority = 'Critical' | 'High' | 'Medium' | 'Low';

export type Intent = 
  | { type: 'LAUNCH_APP'; package: string; priority: IntentPriority }
  | { type: 'SPEAK'; text: string; priority: IntentPriority }
  | { type: 'SILENT_LOG'; data: any; source: string }
  | { type: 'NOTIFY'; title: string; body: string; priority: IntentPriority }
  | { type: 'START_AI_DEBATE'; topic: string; rounds: number };

export interface SystemState {
    isStealthMode: boolean;
    isOnline: boolean;
    batteryLevel?: number;
    performance?: { cpu: number; memory: number; gpu: number; latency: number; };
}

export interface AIDaemonState {
    active: boolean;
    isProcessing: boolean;
    isExchanging: boolean;
    lastThoughtTs: number;
    heartbeatInterval: number;
    stealthAware: boolean;
}

export interface NanobotSwarm {
  status: string;
  activeCount: number;
  efficiency: number;
  currentTask: string;
}

export interface RadioStation {
    name: string;
    url_resolved: string;
    tags: string;
}

export interface SystemPerformanceMetrics {
    cpuCores: number;
    memory: {
        totalJSHeapSize: number;
        usedJSHeapSize: number;
        jsHeapSizeLimit: number;
    };
    cpuUsage: number[];
    gpuUsage: number;
}

export interface NexusLink {
    id: string;
    name: string;
    packageName: string;
    createdAt: number;
}

export interface AIModelSettings {
    model: string;
    engine: AIEngine;
    hfToken?: string;
    personality: string;
    useSearchGrounding: boolean;
    useThinking: boolean;
    textToSpeechEnabled: boolean;
    speechSpeed: number;
    voiceName: string;
    temperature: number;
    directive?: string;
    useLocalModel: boolean;
    isLocalModelLoaded: boolean;
    localEndpoint: string;
    contextWindow: number;
    gpuLayers: number;
    useMapsGrounding?: boolean;
    tone?: string;
    verbosity?: string;
    useLingo?: boolean;
    activeLocalModelId?: string;
}

export interface ChatSession {
    id: string;
    title: string;
    createdAt: number;
    messages: Message[];
}

export interface Profile {
  id: string;
  name: string;
  speciality: ProfileClass;
  nodeCreatedAt: number;
  aiEvolutionLevel: number;
  aiSettings: AIModelSettings;
  uiSettings: {
    primaryColor: string;
    accentColor: string;
    glowIntensity: number;
    showScanlines: boolean;
    hudPosition: string;
    codeRainDensity: number;
    uiScale: number;
    soundVolume: number;
    hapticEnabled: boolean;
  };
  hudSettings?: {
    visible: boolean;
    position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
    showSystem: boolean;
    showAI: boolean;
    showAlerts: boolean;
    opacity: number;
  };
  chats: ChatSession[];
  chatHistory?: Message[];
  activeChatId?: string;
  nexusLinks: NexusLink[];
  launcherApps: LauncherApp[];
  registeredModels: RegisteredAIModel[];
  notes: Note[];
  contacts: Contact[];
  tasks: Task[];
  journal: JournalEntry[];
  events: CalendarEvent[];
  systemLog: LogEntry[];
  features: SystemFeature[];
  usageMetrics: Record<string, number>;
  lastMode?: Mode;
  activeTheme: string;
  customThemes: Record<string, any>;
  nanobotSwarm: NanobotSwarm;
  automations: AutomationRule[];
  plugins: Plugin[];
  faizAppUrl?: string;
  passcode?: string;
  isSuperUser?: boolean;
  allowedModes?: Mode[];
  bio?: string;
  profilePicture?: string;
  groupChatHistory?: Message[];
}

export interface LauncherApp { id: string; name: string; url: string; icon: string; isNative: boolean; packageName?: string; }
export interface Message { id: number; sender: string; text: string; urls?: { uri: string; title?: string }[]; timestamp?: number; }
export interface Note { id: string; title: string; content: string; tags: string[]; timestamp: number; }
export interface Contact { id: string; name: string; number: string; isSecure: boolean; history: any[]; }
export interface Task { id: string; text: string; completed: boolean; dueDate?: string; priority?: TaskPriority; }
export interface LogEntry { id: string; timestamp: number; source: string; message: string; level: 'info' | 'warn' | 'error' | 'success'; }
export interface SystemFeature { id: string; name: string; description: string; type: string; }
export interface DiagnosticResult { id: string; category: string; status: 'OK' | 'WARNING' | 'CRITICAL'; message: string; }
export interface RegisteredAIModel { id: string; name: string; fileName: string; sizeMB: number; path: string; type: 'GGUF' | 'BIN' | 'CUSTOM'; addedAt: number; isActive: boolean; }
export interface Address { city?: string; district?: string; country?: string; }
export interface AutomationRule { id: string; trigger: { type: 'TIME' | 'SYSTEM_EVENT'; value: string }; action: { type: 'SET_MODE' | 'SHOW_ALERT' | 'SEND_MESSAGE'; value: string }; enabled: boolean; }
export interface Plugin { id: string; name: string; description: string; category: string; enabled: boolean; }
export interface CalendarEvent { id: string; date: string; title: string; description: string; time: string; }
export interface JournalEntry { id: string; date: string; content: string; }
export interface GlobalPost { id: string; author: string; authorId: string; title: string; content: string; type: 'GENERAL' | 'NEWS' | 'HELP' | 'INTEL'; timestamp: number; upvotes: number; tags: string[]; }
export interface CryptoData { id: string; symbol: string; name: string; image: string; current_price: number; price_change_percentage_24h: number; }
export interface FlightData { icao24: string; callsign: string; origin_country: string; longitude: number; latitude: number; baro_altitude: number | null; velocity: number | null; on_ground: boolean; }

// ==================== CARNIX MODULAR PLATFORM TYPES ====================

export type ToolCategory = 'OSINT' | 'DEFENSIVE_SECURITY' | 'THREAT_INTEL' | 'AI_SECURITY' | 'FORENSICS' | 'NETWORK' | 'CODE_AUDIT';
export type ToolSafetyLevel = 'SAFE_PASSIVE' | 'CAUTION_ACTIVE' | 'AUDIT_ONLY';
export type ToolIntegrationType = 'Library' | 'CLI adapter' | 'REST API' | 'MCP server' | 'Service' | 'Research/Reference';
export type ToolStatus = 'ACTIVE' | 'IDLE' | 'CONFIG_REQUIRED' | 'DISABLED';

export interface CarnixTool {
  id: string;
  name: string;
  description: string;
  category: ToolCategory;
  version: string;
  repository: string;
  license: string;
  commercialUseAllowed: boolean;
  capabilities: string[];
  requiredPermissions: string[];
  requiredApiKeys: string[];
  inputSchema: Record<string, any>;
  outputSchema: Record<string, any>;
  timeoutMs: number;
  safetyLevel: ToolSafetyLevel;
  integrationType: ToolIntegrationType;
  enabled: boolean;
  installed: boolean;
  status: ToolStatus;
  lastUpdated?: string;
  securityStatus: 'VERIFIED_CLEAN' | 'SANDBOXED' | 'UNVERIFIED';
}

export interface ToolExecutionResult {
  success: boolean;
  tool: string;
  error?: string;
  retryable?: boolean;
  data?: any;
  executionTimeMs?: number;
  timestamp: number;
}

export interface OsintResult {
  id: string;
  source: string;
  timestamp: number;
  query: string;
  result: any;
  confidence: 'CONFIRMED' | 'LIKELY' | 'POSSIBLE' | 'UNKNOWN';
  sourceUrl?: string;
  evidence?: string;
  processingMethod: string;
  category: string;
}

export interface SecurityFinding {
  id: string;
  title: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFORMATIONAL';
  category: string;
  description: string;
  remediation: string;
  target: string;
  cve?: string;
  cvss?: number;
  mitreTechnique?: string;
  source: string;
  timestamp: number;
  evidence?: string;
}

export interface SecurityAssessment {
  target: string;
  scanType: string;
  timestamp: number;
  score: number; // 0-100
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  findings: SecurityFinding[];
  headersAudit?: Record<string, { present: boolean; value?: string; risk: string }>;
  tlsAudit?: { valid: boolean; cipher?: string; issuer?: string; expiresDays?: number; protocols?: string[] };
  secretsFound?: { type: string; line: number; matchSnippet: string; severity: string }[];
  sastFindings?: { ruleId: string; file: string; line: number; description: string; severity: string }[];
}

export interface ThreatIndicator {
  id: string;
  type: 'IP' | 'DOMAIN' | 'URL' | 'HASH' | 'EMAIL' | 'CVE' | 'CERTIFICATE' | 'ORGANIZATION';
  value: string;
  threatLevel: 'BENIGN' | 'SUSPICIOUS' | 'MALICIOUS' | 'UNKNOWN';
  score: number; // 0-100
  malwareFamilies?: string[];
  threatActors?: string[];
  firstSeen?: string;
  lastSeen?: string;
  asn?: string;
  geoCountry?: string;
  mitreAttack?: string[];
  sources: { provider: string; reportUrl?: string; confidence: number; summary: string }[];
  timestamp: number;
}

export type EvidenceConfidence = 'CONFIRMED' | 'LIKELY' | 'POSSIBLE' | 'UNKNOWN';

export interface EvidenceNode {
  id: string;
  label: string;
  type: 'DOMAIN' | 'IP' | 'CERTIFICATE' | 'ORGANIZATION' | 'EMAIL' | 'USERNAME' | 'HASH' | 'INFRASTRUCTURE' | 'VULNERABILITY';
  confidence: EvidenceConfidence;
  properties: Record<string, any>;
  source: string;
  timestamp: number;
}

export interface EvidenceEdge {
  id: string;
  fromId: string;
  toId: string;
  relationship: string; // e.g., 'RESOLVES_TO', 'REGISTERED_BY', 'ISSUED_CERT', 'HOSTS_SERVICE'
  confidence: EvidenceConfidence;
  evidence: string;
  source: string;
  timestamp: number;
}

export interface EvidenceGraph {
  nodes: EvidenceNode[];
  edges: EvidenceEdge[];
}

export interface InvestigationTimelineEvent {
  id: string;
  timestamp: number;
  dateStr: string;
  title: string;
  description: string;
  type: 'OSINT' | 'SECURITY' | 'INTEL' | 'NOTE' | 'ALERT';
  confidence: EvidenceConfidence;
  source: string;
}

export interface InvestigationCase {
  id: string;
  title: string;
  description: string;
  scope: string;
  targets: string[];
  queries: string[];
  findings: SecurityFinding[];
  evidence: OsintResult[];
  graph: EvidenceGraph;
  timeline: InvestigationTimelineEvent[];
  notes: string;
  reports: string[];
  status: 'OPEN' | 'IN_PROGRESS' | 'ARCHIVED' | 'CLOSED';
  createdAt: number;
  updatedAt: number;
  leadAnalyst: string;
}

export interface CarnixReport {
  id: string;
  investigationId?: string;
  title: string;
  type: 'INVESTIGATION' | 'OSINT' | 'SECURITY_ASSESSMENT' | 'THREAT_INTEL' | 'EXECUTIVE_SUMMARY' | 'TECHNICAL_IOC';
  generatedAt: number;
  author: string;
  summary: string;
  markdownContent: string;
  targets: string[];
  evidenceCount: number;
  findingsCount: number;
  mitreMappings: string[];
  iocs: string[];
}

export interface McpServerConfig {
  id: string;
  name: string;
  description: string;
  endpoint: string;
  transport: 'stdio' | 'sse' | 'websocket' | 'http';
  enabled: boolean;
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  capabilities: string[];
  discoveredTools: { name: string; description: string; inputSchema: Record<string, any> }[];
  lastPing?: number;
}

